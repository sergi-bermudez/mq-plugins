'use strict';

/**
 * VideoQuiz — forms with an optional video (MQ Plugins contract v1). Player.
 *
 * Reads the form from window.MQ_CONFIG (file <page>.config.js next to the page) or receives it through window.vuplex,
 * plays the intro video (if any), then the questions, one per screen, and returns the result in the NeuroExercises format
 * when it ends (FINISHED: the host moves on). Same in Unity (Vuplex) and in MQ Creator. No fetch(): runs under file://.
 *
 * Form:
 * {
 *   "version": 2,
 *   "title": "…", "description": "…",
 *   "path": "./Videos/intro.webm",        // intro video ("" = none)
 *   "allowReplay": false,                 // when the intro video ends: «↻» / «➜» (otherwise straight to the questions)
 *   "showResult": true,                   // score screen at the end (only when there are scored questions)
 *   "shuffle": true,                      // shuffle the options of choice questions
 *   "allowBack": true, "showProgress": true,
 *   "questions": [ {
 *       "type": "single" | "multi" | "text" | "number" | "scale" | "date" | "info",
 *       "question": "…", "help": "…", "required": true,
 *       "image": "data:image/…", "video": "./Videos/q3.webm", "watchFirst": false, "audio": "./Audio/q3.webm",
 *       "options": [ { "text": "…", "score": 1, "image": "data:…", "goto": 5 | "end" } ],   // single, multi
 *       "other": false,                                                                       // single, multi: «Outro» with text
 *       "minSel": 0, "maxSel": 0,                                                             // multi (0 = no limit)
 *       "multiline": false,                                                                   // text
 *       "min": 0, "max": 100, "step": 1, "unit": "", "correct": null, "points": 1,            // number
 *       "scaleMin": 1, "scaleMax": 5, "labelMin": "", "labelMax": "", "style": "numbers" | "stars" | "faces", "scored": false
 *   } ]
 * }
 * Older forms (version 1) have no "type": { "question", "Pontuacao_0": […], …, "Pontuacao_3": […] } = single choice.
 */
class VideoQuizManager {
    constructor() {
        this.activity = 'VideoQuiz';
        this.FACES = ['😣', '🙁', '😐', '🙂', '😄'];
        this.setupState();
        this.initializeUI();
        this.initializeScenarioLoading();
    }

    /* ---------- state ---------- */

    setupState() {
        this.scenario = null;
        this.questions = [];
        this.index = -1;
        this.history = [];             // indices of the questions shown, in order (for ⬅)
        this.answers = {};             // index -> { value, score, maxScore, at, changes }
        this.current = null;           // answer being given on the current screen
        this.log = [];
        this.startTime = null;
        this.shownAt = null;
        this.videoStarted = false;
        this.videoFinished = false;
        this.videoReplays = 0;
        this.finished = false;
        this.sent = false;
        this.options = {};
    }

    /* ---------- interface ---------- */

    $(id) { return document.getElementById(id); }

    initializeUI() {
        this.video = this.$('video');
        this.optionsDiv = this.$('optionsDiv');
        /* toque que se mexe um pouco (comum no Unity): se carregou e largou no mesmo botão, conta como clique, mesmo que o
           navegador o tenha tomado por um arrastar */
        let down = null;
        document.addEventListener('pointerdown', (e) => { const b = e.target.closest('button, [role=button]'); down = b ? { b, x: e.clientX, y: e.clientY, t: performance.now() } : null; }, true);
        let last = null;
        document.addEventListener('click', (e) => { for (const d of [down, last]) if (d && d.b.contains(e.target)) d.clicked = true; }, true);
        document.addEventListener('pointerup', (e) => {
            const d = down; down = null; last = d;
            if (!d || d.b.disabled) return;
            const r = d.b.getBoundingClientRect(), pad = 24;
            const inside = e.clientX >= r.left - pad && e.clientX <= r.right + pad && e.clientY >= r.top - pad && e.clientY <= r.bottom + pad;
            if (!inside || Math.hypot(e.clientX - d.x, e.clientY - d.y) > 60) return;
            setTimeout(() => { if (!d.clicked && d.b.isConnected && !d.b.disabled) d.b.click(); }, 60);
        }, true);
        /* reajusta só quando o tamanho muda mesmo (algumas vistas web mandam «resize» sem parar) */
        addEventListener('resize', () => { const k = innerWidth + 'x' + innerHeight; if (k !== this.lastSize) { this.lastSize = k; this.fitSoon(); } });
        this.$('questionMedia').addEventListener('load', () => this.fitSoon(), true);
        this.$('questionMedia').addEventListener('loadedmetadata', () => this.fitSoon(), true);
        this.nextButton = this.$('questionContinueBtn');
        this.backButton = this.$('backBtn');
        this.resetButton = this.$('reset');

        this.$('videoContinueBtn').addEventListener('click', () => this.finishVideo(true));
        this.$('replayVideoBtn').addEventListener('click', () => this.replayVideo());
        this.$('toQuestionsBtn').addEventListener('click', () => this.finishVideo(false));
        this.nextButton.addEventListener('click', () => this.nextQuestion());
        this.backButton.addEventListener('click', () => this.previousQuestion());
        this.resetButton.addEventListener('click', () => this.clearAnswer());
        this.$('endContinueBtn').addEventListener('click', () => this.finishExercise());
        document.addEventListener('keydown', (event) => {
            if (event.code === 'Space' && this.finished && !this.sent) { event.preventDefault(); this.finishExercise(); }
        });

        this.video.addEventListener('loadeddata', () => this.pushLogEntry({ state: 'VIDEO_LOADED', path: this.scenario ? this.scenario.path : '', videoDuration: this.round(this.video.duration) }));
        this.video.addEventListener('playing', () => {
            if (this.videoStarted) return;
            this.videoStarted = true;
            this.pushLogEntry({ state: 'VIDEO_STARTED' });
        });
        this.video.addEventListener('ended', () => this.videoEnded());
        this.video.addEventListener('error', () => {
            if (this.scenario && this.scenario.path && !this.videoFinished) this.pushLogEntry({ state: 'VIDEO_ERROR', path: this.scenario.path });
        });
        this.showSection('none');
    }

    showSection(name) {
        this.$('videoDiv').style.display = name === 'video' || name === 'videoEnd' ? 'grid' : 'none';
        /* a página nunca fica deslocada (no Unity um deslocamento faz os toques caírem fora dos botões) */
        try { window.scrollTo(0, 0); document.documentElement.scrollTop = 0; document.body.scrollTop = 0; } catch (e) { /* nothing */ }
        this.$('continueDiv').style.display = name === 'video' ? 'flex' : 'none';
        this.$('videoEndDiv').style.display = name === 'videoEnd' ? 'flex' : 'none';
        this.$('questionDiv').style.display = name === 'question' ? 'flex' : 'none';
        this.$('resultDiv').style.display = name === 'result' ? 'flex' : 'none';
    }

    /* ---------- receiving the form ---------- */

    initializeScenarioLoading() {
        if (window.MQ_CONFIG && typeof window.MQ_CONFIG === 'object') this.initializeScenario(window.MQ_CONFIG);
        if (window.vuplex) this.registerMessageReceiver();
        else window.addEventListener('vuplexready', () => this.registerMessageReceiver());
    }

    registerMessageReceiver() {
        window.vuplex.addEventListener('message', (event) => {
            let scenario;
            try { scenario = typeof event.data === 'string' ? JSON.parse(event.data) : event.data; }
            catch (error) { console.error('VideoQuiz: invalid JSON', error); return; }
            if (scenario && Array.isArray(scenario.questions)) this.initializeScenario(scenario);
        });
    }

    initializeScenario(scenario) {
        if (!scenario || !Array.isArray(scenario.questions)) { console.error('VideoQuiz: form without "questions"', scenario); return; }
        /* o mesmo formulário outra vez (o Unity pode mandá-lo de novo, além do .config.js): não recomeça — senão as respostas
           desaparecem a cada mensagem e parece que os botões não respondem */
        let json = '';
        try { json = JSON.stringify(scenario); } catch (e) { /* nothing */ }
        if (json && json === this.scenarioJson) return;
        this.scenarioJson = json;
        this.setupState();
        this.scenario = scenario;
        this.options = {
            allowReplay: scenario.allowReplay === true,
            showResult: scenario.showResult !== false,
            shuffle: scenario.shuffle !== false,
            allowBack: scenario.allowBack !== false && scenario.version >= 2,
            showProgress: scenario.showProgress !== false && scenario.version >= 2
        };
        this.questions = scenario.questions.map((q) => VideoQuizManager.normalizeQuestion(q));
        this.questions.forEach((q) => {
            if (this.options.shuffle && (q.type === 'single' || q.type === 'multi') && !q.options.some((o) => o.goto != null)) this.shuffleArray(q.options);
        });
        this.startTime = performance.now();
        this.$('vidTitle').textContent = scenario.title || '';
        this.$('vidDesc').textContent = scenario.description || '';
        this.$('vidDesc').hidden = !scenario.description;
        this.$('progress').hidden = !this.options.showProgress;
        this.pushLogEntry({ state: 'STARTED', title: scenario.title || '', questions: this.questions.length });

        if (!scenario.path) { this.videoFinished = true; this.startQuestions(); return; }
        this.showSection('video');
        this.video.src = scenario.path;
        const playing = this.video.play();
        if (playing && playing.catch) playing.catch(() => { /* autoplay blocked: the play button stays */ });
    }

    /** Any question (old or new format) as { type, text, help, required, options: [{ text, score, image, goto }], … }. */
    static normalizeQuestion(q) {
        const type = ['single', 'multi', 'text', 'number', 'scale', 'date', 'info'].includes(q.type) ? q.type : 'single';
        const out = Object.assign({}, q, { type, text: String(q.question || ''), help: String(q.help || '') });
        let options = Array.isArray(q.options) ? q.options.map((o) => ({ text: String(o.text || ''), score: Number(o.score) || 0, image: o.image || '', goto: o.goto == null || o.goto === '' ? null : o.goto }))
            .filter((o) => o.text.trim() || o.image) : [];
        if (!Array.isArray(q.options)) {
            Object.keys(q).forEach((key) => {
                const m = /^Pontuacao_(\d+)$/.exec(key);
                if (!m || !Array.isArray(q[key])) return;
                q[key].forEach((text) => { if (text != null && String(text).trim() !== '') options.push({ text: String(text), score: Number(m[1]), image: '', goto: null }); });
            });
        }
        out.options = options;
        /* old forms: a question with options must be answered; one without options can be skipped */
        out.required = q.required != null ? !!q.required : (type === 'single' && options.length > 0);
        if (type === 'scale') {
            out.scaleMin = Number.isFinite(+q.scaleMin) ? +q.scaleMin : 1;
            out.scaleMax = Number.isFinite(+q.scaleMax) && +q.scaleMax > out.scaleMin ? +q.scaleMax : out.scaleMin + 4;
            out.style = ['numbers', 'stars', 'faces'].includes(q.style) ? q.style : 'numbers';
        }
        return out;
    }

    static maxScoreOf(q) {
        if (q.type === 'single') return q.options.reduce((m, o) => Math.max(m, o.score), 0);
        if (q.type === 'multi') {
            const pos = q.options.map((o) => o.score).filter((s) => s > 0).sort((a, b) => b - a);
            return (q.maxSel > 0 ? pos.slice(0, q.maxSel) : pos).reduce((a, b) => a + b, 0);
        }
        if (q.type === 'number') return q.correct != null && q.correct !== '' ? (Number(q.points) || 1) : 0;
        if (q.type === 'scale') return q.scored ? q.scaleMax - q.scaleMin : 0;
        return 0;
    }

    /* ---------- intro video ---------- */

    videoEnded() {
        if (this.videoFinished || !this.scenario) return;
        if (!this.options.allowReplay) { this.finishVideo(false); return; }
        this.pushLogEntry({ state: 'VIDEO_ENDED', replays: this.videoReplays });
        this.showSection('videoEnd');
    }

    replayVideo() {
        if (this.videoFinished) return;
        this.videoReplays++;
        this.pushLogEntry({ state: 'VIDEO_REPLAY', replays: this.videoReplays });
        this.showSection('video');
        /* no Unity (Vuplex) o vídeo vem de um servidor local que muitas vezes não deixa saltar (currentTime = 0 não faz
           nada depois de acabar): volta-se a carregar o vídeo do princípio, o que funciona em todo o lado */
        const v = this.video, src = this.scenario.path || v.currentSrc || v.src;
        const play = () => { const p = v.play(); if (p && p.catch) p.catch(() => { v.muted = true; const p2 = v.play(); if (p2 && p2.catch) p2.catch(() => {}); }); };
        try { v.pause(); } catch (e) { /* nothing */ }
        v.removeAttribute('src'); v.load();
        v.src = src; v.load();
        v.addEventListener('loadeddata', () => { if (v.currentTime > 0.5) { try { v.currentTime = 0; } catch (e) { /* nothing */ } } }, { once: true });
        play();
        /* se mesmo assim ficou no fim (cache do navegador do Unity), pede o ficheiro outra vez com outro endereço */
        const n = this.videoReplays;
        setTimeout(() => {
            if (this.videoFinished || n !== this.videoReplays || !(v.ended || (v.paused && v.duration && v.currentTime >= v.duration - 0.3))) return;
            if (!/^(https?|file):/i.test(String(src)) && !/^[^:]+$/.test(String(src))) return;
            v.src = String(src).replace(/([?&])mqr=\d+/, '$1').replace(/[?&]$/, '') + (String(src).includes('?') ? '&' : '?') + 'mqr=' + n;
            v.load(); play();
        }, 1200);
    }

    finishVideo(skipped) {
        if (this.videoFinished || !this.scenario) return;
        this.videoFinished = true;
        this.pushLogEntry({ state: 'VIDEO_FINISHED', skipped, replays: this.videoReplays, videoTime: this.round(this.video.currentTime || 0) });
        this.video.pause();
        this.startQuestions();
    }

    startQuestions() {
        this.showSection('question');
        if (this.questions.length === 0) { this.finishQuiz(); return; }
        this.history = [];
        this.goTo(0);
    }

    /* ---------- questions ---------- */

    goTo(index) {
        this.index = index;
        this.history.push(index);
        this.showQuestion();
    }

    showQuestion() {
        const q = this.questions[this.index];
        const prev = this.answers[this.index];
        this.current = prev ? { value: this.clone(prev.value), changes: prev.changes, at: prev.at } : { value: null, changes: 0, at: null };
        this.shownAt = performance.now();
        this.$('question').textContent = q.text + (q.required && q.type !== 'info' ? ' *' : '');
        this.$('question').classList.toggle('info', q.type === 'info');
        if (q.audio) this.$('question').append(' ', this.sound(q.audio)); else this.stopSound();
        this.$('questionHelp').textContent = q.help;
        this.$('questionHelp').hidden = !q.help;
        this.buildMedia(q);
        this.optionsDiv.innerHTML = '';
        this.optionsDiv.className = 'answers ' + q.type + (q.options.some((o) => o.image) ? ' pictures' : '');
        if (!(q.video && q.watchFirst && !this.watched(q))) this.buildAnswer(q);
        this.$('vidDesc').hidden = !(this.scenario.description && this.history.length <= 1);
        this.backButton.style.visibility = this.options.allowBack && this.history.length > 1 ? 'visible' : 'hidden';
        this.updateButtons();
        this.updateProgress();
        this.pushLogEntry({ state: 'QUESTION_SHOWN', question: this.index + 1, type: q.type, text: q.text });
    }

    watched(q) { return !!(this.answers[this.index] || (q._watched)); }

    buildMedia(q) {
        const box = this.$('questionMedia');
        box.innerHTML = '';
        if (q.image) {
            const img = document.createElement('img');
            img.src = q.image; img.alt = '';
            box.appendChild(img);
        }
        if (q.video) {
            const v = document.createElement('video');
            v.src = q.video; v.controls = true; v.autoplay = true; v.muted = true; v.playsInline = true;
            v.addEventListener('ended', () => {
                this.pushLogEntry({ state: 'QUESTION_VIDEO_ENDED', question: this.index + 1 });
                if (q.watchFirst && !q._watched) { q._watched = true; this.buildAnswer(q); this.updateButtons(); }
            });
            box.appendChild(v);
            const p = v.play();
            if (p && p.catch) p.catch(() => {});
        }
        box.hidden = !box.children.length;
    }

    buildAnswer(q) {
        const div = this.optionsDiv;
        const cur = this.current;
        const button = (cls, html, onClick) => {
            const b = document.createElement('button');
            b.type = 'button'; b.className = cls;
            b.innerHTML = html;
            b.addEventListener('click', onClick);
            div.appendChild(b);
            return b;
        };
        const optHTML = (o) => (o.image ? `<img src="${o.image}" alt="">` : '') + (o.text ? `<span>${this.esc(o.text)}</span>` : '');
        /* «Outro»: a row (not a button, so the text field inside works) — clicking it or writing in it selects it */
        const otherRow = (cls, mark, select) => {
            const row = document.createElement('div');
            row.className = cls; row.dataset.i = -1; row.setAttribute('role', 'button');
            row.innerHTML = mark + '<span>✎</span>';
            const inp = document.createElement('input');
            inp.type = 'text'; inp.className = 'other'; inp.placeholder = '…';
            inp.value = cur.value && cur.value.other || '';
            inp.addEventListener('input', () => { select(true); cur.value.other = inp.value; this.refreshSelection(q); });
            row.addEventListener('click', (e) => { if (e.target !== inp) { select(false); this.refreshSelection(q); inp.focus(); } });
            row.appendChild(inp);
            div.appendChild(row);
        };

        if (q.type === 'single') {
            q.options.forEach((o, i) => {
                const b = button('options', optHTML(o), () => {
                    if (cur.value && cur.value.i !== i) cur.changes++;
                    cur.value = { i, other: '' };
                    cur.at = performance.now();
                    this.refreshSelection(q);
                });
                b.dataset.i = i;
            });
            if (q.other) {
                otherRow('options otherBtn', '', () => {
                    if (cur.value && cur.value.i === -1) return;
                    if (cur.value) cur.changes++;
                    cur.value = { i: -1, other: div.querySelector('input.other') ? div.querySelector('input.other').value : '' };
                    cur.at = performance.now();
                });
            }
        } else if (q.type === 'multi') {
            if (!cur.value) cur.value = { sel: [], other: '' };
            q.options.forEach((o, i) => {
                const b = button('options check', '<b class="box"></b>' + optHTML(o), () => {
                    const sel = cur.value.sel;
                    const k = sel.indexOf(i);
                    if (k >= 0) sel.splice(k, 1);
                    else {
                        if (q.maxSel > 0 && sel.length >= q.maxSel) return;
                        sel.push(i);
                    }
                    cur.changes++;
                    cur.at = performance.now();
                    this.refreshSelection(q);
                });
                b.dataset.i = i;
            });
            if (q.other) {
                otherRow('options check otherBtn', '<b class="box"></b>', (typing) => {
                    const sel = cur.value.sel, k = sel.indexOf(-1);
                    if (k >= 0) { if (!typing) sel.splice(k, 1); }
                    else sel.push(-1);
                    cur.at = performance.now();
                });
            }
        } else if (q.type === 'text') {
            const t = document.createElement(q.multiline ? 'textarea' : 'input');
            if (!q.multiline) t.type = 'text';
            t.className = 'textAnswer';
            t.value = cur.value || '';
            t.addEventListener('input', () => { cur.value = t.value; cur.at = cur.at || performance.now(); this.updateButtons(); });
            div.appendChild(t);
            setTimeout(() => t.focus(), 50);
        } else if (q.type === 'number') {
            const row = document.createElement('div');
            row.className = 'numberRow';
            const minus = document.createElement('button'), plus = document.createElement('button');
            minus.type = plus.type = 'button'; minus.textContent = '−'; plus.textContent = '+';
            const inp = document.createElement('input');
            inp.type = 'number'; inp.inputMode = 'decimal';
            if (q.min !== '' && q.min != null) inp.min = q.min;
            if (q.max !== '' && q.max != null) inp.max = q.max;
            inp.step = q.step || 'any';
            inp.value = cur.value == null ? '' : cur.value;
            const set = (v) => {
                if (v === '' || v == null || !Number.isFinite(+v)) { cur.value = null; }
                else {
                    let n = +v;
                    if (inp.min !== '') n = Math.max(+inp.min, n);
                    if (inp.max !== '') n = Math.min(+inp.max, n);
                    cur.value = n;
                }
                cur.at = cur.at || performance.now();
                this.updateButtons();
            };
            inp.addEventListener('input', () => set(inp.value));
            inp.addEventListener('change', () => { set(inp.value); inp.value = cur.value == null ? '' : cur.value; });
            const step = (d) => {
                const base = cur.value == null ? (inp.min !== '' ? +inp.min : 0) - (d > 0 ? Number(q.step) || 1 : 0) : cur.value;
                set(this.round(base + d * (Number(q.step) || 1)));
                inp.value = cur.value;
            };
            minus.addEventListener('click', () => step(-1));
            plus.addEventListener('click', () => step(1));
            row.append(minus, inp, plus);
            if (q.unit) { const u = document.createElement('span'); u.className = 'unit'; u.textContent = q.unit; row.appendChild(u); }
            div.appendChild(row);
        } else if (q.type === 'scale') {
            const row = document.createElement('div');
            row.className = 'scaleRow ' + q.style;
            const n = q.scaleMax - q.scaleMin;
            for (let v = q.scaleMin; v <= q.scaleMax; v++) {
                const b = document.createElement('button');
                b.type = 'button'; b.className = 'scaleBtn'; b.dataset.v = v;
                if (q.style === 'stars') b.textContent = '★';
                else if (q.style === 'faces') b.textContent = this.FACES[Math.round((v - q.scaleMin) / (n || 1) * (this.FACES.length - 1))];
                else b.textContent = v;
                b.addEventListener('click', () => {
                    if (cur.value != null && cur.value !== v) cur.changes++;
                    cur.value = v; cur.at = performance.now();
                    this.refreshSelection(q);
                });
                row.appendChild(b);
            }
            div.appendChild(row);
            if (q.labelMin || q.labelMax) {
                const lab = document.createElement('div');
                lab.className = 'scaleLabels';
                lab.innerHTML = `<span>${this.esc(q.labelMin || '')}</span><span>${this.esc(q.labelMax || '')}</span>`;
                div.appendChild(lab);
            }
        } else if (q.type === 'date') {
            const inp = document.createElement('input');
            inp.type = 'date'; inp.className = 'dateAnswer';
            inp.value = cur.value || '';
            inp.addEventListener('input', () => { cur.value = inp.value || null; cur.at = cur.at || performance.now(); this.updateButtons(); });
            div.appendChild(inp);
        }
        this.refreshSelection(q);
        this.fitSoon();
    }

    fitSoon() { cancelAnimationFrame(this.fitRaf); this.fitRaf = requestAnimationFrame(() => this.fitOptions()); }
    /** the answers fit the space that is left: the biggest letters (the same for all) and the number of columns
        with which every answer is seen whole — long answers get smaller letters, short ones big buttons */
    fitOptions() {
        try { this.fitOptionsNow(); } catch (e) { console.warn('MQ Forms: fit', e); }
    }
    fitOptionsNow() {
        const div = this.optionsDiv;
        if (!/\b(single|multi)\b/.test(div.className)) { div.style.removeProperty('--ofs'); div.style.removeProperty('grid-template-columns'); return; }
        const items = [...div.querySelectorAll('.options')];
        if (!items.length) return;
        const qf = parseFloat(getComputedStyle(this.$('question')).fontSize) || 32;   /* as respostas nunca com letra maior do que a pergunta */
        const n = items.length, maxF = Math.max(16, Math.min(44, innerHeight * 0.05, qf)), minF = 13;
        const fits = () => div.scrollHeight <= div.clientHeight + 1 && items.every((b) => b.scrollWidth <= b.clientWidth + 1 && b.scrollHeight <= b.clientHeight + 1);
        const tryCols = (c, f) => { div.style.gridTemplateColumns = `repeat(${c}, minmax(0, 1fr))`; div.style.setProperty('--ofs', f + 'px'); return fits(); };
        let best = { c: Math.min(n, 2), f: minF };
        const maxC = Math.max(1, Math.min(n, Math.floor(div.clientWidth / 150) || 1, 5));
        for (let c = 1; c <= maxC; c++) {
            let lo = minF, hi = maxF;
            if (!tryCols(c, lo)) continue;
            while (hi - lo > 0.5) { const mid = (lo + hi) / 2; if (tryCols(c, mid)) lo = mid; else hi = mid; }
            /* the same letters with more columns: prefer fewer columns only if they give clearly bigger letters */
            if (lo > best.f + 0.5) best = { c, f: lo };
        }
        tryCols(best.c, Math.floor(best.f));
    }

    refreshSelection(q) {
        const cur = this.current;
        if (q.type === 'single') {
            this.optionsDiv.querySelectorAll('.options').forEach((b) => b.classList.toggle('selected', !!cur.value && +b.dataset.i === cur.value.i));
        } else if (q.type === 'multi') {
            const sel = cur.value ? cur.value.sel : [];
            this.optionsDiv.querySelectorAll('.options').forEach((b) => b.classList.toggle('selected', sel.includes(+b.dataset.i)));
        } else if (q.type === 'scale') {
            this.optionsDiv.querySelectorAll('.scaleBtn').forEach((b) => {
                const v = +b.dataset.v;
                b.classList.toggle('selected', q.style === 'stars' ? cur.value != null && v <= cur.value : v === cur.value);
            });
        }
        this.updateButtons();
    }

    answered(q, value) {
        if (q.type === 'info') return true;
        if (value == null) return false;
        if (q.type === 'single') return value.i >= 0 || !!(value.other || '').trim();
        if (q.type === 'multi') {
            const n = value.sel.filter((i) => i >= 0 || (value.other || '').trim()).length;
            return n > 0 && n >= (q.minSel || 1);
        }
        if (q.type === 'text') return String(value).trim() !== '';
        return true;
    }

    updateButtons() {
        const q = this.questions[this.index];
        if (!q) return;
        const waiting = q.video && q.watchFirst && !this.watched(q);
        const ok = this.answered(q, this.current.value);
        const multiLow = q.type === 'multi' && this.current.value && this.current.value.sel.length > 0 && !ok;
        this.nextButton.disabled = waiting || multiLow || (q.required && !ok);
        this.resetButton.style.visibility = q.type !== 'info' && this.current.value != null ? 'visible' : 'hidden';
    }

    updateProgress() {
        if (!this.options.showProgress) return;
        const n = this.questions.length;
        const done = this.index;
        this.$('progressBar').style.width = Math.round(done / n * 100) + '%';
        this.$('progressText').textContent = (this.index + 1) + '/' + n;
    }

    clearAnswer() {
        const q = this.questions[this.index];
        if (this.current.value != null) this.current.changes++;
        this.current.value = null;
        this.optionsDiv.innerHTML = '';
        this.buildAnswer(q);
    }

    /** Score of an answer, and the answer as data for the results. */
    evaluate(q, value) {
        const max = VideoQuizManager.maxScoreOf(q);
        if (value == null || !this.answered(q, value)) return { answer: null, score: 0, maxScore: max };
        if (q.type === 'single') {
            const o = q.options[value.i];
            return { answer: o ? o.text : null, other: value.i === -1 ? value.other : undefined, score: o ? o.score : 0, maxScore: max };
        }
        if (q.type === 'multi') {
            const picked = value.sel.filter((i) => i >= 0).map((i) => q.options[i]);
            return { answer: picked.map((o) => o.text), other: value.sel.includes(-1) ? value.other : undefined, score: picked.reduce((a, o) => a + o.score, 0), maxScore: max };
        }
        if (q.type === 'number') {
            const ok = q.correct != null && q.correct !== '' && Math.abs(value - Number(q.correct)) < 1e-9;
            return { answer: value, score: ok ? (Number(q.points) || 1) : 0, maxScore: max };
        }
        if (q.type === 'scale') return { answer: value, score: q.scored ? value - q.scaleMin : 0, maxScore: max };
        return { answer: value, score: 0, maxScore: max };
    }

    saveCurrent() {
        const q = this.questions[this.index];
        const e = this.evaluate(q, this.current.value);
        this.answers[this.index] = {
            value: this.clone(this.current.value), changes: this.current.changes, at: this.current.at,
            responseTime: this.current.at ? this.round((this.current.at - this.shownAt) / 1000) : null,
            ...e
        };
        if (q.type !== 'info') {
            this.pushLogEntry(Object.assign({ state: 'ANSWER', question: this.index + 1, type: q.type, text: q.text }, e,
                { responseTime: this.answers[this.index].responseTime, changes: this.current.changes }));
        }
    }

    nextQuestion() {
        if (this.finished || this.index < 0 || this.nextButton.disabled) return;
        const q = this.questions[this.index];
        this.saveCurrent();
        let next = this.index + 1;
        if (q.type === 'single' && this.current.value && this.current.value.i >= 0) {
            const g = q.options[this.current.value.i].goto;
            if (g === 'end') next = this.questions.length;
            else if (g != null && Number.isFinite(+g) && +g >= 1) next = Math.min(this.questions.length, +g - 1);
        }
        if (next < this.questions.length) this.goTo(next);
        else this.finishQuiz();
    }

    previousQuestion() {
        if (!this.options.allowBack || this.history.length < 2) return;
        this.history.pop();
        this.index = this.history[this.history.length - 1];
        this.pushLogEntry({ state: 'BACK', question: this.index + 1 });
        this.showQuestion();
    }

    /* ---------- end ---------- */

    totals() {
        /* only the questions on the path taken (a jump may skip some) */
        let score = 0, maxScore = 0;
        const seen = new Set();
        this.history.forEach((i) => {
            if (seen.has(i)) return;
            seen.add(i);
            const a = this.answers[i];
            score += a ? a.score : 0;
            maxScore += VideoQuizManager.maxScoreOf(this.questions[i]);
        });
        return { score, maxScore };
    }

    finishQuiz() {
        if (this.finished) return;
        this.stopSound();
        this.finished = true;
        const t = this.totals();
        this.score = t.score; this.maxScore = t.maxScore;
        if (!this.options.showResult || this.maxScore === 0) { this.finishExercise(); return; }
        this.$('result').textContent = `${this.score}/${this.maxScore}`;
        this.showSection('result');
    }

    finishExercise() {
        if (this.sent) return;
        this.sent = true;
        this.pushLogEntry({ state: 'FINISHED', score: this.score || 0, maxScore: this.maxScore || 0 });
    }

    /* ---------- results ---------- */

    pushLogEntry(entry) {
        entry.positionInTime = this.elapsedSeconds();
        this.log.push(entry);
        if (entry.state === 'FINISHED') this.sendResults();
    }

    sendResults() {
        const seen = new Set();
        const answers = this.history.filter((i) => !seen.has(i) && seen.add(i)).map((i) => {
            const q = this.questions[i], a = this.answers[i] || {};
            return { n: i + 1, id: q.id || undefined, type: q.type, question: q.text, answer: a.answer == null ? null : a.answer, other: a.other,
                score: a.score || 0, maxScore: VideoQuizManager.maxScoreOf(q), responseTime: a.responseTime == null ? null : a.responseTime, changes: a.changes || 0 };
        }).filter((a) => a.type !== 'info');
        const sendData = {
            type: 'NeuroExercises',
            activity: this.activity,
            dataNE: {
                title: this.scenario ? this.scenario.title || '' : '',
                score: this.score || 0,
                maxScore: this.maxScore || 0,
                duration: this.elapsedSeconds(),
                answers,
                log: this.log
            }
        };
        if (window.vuplex) window.vuplex.postMessage(JSON.stringify(sendData));
        else console.log('VUPLEX bridge not available', sendData);
    }

    /** plays the question's audio and gives a 🔊 button to hear it again */
    sound(src) {
        this.stopSound();
        const b = document.createElement('button');
        b.type = 'button'; b.className = 'snd'; b.textContent = '🔊'; b.setAttribute('aria-label', '🔊');
        const play = () => { try { this.stopSound(); this.audio = new Audio(src); const p = this.audio.play(); if (p && p.catch) p.catch(() => {}); } catch (e) { /* nothing */ } };
        b.addEventListener('click', () => { play(); this.pushLogEntry({ state: 'AUDIO_REPLAY', question: this.index + 1 }); });
        setTimeout(play, 200);
        return b;
    }
    stopSound() { if (this.audio) { try { this.audio.pause(); } catch (e) { /* nothing */ } this.audio = null; } }

    /* ---------- utilities ---------- */

    clone(v) { return v == null ? v : JSON.parse(JSON.stringify(v)); }
    esc(s) { return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
    elapsedSeconds() { return this.startTime === null ? 0 : this.round((performance.now() - this.startTime) / 1000); }
    round(value) { return Number.isFinite(value) ? parseFloat(value.toFixed(2)) : 0; }
    shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.videoQuizManager = new VideoQuizManager();
});
