
/* ================= i18n: English text is the key; value = [pt, es, it]. Task names, domain names, profile
   labels and the instructions of the original tasks reuse the original NeuroRehabLab translations. ================= */
const LANGS=[['en','English'],['pt','Português'],['es','Español'],['it','Italiano']];
let LANG=(()=>{const hl=(window.MQ_HOST&&window.MQ_HOST.lang)||window.MQ_LANG;if(hl){let n=String(hl).slice(0,2).toLowerCase();if(n=='ca'||n=='gl'||n=='eu')n='es';return LANGS.some(l=>l[0]==n)?n:'en'}try{const s=localStorage.getItem('tg2_lang');if(LANGS.some(l=>l[0]==s))return s}catch(e){}
  const n=((navigator.languages&&navigator.languages[0])||navigator.language||'en').slice(0,2).toLowerCase();return LANGS.some(l=>l[0]==n)?n:'en'})();
const setLang=(c,save=true)=>{LANG=c;if(save)try{localStorage.setItem('tg2_lang',c)}catch(e){}document.documentElement.lang=c;document.title={en:'Task Generator',pt:'Gerador de Tarefas',es:'Generador de Tareas',it:'Generatore di Compiti'}[c]};
const S={
/* ---- task names & domains (original) ---- */
'Cancellation':['Cancelamento','Cancelar','Barrage'],
'Number sequencing':['Sequências Numéricas','Secuenciación de Números','Sequenziamento di numeri'],
'Problem solving':['Resolução de Problemas','Resolución de Problemas','Risoluzione di problemi'],
'Word search':['Sopa de Letras','Sopa de letras','Ricerca di parole'],
'Labyrinth':['Labirintos','Laberintos','Labirinti'],
'Action sequencing':['Sequências de Ações','Secuenciación de Acciones','Sequenziamento di azioni'],
'Categorization':['Categorização','Categorización','Categorizzazione'],
'Association':['Associação','Asociación','Associazione'],
'Context':['Contextos','Contexto','Contesto'],
'Image pairs':['Pares de Imagens','Pareo de Imágenes','Coppie di immagini'],
'Memory recall':['Memória de histórias e imagens','Memoria y Recuerdo de Imágenes','Memoria e rievocazione'],
'Attention':['Atenção','Atención','Attenzione'],'Memory':['Memória','Memoria','Memoria'],
'Executive functions':['Funções executivas','Funcionamiento ejecutivo','Funzioni esecutive'],
'Language':['Linguagem','Lenguaje','Linguaggio'],'Difficulty':['Dificuldade','Dificultad','Difficoltà'],
'Overall difficulty':['Dificuldade global','Dificultad global','Difficoltà complessiva'],
/* ---- task descriptions ---- */
'Find and mark every target character in a grid.':['Encontre e assinale todos os elementos-alvo numa grelha.','Encuentre y marque todos los elementos objetivo de una cuadrícula.','Trovi e segni tutti gli elementi bersaglio in una griglia.'],
'Complete number sequences that have missing elements.':['Complete sequências de números a que faltam elementos.','Complete secuencias de números a las que les faltan elementos.','Completi sequenze di numeri a cui mancano degli elementi.'],
'Solve calculations or short word problems.':['Resolva cálculos ou pequenos problemas.','Resuelva cálculos o problemas breves.','Risolva calcoli o brevi problemi.'],
'Find hidden words in a grid of letters.':['Encontre palavras escondidas numa grelha de letras.','Encuentre palabras escondidas en una cuadrícula de letras.','Trovi le parole nascoste in una griglia di lettere.'],
'Trace the path from the entrance to the exit.':['Trace o caminho da entrada até à saída.','Dibuje el camino desde la entrada hasta la salida.','Tracci il percorso dall’entrata all’uscita.'],
'Put the steps of an everyday action in the right order.':['Ordene os passos de uma ação do dia a dia.','Ordene los pasos de una acción cotidiana.','Ordini i passaggi di un’azione quotidiana.'],
'Group pictures into the categories they belong to.':['Agrupe imagens nas categorias a que pertencem.','Agrupe imágenes en las categorías a las que pertenecen.','Raggruppi le immagini nelle categorie di appartenenza.'],
'Match pictures that go together.':['Associe as imagens que fazem par.','Empareje las imágenes que van juntas.','Associ le immagini che vanno insieme.'],
'Judge whether statements about a picture are correct.':['Indique se as afirmações sobre uma imagem estão corretas.','Indique si los enunciados sobre una imagen son correctos.','Indichi se le affermazioni su un’immagine sono corrette.'],
'Memorise pairs of pictures, then recall them.':['Memorize pares de imagens e depois recorde-os.','Memorice pares de imágenes y luego recuérdelos.','Memorizzi coppie di immagini e poi le rievochi.'],
'Study a story or picture, then answer questions from memory.':['Estude uma história ou imagem e responda de memória.','Estudie una historia o imagen y responda de memoria.','Studi una storia o un’immagine e risponda a memoria.'],
/* ---- parameters ---- */
'Grid size':['Tamanho da grelha','Tamaño de la cuadrícula','Dimensione della griglia'],'Targets (%)':['Alvos (%)','Objetivos (%)','Bersagli (%)'],
'Content':['Conteúdo','Contenido','Contenuto'],'Organisation':['Organização','Organización','Organizzazione'],
'Sequence length':['Comprimento da sequência','Longitud de la secuencia','Lunghezza della sequenza'],'Missing numbers':['Números em falta','Números faltantes','Numeri mancanti'],
'Step size':['Passo','Paso','Passo'],'Order':['Ordem','Orden','Ordine'],'Missing position':['Posição em falta','Posición faltante','Posizione mancante'],
'Problems':['Problemas','Problemas','Problemi'],'Digits':['Dígitos','Dígitos','Cifre'],'Type':['Tipo','Tipo','Tipo'],'Problem length':['Extensão do problema','Extensión del problema','Lunghezza del problema'],
'Words':['Palavras','Palabras','Parole'],'Word list':['Lista de palavras','Lista de palabras','Elenco delle parole'],'Layers':['Camadas','Capas','Livelli'],
'Steps':['Passos','Pasos','Passaggi'],'Categories':['Categorias','Categorías','Categorie'],'Items per category':['Itens por categoria','Elementos por categoría','Elementi per categoria'],
'Pairs':['Pares','Pares','Coppie'],'Pictures':['Fotografias','Fotografías','Fotografie'],'Statements':['Afirmações','Enunciados','Affermazioni'],'Material':['Material','Material','Materiale'],'Questions':['Perguntas','Preguntas','Domande'],
'Letters':['Letras','Letras','Lettere'],'Numbers':['Números','Números','Numeri'],'Symbols':['Símbolos','Símbolos','Simboli'],
'Ordered':['Ordenado','Ordenado','Ordinato'],'Not ordered':['Desordenado','Desordenado','Non ordinato'],
'Ascending':['Crescente','Ascendente','Crescente'],'Descending':['Decrescente','Descendente','Decrescente'],'Any':['Qualquer','Cualquiera','Qualsiasi'],'Beginning':['Início','Inicio','Inizio'],
'Under 10':['Menos de 10','Menos de 10','Meno di 10'],'Under 100':['Menos de 100','Menos de 100','Meno di 100'],
'Calculations':['Cálculos','Cálculos','Calcoli'],'Word problems':['Problemas com texto','Problemas con texto','Problemi con testo'],
'Show words':['Mostrar palavras','Mostrar palabras','Mostra le parole'],'Hide words':['Esconder palavras','Ocultar palabras','Nascondi le parole'],
'Explicit (titled)':['Explícito (com título)','Explícito (con título)','Esplicito (con titolo)'],'Implicit':['Implícito','Implícito','Implicito'],
'Clipart':['Clipart','Clipart','Clipart'],'Photos':['Fotografias','Fotografías','Fotografie'],
'Short text':['Texto curto','Texto corto','Testo breve'],'Medium text':['Texto médio','Texto medio','Testo medio'],'Long text':['Texto longo','Texto largo','Testo lungo'],'Picture':['Imagem','Imagen','Immagine'],
/* ---- task instructions (adapted from the originals) ---- */
'Tap every':['Toque em todos os elementos','Toque todos los elementos','Tocchi tutti gli elementi'],
'you can find.':['que encontrar.','que encuentre.','che trova.'],
'{0} found, {1} missed, {2} wrongly marked.':['{0} encontrados, {1} em falta, {2} marcados por engano.','{0} encontrados, {1} omitidos, {2} marcados por error.','{0} trovati, {1} mancanti, {2} segnati per errore.'],
'Fill in the missing numbers of each sequence.':['Preencha os números em falta nas seguintes sequências.','Complete los números faltantes en las siguientes secuencias.','Riempia i numeri mancanti nelle seguenti sequenze.'],
'Solve the following problems.':['Por favor, resolva os seguintes problemas.','Resuelva los siguientes problemas.','Risolva i seguenti problemi.'],
'Solve the following calculations.':['Por favor, resolva os seguintes cálculos.','Resuelva los siguientes problemas de cálculo.','Risolva i seguenti problemi aritmetici.'],
'Find {0} words (any direction). Tap the first and the last letter of each word.':['Procure {0} palavras nesta sopa de letras (em qualquer direção). Toque na primeira e na última letra de cada palavra.','Encuentre las {0} palabras en el recuadro (en cualquier dirección). Toque la primera y la última letra de cada palabra.','Trovi le {0} parole nel riquadro (in qualsiasi direzione). Tocchi la prima e l’ultima lettera di ogni parola.'],
'Missed words are in amber: {0}':['As palavras em falta estão a âmbar: {0}','Las palabras omitidas están en ámbar: {0}','Le parole mancanti sono in ambra: {0}'],
'Trace a path from ▶ to ⚑ by tapping neighbouring cells. Tap a cell on your path to step back to it.':['Desenhe o caminho desde a entrada ▶ até à saída ⚑ tocando nas células vizinhas. Toque numa célula do seu caminho para recuar até ela.','Dibuje el camino desde la entrada ▶ hasta la salida ⚑ tocando las celdas vecinas. Toque una celda de su camino para volver a ella.','Disegni il percorso dall’entrata ▶ all’uscita ⚑ toccando le caselle vicine. Tocchi una casella del percorso per tornare indietro.'],
'Exit reached in {0} cells.':['Saída alcançada em {0} células.','Salida alcanzada en {0} celdas.','Uscita raggiunta in {0} caselle.'],
'Exit not reached. The route you did not trace is in amber.':['A saída não foi alcançada. O caminho que não traçou está a âmbar.','No llegó a la salida. El camino que no trazó está en ámbar.','Uscita non raggiunta. Il percorso non tracciato è in ambra.'],
'Action:':['Ação:','Acción:','Azione:'],
'Number the steps in the order they happen.':['Indique a ordem pela qual os passos que se seguem devem ser executados.','Indique el orden en que los siguientes pasos deben ser realizados.','Indichi l’ordine nel quale i seguenti passaggi devono essere eseguiti.'],
'Group {0}':['Grupo {0}','Grupo {0}','Gruppo {0}'],
'Sort the pictures into {0} groups of things that belong together. Use the same group number for pictures of the same kind.':['Agrupe as imagens abaixo em {0} categorias de pertença. Use o mesmo número de grupo para imagens do mesmo tipo.','Agrupe las siguientes imágenes en {0} categorías. Use el mismo número de grupo para las imágenes del mismo tipo.','Raggruppi le seguenti immagini in {0} categorie. Usi lo stesso numero di gruppo per le immagini dello stesso tipo.'],
'Groups are graded by what each group mostly contains, so the numbering does not matter.':['Os grupos são avaliados pelo que contêm na maioria, por isso a numeração não importa.','Los grupos se evalúan según lo que contienen en su mayoría, así que la numeración no importa.','I gruppi sono valutati in base al contenuto prevalente, quindi la numerazione non conta.'],
'Match each picture on the left with the one on the right that goes with it. Tap one on the left, then one on the right. Tap a linked picture on the left to undo.':['Indique quais as imagens da esquerda que fazem par com as da direita. Toque numa imagem à esquerda e depois noutra à direita. Toque numa imagem já ligada para desfazer.','Encuentre los pares de asociación correctos entre columnas. Toque una imagen a la izquierda y luego una a la derecha. Toque una imagen ya unida para deshacer.','Associ correttamente le coppie. Tocchi un’immagine a sinistra e poi una a destra. Tocchi un’immagine già collegata per annullare.'],
'Amber marks the picture that should have been matched.':['A âmbar está a imagem que deveria ter sido associada.','En ámbar está la imagen que debía emparejarse.','In ambra l’immagine che andava associata.'],
'Which picture was paired with each of these?':['Qual era a imagem associada a cada uma destas?','¿Qué imagen estaba emparejada con cada una de estas?','Quale immagine era abbinata a ciascuna di queste?'],
'Memorise these pairs. When you are ready (you may wait, for example 30 minutes), hide them and start the recall.':['Memorize os pares de imagens seguintes e, passado algum tempo (por exemplo, 30 minutos), tente recordá-los.','Memorice los siguientes pares de imágenes y, pasado un tiempo (por ejemplo, 30 minutos), trate de recordarlos.','Memorizzi le seguenti coppie di immagini e poi, dopo un po’ (ad esempio 30 minuti), le rievochi.'],
'Hide the pairs and start recall':['Esconder os pares e começar a recordar','Ocultar los pares y comenzar el recuerdo','Nascondi le coppie e inizia la rievocazione'],
'Amber marks the correct partner.':['A âmbar está o par correto.','En ámbar está la pareja correcta.','In ambra il partner corretto.'],
'You finished before starting the recall phase.':['Terminou antes de iniciar a fase de recordação.','Terminó antes de comenzar la fase de recuerdo.','Ha terminato prima di iniziare la fase di rievocazione.'],
'Look at the picture and decide whether each statement is correct or incorrect.':['Indique quais as descrições mais corretas para a imagem: diga se cada afirmação está correta ou incorreta.','Indique si los enunciados sobre la imagen son correctos o incorrectos.','Indichi se le seguenti affermazioni riguardo l’immagine sono vere o false.'],
'Correct':['Correto','Correcto','Corretto'],'Incorrect':['Incorreto','Incorrecto','Errato'],
'→ this statement is correct':['→ esta afirmação está correta','→ este enunciado es correcto','→ questa affermazione è corretta'],
'→ this statement is incorrect':['→ esta afirmação está incorreta','→ este enunciado es incorrecto','→ questa affermazione è errata'],
'(answer: {0})':['(resposta: {0})','(respuesta: {0})','(risposta: {0})'],
'Compare your answers with the original and mark each one yourself.':['Compare as suas respostas com o original e marque cada uma.','Compare sus respuestas con el original y marque cada una.','Confronti le sue risposte con l’originale e segni ciascuna.'],
'(no answer)':['(sem resposta)','(sin respuesta)','(nessuna risposta)'],
'Answer from memory.':['Responda de memória.','Responda de memoria.','Risponda a memoria.'],
'Show it again so I can mark my answers':['Mostrar de novo para marcar as minhas respostas','Mostrar de nuevo para marcar mis respuestas','Mostra di nuovo per segnare le mie risposte'],
'Observe the picture for about 2 minutes, then continue.':['Observe com atenção a imagem durante cerca de 2 minutos e continue.','Observe la imagen por alrededor de 2 minutos y luego continúe.','Osservi l’immagine per circa due minuti e poi continui.'],
'Read the story carefully, then continue.':['Leia com atenção a história e continue.','Lea con atención la historia y luego continúe.','Legga con attenzione la storia e poi continui.'],
'Hide it and show the questions':['Esconder e mostrar as perguntas','Ocultar y mostrar las preguntas','Nascondi e mostra le domande'],
'You finished before marking your answers, so none could be scored.':['Terminou antes de marcar as respostas, por isso nenhuma foi pontuada.','Terminó antes de marcar sus respuestas, por lo que ninguna se puntuó.','Ha terminato prima di segnare le risposte, quindi nessuna è stata valutata.'],
'Scored from your own marking, since open answers cannot be checked automatically.':['Pontuado pela sua própria marcação, pois as respostas abertas não se verificam automaticamente.','Puntuado según su propia marcación, ya que las respuestas abiertas no se pueden comprobar automáticamente.','Valutato in base alla sua marcatura, perché le risposte aperte non si controllano automaticamente.'],

'Recall in {0} min. You can do other things meanwhile.':['Recordação daqui a {0} min. Pode fazer outras coisas entretanto.','Recuerdo en {0} min. Mientras tanto puede hacer otras cosas.','Rievocazione tra {0} min. Nel frattempo può fare altro.'],
'The recall starts right after.':['A recordação começa logo a seguir.','El recuerdo comienza justo después.','La rievocazione inizia subito dopo.'],
'Group':['Grupo','Grupo','Gruppo'],
'Memorise these pairs.':['Memorize os pares de imagens seguintes.','Memorice los siguientes pares de imágenes.','Memorizzi le seguenti coppie di immagini.'],
'I have memorised them':['Já memorizei','Ya los memoricé','Li ho memorizzati'],
'Which picture was paired with this one?':['Qual era a imagem associada a esta?','¿Qué imagen estaba emparejada con esta?','Quale immagine era abbinata a questa?'],
'Your answers':['As suas respostas','Sus respuestas','Le sue risposte'],
'Red = your answer; green = the correct partner.':['Vermelho = a sua resposta; verde = o par correto.','Rojo = su respuesta; verde = la pareja correcta.','Rosso = la sua risposta; verde = il partner corretto.'],
'Hide it and continue':['Esconder e continuar','Ocultar y continuar','Nascondi e continua'],
'Answer from memory (say it aloud or type it).':['Responda de memória (diga em voz alta ou escreva).','Responda de memoria (dígalo en voz alta o escríbalo).','Risponda a memoria (lo dica ad alta voce o lo scriva).'],
'Optional: type your answer':['Opcional: escreva a resposta','Opcional: escriba su respuesta','Facoltativo: scriva la risposta'],
'Sort the pictures into {0} groups of things that belong together. Tap a picture to choose its group; use the same group for pictures of the same kind.':['Agrupe as imagens em {0} categorias de pertença. Toque numa imagem para escolher o grupo; use o mesmo grupo para imagens do mesmo tipo.','Agrupe las imágenes en {0} categorías. Toque una imagen para elegir su grupo; use el mismo grupo para imágenes del mismo tipo.','Raggruppi le immagini in {0} categorie. Tocchi un’immagine per scegliere il gruppo; usi lo stesso gruppo per immagini dello stesso tipo.'],
'Find {0} words (any direction). Tap the first and the last letter of each word; the mark stays until you finish.':['Procure {0} palavras nesta sopa de letras (em qualquer direção). Toque na primeira e na última letra de cada palavra; a marca fica até terminar.','Encuentre las {0} palabras en el recuadro (en cualquier dirección). Toque la primera y la última letra de cada palabra; la marca queda hasta terminar.','Trovi le {0} parole nel riquadro (in qualsiasi direzione). Tocchi la prima e l’ultima lettera di ogni parola; il segno resta fino alla fine.'],
'{0} marked':['{0} marcadas','{0} marcadas','{0} segnate'],
'Undo last mark':['Desfazer última marca','Deshacer última marca','Annulla ultimo segno'],
'Missed words are in orange: {0}':['As palavras em falta estão a laranja: {0}','Las palabras omitidas están en naranja: {0}','Le parole mancanti sono in arancione: {0}'],
'Exit not reached. The route you did not trace is in orange.':['A saída não foi alcançada. O caminho que não traçou está a laranja.','No llegó a la salida. El camino que no trazó está en naranja.','Uscita non raggiunta. Il percorso non tracciato è in arancione.'],
'Orange marks the picture that should have been matched.':['A laranja está a imagem que deveria ter sido associada.','En naranja está la imagen que debía emparejarse.','In arancione l’immagine che andava associata.'],
'Recall delay (min)':['Atraso da recordação (min)','Demora del recuerdo (min)','Ritardo della rievocazione (min)'],
'Recall in':['Recordação em','Recuerdo en','Rievocazione tra'],
'You can rest. The recall starts by itself.':['Pode descansar. A recordação começa sozinha.','Puede descansar. El recuerdo comienza solo.','Può riposare. La rievocazione parte da sola.'],
'Start recall now':['Começar a recordação agora','Comenzar el recuerdo ahora','Inizia ora la rievocazione'],
'Skip the recall':['Saltar a recordação','Omitir el recuerdo','Salta la rievocazione'],
'Find {0} words (any direction). Tap the letters to mark them; tap again to unmark.':['Procure {0} palavras nesta sopa de letras (em qualquer direção). Toque nas letras para as marcar; toque de novo para desmarcar.','Encuentre las {0} palabras en el recuadro (en cualquier dirección). Toque las letras para marcarlas; toque de nuevo para desmarcar.','Trovi le {0} parole nel riquadro (in qualsiasi direzione). Tocchi le lettere per segnarle; tocchi di nuovo per deselezionarle.'],
'Trace a path from ▶ to ⚑ by dragging your finger (or tapping neighbouring cells). Go back over your path to undo.':['Desenhe o caminho desde a entrada ▶ até à saída ⚑ arrastando o dedo (ou tocando nas células vizinhas). Volte sobre o caminho para desfazer.','Dibuje el camino desde la entrada ▶ hasta la salida ⚑ arrastrando el dedo (o tocando las celdas vecinas). Vuelva sobre el camino para deshacer.','Disegni il percorso dall’entrata ▶ all’uscita ⚑ trascinando il dito (o toccando le caselle vicine). Torni indietro sul percorso per annullare.'],
/* ---- app ---- */
'No attempts yet.':['Ainda sem tentativas.','Aún no hay intentos.','Ancora nessun tentativo.'],'Performance chart':['Gráfico de desempenho','Gráfico de rendimiento','Grafico delle prestazioni'],
'Profile':['Perfil','Perfil','Profilo'],'Hello, {0}':['Olá, {0}','Hola, {0}','Ciao, {0}'],'Welcome':['Bem-vindo','Bienvenido','Benvenuto'],
'What would you like to do today?':['O que gostaria de fazer hoje?','¿Qué le gustaría hacer hoy?','Che cosa vorrebbe fare oggi?'],
'My profile':['O meu perfil','Mi perfil','Il mio profilo'],
'Tap to adjust the levels that personalise every exercise':['Toque para ajustar os níveis que personalizam cada exercício','Toque para ajustar los niveles que personalizan cada ejercicio','Tocchi per regolare i livelli che personalizzano ogni esercizio'],
'Adaptive training':['Treino adaptativo','Entrenamiento adaptativo','Allenamento adattivo'],'Keeps you at 50–70% correct':['Mantém-no entre 50 e 70% de acertos','Lo mantiene entre 50 y 70% de aciertos','La mantiene tra il 50 e il 70% di risposte corrette'],
'Full session':['Sessão completa','Sesión completa','Sessione completa'],'Matched tasks, one after another':['Tarefas adequadas, uma após outra','Tareas adecuadas, una tras otra','Compiti adatti, uno dopo l’altro'],
'Free practice':['Prática livre','Práctica libre','Pratica libera'],'Choose a task and set it up':['Escolha uma tarefa e configure-a','Elija una tarea y configúrela','Scelga un compito e lo imposti'],
'Progress':['Progresso','Progreso','Progressi'],'Your results over time':['Os seus resultados ao longo do tempo','Sus resultados a lo largo del tiempo','I suoi risultati nel tempo'],
'New profile':['Novo perfil','Nuevo perfil','Nuovo profilo'],'Name or initials':['Nome ou iniciais','Nombre o iniciales','Nome o iniziali'],'Me':['Eu','Yo','Io'],
'Tap again to delete this profile':['Toque de novo para apagar este perfil','Toque de nuevo para borrar este perfil','Tocchi di nuovo per eliminare questo profilo'],
'Delete profile':['Apagar perfil','Borrar perfil','Elimina profilo'],'Create your profile':['Crie o seu perfil','Cree su perfil','Crei il suo profilo'],
'These levels (1 = very low, 10 = very high) set the starting difficulty of every exercise and the tasks in a full session.':['Estes níveis (1 = muito baixo, 10 = muito alto) definem a dificuldade inicial de cada exercício e as tarefas de uma sessão completa.','Estos niveles (1 = muy bajo, 10 = muy alto) fijan la dificultad inicial de cada ejercicio y las tareas de una sesión completa.','Questi livelli (1 = molto basso, 10 = molto alto) stabiliscono la difficoltà iniziale di ogni esercizio e i compiti di una sessione completa.'],
'Name':['Nome do paciente','Nombre del Paciente','Nome del paziente'],
'Only include tasks that closely match the profile':['Incluir só tarefas muito próximas do perfil','Incluir solo tareas muy cercanas al perfil','Includi solo compiti molto vicini al profilo'],
'Save profile':['Guardar perfil','Guardar perfil','Salva profilo'],'Create profile':['Criar perfil','Crear perfil','Crea profilo'],
'Levels restarted from profile ✓':['Níveis reiniciados a partir do perfil ✓','Niveles reiniciados desde el perfil ✓','Livelli riavviati dal profilo ✓'],
'Restart levels from my profile':['Reiniciar níveis a partir do meu perfil','Reiniciar niveles desde mi perfil','Riavvia i livelli dal mio profilo'],
'Each exercise keeps you between 50% and 70% correct: harder above 70%, easier below 50%. It starts from {0}’s profile.':['Cada exercício mantém-no entre 50% e 70% de acertos: mais difícil acima de 70%, mais fácil abaixo de 50%. Começa a partir do perfil de {0}.','Cada ejercicio lo mantiene entre 50% y 70% de aciertos: más difícil por encima de 70%, más fácil por debajo de 50%. Parte del perfil de {0}.','Ogni esercizio la mantiene tra il 50% e il 70% di risposte corrette: più difficile sopra il 70%, più facile sotto il 50%. Parte dal profilo di {0}.'],
'Focus on a domain':['Focar num domínio','Centrarse en un dominio','Concentrarsi su un dominio'],'or choose tasks':['ou escolha tarefas','o elija tareas','oppure scelga i compiti'],
'Training your chosen tasks.':['A treinar as tarefas escolhidas.','Entrenando las tareas elegidas.','Allenamento dei compiti scelti.'],
'Training the tasks that load these domains most.':['A treinar as tarefas que mais exigem estes domínios.','Entrenando las tareas que más exigen estos dominios.','Allenamento dei compiti che richiedono di più questi domini.'],
'Nothing chosen: training all tasks in turn.':['Nada escolhido: todas as tarefas por turnos.','Nada elegido: todas las tareas por turnos.','Nessuna scelta: tutti i compiti a turno.'],
'Start training':['Iniciar treino','Iniciar entrenamiento','Inizia l’allenamento'],
'{0} tasks matched to {1}’s profile, one after another. Results are shown briefly after each task and summarised at the end.':['{0} tarefas adequadas ao perfil de {1}, uma após outra. Os resultados aparecem brevemente após cada tarefa e são resumidos no fim.','{0} tareas adecuadas al perfil de {1}, una tras otra. Los resultados se muestran brevemente tras cada tarea y se resumen al final.','{0} compiti adatti al profilo di {1}, uno dopo l’altro. I risultati compaiono brevemente dopo ogni compito e sono riassunti alla fine.'],
'No task is close enough to this profile. Untick “only include tasks that closely match” in your profile.':['Nenhuma tarefa está suficientemente próxima deste perfil. Desmarque “incluir só tarefas muito próximas” no perfil.','Ninguna tarea se acerca lo suficiente a este perfil. Desmarque “incluir solo tareas muy cercanas” en el perfil.','Nessun compito è abbastanza vicino a questo profilo. Deselezioni “includi solo compiti molto vicini” nel profilo.'],
'Left out as too far from the profile: {0}.':['Excluídas por estarem longe do perfil: {0}.','Excluidas por estar lejos del perfil: {0}.','Escluse perché lontane dal profilo: {0}.'],
'Start session':['Iniciar sessão','Iniciar sesión','Inizia la sessione'],
'Cognitive demand of these settings':['Exigência cognitiva destas definições','Exigencia cognitiva de esta configuración','Richiesta cognitiva di queste impostazioni'],
'Match settings to my profile':['Ajustar ao meu perfil','Ajustar a mi perfil','Adatta al mio profilo'],'Start':['Iniciar','Iniciar','Inizia'],
'Exit task':['Sair da tarefa','Salir de la tarea','Esci dal compito'],'Level {0} of {1}':['Nível {0} de {1}','Nivel {0} de {1}','Livello {0} di {1}'],'Practice':['Prática','Práctica','Pratica'],
'Next one is harder':['O próximo será mais difícil','El siguiente será más difícil','Il prossimo sarà più difficile'],'Top level reached':['Nível máximo atingido','Nivel máximo alcanzado','Livello massimo raggiunto'],
'Next one is easier':['O próximo será mais fácil','El siguiente será más fácil','Il prossimo sarà più facile'],'Easiest level reached':['Nível mais fácil atingido','Nivel más fácil alcanzado','Livello più facile raggiunto'],
'In the 50–70% zone: same level':['Na zona de 50–70%: mesmo nível','En la zona de 50–70%: mismo nivel','Nella zona 50–70%: stesso livello'],
'Next':['Seguinte','Siguiente','Avanti'],'Stop and see summary':['Parar e ver o resumo','Parar y ver el resumen','Fermati e vedi il riepilogo'],'Summary':['Resumo','Resumen','Riepilogo'],
'New version':['Nova versão','Nueva versión','Nuova versione'],'Settings':['Definições','Configuración','Impostazioni'],
'Session summary':['Resumo da sessão','Resumen de la sesión','Riepilogo della sessione'],'Training summary':['Resumo do treino','Resumen del entrenamiento','Riepilogo dell’allenamento'],
'average':['média','promedio','media'],'tasks done':['tarefas feitas','tareas hechas','compiti svolti'],'in 50–70% zone':['na zona 50–70%','en zona 50–70%','in zona 50–70%'],
'% correct per task. Green band = 50–70% target zone; blue above, red below.':['% de acertos por tarefa. Faixa verde = zona-alvo 50–70%; azul acima, vermelho abaixo.','% de aciertos por tarea. Banda verde = zona objetivo 50–70%; azul por encima, rojo por debajo.','% di risposte corrette per compito. Fascia verde = zona obiettivo 50–70%; blu sopra, rosso sotto.'],
'% correct per attempt. Green band = 50–70% target zone; blue above, red below.':['% de acertos por tentativa. Faixa verde = zona-alvo 50–70%; azul acima, vermelho abaixo.','% de aciertos por intento. Banda verde = zona objetivo 50–70%; azul por encima, rojo por debajo.','% di risposte corrette per tentativo. Fascia verde = zona obiettivo 50–70%; blu sopra, rosso sotto.'],
'Keep training':['Continuar o treino','Seguir entrenando','Continua l’allenamento'],'Back to menu':['Voltar ao menu','Volver al menú','Torna al menu'],
'All tasks':['Todas as tarefas','Todas las tareas','Tutti i compiti'],
'Tap again to clear {0}’s history':['Toque de novo para apagar o histórico de {0}','Toque de nuevo para borrar el historial de {0}','Tocchi di nuovo per cancellare la cronologia di {0}'],
'Clear history':['Apagar histórico','Borrar historial','Cancella cronologia'],'Show':['Mostrar','Mostrar','Mostra'],'attempts':['tentativas','intentos','tentativi'],'last 10':['últimas 10','últimos 10','ultimi 10'],
'By cognitive domain':['Por domínio cognitivo','Por dominio cognitivo','Per dominio cognitivo'],
'No results yet for {0}. Finish an exercise and your graphs appear here.':['Ainda sem resultados para {0}. Termine um exercício e os gráficos aparecem aqui.','Aún no hay resultados para {0}. Termine un ejercicio y los gráficos aparecerán aquí.','Ancora nessun risultato per {0}. Termini un esercizio e i grafici compariranno qui.'],
'Finish and check my answers':['Terminar e verificar as respostas','Terminar y comprobar mis respuestas','Termina e controlla le risposte'],
'Data and backup':['Dados e cópia de segurança', 'Datos y copia de seguridad', 'Dati e backup'],'All users ({0})':['Todos os utilizadores ({0})', 'Todos los usuarios ({0})', 'Tutti gli utenti ({0})'],'Users to export':['Utilizadores a exportar', 'Usuarios a exportar', 'Utenti da esportare'],'Export':['Exportar', 'Exportar', 'Esporta'],'Import':['Importar', 'Importar', 'Importa'],'Progress file ready ✓':['Ficheiro de progresso pronto ✓', 'Archivo de progreso listo ✓', 'File dei progressi pronto ✓'],'Could not save the file.':['Não foi possível guardar o ficheiro.', 'No se pudo guardar el archivo.', 'Impossibile salvare il file.'],'Could not read the file.':['Não foi possível ler o ficheiro.', 'No se pudo leer el archivo.', 'Impossibile leggere il file.'],'This file is not a valid progress export.':['Este ficheiro não é uma exportação de progresso válida.', 'Este archivo no es una exportación de progreso válida.', 'Questo file non è un’esportazione valida.'],'{0} entries, {1} new':['{0} registos, {1} novos', '{0} registros, {1} nuevos', '{0} voci, {1} nuove'],'exists here':['já existe aqui', 'ya existe aquí', 'esiste già qui'],'new user':['novo utilizador', 'usuario nuevo', 'nuovo utente'],'File from {0}':['Ficheiro de {0}', 'Archivo de {0}', 'File del {0}'],'Merge':['Juntar', 'Combinar', 'Unisci'],'Replace':['Substituir', 'Reemplazar', 'Sostituisci'],'Merge keeps what is here, adds entries that are missing and keeps the newer profile settings.':['Juntar mantém o que existe, acrescenta os registos em falta e mantém as definições de perfil mais recentes.', 'Combinar conserva lo existente, añade los registros que faltan y mantiene los ajustes de perfil más recientes.', 'Unisci mantiene i dati esistenti, aggiunge le voci mancanti e tiene le impostazioni di profilo più recenti.'],'Replace overwrites the selected users’ profile and history with the file.':['Substituir sobrescreve o perfil e o histórico dos utilizadores escolhidos com o ficheiro.', 'Reemplazar sobrescribe el perfil y el historial de los usuarios elegidos con el archivo.', 'Sostituisci sovrascrive profilo e cronologia degli utenti scelti con il file.'],'A backup is saved first.':['Uma cópia de segurança é guardada antes.', 'Antes se guarda una copia de seguridad.', 'Prima viene salvato un backup.'],'Import selected':['Importar selecionados', 'Importar seleccionados', 'Importa selezionati'],'Cancel':['Cancelar', 'Cancelar', 'Annulla'],'Imported: {0} new entries, {1} users added, {2} profiles updated.':['Importado: {0} registos novos, {1} utilizadores novos, {2} perfis atualizados.', 'Importado: {0} registros nuevos, {1} usuarios nuevos, {2} perfiles actualizados.', 'Importato: {0} voci nuove, {1} utenti nuovi, {2} profili aggiornati.'],'Backup restored ✓':['Cópia restaurada ✓', 'Copia restaurada ✓', 'Backup ripristinato ✓'],'Tap again to restore (current data becomes the backup)':['Toque outra vez para restaurar (os dados atuais passam a ser a cópia)', 'Toque otra vez para restaurar (los datos actuales pasan a ser la copia)', 'Tocca ancora per ripristinare (i dati attuali diventano il backup)'],'Restore backup':['Restaurar cópia', 'Restaurar copia', 'Ripristina backup'],'Download backup':['Descarregar cópia', 'Descargar copia', 'Scarica backup'],'Backup from {0}':['Cópia de {0}', 'Copia de {0}', 'Backup del {0}'],'Who is using this app?':['Quem está a usar a aplicação?', '¿Quién usa la aplicación?', 'Chi sta usando l’app?'],'I am the patient':['Sou o utente', 'Soy el paciente', 'Sono il paziente'],'Simple screens: just start your training':['Ecrãs simples: basta começar o treino', 'Pantallas simples: solo empiece el entrenamiento', 'Schermate semplici: basta iniziare l’allenamento'],'I am the clinician':['Sou o clínico', 'Soy el clínico', 'Sono il clinico'],'Prepare and follow the training plans':['Preparar e acompanhar os planos de treino', 'Preparar y seguir los planes de entrenamiento', 'Preparare e seguire i piani di allenamento'],'Clinician PIN':['PIN do clínico', 'PIN del clínico', 'PIN del clinico'],'Wrong PIN':['PIN errado', 'PIN incorrecto', 'PIN errato'],'Stop for now?':['Parar por agora?', '¿Parar por ahora?', 'Fermarsi per ora?'],'Today’s training will not be counted until you finish it.':['O treino de hoje só conta quando o terminar.', 'El entrenamiento de hoy solo cuenta cuando lo termine.', 'L’allenamento di oggi conta solo quando lo termina.'],'Keep going':['Continuar', 'Continuar', 'Continua'],'Stop':['Parar', 'Parar', 'Ferma'],'Not you? Change person':['Não é você? Mudar de pessoa', '¿No es usted? Cambiar de persona', 'Non è lei? Cambia persona'],'Save my results file':['Guardar o ficheiro dos meus resultados', 'Guardar el archivo de mis resultados', 'Salva il file dei miei risultati'],'Clinician':['Clínico', 'Clínico', 'Clinico'],'Nothing set up yet':['Ainda nada preparado', 'Nada preparado todavía', 'Ancora nulla di pronto'],'Ask your clinician to prepare your training.':['Peça ao seu clínico para preparar o treino.', 'Pida a su clínico que prepare el entrenamiento.', 'Chieda al suo clinico di preparare l’allenamento.'],'Who are you?':['Quem é você?', '¿Quién es usted?', 'Chi è lei?'],'Ready when you are':['Quando quiser', 'Cuando quiera', 'Quando vuole'],'No schedule yet. You can train whenever you like.':['Ainda sem plano. Pode treinar quando quiser.', 'Aún sin plan. Puede entrenar cuando quiera.', 'Ancora nessun piano. Può allenarsi quando vuole.'],'Today: training':['Hoje: treino', 'Hoy: entrenamiento', 'Oggi: allenamento'],'{0} minutes':['{0} minutos', '{0} minutos', '{0} minuti'],'Today’s training is done ✓':['O treino de hoje está feito ✓', 'El entrenamiento de hoy está hecho ✓', 'L’allenamento di oggi è fatto ✓'],'You still have {0} missed session(s) this week.':['Ainda tem {0} sessão(ões) em falta esta semana.', 'Todavía tiene {0} sesión(es) pendiente(s) esta semana.', 'Ha ancora {0} sessione/i mancante/i questa settimana.'],'Well done!':['Muito bem!', '¡Muy bien!', 'Bravo!'],'Do a missed session':['Fazer uma sessão em falta', 'Hacer una sesión pendiente', 'Fai una sessione mancante'],'Train a little more':['Treinar mais um pouco', 'Entrenar un poco más', 'Allenarsi ancora un po’'],'You missed {0} session(s) this week':['Falhou {0} sessão(ões) esta semana', 'Ha perdido {0} sesión(es) esta semana', 'Ha saltato {0} sessione/i questa settimana'],'You can catch up now.':['Pode recuperar agora.', 'Puede recuperar ahora.', 'Può recuperare ora.'],'Catch up now':['Recuperar agora', 'Recuperar ahora', 'Recupera ora'],'Rest today':['Hoje é dia de descanso', 'Hoy es día de descanso', 'Oggi si riposa'],'Next training: {0}':['Próximo treino: {0}', 'Próximo entrenamiento: {0}', 'Prossimo allenamento: {0}'],'Start training':['Começar o treino', 'Empezar el entrenamiento', 'Inizia l’allenamento'],'This week: {0} of {1} sessions':['Esta semana: {0} de {1} sessões', 'Esta semana: {0} de {1} sesiones', 'Questa settimana: {0} di {1} sessioni'],'Well done, {0}!':['Muito bem, {0}!', '¡Muy bien, {0}!', 'Bravo, {0}!'],'{0} tasks completed':['{0} tarefas concluídas', '{0} tareas completadas', '{0} compiti completati'],'Finish':['Concluir', 'Terminar', 'Fine'],'{0} min left':['faltam {0} min', 'faltan {0} min', 'mancano {0} min'],'Patients':['Utentes', 'Pacientes', 'Pazienti'],'Patients and plans':['Utentes e planos', 'Pacientes y planes', 'Pazienti e piani'],'Training plans and adherence':['Planos de treino e adesão', 'Planes de entrenamiento y adherencia', 'Piani di allenamento e aderenza'],'Tap a patient to set the training plan and see whether it is being followed.':['Toque num utente para definir o plano e ver se está a ser cumprido.', 'Toque un paciente para definir el plan y ver si se cumple.', 'Tocchi un paziente per impostare il piano e vedere se viene seguito.'],'{0} missed':['{0} em falta', '{0} pendiente(s)', '{0} mancanti'],'{0}/{1} this week':['{0}/{1} esta semana', '{0}/{1} esta semana', '{0}/{1} questa settimana'],'No plan':['Sem plano', 'Sin plan', 'Nessun piano'],'Last session: {0}':['Última sessão: {0}', 'Última sesión: {0}', 'Ultima sessione: {0}'],'No sessions yet':['Ainda sem sessões', 'Aún sin sesiones', 'Ancora nessuna sessione'],'New patient':['Novo utente', 'Nuevo paciente', 'Nuovo paziente'],'Optional. Asked when switching from the patient view to this one. It only prevents accidental changes; it is not secure protection.':['Opcional. Pedido ao passar da vista do utente para esta. Só evita alterações acidentais; não é proteção segura.', 'Opcional. Se pide al pasar de la vista del paciente a esta. Solo evita cambios accidentales; no es una protección segura.', 'Facoltativo. Richiesto passando dalla vista paziente a questa. Evita solo modifiche accidentali; non è una protezione sicura.'],'No PIN':['Sem PIN', 'Sin PIN', 'Nessun PIN'],'PIN saved ✓':['PIN guardado ✓', 'PIN guardado ✓', 'PIN salvato ✓'],'PIN removed':['PIN removido', 'PIN eliminado', 'PIN rimosso'],'Set / clear':['Definir / limpar', 'Definir / borrar', 'Imposta / cancella'],'Switch to patient view':['Mudar para a vista do utente', 'Cambiar a la vista del paciente', 'Passa alla vista paziente'],'Plan for {0}':['Plano de {0}', 'Plan de {0}', 'Piano di {0}'],'Plan on':['Plano ativo', 'Plan activo', 'Piano attivo'],'Plan off':['Plano desligado', 'Plan desactivado', 'Piano disattivato'],'Training days':['Dias de treino', 'Días de entrenamiento', 'Giorni di allenamento'],'{0} sessions per week':['{0} sessões por semana', '{0} sesiones por semana', '{0} sessioni a settimana'],'Minutes per session':['Minutos por sessão', 'Minutos por sesión', 'Minuti per sessione'],'Type of session':['Tipo de sessão', 'Tipo de sesión', 'Tipo di sessione'],'The full session runs all matched tasks once; the minutes are only a guide.':['A sessão completa faz todas as tarefas adequadas uma vez; os minutos são só indicativos.', 'La sesión completa hace una vez todas las tareas adecuadas; los minutos son solo orientativos.', 'La sessione completa svolge una volta tutti i compiti adatti; i minuti sono solo indicativi.'],'Message for the patient':['Mensagem para o utente', 'Mensaje para el paciente', 'Messaggio per il paziente'],'Optional short message':['Mensagem curta opcional', 'Mensaje corto opcional', 'Messaggio breve facoltativo'],'This week':['Esta semana', 'Esta semana', 'Questa settimana'],'{0} of {1} sessions done':['{0} de {1} sessões feitas', '{0} de {1} sesiones hechas', '{0} di {1} sessioni svolte'],'To give the plan to another device, export it in Progress → Data and backup and import it there. Results come back the same way.':['Para passar o plano a outro dispositivo, exporte-o em Progresso → Dados e cópia de segurança e importe lá. Os resultados voltam da mesma forma.', 'Para pasar el plan a otro dispositivo, expórtelo en Progreso → Datos y copia de seguridad e impórtelo allí. Los resultados vuelven igual.', 'Per passare il piano a un altro dispositivo, lo esporti in Progressi → Dati e backup e lo importi lì. I risultati tornano allo stesso modo.'],'Patient view':['Vista do utente', 'Vista del paciente', 'Vista paziente'],'Tools apply to the selected profile.':['As ferramentas aplicam-se ao perfil selecionado.', 'Las herramientas se aplican al perfil seleccionado.', 'Gli strumenti si applicano al profilo selezionato.'],'Selected profile':['Perfil selecionado', 'Perfil seleccionado', 'Profilo selezionato'],'No profile selected':['Nenhum perfil selecionado', 'Ningún perfil seleccionado', 'Nessun profilo selezionato'],'Delete':['Apagar', 'Borrar', 'Elimina'],'Delete?':['Apagar?', '¿Borrar?', 'Eliminare?'],'Training complete! You can finish.':['Treino completo! Pode terminar.', '¡Entrenamiento completo! Puede terminar.', 'Allenamento completo! Può terminare.'],'Time is up: finish this task':['Tempo cumprido: termine esta tarefa', 'Tiempo cumplido: termine esta tarea', 'Tempo raggiunto: termini questo compito'],'Next time you continue from this task.':['Da próxima vez continua a partir desta tarefa.', 'La próxima vez continuará desde esta tarea.', 'La prossima volta riprende da questo compito.'],'Unfinished training: you will continue where you stopped.':['Treino por acabar: vai continuar onde parou.', 'Entrenamiento sin terminar: continuará donde lo dejó.', 'Allenamento non finito: riprenderà da dove si è fermato.'],'Calendar reminder (.ics)':['Lembrete no calendário (.ics)', 'Recordatorio en el calendario (.ics)', 'Promemoria nel calendario (.ics)'],'Add reminder to calendar':['Pôr lembrete no calendário', 'Poner recordatorio en el calendario', 'Aggiungi promemoria al calendario'],'Reminder':['Lembrete', 'Recordatorio', 'Promemoria'],'Cognitive training':['Treino cognitivo', 'Entrenamiento cognitivo', 'Allenamento cognitivo'],'Saved as .txt: rename it to .ics to open it in your calendar.':['Guardado como .txt: mude o nome para .ics para abrir no calendário.', 'Guardado como .txt: cambie el nombre a .ics para abrirlo en el calendario.', 'Salvato come .txt: lo rinomini in .ics per aprirlo nel calendario.'],'Reminder file ready ✓':['Ficheiro de lembrete pronto ✓', 'Archivo de recordatorio listo ✓', 'File del promemoria pronto ✓'],'Name':['Nome', 'Nombre', 'Nome'],'Date':['Data', 'Fecha', 'Data'],'Training report':['Relatório de treino', 'Informe de entrenamiento', 'Rapporto di allenamento'],'Training plan':['Plano de treino', 'Plan de entrenamiento', 'Piano di allenamento'],'Sessions per week (last 8 weeks)':['Sessões por semana (últimas 8 semanas)', 'Sesiones por semana (últimas 8 semanas)', 'Sessioni a settimana (ultime 8 settimane)'],'Dark bar = sessions done; outline = sessions prescribed.':['Barra escura = sessões feitas; contorno = sessões prescritas.', 'Barra oscura = sesiones hechas; contorno = sesiones prescritas.', 'Barra scura = sessioni svolte; contorno = sessioni prescritte.'],'Performance':['Desempenho', 'Rendimiento', 'Prestazioni'],'sessions':['sessões', 'sesiones', 'sessioni'],'By task':['Por tarefa', 'Por tarea', 'Per compito'],'Task':['Tarefa', 'Tarea', 'Compito'],'average':['média', 'promedio', 'media'],'Level':['Nível', 'Nivel', 'Livello'],'Recall':['Recordação', 'Recuerdo', 'Richiamo'],'Answer key':['Soluções', 'Soluciones', 'Soluzioni'],'Preparing the PDF…':['A preparar o PDF…', 'Preparando el PDF…', 'Preparazione del PDF…'],'PDF ready ✓':['PDF pronto ✓', 'PDF listo ✓', 'PDF pronto ✓'],'Could not create the PDF. Use Print and choose “Save as PDF”.':['Não foi possível criar o PDF. Use Imprimir e escolha “Guardar como PDF”.', 'No se pudo crear el PDF. Use Imprimir y elija “Guardar como PDF”.', 'Impossibile creare il PDF. Usi Stampa e scelga “Salva come PDF”.'],'Printing is not available here. Use Download PDF.':['Imprimir não está disponível aqui. Use Descarregar PDF.', 'Imprimir no está disponible aquí. Use Descargar PDF.', 'La stampa non è disponibile qui. Usi Scarica PDF.'],'Print':['Imprimir', 'Imprimir', 'Stampa'],'Download PDF':['Descarregar PDF', 'Descargar PDF', 'Scarica PDF'],'Close':['Fechar', 'Cerrar', 'Chiudi'],'Print and PDF for {0}':['Imprimir e PDF de {0}', 'Imprimir y PDF de {0}', 'Stampa e PDF di {0}'],'Progress report':['Relatório de progresso', 'Informe de progreso', 'Rapporto dei progressi'],'Profile, plan, sessions per week and performance. One page.':['Perfil, plano, sessões por semana e desempenho. Uma página.', 'Perfil, plan, sesiones por semana y rendimiento. Una página.', 'Profilo, piano, sessioni a settimana e prestazioni. Una pagina.'],'Open report':['Abrir relatório', 'Abrir informe', 'Apri rapporto'],'Exercise sheets':['Fichas de exercícios', 'Fichas de ejercicios', 'Schede di esercizi'],'Paper versions of the exercises at {0}’s current level.':['Versões em papel dos exercícios no nível atual de {0}.', 'Versiones en papel de los ejercicios al nivel actual de {0}.', 'Versioni cartacee degli esercizi al livello attuale di {0}.'],'{0} version(s)':['{0} versão(ões)', '{0} versión(es)', '{0} versione/i'],'Include the answer key':['Incluir as soluções', 'Incluir las soluciones', 'Includi le soluzioni'],'Create sheets':['Criar fichas', 'Crear fichas', 'Crea schede'],'Check against the story':['Confirmar com a história', 'Comprobar con la historia', 'Controlla con la storia'],'Hide the story again':['Esconder a história', 'Ocultar la historia', 'Nascondi la storia'],'Answer each question from memory (aloud), check against the story if you wish, then tap whether you were right.':['Responda a cada pergunta de memória (em voz alta), confirme com a história se quiser e toque se acertou.', 'Responda cada pregunta de memoria (en voz alta), compruebe con la historia si quiere y toque si acertó.', 'Risponda a ogni domanda a memoria (ad alta voce), controlli con la storia se vuole e tocchi se ha risposto bene.'],'Scored from your own marking: the original exercise has no answer key to check automatically.':['Pontuado pela sua própria marcação: o exercício original não tem soluções para verificar automaticamente.', 'Puntuado según su propia marca: el ejercicio original no tiene soluciones para comprobar automáticamente.', 'Punteggio dalla sua valutazione: l’esercizio originale non ha soluzioni da verificare automaticamente.'],'Your progress':['O seu progresso', 'Su progreso', 'I suoi progressi'],'Last 10 exercises: {0}% correct':['Últimos 10 exercícios: {0}% certos', 'Últimos 10 ejercicios: {0}% correctos', 'Ultimi 10 esercizi: {0}% corretti'],'Better than before ▲':['Melhor do que antes ▲', 'Mejor que antes ▲', 'Meglio di prima ▲'],'A little lower than before ▼':['Um pouco abaixo do que antes ▼', 'Un poco por debajo que antes ▼', 'Un po’ sotto rispetto a prima ▼'],'About the same as before ●':['Parecido com o que tinha ●', 'Parecido a lo anterior ●', 'Simile a prima ●'],'Your strongest area: {0}':['A sua área mais forte: {0}', 'Su área más fuerte: {0}', 'La sua area più forte: {0}'],'Keep going: every session helps.':['Continue: cada sessão ajuda.', 'Siga así: cada sesión ayuda.', 'Continui: ogni sessione aiuta.'],'sessions done':['sessões feitas', 'sesiones hechas', 'sessioni svolte'],'exercises':['exercícios', 'ejercicios', 'esercizi'],'Choose the profile':['Escolher o perfil', 'Elegir el perfil', 'Scegliere il profilo'],'Manage patients':['Gerir utentes', 'Gestionar pacientes', 'Gestisci pazienti'],'tap to change':['toque para mudar', 'toque para cambiar', 'tocca per cambiare'],'Edit plan':['Editar plano', 'Editar plan', 'Modifica piano'],'Circle the picture that was paired with each one.':['Assinale a imagem que estava emparelhada com cada uma.', 'Marque la imagen que estaba emparejada con cada una.', 'Cerchi l’immagine che era abbinata a ciascuna.'],'Circle every':['Assinale cada', 'Marque cada', 'Cerchi ogni'],'Find {0} words (any direction) and circle them in the grid.':['Encontre {0} palavras (em qualquer direção) e assinale-as na grelha.', 'Encuentre {0} palabras (en cualquier dirección) y márquelas en la cuadrícula.', 'Trovi {0} parole (in qualsiasi direzione) e le cerchi nella griglia.'],'Draw a path from ▶ to ⚑ with a pencil.':['Desenhe um caminho de ▶ até ⚑ com um lápis.', 'Dibuje un camino de ▶ a ⚑ con un lápiz.', 'Disegni un percorso da ▶ a ⚑ con una matita.'],'Sort the pictures into {0} groups of things that belong together. Write the group number under each picture; use the same number for pictures of the same kind.':['Separe as imagens em {0} grupos de coisas que pertencem juntas. Escreva o número do grupo debaixo de cada imagem; use o mesmo número para imagens do mesmo tipo.', 'Separe las imágenes en {0} grupos de cosas que van juntas. Escriba el número del grupo bajo cada imagen; use el mismo número para imágenes del mismo tipo.', 'Divida le immagini in {0} gruppi di cose che stanno insieme. Scriva il numero del gruppo sotto ogni immagine; usi lo stesso numero per immagini dello stesso tipo.'],'Match each picture on the left with the one on the right that goes with it. Draw a line between them.':['Una cada imagem da esquerda à da direita que lhe corresponde. Desenhe uma linha entre elas.', 'Una cada imagen de la izquierda con la de la derecha que le corresponde. Dibuje una línea entre ellas.', 'Colleghi ogni immagine a sinistra con quella a destra che le corrisponde. Tracci una linea tra loro.'],'Answer each question from memory.':['Responda a cada pergunta de memória.', 'Responda cada pregunta de memoria.', 'Risponda a ogni domanda a memoria.'],'Plan active':['Plano ativo','Plan activo','Piano attivo'],'Keeps each exercise between 50% and 70% correct.':['Mantém cada exercício entre 50% e 70% de acertos.','Mantiene cada ejercicio entre el 50% y el 70% de aciertos.','Mantiene ogni esercizio tra il 50% e il 70% di risposte corrette.'],'Plan duration':['Duração do plano', 'Duración del plan', 'Durata del piano'],'{0} weeks':['{0} semanas', '{0} semanas', '{0} settimane'],'Permanent':['Permanente', 'Permanente', 'Permanente'],'Week {0} of {1}':['Semana {0} de {1}', 'Semana {0} de {1}', 'Settimana {0} di {1}'],'Week {0} of {1} · ends {2}':['Semana {0} de {1} · termina a {2}', 'Semana {0} de {1} · termina el {2}', 'Settimana {0} di {1} · termina il {2}'],'Plan ended on {0}.':['O plano terminou a {0}.', 'El plan terminó el {0}.', 'Il piano è terminato il {0}.'],'Restart from today':['Recomeçar a contar de hoje', 'Reiniciar desde hoy', 'Riparti da oggi'],'Plan ended':['Plano terminado', 'Plan terminado', 'Piano terminato'],'Your training plan is complete ✓':['O seu plano de treino está completo ✓', 'Su plan de entrenamiento está completo ✓', 'Il suo piano di allenamento è completo ✓'],'Ask your clinician for the next plan. You can keep training if you like.':['Peça ao seu clínico o plano seguinte. Pode continuar a treinar se quiser.', 'Pida a su clínico el siguiente plan. Puede seguir entrenando si quiere.', 'Chieda al suo clinico il piano successivo. Può continuare ad allenarsi se vuole.'],'Adds the training days to the patient’s calendar app.':['Põe os dias de treino no calendário do utente.', 'Pone los días de entrenamiento en el calendario del paciente.', 'Mette i giorni di allenamento nel calendario del paziente.'],'Time of day':['Hora do dia', 'Hora del día', 'Ora del giorno'],'Alert':['Aviso', 'Aviso', 'Avviso'],'At the time':['À hora', 'A la hora', 'All’ora'],'10 min before':['10 min antes', '10 min antes', '10 min prima'],'30 min before':['30 min antes', '30 min antes', '30 min prima'],'1 h before':['1 h antes', '1 h antes', '1 h prima'],'Add to calendar (.ics)':['Adicionar ao calendário (.ics)', 'Añadir al calendario (.ics)', 'Aggiungi al calendario (.ics)'],'The full session runs all tasks once, whatever the profile; the minutes are only a guide.':['A sessão completa faz todas as tarefas uma vez, independentemente do perfil; os minutos são só indicativos.','La sesión completa hace todas las tareas una vez, sea cual sea el perfil; los minutos son solo orientativos.','La sessione completa svolge tutti i compiti una volta, qualunque sia il profilo; i minuti sono solo indicativi.'],'No task is close enough to this profile. Untick “Only include tasks that closely match the profile” above.':['Nenhuma tarefa se aproxima deste perfil. Desmarque “Incluir só tarefas muito próximas do perfil” acima.','Ninguna tarea se acerca a este perfil. Desmarque “Incluir solo tareas muy cercanas al perfil” arriba.','Nessun compito è abbastanza vicino a questo profilo. Deselezioni “Includi solo compiti molto vicini al profilo” sopra.'],'Tap to edit the plan':['Toque para editar o plano','Toque para editar el plan','Tocca per modificare il piano'],'In progress':['Em curso','En curso','In corso'],'Week complete ✓':['Semana completa ✓','Semana completa ✓','Settimana completa ✓'],'Tasks':['Tarefas','Tareas','Compiti'],'Print this session':['Imprimir esta sessão','Imprimir esta sesión','Stampa questa sessione'],'Print with these settings':['Imprimir com estas definições','Imprimir con estos ajustes','Stampa con queste impostazioni'],'Print this':['Imprimir','Imprimir','Stampa'],'Nothing to print.':['Nada para imprimir.','Nada que imprimir.','Niente da stampare.'],'Overview':['Visualização','Visualización','Visualizzazione'],'Patient profile':['Perfil do utente','Perfil del paciente','Profilo del paziente'],'Current PIN':['PIN atual','PIN actual','PIN attuale'],'New PIN':['Novo PIN','Nuevo PIN','Nuovo PIN'],'Type a new PIN':['Escreva um novo PIN','Escriba un nuevo PIN','Scriva un nuovo PIN'],'Save PIN':['Guardar PIN','Guardar PIN','Salva PIN'],'Remove PIN':['Remover PIN','Quitar PIN','Rimuovi PIN'],'One PIN for the clinician view, whichever profile is selected. Asked when switching from the patient view. It only prevents accidental changes; it is not secure protection.':['Um só PIN para a vista do clínico, seja qual for o perfil selecionado. Pedido ao passar da vista do utente. Só evita alterações acidentais; não é proteção segura.','Un solo PIN para la vista del clínico, sea cual sea el perfil seleccionado. Se pide al pasar de la vista del paciente. Solo evita cambios accidentales; no es una protección segura.','Un solo PIN per la vista del clinico, qualunque sia il profilo selezionato. Richiesto passando dalla vista paziente. Evita solo modifiche accidentali; non è una protezione sicura.'],'Stuck in landscape?':['Preso na horizontal?','¿Atascado en horizontal?','Bloccato in orizzontale?'],'Text size':['Tamanho do texto','Tamaño del texto','Dimensione del testo'],'Plan templates':['Modelos de plano','Plantillas de plan','Modelli di piano'],'Choose one to fill in the plan; you can then adjust anything by hand.':['Escolha um para preencher o plano; depois pode ajustar tudo manualmente.','Elija una para rellenar el plan; después puede ajustar todo a mano.','Sceglietene uno per compilare il piano; poi potete modificare tutto a mano.'],'Ready-made':['Prontos','Predefinidas','Predefiniti'],'My templates':['Os meus modelos','Mis plantillas','I miei modelli'],'None yet.':['Ainda nenhum.','Ninguna todavía.','Nessuno per ora.'],'Save the current plan as a template':['Guardar o plano atual como modelo','Guardar el plan actual como plantilla','Salva il piano attuale come modello'],'Template name':['Nome do modelo','Nombre de la plantilla','Nome del modello'],'Save template':['Guardar modelo','Guardar plantilla','Salva modello'],'Gentle start':['Início suave','Inicio suave','Inizio graduale'],'Standard plan':['Plano standard','Plan estándar','Piano standard'],'Intensive plan':['Plano intensivo','Plan intensivo','Piano intensivo'],'Attention and memory':['Atenção e memória','Atención y memoria','Attenzione e memoria'],'Executive functions and language':['Funções executivas e linguagem','Funciones ejecutivas y lenguaje','Funzioni esecutive e linguaggio'],'Weekly full sessions':['Sessões completas semanais','Sesiones completas semanales','Sessioni complete settimanali'],'Maintenance':['Manutenção','Mantenimiento','Mantenimento'],'Download or import':['Descarregar ou importar','Descargar o importar','Scarica o importa'],'Download my templates':['Descarregar os meus modelos','Descargar mis plantillas','Scarica i miei modelli'],'Import templates':['Importar modelos','Importar plantillas','Importa modelli'],'Templates file ready ✓':['Ficheiro de modelos pronto ✓','Archivo de plantillas listo ✓','File dei modelli pronto ✓'],'{0} templates imported ✓':['{0} modelos importados ✓','{0} plantillas importadas ✓','{0} modelli importati ✓'],'This file is not a valid templates file.':['Este ficheiro não é um ficheiro de modelos válido.','Este archivo no es un archivo de plantillas válido.','Questo file non è un file di modelli valido.'],'Stimuli type':['Tipo de estímulos','Tipo de estímulos','Tipo di stimoli'],'Mixed':['Misto','Mixto','Misto'],'Applies to Association and Image pairs. Mixed alternates between clip art and photos.':['Aplica-se a Associação e Pares de imagens. “Misto” alterna entre clip art e fotografias.','Se aplica a Asociación y Pares de imágenes. «Mixto» alterna entre clip art y fotografías.','Vale per Associazione e Coppie di immagini. «Misto» alterna clip art e fotografie.'],'Validated photos':['Fotografias validadas','Fotografías validadas','Fotografie validate'],'Commons photos':['Fotografias Commons','Fotografías Commons','Fotografie Commons'],'none installed':['nenhuma instalada','ninguna instalada','nessuna installata'],'Association and Image pairs use pictures from every source switched on; each exercise picks one of them.':['Associação e Pares de imagens usam imagens de todas as fontes ativas; cada exercício escolhe uma delas.','Asociación y Pares de imágenes usan imágenes de todas las fuentes activas; cada ejercicio elige una de ellas.','Associazione e Coppie di immagini usano le immagini di tutte le fonti attive; ogni esercizio ne sceglie una.'],'Applies to all training':['Aplica-se a todos os treinos','Se aplica a todos los entrenamientos','Vale per tutti gli allenamenti'],'Validated':['Validadas','Validadas','Validate'],'Commons':['Commons','Commons','Commons'],'Info':['Informação','Información','Informazioni'],'All matched tasks':['Todas as tarefas adequadas','Todas las tareas adecuadas','Tutti i compiti adatti'],'Edit':['Editar','Editar','Modifica'],'Stimuli':['Estímulos','Estímulos','Stimoli'],'Manage':['Gerir','Gestionar','Gestisci'],'Manual':['Manual','Manual','Manuale'],'Manage interventions':['Gerir intervenções','Gestionar intervenciones','Gestisci interventi'],'Black-and-white line drawings from the original PARP-AVC material. Simple, high-contrast and easy to print.':['Desenhos a preto e branco do material original PARP-AVC. Simples, de alto contraste e fáceis de imprimir.','Dibujos en blanco y negro del material original PARP-AVC. Simples, de alto contraste y fáciles de imprimir.','Disegni in bianco e nero del materiale originale PARP-AVC. Semplici, ad alto contrasto e facili da stampare.'],'Real colour photographs of everyday objects, already part of the app and checked by the team.':['Fotografias reais a cores de objetos do dia a dia, já incluídas na app e verificadas pela equipa.','Fotografías reales a color de objetos cotidianos, ya incluidas en la app y revisadas por el equipo.','Fotografie reali a colori di oggetti quotidiani, già incluse nell’app e verificate dal team.'],'Additional photographs from Wikimedia Commons with free licences, kept in a separate pack so they can be switched on or off. Not installed yet.':['Fotografias adicionais da Wikimedia Commons com licenças livres, num pacote separado que pode ser ligado ou desligado. Ainda não instalado.','Fotografías adicionales de Wikimedia Commons con licencias libres, en un paquete separado que se puede activar o desactivar. Aún no instalado.','Fotografie aggiuntive da Wikimedia Commons con licenze libere, in un pacchetto separato che si può attivare o disattivare. Non ancora installato.'],'Database':['Base de dados','Base de datos','Database'],'validated':['validadas','validadas','validate'],'Delete intervention':['Apagar intervenção','Eliminar intervención','Elimina intervento'],'the profile and results are kept':['o perfil e os resultados mantêm-se','el perfil y los resultados se conservan','il profilo e i risultati restano'],'Print the whole week':['Imprimir a semana completa','Imprimir la semana completa','Stampa tutta la settimana'],'One set of sheets for each training day, with the day on every page.':['Um conjunto de folhas para cada dia de treino, com o dia em todas as páginas.','Un conjunto de hojas para cada día de entrenamiento, con el día en cada página.','Un set di schede per ogni giorno di allenamento, con il giorno su ogni pagina.'],'Commons picture':['Imagem Commons','Imagen Commons','Immagine Commons'],'Adaptive: the tasks follow the chosen domains or tasks, about one every 5 minutes, rotated over the week.':['Adaptativo: as tarefas seguem os domínios ou tarefas escolhidos, cerca de uma a cada 5 minutos, rodadas ao longo da semana.','Adaptativo: las tareas siguen los dominios o tareas elegidos, una cada 5 minutos aproximadamente, rotadas durante la semana.','Adattivo: le attività seguono i domini o le attività scelte, circa una ogni 5 minuti, a rotazione nella settimana.'],'Versions':['Versões','Versiones','Versioni'],'Delete the profile “{0}”?':['Apagar o perfil “{0}”?','¿Borrar el perfil “{0}”?','Eliminare il profilo “{0}”?'],'This removes the profile and its plan. Its training history stays in the app data.':['Isto remove o perfil e o plano. O histórico de treino mantém-se nos dados da aplicação.','Esto elimina el perfil y su plan. El historial de entrenamiento se conserva en los datos de la aplicación.','Rimuove il profilo e il piano. Lo storico degli allenamenti resta nei dati dell’app.'],'Share by QR':['Partilhar por QR', 'Compartir por QR', 'Condividi con QR'],'What do you want to share?':['O que quer partilhar?', '¿Qué quiere compartir?', 'Cosa vuoi condividere?'],'A patient profile':['Um perfil de paciente', 'Un perfil de paciente', 'Un profilo paziente'],'Profile and plan':['Perfil e plano', 'Perfil y plan', 'Profilo e piano'],'A patient’s history':['O histórico de um paciente', 'El historial de un paciente', 'Lo storico di un paziente'],'Results of one patient':['Resultados de um paciente', 'Resultados de un paciente', 'Risultati di un paziente'],'Everything':['Tudo', 'Todo', 'Tutto'],'All patients and all history':['Todos os pacientes e todo o histórico', 'Todos los pacientes y todo el historial', 'Tutti i pazienti e tutto lo storico'],'Receive by QR':['Receber por QR', 'Recibir por QR', 'Ricevi con QR'],'Which profile?':['Que perfil?', '¿Qué perfil?', 'Quale profilo?'],'Whose history?':['O histórico de quem?', '¿El historial de quién?', 'Lo storico di chi?'],'Back':['Voltar', 'Volver', 'Indietro'],'Preparing the codes…':['A preparar os códigos…', 'Preparando los códigos…', 'Preparazione dei codici…'],'Scan with the other device':['Leia com o outro dispositivo', 'Escanee con el otro dispositivo', 'Scansiona con l’altro dispositivo'],'Part {0}/{1}':['Parte {0}/{1}', 'Parte {0}/{1}', 'Parte {0}/{1}'],'{0} codes repeat in a loop. Scan them in any order until the other device has all parts.':['{0} códigos repetem-se em ciclo. Leia-os por qualquer ordem até o outro dispositivo ter todas as partes.', '{0} códigos se repiten en bucle. Escanéelos en cualquier orden hasta que el otro dispositivo tenga todas las partes.', '{0} codici si ripetono in ciclo. Scansionali in qualsiasi ordine finché l’altro dispositivo ha tutte le parti.'],'One code. Scan it with the other device.':['Um só código. Leia-o com o outro dispositivo.', 'Un solo código. Escanéelo con el otro dispositivo.', 'Un solo codice. Scansionalo con l’altro dispositivo.'],'Done':['Concluído', 'Hecho', 'Fatto'],'Point the camera at the QR codes.':['Aponte a câmara aos códigos QR.', 'Apunte la cámara a los códigos QR.', 'Inquadra i codici QR con la fotocamera.'],'Parts received: {0}/{1}':['Partes recebidas: {0}/{1}', 'Partes recibidas: {0}/{1}', 'Parti ricevute: {0}/{1}'],'The data is damaged. Scan again.':['Os dados estão danificados. Leia de novo.', 'Los datos están dañados. Escanee de nuevo.', 'I dati sono danneggiati. Scansiona di nuovo.'],'The data could not be read.':['Não foi possível ler os dados.', 'No se pudieron leer los datos.', 'Impossibile leggere i dati.'],'This is not a Task Generator file.':['Isto não é um ficheiro do Task Generator.', 'Esto no es un archivo de Task Generator.', 'Questo non è un file di Task Generator.'],'Received':['Recebido', 'Recibido', 'Ricevuto'],'{0} profile(s) · {1} result(s)':['{0} perfil(is) · {1} resultado(s)', '{0} perfil(es) · {1} resultado(s)', '{0} profilo/i · {1} risultato/i'],'Add to this device':['Adicionar a este dispositivo', 'Añadir a este dispositivo', 'Aggiungi a questo dispositivo'],'Existing data is merged: nothing is deleted and duplicates are skipped.':['Os dados existentes são combinados: nada é apagado e os duplicados são ignorados.', 'Los datos existentes se combinan: no se borra nada y se omiten los duplicados.', 'I dati esistenti vengono uniti: nulla viene eliminato e i duplicati sono ignorati.'],'From a photo':['De uma foto', 'De una foto', 'Da una foto'],'Paste text':['Colar texto', 'Pegar texto', 'Incolla testo'],'Add part':['Adicionar parte', 'Añadir parte', 'Aggiungi parte'],'This is not a code from this app.':['Este não é um código desta aplicação.', 'Este no es un código de esta aplicación.', 'Questo non è un codice di questa app.'],'No code found in the photo.':['Nenhum código encontrado na foto.', 'No se encontró ningún código en la foto.', 'Nessun codice trovato nella foto.'],'This browser cannot read QR codes here. Paste the text instead.':['Este navegador não consegue ler QR aqui. Cole o texto.', 'Este navegador no puede leer QR aquí. Pegue el texto.', 'Questo browser non può leggere i QR qui. Incolla il testo.'],'The camera is not available here. Use a photo or paste the text.':['A câmara não está disponível aqui. Use uma foto ou cole o texto.', 'La cámara no está disponible aquí. Use una foto o pegue el texto.', 'La fotocamera non è disponibile qui. Usa una foto o incolla il testo.'],'Camera access was not granted. Use a photo or paste the text.':['Acesso à câmara não concedido. Use uma foto ou cole o texto.', 'No se concedió acceso a la cámara. Use una foto o pegue el texto.', 'Accesso alla fotocamera non concesso. Usa una foto o incolla il testo.'],'This browser cannot read QR codes live. Take a photo of each code, or paste the text.':['Este navegador não lê QR em direto. Tire uma foto de cada código ou cole o texto.', 'Este navegador no lee QR en directo. Haga una foto de cada código o pegue el texto.', 'Questo browser non legge i QR dal vivo. Scatta una foto di ogni codice o incolla il testo.'],'Imported ✓':['Importado ✓', 'Importado ✓', 'Importato ✓'],'Camera':['Câmara', 'Cámara', 'Fotocamera'],'Use the camera':['Usar a câmara', 'Usar la cámara', 'Usa la fotocamera'],'Starting the camera…':['A iniciar a câmara…', 'Iniciando la cámara…', 'Avvio della fotocamera…'],'Reading photo…':['A ler a foto…', 'Leyendo la foto…', 'Lettura della foto…'],'No code found in the photo. Get closer so the code fills most of the picture, and keep it sharp.':['Nenhum código encontrado na foto. Aproxime-se para o código ocupar quase toda a imagem e mantenha-o nítido.', 'No se encontró ningún código en la foto. Acérquese para que el código ocupe casi toda la imagen y manténgalo nítido.', 'Nessun codice trovato nella foto. Avvicinati perché il codice riempia quasi tutta l’immagine e tienilo nitido.'],'On a computer you can also paste a screenshot of the code (Ctrl+V).':['No computador também pode colar uma captura do código (Ctrl+V).', 'En el ordenador también puede pegar una captura del código (Ctrl+V).', 'Su computer puoi anche incollare uno screenshot del codice (Ctrl+V).'],'The camera is not available in this view. Use a photo or paste the text.':['A câmara não está disponível nesta vista. Use uma foto ou cole o texto.', 'La cámara no está disponible en esta vista. Use una foto o pegue el texto.', 'La fotocamera non è disponibile in questa vista. Usa una foto o incolla il testo.'],'No camera was found on this device.':['Nenhuma câmara encontrada neste dispositivo.', 'No se encontró ninguna cámara en este dispositivo.', 'Nessuna fotocamera trovata su questo dispositivo.'],'The camera is blocked here. Allow it in the browser, or open the app in its own browser tab. You can also use a photo or paste the text.':['A câmara está bloqueada aqui. Permita-a no navegador ou abra a aplicação no seu próprio separador. Também pode usar uma foto ou colar o texto.', 'La cámara está bloqueada aquí. Permítala en el navegador o abra la aplicación en su propia pestaña. También puede usar una foto o pegar el texto.', 'La fotocamera è bloccata qui. Consentila nel browser o apri l’app nella sua scheda. Puoi anche usare una foto o incollare il testo.'],'The camera could not be started. Use a photo or paste the text.':['Não foi possível iniciar a câmara. Use uma foto ou cole o texto.', 'No se pudo iniciar la cámara. Use una foto o pegue el texto.', 'Impossibile avviare la fotocamera. Usa una foto o incolla il testo.'],'Take a photo':['Tirar uma foto', 'Hacer una foto', 'Scatta una foto'],'Open in a new tab':['Abrir noutro separador', 'Abrir en otra pestaña', 'Apri in una nuova scheda'],'The live camera needs permission. If it stays blocked, “Take a photo” opens your camera app: take one photo per code.':['A câmara em direto precisa de permissão. Se continuar bloqueada, “Tirar uma foto” abre a app da câmara: tire uma foto por código.', 'La cámara en directo necesita permiso. Si sigue bloqueada, “Hacer una foto” abre la app de la cámara: haga una foto por código.', 'La fotocamera dal vivo richiede il permesso. Se resta bloccata, “Scatta una foto” apre l’app della fotocamera: una foto per codice.'],'The camera needs permission from the browser. Allow it when asked.':['A câmara precisa de permissão do navegador. Permita quando for pedido.', 'La cámara necesita permiso del navegador. Permítala cuando se pida.', 'La fotocamera richiede il permesso del browser. Consentila quando richiesto.'],'The camera is not available in this view.':['A câmara não está disponível nesta vista.', 'La cámara no está disponible en esta vista.', 'La fotocamera non è disponibile in questa vista.'],'This embedded view does not allow the camera. Open the app in its own tab to use it.':['Esta vista incorporada não permite a câmara. Abra a aplicação no seu próprio separador para a usar.', 'Esta vista incrustada no permite la cámara. Abra la aplicación en su propia pestaña para usarla.', 'Questa vista incorporata non consente la fotocamera. Apri l’app nella sua scheda per usarla.'],'The camera is blocked for this site. Allow it in the browser settings (padlock in the address bar), then tap “Use the camera”.':['A câmara está bloqueada para este site. Permita-a nas definições do navegador (cadeado na barra de endereço) e toque em “Usar a câmara”.', 'La cámara está bloqueada para este sitio. Permítala en los ajustes del navegador (candado en la barra de direcciones) y toque “Usar la cámara”.', 'La fotocamera è bloccata per questo sito. Consentila nelle impostazioni del browser (lucchetto nella barra degli indirizzi) e tocca “Usa la fotocamera”.'],'Camera permission was not given. Allow it in the browser (padlock in the address bar), then tap “Use the camera”.':['A permissão da câmara não foi dada. Permita-a no navegador (cadeado na barra de endereço) e toque em “Usar a câmara”.', 'No se dio permiso a la cámara. Permítala en el navegador (candado en la barra de direcciones) y toque “Usar la cámara”.', 'Permesso della fotocamera non concesso. Consentilo nel browser (lucchetto nella barra degli indirizzi) e tocca “Usa la fotocamera”.'],'The camera could not be started.':['Não foi possível iniciar a câmara.', 'No se pudo iniciar la cámara.', 'Impossibile avviare la fotocamera.'],'Share this profile and plan by QR':['Partilhar este perfil e plano por QR', 'Compartir este perfil y plan por QR', 'Condividi questo profilo e piano con QR'],'Profile and plan: {0}':['Perfil e plano: {0}', 'Perfil y plan: {0}', 'Profilo e piano: {0}'],'More options: history, everything, receive':['Mais opções: histórico, tudo, receber', 'Más opciones: historial, todo, recibir', 'Altre opzioni: storico, tutto, ricevi'],'Scan the QR code from your clinician':['Digitalizar o código QR do seu clínico','Escanear el código QR de su clínico','Scansiona il codice QR del tuo clinico'],'Data':['Dados', 'Datos', 'Dati'],'Backup, export, history':['Cópia, exportar, histórico', 'Copia, exportar, historial', 'Backup, esporta, storico'],'Back to menu ':['','','']
};
const _=(s,...a)=>{const v=S[s],i=LANGS.findIndex(l=>l[0]==LANG)-1;let r=(v&&i>=0&&v[i])||s;a.forEach((x,j)=>r=r.split('{'+j+'}').join(x));return r};


const poolOf=ty=>ty=='c'?A.ip:ty=='m'&&A.cm&&A.cm.length>=4?A.cm:A.pic;
/* ================= Task builders (touch-first, feedback only after "check") ================= */
const $=s=>document.querySelector(s),R=n=>Math.floor(Math.random()*n),pick=a=>a[R(a.length)],
shuf=a=>a.map(x=>[Math.random(),x]).sort((p,q)=>p[0]-q[0]).map(x=>x[1]),
h=(t,a={},...k)=>{const e=document.createElement(t);for(const x in a){const v=a[x];x.startsWith('on')?e[x]=v:x=='class'?e.className=v:e.setAttribute(x,v)}e.append(...k);return e};
const LET='ABCDEFGHIJKLMNOPQRSTUVWXYZ',B64=s=>'data:image/jpeg;base64,'+s,
IM=s=>h('img',{src:B64(s),alt:''}),BIG=s=>h('img',{src:B64(s),alt:'',style:'max-width:100%;max-height:340px;display:block;margin:.5rem auto;border-radius:8px'}),
strip=w=>w.normalize('NFD').replace(/[̀-ͯ]/g,'').toUpperCase();

const PALG=['#2A7FDB','#E0529C','#2FA66A','#F08A24','#8A5CD6','#17A2B8','#C9A400','#D64545'];
/* small popover anchored where the tap happened */
function popAt(ev,anchor,content,opt={}){
  const app=$('#app'),ar=app.getBoundingClientRect(),bg=h('div',{class:'ov2',onclick(e){if(e.target===bg)bg.remove()}}),pop=h('div',{class:'pop'},content);
  bg.append(pop);app.append(bg);
  const r=anchor&&anchor.getBoundingClientRect?anchor.getBoundingClientRect():null;let x,y;
  if(ev&&ev.clientX){x=ev.clientX;y=ev.clientY}else if(r){x=r.left+r.width/2;y=r.top+r.height/2}else{x=ar.left+ar.width/2;y=ar.top+ar.height/2}
  const place=()=>{const zf=(ar.width/(app.offsetWidth||ar.width))||1,w=(pop.offsetWidth||80)*zf,hh=(pop.offsetHeight||80)*zf,gap=r?r.height/2+6:16;let l=x-w/2,t=opt.center?y-hh/2:y+gap;
    if(!opt.center&&t+hh>ar.bottom-6)t=y-hh-gap;
    l=Math.max(ar.left+6,Math.min(ar.right-6-w,l));t=Math.max(ar.top+6,Math.min(ar.bottom-6-hh,t));
    pop.style.left=((l-ar.left)/zf)+'px';pop.style.top=((t-ar.top)/zf)+'px'};
  place();return{close:()=>bg.remove(),place}}
function pickBtn(opts,val,cb,title){const b=h('button',{class:'pb',type:'button'});
  const upd=()=>{const o=opts.find(x=>String(x.v)===String(b.value));b.replaceChildren(...(o&&o.c?[h('i',{style:`background:${o.c}`})]:[]),h('span',{},o?o.l:'—'),h('span',{class:'chv'},'▾'))};
  b.value=val;b.refresh=upd;
  b.open=ev=>{let P_;const pick_=v=>{P_.close();b.value=v;upd();cb&&cb(v)};
    const n=opts.length,cols=n>6?3:n>3?2:1;
    P_=popAt(ev,b,h('div',{class:'pkg',style:`grid-template-columns:repeat(${cols},auto)`},...opts.map(x=>h('button',{type:'button',class:'pko'+(String(x.v)===String(b.value)?' on':''),style:x.c?`--c:${x.c}`:'',onclick(){pick_(x.v)}},...(x.c?[h('i',{})]:[]),x.s||x.l))))};
  b.onclick=b.open;upd();return b}
/* number picker: a short column centred on the preceding number of the sequence, arrows to move beyond it */
function numPick(centerFn,a){const b=h('button',{class:'num nb',type:'button'});b.value='';b.a=a;
  const refresh=()=>{b.textContent=b.value===''?'·':b.value};b.refresh=refresh;refresh();
  b.onclick=ev=>{const c=centerFn(),ctn=h('div',{class:'nl'});let base=Math.max(3,c),P_;
    const render=()=>{const rows=[];for(let i=3;i>=-3;i--){const v=base+i;rows.push(h('button',{type:'button',class:'pko'+(String(v)===b.value?' on':'')+(v===c?' ctr':''),onclick(){P_.close();b.value=String(v);refresh()}},v))}
      ctn.replaceChildren(h('button',{type:'button',class:'ar',onclick(){base+=6;render();P_.place()}},'▲'),...rows,h('button',{type:'button',class:'ar',onclick(){base=Math.max(3,base-6);render();P_.place()}},'▼'))};
    P_=popAt(ev,b,ctn,{center:true});render();P_.place()};
  return b}
function seg(opts,cb){const d=h('div',{class:'seg'}),bs=opts.map(o=>h('button',{type:'button',class:'sgb',onclick(){d.value=o.v;bs.forEach((b,i)=>b.classList.toggle('on',opts[i].v===o.v));cb&&cb(o.v)}},o.l));d.value='';d.bs=bs;d.append(...bs);return d}
const delayNote=d=>+d>0?_('Recall in {0} min. You can do other things meanwhile.',d):_('The recall starts right after.');

/* wrong answers are shown in place: the box turns red and shows the correct value */
function gradeIn(ins){return()=>{let c=0;ins.forEach(x=>{const ok=x.value!==''&&+x.value==x.a;c+=ok;x.classList.add(ok?'ok':'bad');if(!ok){x.value=x.a;x.readOnly=true}if(x.refresh){x.refresh();x.disabled=true}});return{s:c,t:ins.length}}}

function cancel(p,box){
  const S=p.mode=='S',pool=S?A.sym.map((_,i)=>i):p.mode=='N'?[...'0123456789']:[...LET],t=pick(pool),dis=pool.filter(x=>x!==t),N=p.size*p.size,cs=[];
  const show=v=>S?h('img',{src:B64(A.sym[v]),style:'width:70%;vertical-align:middle',alt:''}):v;
  for(let i=0;i<N;i++)cs.push({T:Math.random()*100<p.pct});
  if(!cs.some(c=>c.T))cs[R(N)].T=true;
  box.append(h('p',{},PRT?_('Circle every'):_('Tap every'),' ',S?h('img',{src:B64(A.sym[t]),style:'height:1.5em;vertical-align:middle',alt:''}):h('b',{},'“'+t+'”'),' ',_('you can find.')));
  const g=h('div',{class:'grid plain',style:`grid-template-columns:repeat(${p.size},1fr)`});
  cs.forEach(c=>{c.e=h('button',{class:'cell',style:p.order=='1'?`transform:translate(${R(31)-15}%,${R(31)-15}%)`:'',onclick(){c.s=!c.s;c.e.classList.toggle('sel',c.s)}},show(c.T?t:pick(dis)));g.append(c.e)});
  box.append(g);
  return()=>{let hit=0,mis=0,fp=0;
    cs.forEach(c=>{c.e.classList.remove('sel');if(c.T&&c.s){hit++;c.e.classList.add('ok')}else if(c.T){mis++;c.e.classList.add('miss')}else if(c.s){fp++;c.e.classList.add('bad')}});
    return{s:Math.max(0,hit-fp),t:hit+mis,n:_('{0} found, {1} missed, {2} wrongly marked.',hit,mis,fp)}}}

function seq(p,box){
  const miss=Math.min(p.miss,p.len-1),ins=[];
  box.append(h('p',{},_('Fill in the missing numbers of each sequence.')));
  for(let r=0;r<6;r++){
    const d=p.order=='a'?1:p.order=='d'?-1:pick([1,-1]),st=d*p.step,f=R(10)+(d<0?p.len*p.step:0),m=p.where=='0'?0:R(p.len-miss+1),row=h('div',{class:'row seqr',style:'--n:'+p.len},h('b',{class:'seqi'},(r+1)+'.')),cells=[];
    for(let i=0;i<p.len;i++){const v=f+st*i;
      if(i>=m&&i<m+miss){const x=numPick(()=>{for(let j=i-1;j>=0;j--){const c=cells[j];if(c.x){if(c.x.value!=='')return +c.x.value}else return c.v}for(let j=i+1;j<cells.length;j++)if(!cells[j].x)return cells[j].v;return 10},v);cells.push({x});ins.push(x);row.append(x)}
      else{cells.push({v});row.append(h('span',{class:'n'},v))}}
    box.append(row)}
  return gradeIn(ins)}

function prob(p,box){
  const mx=p.dig==2?99:9,ins=[];
  box.append(h('p',{},p.kind=='w'?_('Solve the following problems.'):_('Solve the following calculations.')));
  for(let i=0;i<p.n;i++){let q,a;
    if(p.kind=='w'){[q,a]=word(Math.min(p.len,4),mx)}else{[q,a]=calc(p.len,mx)}
    const inp=h('input',{type:'number',inputmode:'numeric',class:'num'});inp.a=a;ins.push(inp);
    box.append(h('div',{class:'row probr'},h('b',{class:'seqi'},(i+1)+'.'),h('span',{},q),inp))}
  return gradeIn(ins)}

function soup(p,box){
  const N=p.size,g=Array(N*N).fill(''),pl=[],D_=[[0,1],[1,0],[1,1]],on=new Set();
  const W=shuf(D[LANG].soup.map(d=>({w:strip(d).replace(/[^A-Z]/g,''),d:d.toUpperCase()})).filter(o=>o.w.length>=3&&o.w.length<=N));
  for(const o of W){const w=o.w;if(pl.length>=p.words)break;
    for(let t=0;t<60;t++){const[dr,dc]=pick(D_),r=R(N-(dr?w.length-1:0)),c=R(N-(dc?w.length-1:0));let ok=true;
      for(let i=0;i<w.length;i++){const q=g[(r+dr*i)*N+c+dc*i];if(q&&q!=w[i])ok=false}
      if(ok){const cells=[];for(let i=0;i<w.length;i++){const k=(r+dr*i)*N+c+dc*i;g[k]=w[i];cells.push(k)}pl.push({w,d:o.d,cells});break}}}
  const gr=h('div',{class:'grid plain',style:`grid-template-columns:repeat(${N},1fr)`});
  const el=g.map((x,i)=>h('button',{class:'cell',onclick(){on.has(i)?on.delete(i):on.add(i);el[i].classList.toggle('sel',on.has(i))}},x||(g[i]=LET[R(26)])));
  el.forEach(e=>gr.append(e));
  box.append(h('p',{},PRT?_('Find {0} words (any direction) and circle them in the grid.',pl.length):_('Find {0} words (any direction). Tap the letters to mark them; tap again to unmark.',pl.length)),
    h('p',{class:'mut sm'},p.cues=='y'?pl.map(o=>o.d).join('  ·  '):pl.map(()=>'•••').join(' ')),gr);
  return()=>{const all=new Set(pl.flatMap(o=>o.cells));let hit=0,mis=0,fp=0;
    el.forEach((e,i)=>{e.classList.remove('sel');const w=all.has(i),s_=on.has(i);if(w&&s_){hit++;e.classList.add('ok')}else if(w){mis++;e.classList.add('miss')}else if(s_){fp++;e.classList.add('bad')}});
    return{s:Math.max(0,hit-fp),t:all.size,n:_('{0} found, {1} missed, {2} wrongly marked.',hit,mis,fp)}}}

function maze(p,box){
  const N=2*Math.round(p.layers*1.3)-2,op=new Set(),vis=Array(N*N).fill(0),st=[0];vis[0]=1;
  const nb=i=>{const r=Math.trunc(i/N),c=i%N,o=[];if(r>0)o.push(i-N);if(r<N-1)o.push(i+N);if(c>0)o.push(i-1);if(c<N-1)o.push(i+1);return o};
  while(st.length){const i=st[st.length-1],f=nb(i).filter(j=>!vis[j]);if(!f.length){st.pop();continue}
    const j=pick(f);vis[j]=1;op.add(i+'-'+j);op.add(j+'-'+i);st.push(j)}
  const isO=(a,b)=>op.has(a+'-'+b),el=[],g=h('div',{class:'maze',style:`grid-template-columns:repeat(${N},1fr)`});
  let path=[0];
  const draw=()=>el.forEach((e,i)=>e.classList.toggle('sel',path.includes(i)));
  for(let i=0;i<N*N;i++){const r=Math.trunc(i/N),c=i%N,w=ok=>ok?0:2;
    const e=h('div',{class:'mc',style:`border-width:${w(r>0&&isO(i,i-N))}px ${w(c<N-1&&isO(i,i+1))}px ${w(r<N-1&&isO(i,i+N))}px ${w(c>0&&isO(i,i-1))}px`,});
    el.push(e);g.append(e)}
  /* tap or drag to trace: moving over a cell extends the path, moving back over it steps back */
  const step=i=>{const k=path.indexOf(i);if(k>=0){if(k<path.length-1)path=path.slice(0,k+1)}else if(isO(path[path.length-1],i))path.push(i);draw()},
    at=(x,y)=>el.indexOf(document.elementFromPoint(x,y));
  let drag=false,lx=0,ly=0;g.style.touchAction='none';
  g.onpointerdown=e=>{const i=at(e.clientX,e.clientY);if(i<0)return;drag=true;lx=e.clientX;ly=e.clientY;try{g.setPointerCapture(e.pointerId)}catch(_e){}step(i)};
  g.onpointermove=e=>{if(!drag)return;const d=Math.hypot(e.clientX-lx,e.clientY-ly),n=Math.max(1,Math.ceil(d/6));
    for(let j=1;j<=n;j++){const i=at(lx+(e.clientX-lx)*j/n,ly+(e.clientY-ly)*j/n);if(i>=0)step(i)}lx=e.clientX;ly=e.clientY};
  g.onpointerup=g.onpointercancel=()=>{drag=false};
  el[0].textContent='▶';el[N*N-1].textContent='⚑';draw();
  box.append(h('p',{},PRT?_('Draw a path from ▶ to ⚑ with a pencil.'):_('Trace a path from ▶ to ⚑ by dragging your finger (or tapping neighbouring cells). Go back over your path to undo.')),g);
  return()=>{
    const done=path[path.length-1]==N*N-1,prev={0:-1},q=[0];
    while(q.length){const i=q.shift();for(const j of nb(i))if(isO(i,j)&&!(j in prev)){prev[j]=i;q.push(j)}}
    const sol=[];for(let i=N*N-1;i!=-1;i=prev[i])sol.push(i);
    sol.forEach(i=>{if(!path.includes(i))el[i].classList.add('miss')});
    if(done)path.forEach(i=>el[i].classList.add('ok'));
    return{s:done?1:0,t:1,n:done?_('Exit reached in {0} cells.',path.length):_('Exit not reached. The route you did not trace is in orange.')}}}

function act(p,box){
  const imp=p.type=='i',n=Math.min(p.n,6),idx=shuf([0,1,2,3,4,5]).slice(0,n).sort((a,b)=>a-b),ins=[];
  let title,steps;
  if(imp){const b=R(5)*6;steps=D[LANG].imp.slice(b,b+6)}else{const b=R(5)*7;title=D[LANG].exp[b];steps=D[LANG].exp.slice(b+1,b+7)}
  box.append(h('p',{},...(title?[_('Action:'),' ',h('b',{},title),'. ']:[]),_('Number the steps in the order they happen.')));
  shuf(idx.map((k,i)=>({t:steps[k],a:i+1}))).forEach(o=>{
    const x=pickBtn([...Array(n)].map((_x,j)=>({v:j+1,l:String(j+1)})),'',null,'');x.classList.add('nb');x.a=o.a;ins.push(x);box.append(h('div',{class:'row'},x,h('span',{},o.t)))});
  return gradeIn(ins)}

function cat(p,box){
  const wm=p.type=='m'&&A.cmcat&&A.cmcat.some(x=>x.length>=p.per),useC=!wm,useM=wm,cs=shuf(A.cat.map((c,i)=>({...c,i:[...(useC?c.i:[]),...(useM&&A.cmcat[i]?A.cmcat[i]:[])],n:D.cat[LANG][i]})).filter(c=>c.i.length>=p.per)).slice(0,p.cats),
    items=shuf(cs.flatMap((c,ci)=>shuf(c.i).slice(0,p.per).map(m=>({m,c:ci})))),
    opts=[{v:-1,l:'—'},...cs.map((_x,i)=>({v:i,l:String(i+1),s:String(i+1),c:PALG[i]}))],wrap=h('div',{class:'cgrid'});
  box.append(h('p',{},PRT?_('Sort the pictures into {0} groups of things that belong together. Write the group number under each picture; use the same number for pictures of the same kind.',cs.length):_('Sort the pictures into {0} groups of things that belong together. Tap a picture to choose its group; use the same group for pictures of the same kind.',cs.length)),wrap);
  items.forEach(o=>{o.g=-1;o.pb=pickBtn(opts,-1,v=>{o.g=+v;o.d.style.borderColor=v>=0?PALG[v]:'';o.d.style.background=v>=0?PALG[v]+'22':''},_('Group'));
    o.d=h('div',{class:'ctile'},h('button',{class:'cimg',type:'button',onclick(ev){o.pb.open(ev)}},IM(o.m)),o.pb);wrap.append(o.d)});
  return()=>{
    const cnt=cs.map(()=>cs.map(()=>0));items.forEach(o=>{o.g=+o.pb.value;if(o.g>=0)cnt[o.g][o.c]++});
    const pr=[];cnt.forEach((r,g)=>r.forEach((n,c)=>pr.push([n,g,c])));pr.sort((a,b)=>b[0]-a[0]);
    const mg={},uc=new Set();pr.forEach(([n,g,c])=>{if(n>0&&!(g in mg)&&!uc.has(c)){mg[g]=c;uc.add(c)}});
    let ok=0;items.forEach(o=>{const good=o.g>=0&&mg[o.g]===o.c;ok+=good;o.d.style.borderColor='';o.d.style.background='';o.d.classList.add(good?'ok':'bad');o.pb.disabled=true;if(!good)o.d.append(h('small',{class:'fix'},'→ '+cs[o.c].n))});
    return{s:ok,t:items.length,n:_('Groups are graded by what each group mostly contains, so the numbering does not matter.')}}}

function assoc(p,box){
  const pool=poolOf(p.type),n=p.n,ids=shuf([...Array(pool.length>>1).keys()]).slice(0,p.n),
    L=shuf(ids.map(i=>({i,s:pool[2*i]}))),Rr=shuf(ids.map(i=>({i,s:pool[2*i+1]}))),lk=new Map(),
    pal=['#2563eb','#db2777','#16a34a','#ea580c','#7c3aed','#0891b2','#ca8a04','#dc2626','#4b5563','#0d9488'];
  let sl=null;
  const mk=(o,side)=>{o.b=h('span',{class:'bdg'});o.e=h('button',{class:'pic',onclick(){tap(o,side)}},IM(o.s),o.b);return o.e};
  function paint(){[...L,...Rr].forEach(o=>{o.b.textContent='';o.b.style.background='';o.e.classList.remove('sel')});
    let k=0;lk.forEach((r,l)=>{k++;[l,r].forEach(o=>{o.b.textContent=k;o.b.style.background=pal[(k-1)%10]})});if(sl){sl.b.textContent=k+1;sl.b.style.background=pal[k%10]}}
  function tap(o,side){
    if(side=='l'){lk.delete(o);sl=sl===o?null:o}
    else if(sl){for(const[l,r]of lk)if(r===o)lk.delete(l);lk.set(sl,o);sl=null}
    paint()}
  box.append(h('p',{},PRT?_('Match each picture on the left with the one on the right that goes with it. Draw a line between them.'):_('Match each picture on the left with the one on the right that goes with it. Tap one on the left, then one on the right. Tap a linked picture on the left to undo.')),
    h('div',{class:'cols',style:`--n:${n}`},h('div',{class:'col'},...L.map(o=>mk(o,'l'))),h('div',{class:'col'},...Rr.map(o=>mk(o,'r')))));
  return()=>{let c=0;sl=null;paint();
    L.forEach(l=>{const r=lk.get(l),ok=r&&r.i===l.i;c+=!!ok;l.e.classList.add(ok?'ok':'bad');
      if(r)r.e.classList.add(ok?'ok':'bad');if(!ok)Rr.find(x=>x.i==l.i).e.classList.add('miss')});
    return{s:c,t:n,n:_('Orange marks the picture that should have been matched.')}}}

let PRT=false;
function pairs(p,box){
  const pool=poolOf(p.type),n=p.n,im=shuf(pool).slice(0,2*n),P=[...Array(n).keys()].map(i=>({a:im[2*i],b:im[2*i+1]}));
  const study=(bx,done)=>{bx.classList.add('fill');
    bx.append(h('p',{},_('Memorise these pairs.')),
      h('div',{class:'pstudy',style:`grid-template-rows:repeat(${n},minmax(0,1fr));--hr:${Math.ceil(n/2)}`},...P.map(o=>h('div',{class:'prow'},IM(o.a),h('span',{},'↔'),IM(o.b)))),
      h('p',{class:'dnote'},delayNote(p.delay)),h('button',{class:'btn big',onclick:done},_('I have memorised them')))};
  const recall=bx=>{if(PRT){const opts=shuf(P.map(o=>o.b));bx.append(h('p',{},_('Circle the picture that was paired with each one.')),...P.map((o,i)=>h('div',{class:'prq'},h('b',{},i+1+'.'),h('div',{class:'prp'},IM(o.a)),h('span',{},'→'),h('div',{class:'pro'},...opts.map(s=>{const d=h('div',{class:'pri'},h('i',{}),IM(s));d.s=s;return d})))));
      return()=>{bx.querySelectorAll('.prq').forEach((r,i)=>r.querySelectorAll('.pri').forEach(d=>{if(d.s===P[i].b)d.classList.add('ok')}));return{s:0,t:n}}}
    bx.classList.add('fill');
    const opts=shuf(P.map(o=>o.b));let q=0,fin=false;P.forEach(o=>o.pick=null);
    const head=h('div',{class:'qdots'}),prompt=h('div',{class:'qprompt'}),og=h('div',{class:'ogrid',style:`--c:${n<=4?2:3};--r:${Math.ceil(n/(n<=4?2:3))}`});
    function paint(){head.replaceChildren(...P.map((o,i)=>h('button',{class:'qd'+(i==q?' c':'')+(o.pick?' d':''),onclick(){q=i;paint()}},i+1)));
      prompt.replaceChildren(IM(P[q].a));
      og.replaceChildren(...opts.map(s=>h('button',{class:'pic'+(P[q].pick===s?' sel':''),onclick(){if(fin)return;P[q].pick=s;if(q<n-1)q++;paint()}},IM(s))))}
    bx.append(h('p',{},_('Which picture was paired with this one?')),head,prompt,og);paint();
    return()=>{fin=true;let c=0;P.forEach(o=>{if(o.pick===o.b)c++});
      bx.replaceChildren(h('p',{},_('Your answers')),h('div',{class:'pstudy',style:`grid-template-rows:repeat(${n},minmax(0,1fr));--hr:${Math.ceil(n/2)}`},...P.map(o=>{const ok=o.pick===o.b;
        return h('div',{class:'prow rev'},IM(o.a),h('span',{},'→'),h('div',{class:'two2'},...(ok?[h('span',{class:'ok'},IM(o.b))]:[o.pick?h('span',{class:'bad'},IM(o.pick)):h('span',{class:'bad nan'},'—'),h('span',{class:'ok'},IM(o.b))])))})));
      return{s:c,t:n,n:_('Red = your answer; green = the correct partner.')}}};
  return{two:true,study,recall}}

function ctx(p,box){
  const useM=p.type=='m'&&A.cmx&&A.cmx.length>0,useC=!useM,sc=[...(useC?A.ctx.img.map((_x,j)=>[0,j]):[]),...(useM?A.cmx.map((_x,j)=>[1,j]):[])],[sm,k]=pick(sc),d=D[LANG],li=LANGS.findIndex(l=>l[0]==LANG),
    pool=shuf(sm?[...A.cmx[k].c[li].map(t=>({t,v:1})),...A.cmx[k].i[li].map(t=>({t,v:0}))]:[...d.ctxC.slice(5*k,5*k+5).map(t=>({t,v:1})),...d.ctxI.slice(5*k,5*k+5).map(t=>({t,v:0}))]).slice(0,p.n);
  box.append(h('p',{},_('Look at the picture and decide whether each statement is correct or incorrect.')),BIG(sm?A.cmx[k].img:A.ctx.img[k]));
  pool.forEach((o,i)=>{o.s=seg([{v:1,l:'✓ '+_('Correct')},{v:0,l:'✗ '+_('Incorrect')}]);
    o.d=h('div',{class:'ctx'},h('span',{},`${i+1}. ${o.t}`),o.s);box.append(o.d)});
  return()=>{let c=0;pool.forEach(o=>{const ok=o.s.value!==''&&+o.s.value===o.v;c+=ok;o.d.classList.add(ok?'ok':'bad');
    o.s.bs.forEach((b,j)=>{b.disabled=true;if((j==0?1:0)===o.v)b.classList.add('right')});
    0});
    return{s:c,t:pool.length}}}

function stories(p,box){
  const ty0=+p.type,img=ty0>=3,cm=ty0==4&&A.cmx&&A.cmq,ty=img?3:ty0,li=LANGS.findIndex(l=>l[0]==LANG),cap=cm?5:[4,6,10,9][ty],n=Math.min(p.n,cap),d=D[LANG];
  let src,qs;
  if(img){const k=R(cm?A.cmx.length:A.st.img.length);src=h('div',{class:'src'},h('img',{src:B64(cm?A.cmx[k].img:A.st.img[k]),alt:'',style:'max-width:100%;max-height:100%;object-fit:contain;border-radius:8px'}));qs=cm?A.cmq[k][li]:d.st_correct.slice(9*k,9*k+9)}
  else{const T_=[d.st_textShort,d.st_textMedium,d.st_textLong][ty],Q=[d.st_correctShort,d.st_correctMedium,d.st_correctLong][ty],k=R(T_.length);src=h('div',{class:'src txt'},h('p',{style:'font-size:1.1rem;margin:0'},T_[k]));qs=Q.slice(cap*k,cap*k+cap)}
  qs=shuf(qs).slice(0,n);
  const study=(bx,done)=>{bx.classList.add('fill');
    bx.append(h('p',{},img?_('Observe the picture for about 2 minutes, then continue.'):_('Read the story carefully, then continue.')),src,
      h('p',{class:'dnote'},delayNote(p.delay)),h('button',{class:'btn big',onclick:done},_('Hide it and continue')))};
  const recall=bx=>{if(PRT){bx.append(h('p',{},_('Answer each question from memory.')),...qs.map((q,i)=>h('div',{class:'row'},h('b',{},`${i+1}. ${q}`),h('div',{class:'wline'}),h('div',{class:'wline'}))));return()=>({s:0,t:qs.length})}
    const marks=[],rows=[];let shown=false;
    const srcBox=h('div',{class:'hid'},src),show=h('button',{class:'btn alt',onclick(){shown=!shown;srcBox.classList.toggle('hid',!shown);src.className='src2';show.textContent=shown?_('Hide the story again'):_('Check against the story')}},_('Check against the story'));
    bx.append(h('p',{},_('Answer each question from memory (aloud), check against the story if you wish, then tap whether you were right.')),show,srcBox,...qs.map((q,i)=>{
      marks[i]=null;const y=h('button',{class:'tab',onclick(){marks[i]=1;y.classList.add('on');no.classList.remove('on')}},'✓ '+_('Correct')),
        no=h('button',{class:'tab',onclick(){marks[i]=0;no.classList.add('on');y.classList.remove('on')}},'✗ '+_('Incorrect'));
      rows[i]=h('div',{class:'row'},h('b',{},`${i+1}. ${q}`),h('div',{class:'two'},y,no));rows[i].bt=[y,no];return rows[i]}));
    return()=>{let c=0;rows.forEach((d_,i)=>{c+=marks[i]==1;d_.classList.add(marks[i]==1?'ok':'bad');d_.bt.forEach(x=>x.disabled=true)});
      return{s:c,t:qs.length,n:_('Scored from your own marking: the original exercise has no answer key to check automatically.')}}};
  return{two:true,study,recall}}

/* ---- registry (English keys are translated at display time with _()) ---- */
const T={
  cancel:{n:'Cancellation',d:'Find and mark every target character in a grid.',b:cancel,p:[
    {id:'size',l:'Grid size',d:10,min:3,max:16},{id:'pct',l:'Targets (%)',d:15,min:5,max:90},{id:'mode',l:'Content',d:'L',o:[['L','Letters'],['N','Numbers'],['S','Symbols']]},
    {id:'order',l:'Organisation',d:'0',o:[['0','Ordered'],['1','Not ordered']]}]},
  seq:{n:'Number sequencing',d:'Complete number sequences that have missing elements.',b:seq,p:[
    {id:'len',l:'Sequence length',d:12,min:5,max:14},{id:'miss',l:'Missing numbers',d:3,min:1,max:6},{id:'step',l:'Step size',d:2,min:1,max:9},
    {id:'order',l:'Order',d:'x',o:[['a','Ascending'],['d','Descending'],['x','Any']]},{id:'where',l:'Missing position',d:'1',o:[['1','Any'],['0','Beginning']]}]},
  prob:{n:'Problem solving',d:'Solve calculations or short word problems.',b:prob,p:[
    {id:'n',l:'Problems',d:5,min:1,max:10},{id:'dig',l:'Digits',d:'1',o:[['1','Under 10'],['2','Under 100']]},{id:'kind',l:'Type',d:'a',o:[['a','Calculations'],['w','Word problems']]},
    {id:'len',l:'Problem length',d:3,min:2,max:9}]},
  soup:{n:'Word search',d:'Find hidden words in a grid of letters.',b:soup,p:[
    {id:'words',l:'Words',d:5,min:1,max:19},{id:'size',l:'Grid size',d:10,min:7,max:19},{id:'cues',l:'Word list',d:'y',o:[['y','Show words'],['n','Hide words']]}]},
  maze:{n:'Labyrinth',d:'Trace the path from the entrance to the exit.',b:maze,p:[{id:'layers',l:'Layers',d:3,min:3,max:10}]},
  act:{n:'Action sequencing',d:'Put the steps of an everyday action in the right order.',b:act,p:[
    {id:'type',l:'Type',d:'e',o:[['e','Explicit (titled)'],['i','Implicit']]},{id:'n',l:'Steps',d:4,min:2,max:6}]},
  cat:{n:'Categorization',d:'Group pictures into the categories they belong to.',b:cat,p:[
    {id:'cats',l:'Categories',d:3,min:2,max:8},{id:'per',l:'Items per category',d:3,min:1,max:8},{id:'type',l:'Stimuli',d:'c',o:[['c','Clipart'],['m','Commons photos']]}]},
  assoc:{n:'Association',d:'Match pictures that go together.',b:assoc,p:[{id:'n',l:'Pairs',d:5,min:2,max:19},{id:'type',l:'Stimuli',d:'c',o:[['c','Clipart'],['p','Pictures'],['m','Commons photos']]}]},
  ctx:{n:'Context',d:'Judge whether statements about a picture are correct.',b:ctx,p:[{id:'n',l:'Statements',d:5,min:1,max:10},{id:'type',l:'Stimuli',d:'c',o:[['c','Clipart'],['m','Commons photos']]}]},
  pairs:{n:'Image pairs',d:'Memorise pairs of pictures, then recall them.',b:pairs,p:[{id:'n',l:'Pairs',d:4,min:1,max:8},{id:'type',l:'Stimuli',d:'c',o:[['c','Clipart'],['p','Pictures'],['m','Commons photos']]},{id:'delay',l:'Recall delay (min)',d:30,min:0,max:60}]},
  stories:{n:'Memory recall',d:'Study a story or picture, then answer questions from memory.',b:stories,p:[
    {id:'type',l:'Material',d:'0',o:[['0','Short text'],['1','Medium text'],['2','Long text'],['3','Pictures'],['4','Commons photos']]},{id:'n',l:'Questions',d:4,min:1,max:10},{id:'delay',l:'Recall delay (min)',d:1,min:0,max:60}]}
};

/* ---- Original NeuroRehabLab models: each returns [attention, memory, executive, language, difficulty] ---- */
const DIMS=['Attention','Memory','Executive functions','Language','Difficulty'];
const M={
  cancel:p=>{const E=p.size*p.size,D=E*(100-p.pct)/100,Tg=E-D,L=p.mode=='L'?1:0,N=p.mode=='N'?1:0,S=p.mode=='S'?1:0,O=+p.order;
    return[4.314+D*.014-.697*N+Tg*.021,3.125+D*.009+Tg*.017-.813*N,3.579+D*.009-1.463*L-.754*N+Tg*.015+O*.683+D*L*.015,2.433+D*.011+.42*S-.467*N,3.61+D*.015+Tg*.012-.494*L-1.054*N]},
  seq:p=>{const a=p.order=='a'?1:p.order=='d'?0:.5,m=p.miss,pos=p.where=='1'?(p.len-m)/2:0;
    return[6.923-.02*m-.003*pos,5.364-.027*m-.003*pos,6.682-.014*m-.002*pos,4.722-.02*m-.003*pos,1.29+p.step*1.232-.841*a]},
  prob:p=>{const w=p.kind=='w',s=w?Math.min(p.len,4):p.len;return[6.97,6.1,7.23,4.65+(w?1.1:0),4.87+s*.542+(p.dig=='2'?.365:0)]},
  soup:p=>{const c=p.cues=='y'?1:0,n=p.words;return[6.15-.7*c+.144*n,4-c+.269*n,5.138-.913*c+.171*n,5.65,5.466-1.154*c+.176*n]},
  maze:p=>{const e=p.layers/2;return[2.876+1.2*e,1.867+e,2.39+1.375*e,2.233+.525*e,1.733+1.45*e]},
  act:p=>{const s=Math.min(p.n,6),t=p.type=='e'?1:0;return[2.9+.75*s-1.1*t,1.507+.635*s,2.838+.487*s,3.325+.525*s-1.2*t,1.95+.862*s-1.325*t]},
  cat:p=>{const c=+p.cats,e=+p.per;return[-3.26+3.75*c-.41*c*e,.6+.9*c,1.136+.989*c,1.914+.586*c,.234+1.165*c]},
  assoc:p=>{const s=p.n;return[1.512+.487*s,1.378+.4*s,2.729+.238*s,3.28,1.435+.45*s]},
  ctx:p=>{const s=p.n;return[3.4,2.63,.25+1.2*s,1.45+s,1.05+.75*s]},
  pairs:p=>{const s=p.n;return[3.811+.587*s,3.792+.637*s,3.491+.412*s,2.716+.388*s,2.54+.762*s]},
  stories:p=>{const ty=Math.min(3,+p.type),q=Math.min(p.n,+p.type==4?5:[4,6,10,9][ty]),sz=ty==3?1:ty,t=ty==3?0:1;
    return[2.618+t*1.025+q*.454,1.95+t*1.05+q*.5,1.9+sz*1.45,1.461+t*1.575+q*.382,1.298+t*.937+q*.545]}
};
/* ---- Parameter grids searched by the original generateTraining() ---- */
const rng=(a,b,s=1)=>{const r=[];for(let i=a;i<=b;i+=s)r.push(i);return r},
prod=o=>Object.entries(o).reduce((a,[k,v])=>a.flatMap(x=>v.map(y=>({...x,[k]:y}))),[{}]);
const G={
  cancel:()=>prod({size:rng(3,16),pct:rng(5,85,5),mode:['L','N','S'],order:['0','1']}),
  seq:()=>prod({len:[12],step:rng(1,8),order:['x','d','a'],where:['1','0'],miss:rng(1,5)}),
  prob:()=>prod({len:rng(2,9),dig:['1','2'],kind:['a','w']}).filter(p=>p.kind=='a'||p.len<=4),
  soup:()=>prod({words:rng(1,19),cues:['n','y']}),
  maze:()=>prod({layers:rng(3,10)}),
  act:()=>prod({n:rng(2,6),type:['i','e']}),
  cat:()=>prod({cats:rng(2,8),per:rng(2,8)}),
  assoc:()=>prod({n:rng(2,19)}),
  ctx:()=>prod({n:rng(3,9)}),
  pairs:()=>prod({n:rng(1,7)}),
  stories:()=>prod({n:rng(1,10),type:['0','1','2','3']}).filter(p=>p.n<=[4,6,10,9][+p.type])
};

const WP={
 en:{names:['John','Maria','Anna','Fred','Kate','Dan'],objs:['apples','cards','cookies','pencils','tickets'],
  t:['{N} had {x} {o} and found {y} more. How many {o} does {N} have now?','{N} had {x} {o} and lost {y}. How many {o} are left?','{N} has {a} friends and gives each of them {b} {o}. How many {o} are given away in total?',
     '{N} had {x} {o}, found {y} more and then lost {c}. How many {o} does {N} have now?','{N} has {a} boxes with {b} {o} each and {c} boxes with {d} {o} each. How many {o} does {N} have in total?']},
 pt:{names:['João','Maria','Ana','Mónica','Afonso','Eva','Teresa','André'],objs:['maçãs','cartas','bolachas','canetas','moedas'],
  t:['{N} tinha {x} {o} e encontrou mais {y}. Quantas {o} tem {N} agora?','{N} tinha {x} {o} e perdeu {y}. Quantas {o} ficaram?','{N} tem {a} amigos e dá {b} {o} a cada um. Quantas {o} deu no total?',
     '{N} tinha {x} {o}, encontrou mais {y} e depois perdeu {c}. Quantas {o} tem {N} agora?','{N} tem {a} caixas com {b} {o} cada e {c} caixas com {d} {o} cada. Quantas {o} tem {N} no total?']},
 es:{names:['Juan','María','Ana','Luis','Carla','Pedro'],objs:['manzanas','tarjetas','galletas','plumas','monedas'],
  t:['{N} tenía {x} {o} y encontró {y} más. ¿Cuántas {o} tiene {N} ahora?','{N} tenía {x} {o} y perdió {y}. ¿Cuántas {o} le quedan?','{N} tiene {a} amigos y le da {b} {o} a cada uno. ¿Cuántas {o} regala en total?',
     '{N} tenía {x} {o}, encontró {y} más y luego perdió {c}. ¿Cuántas {o} tiene {N} ahora?','{N} tiene {a} cajas con {b} {o} cada una y {c} cajas con {d} {o} cada una. ¿Cuántas {o} tiene {N} en total?']},
 it:{names:['Giovanni','Maria','Anna','Luca','Chiara','Paolo'],objs:['mele','carte','caramelle','matite','penne'],
  t:['{N} aveva {x} {o} e ha trovato {y} {o} in più. Quante {o} ha {N} adesso?','{N} aveva {x} {o} e ha perso {y} {o}. Quante {o} restano?','{N} ha {a} amici e dà {b} {o} a ciascuno. Quante {o} regala in totale?',
     '{N} aveva {x} {o}, ha trovato {y} {o} in più e poi ha perso {c} {o}. Quante {o} ha {N} adesso?','{N} ha {a} scatole con {b} {o} ciascuna e {c} scatole con {d} {o} ciascuna. Quante {o} ha {N} in totale?']}};
function word(s,mx){
  const w=WP[LANG],rn=m=>1+R(m),N=pick(w.names),o=pick(w.objs),x=rn(mx),y=rn(mx),f=(i,v)=>w.t[i].replace(/\{(\w)\}/g,(_m,k)=>({N,o,...v})[k]);
  if(s==3){const c=Math.min(rn(mx),x+y);return[f(3,{x,y,c}),x+y-c]}
  if(s>=4){const a=rn(9),b=rn(9),c=rn(9),d=rn(9);return[f(4,{a,b,c,d}),a*b+c*d]}
  const k=R(3);
  if(k==0)return[f(0,{x,y}),x+y];
  if(k==1){const A_=Math.max(x,y),B=Math.min(x,y);return[f(1,{x:A_,y:B}),A_-B]}
  const a=rn(9),b=rn(9);return[f(2,{a,b}),a*b]}
function calc(len,mx){
  const rn=m=>1+R(m);
  for(;;){const t=[],ops=[];
    for(let i=0;i<len;i++){t.push(rn(mx));if(i<len-1)ops.push(pick(['+','+','+','−','−','×']))}
    ops.forEach((o,i)=>{if(o=='×'){t[i]=rn(9);t[i+1]=rn(9)}});
    const v=[t[0]],os=[];ops.forEach((o,i)=>{if(o=='×')v[v.length-1]*=t[i+1];else{os.push(o);v.push(t[i+1])}});
    let a=v[0];os.forEach((o,i)=>a=o=='+'?a+v[i+1]:a-v[i+1]);
    if(a>=0)return[t.map((x,i)=>i<ops.length?x+' '+ops[i]+' ':x).join('')+' =',a]}}

function bars(v,tg){
  return h('div',{class:'bars'},...DIMS.map((d,i)=>{const x=v[i],r=Math.min(255,Math.max(0,Math.round(255/8*x))),g=Math.max(0,Math.min(255,Math.round(255-155/8*x)));
    return h('div',{class:'br'},h('span',{},_(d)),h('div',{class:'trk'},h('div',{class:'fill',style:`width:${Math.max(0,Math.min(100,x*10))}%;background:rgb(${r},${g},0)`}),
      tg?h('i',{class:'tick',style:`left:calc(${Math.min(100,tg[i]*10)}% - 1px)`}):''),h('b',{},x.toFixed(1)))}))}

/* ===================== NeuroRehabLab app shell ===================== */
const MEM={},LS={get(k,d){if(k in MEM)return MEM[k];try{const v=JSON.parse(localStorage.getItem(k));return v==null?d:v}catch(e){return d}},set(k,v){MEM[k]=v;try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
let PS=LS.get('tg2_ps',{}),CUR=LS.get('tg2_cur',''),hist=LS.get('tg2_h',[]),FOC=LS.get('tg2_f',{d:[],k:[]});
if(!PS[CUR])CUR=Object.keys(PS)[0]||'';
const saveP=(touch)=>{if(touch&&PS[CUR])PS[CUR].upd=Date.now();LS.set('tg2_ps',PS);LS.set('tg2_cur',CUR)},saveH=()=>LS.set('tg2_h',hist.slice(-3000)),
 P=()=>PS[CUR],pv=()=>P()?P().v:[3,3,3,3,3],myH=()=>hist.filter(x=>(x.u||'')==CUR),KS=Object.keys(T),
 def=k=>Object.fromEntries(T[k].p.map(q=>[q.id,q.d])),fmt=x=>Number.isInteger(+x)?String(+x):(+x).toFixed(1),
 fixp=(k,c)=>{const p={...def(k),...c};if(k=='soup')p.size=Math.max(10,p.words);return p},
 clampP=(k,p)=>{const o={...p};T[k].p.forEach(q=>{if(!q.o){const n=+o[q.id];o[q.id]=Math.min(q.max,Math.max(q.min,isNaN(n)||o[q.id]===''?q.d:n))}});return o},
 sq=(m,v,n)=>m.slice(0,n).reduce((s,x,i)=>s+(x-v[i])**2,0);

/* ---------- icons ---------- */
const ICON={target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/>',
 list:'<path d="M9 6h11M9 12h11M9 18h11"/><circle cx="4.5" cy="6" r="1"/><circle cx="4.5" cy="12" r="1"/><circle cx="4.5" cy="18" r="1"/>',
 puzzle:'<rect x="3" y="3" width="8" height="8" rx="2.5"/><rect x="13" y="3" width="8" height="8" rx="2.5"/><rect x="3" y="13" width="8" height="8" rx="2.5"/><rect x="13" y="13" width="8" height="8" rx="2.5" transform="rotate(12 17 17)"/>',
 timer:'<circle cx="12" cy="13" r="8"/><path d="M12 9v4l3 2M9 2h6"/>',chart:'<path d="M5 20V11M12 20V4M19 20v-6"/>',db:'<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v6c0 1.7 3.1 3 7 3s7-1.3 7-3V6M5 12v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/>',user:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>'};
const ic=n=>{const s=h('span',{class:'ic'});s.innerHTML=`<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON[n]}</svg>`;return s};

/* ---------- charts (% correct; 50-70% target band) ---------- */
function chart(L,o={}){
  if(!L.length)return o.small?'':h('p',{class:'mut'},_('No attempts yet.'));
  const W=320,H=o.small?44:o.h||130,l=o.small?6:30,r=8,t=14,b=o.small?4:14,X=i=>l+(L.length<2?(W-l-r)/2:i*(W-l-r)/(L.length-1)),Y=v=>t+(H-t-b)*(1-v/100),
    col=v=>v>70?'var(--hi)':v<50?'var(--lo)':'var(--good)';
  let s=`<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto;max-height:${o.small?44:260}px" role="img" aria-label="${_('Performance chart')}"><rect x="${l}" y="${Y(70)}" width="${W-l-r}" height="${Y(50)-Y(70)}" style="fill:var(--good);fill-opacity:.2"/>`;
  if(!o.small)[0,50,70,100].forEach(v=>s+=`<line x1="${l}" x2="${W-r}" y1="${Y(v)}" y2="${Y(v)}" style="stroke:var(--bd)"/><text x="${l-5}" y="${Y(v)+4}" text-anchor="end" font-size="11" style="fill:var(--mut)">${v}</text>`);
  if(!o.small)s+=`<line x1="${l}" x2="${l}" y1="${Y(100)}" y2="${Y(0)}" style="stroke:var(--mut)"/><text x="4" y="${t-4}" font-size="10" style="fill:var(--mut)">%</text>`;
  s+=`<polyline fill="none" style="stroke:var(--mut)" stroke-width="1.5" points="${L.map((v,i)=>X(i)+','+Y(v)).join(' ')}"/>`+L.map((v,i)=>`<circle cx="${X(i)}" cy="${Y(v)}" r="${o.small?2.5:4}" style="fill:${col(v)}"/>`).join('')+(o.small?'':L.map((v,i)=>`<circle class="hit" data-i="${i}" cx="${X(i)}" cy="${Y(v)}" r="11" tabindex="0" style="fill:transparent;cursor:pointer;outline:none"/>`).join(''))+'</svg>';
  const d=h('div',{style:'position:relative'});d.innerHTML=s;
  if(!o.small)try{const tip=h('div',{class:'ctip',role:'status'});d.append(tip);const svg=d.querySelector('svg');
    const show=c=>{const i=+c.dataset.i,v=L[i],t=o.t&&o.t[i],cr=c.getBoundingClientRect(),dr=d.getBoundingClientRect();
      tip.innerHTML='<b>'+v+'%</b>'+(t?'<span>'+new Date(t).toLocaleDateString(LANG,{day:'numeric',month:'short'})+' '+new Date(t).toLocaleTimeString(LANG,{hour:'2-digit',minute:'2-digit'})+'</span>':'')+(o.k&&o.k[i]?'<span>'+o.k[i]+'</span>':'');
      tip.style.display='flex';const w=tip.offsetWidth;let x=cr.left+cr.width/2-dr.left-w/2;x=Math.max(0,Math.min(dr.width-w,x));tip.style.left=x+'px';tip.style.top=Math.max(0,cr.top-dr.top-tip.offsetHeight-8)+'px'};
    const hide=()=>{tip.style.display='none'};
    svg.querySelectorAll('.hit').forEach(c=>{c.addEventListener('mouseenter',()=>show(c));c.addEventListener('focus',()=>show(c));c.addEventListener('click',()=>show(c));c.addEventListener('mouseleave',hide);c.addEventListener('blur',hide)});
    document.addEventListener('click',e=>{if(!d.contains(e.target))hide()},{passive:true})}catch(e){}
  return d}
const cx=(L,o)=>chart(L.map(x=>x.pct),{...o,t:L.map(x=>x.t),k:L.map(x=>x.k?tn(x.k):'')}),
 perf=(k,o={})=>{const H=myH().filter(x=>!k||x.k==k).slice(-(o.n||15));return chart(H.map(x=>x.pct),{...o,t:H.map(x=>x.t),k:H.map(x=>tn(x.k))})},
 rowBars=a=>h('div',{class:'bars'},...a.map(x=>h('div',{class:'br'},h('span',{},x.l),h('div',{class:'trk'},h('div',{class:'fill',style:`width:${x.v}%;background:${x.v>70?'var(--hi)':x.v<50?'var(--lo)':'var(--good)'}`}),h('i',{class:'tick',style:'left:50%'}),h('i',{class:'tick',style:'left:70%'})),h('b',{},x.v+'%')))),
 mini=v=>h('div',{class:'mini'},...DIMS.map((l,i)=>h('div',{},h('i',{style:`height:${Math.max(8,Math.min(100,v[i]*10))}%`}),h('small',{},_(l).slice(0,3)))));

/* ---------- personalised difficulty ladder ---------- */
const LD={};
function ladder(k){const v=pv(),key=k+'|'+v.join();if(LD[key])return LD[key];
  const bins=new Map();
  G[k]().forEach(c=>{const p=fixp(k,c),m=M[k](p),b=Math.round(m[4]/.75),e=sq(m,v,4),o=bins.get(b);if(!o||e<o.e)bins.set(b,{p,e})});
  return LD[key]=[...bins.entries()].sort((a,b)=>a[0]-b[0]).map(e=>e[1].p)}
function lvl(k){const L=ladder(k),P_=P();if(!P_)return 0;P_.lev=P_.lev||{};
  if(P_.lev[k]==null){const d=pv()[4];P_.lev[k]=L.reduce((b,x,i)=>Math.abs(M[k](x)[4]-d)<Math.abs(M[k](L[b])[4]-d)?i:b,0)}
  return Math.min(P_.lev[k],L.length-1)}
function best(k){const v=pv();let b=null,be=1e12;for(const c of G[k]()){const p=fixp(k,c),m=M[k](p),e=sq(m,v,5);if(e<be){be=e;b={p,m,e}}}return b}
function elig(){
  if(FOC.k.length)return FOC.k;
  if(FOC.d.length){const r=KS.filter(k=>{const v=M[k](ladder(k)[lvl(k)]),m=(v[0]+v[1]+v[2]+v[3])/4;return FOC.d.reduce((a,d)=>a+v[d],0)/FOC.d.length>=m});if(r.length)return r}
  return KS}
const lastL={};
function nextTask(){const e=elig(),ls=k=>{const x=hist.filter(q=>q.k==k&&q.m=='adaptive'&&(q.u||'')==CUR).pop();return Math.max(x?x.t:0,lastL[k]||0)},busy=new Set(pend.map(x=>x.k)),e2=e.filter(k=>!busy.has(k)),pool=e2.length?e2:e,m=Math.min(...pool.map(ls));return pick(pool.filter(k=>ls(k)==m))}
const startA=()=>{const k=nextTask();launch(k,ladder(k)[lvl(k)],'adaptive')};



/* ---------- data: export / import / backup ---------- */
const hkey=x=>x.t+'|'+x.k+'|'+(x.u||''),
 stamp=d=>{d=d||new Date();const p=n=>String(n).padStart(2,'0');return d.getFullYear()+p(d.getMonth()+1)+p(d.getDate())+'-'+p(d.getHours())+p(d.getMinutes())},
 fdate=t=>new Date(t).toLocaleString(LANG=='en'?'en-GB':LANG,{dateStyle:'short',timeStyle:'short'});
function buildExport(names){
  const users={};names.forEach(n=>{if(PS[n])users[n]={...PS[n],upd:PS[n].upd||0}});
  return{app:'task-generator',format:1,exportedAt:new Date().toISOString(),exportedAtMs:Date.now(),scope:names.length==Object.keys(PS).length?'all':'one',
    users,history:hist.filter(x=>users[x.u||'']).map(x=>({...x,id:hkey(x)}))}}
function parseImport(txt){
  let d;try{d=JSON.parse(txt)}catch(e){return{err:'bad'}}
  if(!d||d.app!='task-generator'||typeof d.users!='object'||!Array.isArray(d.history))return{err:'fmt'};
  const users={},hs=[];let drop=0;
  Object.entries(d.users||{}).forEach(([n,p])=>{if(p&&Array.isArray(p.v)&&p.v.length>=5&&p.v.every(x=>isFinite(+x)))users[n]={v:p.v.slice(0,5).map(Number),cc:p.cc!==false,lev:(p.lev&&typeof p.lev=='object')?p.lev:{},upd:+p.upd||0,rx:p.rx&&Array.isArray(p.rx.days)?p.rx:undefined,done:Array.isArray(p.done)?p.done.map(Number).filter(isFinite):[]};else drop++});
  d.history.forEach(x=>{if(x&&isFinite(+x.t)&&T[x.k]&&isFinite(+x.pct)&&Array.isArray(x.v)&&users[x.u||''])hs.push({t:+x.t,k:x.k,m:x.m,u:x.u||'',pct:+x.pct,v:x.v.map(Number)});else drop++});
  return{users,hist:hs,drop,at:d.exportedAt||'',scope:d.scope}}
function mkBackup(why){LS.set('tg2_bk',{at:Date.now(),why,ps:PS,cur:CUR,hist,foc:FOC})}
function applyImport(im,names,mode){
  mkBackup('import');const r={added:0,dup:0,upd:0,newU:0,rep:0};
  const have=new Set(hist.map(hkey));
  names.forEach(n=>{const p=im.users[n],mine=im.hist.filter(x=>x.u==n);
    if(mode=='replace'){if(PS[n])r.rep++;else r.newU++;if(!p.rx)delete p.rx;hist=hist.filter(x=>(x.u||'')!=n);PS[n]=p;mine.forEach(x=>{hist.push(x);r.added++})}
    else{if(!PS[n]){PS[n]=p;r.newU++}else{const dn=[...new Set([...(PS[n].done||[]),...(p.done||[])])].sort((a,b)=>a-b);if(p.upd>(PS[n].upd||0)){PS[n]=p;r.upd++}PS[n].done=dn}
      mine.forEach(x=>{if(have.has(hkey(x)))r.dup++;else{hist.push(x);have.add(hkey(x));r.added++}})}});
  hist.sort((a,b)=>a.t-b.t);if(!PS[CUR])CUR=Object.keys(PS)[0]||'';
  saveP();LS.set('tg2_h',hist.slice(-3000));return r}
function restoreBackup(){
  const b=LS.get('tg2_bk',null);if(!b)return false;
  const cur={at:Date.now(),why:'undo',ps:PS,cur:CUR,hist,foc:FOC};
  PS=b.ps||{};CUR=PS[b.cur]?b.cur:(Object.keys(PS)[0]||'');hist=b.hist||[];saveP();LS.set('tg2_h',hist);LS.set('tg2_bk',cur);return true}
const b64of=d=>{if(typeof d=='string'){return btoa(unescape(encodeURIComponent(d)))}let s='';const a=new Uint8Array(d);for(let i=0;i<a.length;i+=8192)s+=String.fromCharCode.apply(null,a.subarray(i,i+8192));return btoa(s)};
function bridgeSave(name,data,mime){try{if(window.AndroidBridge&&AndroidBridge.save){AndroidBridge.save(name,mime||'application/octet-stream',b64of(data));return true}}catch(e){}return false}
window.__back=()=>{try{if(['home','phome','role','pdone'].includes(scr)&&!document.querySelector('.ov2'))return false;if(document.querySelector('.ov2')){document.querySelectorAll('.ov2').forEach(e=>e.remove());return true}if(!$('#pv').classList.contains('hid')){pvClose();return true}goBack();return true}catch(e){return false}};
async function saveFile(name,text){
  if(bridgeSave(name,text,'application/json'))return'ok';
  try{const dl=window.claude&&claude.use?await claude.use('downloads'):null;
    if(dl){await dl.save({filename:name,data:text});return'ok'}}catch(e){if(e&&e.code=='declined')return'declined'}
  try{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:'application/json'}));a.download=name;document.body.append(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500);return'ok'}catch(e){return'fail'}}

/* picture sources: c = clip art, p = validated photos, m = Commons photos */
const SRCN={c:'Clipart',p:'Pictures',m:'Commons photos'},srcAvail=x=>x!='m'||(A.cm&&A.cm.length>=4),
 srcOf=()=>{const a=LS.get('tg2_src',['c','p']);return (Array.isArray(a)?a:['c','p']).filter(x=>x in SRCN)},
 srcOn=()=>{const a=srcOf().filter(srcAvail);return a.length?a:['c','p']},pickSrc=()=>pick(srcOn());

/* ===================== roles, prescriptions, adherence ===================== */
let ROLE=LS.get('tg2_role',''),RXs=null,oldFOC=null,pickMode=false;
const DAYS=7,dname=i=>new Date(2024,0,1+i).toLocaleDateString(LANG,{weekday:'short'}).replace('.','').slice(0,3),
 dlong=i=>new Date(2024,0,1+i).toLocaleDateString(LANG,{weekday:'long'}),
 rxOf=p=>p.rx||(p.rx={on:false,days:[0,2,4],minutes:15,mode:'adaptive',d:[],k:[],note:'',from:0}),
 getBig=()=>Math.min(2,+LS.get('tg2_big',0)||0),
 setBig=v=>{v=v===true?1:v===false?0:+v||0;LS.set('tg2_big',v);try{const c=document.documentElement.classList;c.toggle('big',v>=1);c.toggle('big2',v>=2);const st=document.documentElement.style;st.fontSize=[16,20,24][v]+'px';st.setProperty('--zb',[1,1.25,1.5][v])}catch(e){}try{const b=document.querySelector('#bigb');if(b)b.innerHTML='A'+['','<sup>+</sup>','<sup>++</sup>'][v]}catch(e){}},
 setRole=r=>{ROLE=r;LS.set('tg2_role',r);if(r=='patient'&&LS.get('tg2_big',null)===null)setBig(1)};
setBig(getBig());
function mdl(...c){const o=h('div',{class:'ov2 mdl'},h('div',{class:'mbox'},...c));$('#app').append(o);return o}
const DAYMS=86400000,rxStart=rx=>{const d=new Date(rx.from||0);return +new Date(d.getFullYear(),d.getMonth(),d.getDate())},rxEnd=rx=>rx.weeks?rxStart(rx)+rx.weeks*7*DAYMS:Infinity;
function weekInfo(p,now=new Date()){
  const raw=p&&p.rx&&p.rx.on?p.rx:null,ended=!!raw&&raw.weeks>0&&+now>=rxEnd(raw),rx=raw&&!ended?raw:null,done=(p&&p.done)||[],t0=new Date(now.getFullYear(),now.getMonth(),now.getDate()),ti=(t0.getDay()+6)%7,days=[];
  let missed=0,extra=0,pres=0,S=0;
  for(let i=0;i<7;i++){const d0=+new Date(t0.getFullYear(),t0.getMonth(),t0.getDate()-ti+i),d1=+new Date(t0.getFullYear(),t0.getMonth(),t0.getDate()-ti+i+1),
    n=done.filter(x=>x>=d0&&x<d1).length,pr=!!rx&&rx.days.includes(i)&&d1>(rx.from||0)&&d0<rxEnd(rx);let st;
    if(pr){pres++;st=n?'done':i<ti?'missed':i==ti?'today':'later';if(st=='missed')missed++}else{st=n?'extra':'rest';if(n)extra++}
    S+=n;days.push({i,pr,st,n})}
  const nx=days.slice(ti+1).find(d=>d.pr),first=days.find(d=>d.pr);
  const wkn=rx&&rx.from?Math.floor((+t0-rxStart(rx))/(7*DAYMS))+1:0;
  return{days,pres,S,done:Math.min(S,pres),owed:Math.max(0,missed-extra),rx,raw,ended,wkn,ti,todayDue:days[ti].st=='today',todayDone:days[ti].n>0,
    next:nx?nx.i:first?first.i:-1,nextWeek:!nx,last:done.length?Math.max(...done):0}}
const SYM={done:'✓',missed:'!',today:'●',extra:'+',later:'',rest:''};
function weekRow(w,sm){return h('div',{class:'wk'+(sm?' sm':'')},...w.days.map(d=>h('div',{class:'wd '+d.st+(d.i==w.ti?' now':'')+(d.pr?' pr':'')},h('span',{},dname(d.i)),h('i',{},SYM[d.st]))))}

/* ---- run a prescribed session ---- */
const rxOver=()=>RXs&&(RXs.mode=='session'?nextIdx>=plan.length:Date.now()-RXs.start>=RXs.min*60000);
let rxT=0;
function startRx(){const p=P(),rx=rxOf(p);RXs={start:Date.now(),min:+rx.minutes||10,mode:p.rx&&p.rx.on?rx.mode:'adaptive'};clearInterval(rxT);rxT=setInterval(()=>{if(RXs&&scr=='run'&&chk!==undefined)runBar()},20000);const rs=p.resume&&p.resume.mode==RXs.mode?p.resume:null;
  oldFOC=FOC;FOC={d:p.rx&&p.rx.on?rx.d||[]:[],k:p.rx&&p.rx.on?rx.k||[]:[]};runLog=[];pend=[];
  if(RXs.mode=='session'){buildPlan(p.rx&&p.rx.on?rx.match!==false:null);if(plan.length){sumMode='session';plan.forEach(x=>x.r=null);return run(rs?Math.min(rs.idx||0,plan.length-1):0)}RXs.mode='adaptive'}
  sumMode='adaptive';if(rs&&T[rs.k]&&RXs.mode=='adaptive'){launch(rs.k,ladder(rs.k)[lvl(rs.k)],'adaptive');return}startA()}
function endRx(){clearInterval(rxT);if(oldFOC)FOC=oldFOC;oldFOC=null;RXs=null}
function finishRx(){const p=P();delete p.resume;(p.done=p.done||[]).push(Date.now());saveP(true);endRx();show('pdone')}
function stopRx(){const p=P();if(p&&RXs)p.resume={mode:RXs.mode,k:cur,idx:Math.max(0,nextIdx-1),at:Date.now()};saveP();endRx();pend=[];show('home')}
function askStop(){const o=mdl(h('h2',{class:'ctr'},_('Stop for now?')),h('p',{class:'mut ctr'},_('Today’s training will not be counted until you finish it.')),
  h('button',{class:'btn big',onclick(){o.remove()}},_('Keep going')),h('p',{class:'mut ctr xs'},_('Next time you continue from this task.')),h('button',{class:'btn alt big',onclick(){o.remove();stopRx()}},_('Stop')))}

/* ---- role chooser & clinician gate ---- */
function rRole(){const ai=document.querySelector('link[rel=apple-touch-icon]');$('#role').replaceChildren(h('div',{class:'grow'}),h('h1',{class:'ctr'},_('Who is using this app?')),
  h('button',{class:'pbtn',onclick(){setRole('patient');show('home')}},h('b',{},_('I am the patient')),h('span',{},_('Simple screens: just start your training'))),
  h('button',{class:'pbtn alt',onclick(){gate(()=>{setRole('clin');show('home')})}},h('b',{},_('I am the clinician')),h('span',{},_('Prepare and follow the training plans'))),h('div',{class:'grow'}))}
function gate(ok){const pin=LS.get('tg2_pin','');if(!pin)return ok();
  const inp=h('input',{class:'inp ctr',type:'password',inputmode:'numeric',maxlength:8,autocomplete:'off'}),msg=h('p',{class:'dmsg ctr'}),
    o=mdl(h('h2',{class:'ctr'},_('Clinician PIN')),inp,msg,h('button',{class:'btn big',onclick(){if(inp.value==pin){o.remove();ok()}else{msg.textContent=_('Wrong PIN');inp.value=''}}},'OK'),h('button',{class:'link ctr',onclick(){o.remove()}},_('Cancel')));
  inp.focus()}

/* ---- patient screens ---- */
function rPhome(){const names=Object.keys(PS),root=$('#phome');
  const foot=h('div',{class:'pfoot'},h('button',{class:'link',onclick:()=>recvModal()},'📷 '+_('Receive by QR')),names.length>1?h('button',{class:'link',onclick(){pickMode=true;rPhome()}},_('Not you? Change person')):'',
    P()?h('button',{class:'link',async onclick(){await saveFile('neurorehab-'+CUR.replace(/[^\w-]+/g,'_')+'-'+stamp()+'.json',JSON.stringify(buildExport([CUR]),null,1))}},_('Save my results file')):'',
    P()&&weekInfo(P()).rx?h('button',{class:'link',async onclick(e){const m=await sendIcs(CUR,P().rx);e.target.textContent=m||_('Add reminder to calendar')}},'📅 '+_('Add reminder to calendar')):'',
    h('button',{class:'link',onclick(){gate(()=>{setRole('clin');show('home')})}},_('Clinician')));
  if(!names.length){root.replaceChildren(h('div',{class:'grow'}),h('h2',{class:'ctr'},_('Nothing set up yet')),h('p',{class:'mut ctr'},_('Ask your clinician to prepare your training.')),h('button',{class:'qrsq',onclick:()=>recvModal()},h('span',{class:'qrsv'}),h('b',{},_('Scan the QR code from your clinician'))),h('div',{class:'grow'}),foot);return}
  if(pickMode||!P()){root.replaceChildren(h('h1',{class:'ctr'},_('Who are you?')),...names.map(n=>h('button',{class:'pbtn',onclick(){CUR=n;saveP();pickMode=false;show('home')}},h('b',{},n))),h('div',{class:'grow'}),foot);return}
  const w=weekInfo(P(),new Date()),rx=w.rx,mins=rx?rx.minutes:10;let title,sub='',btn=_('Start training'),alt='';
  if(!rx&&w.ended){title=_('Your training plan is complete ✓');sub=_('Ask your clinician for the next plan. You can keep training if you like.');btn=_('Train a little more')}
  else if(!rx){title=_('Ready when you are');sub=_('No schedule yet. You can train whenever you like.')}
  else if(w.todayDue){title=_('Today: training');sub=_('{0} minutes',mins)}
  else if(w.todayDone){title=_('Today’s training is done ✓');sub=w.owed?_('You still have {0} missed session(s) this week.',w.owed):_('Well done!');btn=w.owed?_('Do a missed session'):_('Train a little more')}
  else if(w.owed){title=_('You missed {0} session(s) this week',w.owed);sub=_('You can catch up now.');btn=_('Catch up now')}
  else{title=_('Rest today');sub=w.next>=0?_('Next training: {0}',dlong(w.next)):'';btn=_('Train a little more')}
  const strong=rx&&(w.todayDue||(!w.todayDone&&w.owed)||(w.todayDone&&w.owed));
  root.replaceChildren(h('h1',{class:'phi'},_('Hello, {0}',CUR)),
    h('div',{class:'pcard2'},h('div',{class:'ptitle'},title),sub?h('div',{class:'psub'},sub):'',P().resume?h('div',{class:'psub'},'▶ '+_('Unfinished training: you will continue where you stopped.')):'',rx?weekRow(w):'',rx?h('div',{class:'psum'},_('This week: {0} of {1} sessions',w.done,w.pres),rx.weeks?h('small',{class:'pwk'},_('Week {0} of {1}',Math.min(w.wkn,rx.weeks),rx.weeks)):''):''),
    patProg(),h('div',{class:'grow'}),
    h('button',{class:strong||!rx?'pbig':'pbig alt',onclick:startRx},btn),foot)}
function rPdone(){const w=weekInfo(P()),L=runLog,avg=L.length?Math.round(L.reduce((a,x)=>a+x.pct,0)/L.length):0;
  $('#pdone').replaceChildren(h('div',{class:'grow'}),h('div',{class:'bigok'},'✓'),h('h1',{class:'ctr'},_('Well done, {0}!',CUR)),
    h('p',{class:'ctr psub'},_('{0} tasks completed',L.length)),w.rx?h('p',{class:'ctr psum'},_('This week: {0} of {1} sessions',w.done,w.pres)):'',w.rx?weekRow(w):'',
    h('div',{class:'grow'}),h('button',{class:'pbig',onclick(){show('home')}},_('Finish')))}

/* ---- clinician screens ---- */
function pinModal(){let o;const cur=LS.get('tg2_pin',''),m=h('p',{class:'dmsg'}),
  old=cur?h('input',{class:'inp',type:'password',inputmode:'numeric',maxlength:8,placeholder:_('Current PIN')}):null,
  nw=h('input',{class:'inp',type:'password',inputmode:'numeric',maxlength:8,placeholder:_('New PIN')});
  const ok=()=>!cur||old.value==cur||(m.textContent=_('Wrong PIN'),false);
  o=mdl(h('h2',{class:'ctr'},'🔒 '+_('Clinician PIN')),h('p',{class:'mut xs ctr'},_('One PIN for the clinician view, whichever profile is selected. Asked when switching from the patient view. It only prevents accidental changes; it is not secure protection.')),
    ...(old?[old]:[]),nw,
    h('button',{class:'btn',onclick(){if(!ok())return;if(!nw.value){m.textContent=_('Type a new PIN');return}LS.set('tg2_pin',nw.value);o.remove()}},_('Save PIN')),
    cur?h('button',{class:'btn alt',onclick(){if(!ok())return;LS.set('tg2_pin','');o.remove()}},_('Remove PIN')):'',m,
    h('button',{class:'link ctr',onclick(){o.remove()}},_('Cancel')))}
function rClin(){const names=Object.keys(PS);
  $('#clin').replaceChildren(h('h2',{},_('Patients')),
    h('p',{class:'mut sm'},_('Tap a patient to set the training plan and see whether it is being followed.')),
    h('div',{class:'plist2'},...names.map(n=>{const p=PS[n],w=weekInfo(p),on=!!w.rx;
      const tr=h('button',{class:'trash','aria-label':_('Delete intervention'),title:_('Delete intervention')+' — '+_('the profile and results are kept'),onclick(e){e.stopPropagation();if(tr.dataset.s){delete p.rx;delete p.resume;saveP(true);rClin()}else{tr.dataset.s=1;tr.classList.add('arm');tr.textContent=_('Delete?');setTimeout(()=>{if(tr.isConnected){delete tr.dataset.s;tr.classList.remove('arm');tr.textContent='🗑'}},3500)}}},'🗑');
      return h('div',{class:'crow'},h('button',{class:'pmain',onclick(){CUR=n;saveP();show('rx')}},h('div',{class:'pr1'},h('b',{},n),
        on?h('span',{class:'badge '+(w.owed?'bad':w.done>=w.pres?'ok':'')},w.owed?_('{0} missed',w.owed):(w.done>=w.pres?_('Week complete ✓')+' '+w.done+'/'+w.pres:_('In progress')+' · '+w.done+'/'+w.pres)):h('span',{class:'badge'},w.ended?_('Plan ended'):_('No plan'))),
        on?weekRow(w,true):'',h('span',{class:'mut xs'},w.last?_('Last session: {0}',fdate(w.last)):_('No sessions yet'))),p.rx?tr:'')})),
    h('button',{class:'btn alt',onclick(){draft={orig:'',name:'',v:[3,3,3,3,3],cc:true};show('profile')}},'＋ '+_('New patient')),
    h('div',{class:'grow'}),
    '')}
function wkCard(){const p=P();if(!p)return'';const w=weekInfo(p);return w.rx?h('div',{class:'wkcard'},h('div',{class:'pr1'},h('b',{},_('This week')),h('span',{class:'badge '+(w.owed?'bad':w.done>=w.pres?'ok':'')},(w.owed?_('{0} missed',w.owed):(w.done>=w.pres?_('Week complete ✓'):_('In progress'))))),weekRow(w),h('p',{class:'mut xs'},_('{0} of {1} sessions done',w.done,w.pres)+(w.owed?' · '+_('{0} missed',w.owed):''))):''}
function stimInfo(){const o=mdl(h('h2',{class:'ctr'},'🖼 '+_('Stimuli type')),h('p',{class:'mut sm'},_('Applies to all training')+'. '+_('Association and Image pairs use pictures from every source switched on; each exercise picks one of them.')),
 h('div',{class:'stimx'},h('b',{},_('Clipart')+' ✓ '+_('validated')),h('p',{class:'mut sm'},_('Black-and-white line drawings from the original PARP-AVC material. Simple, high-contrast and easy to print.'))),
 h('div',{class:'stimx'},h('b',{},_('Pictures')+' ✓ '+_('validated')),h('p',{class:'mut sm'},_('Real colour photographs of everyday objects, already part of the app and checked by the team.'))),
 h('div',{class:'stimx'},h('b',{},_('Commons photos')),h('p',{class:'mut sm'},_('Additional photographs from Wikimedia Commons with free licences, kept in a separate pack so they can be switched on or off. Not installed yet.'))),
 h('button',{class:'btn big',onclick(){o.remove()}},_('Close')))}
function imgChips(){const cur=srcOf(),SH=SRCN;return h('div',{class:'imgset one'},h('b',{class:'imgt'},'🖼 '+_('Stimuli')),h('div',{class:'chips sm1'},...Object.keys(SRCN).map(v=>{const on=cur.includes(v),av=srcAvail(v),a={class:'tab'+(on&&av?' on':''),role:'switch','aria-checked':on&&av?'true':'false',title:av?'':_('none installed'),onclick(){const n=on?cur.filter(x=>x!=v):[...cur,v];if(n.length){LS.set('tg2_src',n);rHome()}}};if(!av)a.disabled='disabled';if(v!='m')a.title=_('validated');return h('button',a,_(SH[v]),v!='m'?h('i',{class:'vt','aria-label':_('validated')},'✓'):'')})),h('button',{class:'imgi','aria-label':_('Info'),onclick:stimInfo},'ⓘ'))}
function rRx(){const p=P();if(!p){show('clin');return}const rx=rxOf(p),w=weekInfo(p),sv=()=>{saveP(true);rRx()},tg=(a,v)=>{const i=a.indexOf(v);i<0?a.push(v):a.splice(i,1);sv()};
  const swt=h('label',{class:'swl'},h('span',{},_('Plan active')),(()=>{const c=h('input',{type:'checkbox',role:'switch',class:'swi',onchange(){rx.on=c.checked;if(c.checked&&!rx.from)rx.from=Date.now();sv()}});c.checked=!!rx.on;return c})(),h('i',{class:'sws'}));
  $('#rx').replaceChildren(h('h2',{},_('Plan for {0}',CUR)),
    h('div',{class:'two'},h('button',{class:'btn alt',onclick(){show('profile')}},_('Profile')),h('button',{class:'btn alt',onclick:tplModal},'📋 '+_('Plan templates'))),
    swt,
    rx.on?h('div',{class:'pgw'},
      h('h3',{},_('Training days')),h('div',{class:'chips'},...[0,1,2,3,4,5,6].map(i=>h('button',{class:'tab'+(rx.days.includes(i)?' on':''),onclick(){tg(rx.days,i);rx.days.sort()}},dname(i)))),
      h('p',{class:'mut xs'},_('{0} sessions per week',rx.days.length)),
      h('h3',{},_('Plan duration')),h('div',{class:'chips'},...[0,2,4,6,8,12,26].map(n=>h('button',{class:'tab'+((rx.weeks||0)==n?' on':''),onclick(){rx.weeks=n;if(!rx.from)rx.from=Date.now();sv()}},n?_('{0} weeks',n):'∞ '+_('Permanent')))),
      (()=>{const wi=weekInfo(p);return h('p',{class:'mut xs'},rx.weeks?(wi.ended?_('Plan ended on {0}.',new Date(rxEnd(rx)).toLocaleDateString(LANG)):_('Week {0} of {1} · ends {2}',Math.min(wi.wkn,rx.weeks),rx.weeks,new Date(rxEnd(rx)-DAYMS).toLocaleDateString(LANG)))+' ':'',h('button',{class:'link',onclick(){rx.from=Date.now();sv()}},_('Restart from today')))})(),
      h('h3',{},_('Minutes per session')),h('div',{class:'chips'},...[5,10,15,20,30,45,60].map(m=>h('button',{class:'tab'+(rx.minutes==m?' on':''),onclick(){rx.minutes=m;sv()}},m))),
      h('h3',{},_('Type of session')),
      h('div',{class:'ftabs',role:'tablist'},h('button',{role:'tab',class:'ftab'+(rx.mode=='adaptive'?' on':''),onclick(){rx.mode='adaptive';sv()}},_('Adaptive training')),h('button',{role:'tab',class:'ftab'+(rx.mode=='session'?' on':''),onclick(){rx.mode='session';sv()}},_('Full session'))),
      h('div',{class:'fpanel',role:'tabpanel'},rx.mode=='adaptive'?h('div',{},h('p',{class:'mut xs'},_('Keeps each exercise between 50% and 70% correct.')),h('h3',{},_('Focus on a domain')),h('div',{class:'chips'},...DIMS.slice(0,4).map((d,i)=>h('button',{class:'tab'+(rx.d.includes(i)?' on':''),onclick(){tg(rx.d,i)}},_(d)))),
        h('h3',{},_('or choose tasks')),h('div',{class:'chips'},...KS.map(k=>h('button',{class:'tab'+(rx.k.includes(k)?' on':''),onclick(){tg(rx.k,k)}},tn(k)))),
        h('p',{class:'mut xs'},rx.k.length||rx.d.length?'':_('Nothing chosen: training all tasks in turn.'))):h('div',{},h('label',{class:'chk'},(()=>{const c=h('input',{type:'checkbox',onchange(){rx.match=c.checked;saveP(true);rRx()}});c.checked=rx.match!==false;return c})(),h('span',{},_('Only include tasks that closely match the profile'))),
        h('p',{class:'mut xs'},rx.match!==false?_('The full session runs all matched tasks once; the minutes are only a guide.'):_('The full session runs all tasks once, whatever the profile; the minutes are only a guide.')))),
      weekBox(weekSpec(rx,rx.match!==false),rx.mode!='session'),
      h('div',{class:'remcard'},h('div',{class:'remh'},h('b',{},'📅 '+_('Reminder')),h('span',{class:'mut xs'},_('Adds the training days to the patient’s calendar app.'))),
        (()=>{const t=h('input',{class:'remtime',type:'time',onchange(){rx.time=t.value||'10:00';saveP(true);rRx()}}),m=h('p',{class:'dmsg'});t.value=rx.time||'10:00';
          return h('div',{class:'remb'},h('label',{class:'fld'},_('Time of day'),t),
            h('div',{class:'fld'},_('Alert'),h('div',{class:'chips'},...[[0,_('At the time')],[10,_('10 min before')],[30,_('30 min before')],[60,_('1 h before')]].map(([v,l])=>h('button',{class:'tab'+((rx.alarm==null?10:rx.alarm)==v?' on':''),onclick(){rx.alarm=v;sv()}},l)))),
            h('p',{class:'remsum'},rx.days.map(dname).join(' · ')+' — '+(rx.time||'10:00')+' · '+_('{0} minutes',rx.minutes)),
            h('button',{class:'btn',async onclick(){m.textContent=await sendIcs(CUR,rx)}},_('Add to calendar (.ics)')),m)})()),
      ):'',
    h('div',{class:'grow'}),
    h('p',{class:'mut xs'},_('To give the plan to another device, export it in Progress → Data and backup and import it there. Results come back the same way.')))}

function patProg(){const H=myH();if(!H.length)return'';const last=H.slice(-20),l10=H.slice(-10),pv_=H.slice(-20,-10),avg=a=>a.length?Math.round(a.reduce((s,x)=>s+x.pct,0)/a.length):0,
  now=avg(l10),before=pv_.length?avg(pv_):null,tr=before==null?_('Keep going: every session helps.'):now>before+3?_('Better than before ▲'):now<before-3?_('A little lower than before ▼'):_('About the same as before ●'),
  dom=DIMS.slice(0,4).map((d,i)=>{let a=0,w=0;H.slice(-30).forEach(x=>{const q=Math.max(0,x.v[i]);a+=x.pct*q;w+=q});return{l:_(d),v:w?a/w:0}}).sort((a,b)=>b.v-a.v)[0];
  return h('div',{class:'pcard2 prog'},h('div',{class:'ptitle sm'},_('Your progress')),cx(last,{h:90}),
    h('div',{class:'psub'},_('Last 10 exercises: {0}% correct',now)),h('div',{class:'psum'},tr),dom&&dom.v?h('div',{class:'psub'},'★ '+_('Your strongest area: {0}',dom.l)):'',
    h('div',{class:'stats'},h('div',{},h('b',{},(P().done||[]).length),h('span',{},_('sessions done'))),h('div',{},h('b',{},H.length),h('span',{},_('exercises')))))}

function delProf(n,po){const o=mdl(h('h2',{class:'ctr'},_('Delete the profile “{0}”?',n)),h('p',{class:'mut ctr xs'},_('This removes the profile and its plan. Its training history stays in the app data.')),
  h('button',{class:'btn big',onclick(){try{mkBackup('delete profile')}catch(e){}delete PS[n];if(CUR==n)CUR=Object.keys(PS)[0]||'';saveP(true);o.remove();po.remove();try{hdr()}catch(e){}if(Object.keys(PS).length)pickPatient();else{draft={orig:'',name:'',v:[3,3,3,3,3],cc:true};show('profile')}}},_('Delete')),
  h('button',{class:'link ctr',onclick(){o.remove()}},_('Cancel')))}
function pickPatient(){const names=Object.keys(PS),o=mdl(h('h2',{class:'ctr'},_('Choose the profile')),
  ...names.map(n=>h('div',{class:'prow'},h('button',{class:'btn'+(n==CUR?'':' alt')+' big',onclick(){CUR=n;saveP();o.remove();show('home')}},n),h('button',{class:'btn alt big pedit','aria-label':_('Edit')+' '+n,title:_('Edit'),onclick(){CUR=n;saveP();draft=null;o.remove();show('profile')}},'✎'),h('button',{class:'btn alt big pedit pdel','aria-label':_('Delete profile')+' '+n,title:_('Delete profile'),onclick(){delProf(n,o)}},'🗑'))),
  h('button',{class:'link ctr',onclick(){o.remove();draft={orig:'',name:'',v:[3,3,3,3,3],cc:true};show('profile')}},'＋ '+_('New patient')),
  h('button',{class:'link ctr',onclick(){o.remove()}},_('Cancel')))}
function planCard(){const p=P();if(!p)return'';const w=weekInfo(p),rx=w.rx;
  return h('button',{class:'plancard',onclick(){show('rx')}},h('div',{class:'pr1'},h('b',{},_('Plan for {0}',CUR)),rx?h('span',{class:'badge '+(w.owed?'bad':w.done>=w.pres?'ok':'')},w.owed?_('{0} missed',w.owed):(w.done>=w.pres?_('Week complete ✓')+' '+w.done+'/'+w.pres:_('In progress')+' · '+w.done+'/'+w.pres)):h('span',{class:'badge'},w.ended?_('Plan ended'):_('No plan'))),
    rx?h('span',{class:'mut xs'},rx.days.map(dname).join(' · ')+' · '+_('{0} minutes',rx.minutes)+' · '+(rx.mode=='session'?_('Full session'):_('Adaptive training'))+' · '+(rx.weeks?_('Week {0} of {1}',Math.min(w.wkn,rx.weeks),rx.weeks):_('Permanent'))):'',rx?weekRow(w,true):'',h('div',{class:'pcrow'},h('span',{class:'mut xs'},rx?(rx.mode=='session'?_('All matched tasks'):(rx.k.length?rx.k.map(tn).join(', '):rx.d.length?rx.d.map(i=>_(DIMS[i])).join(', '):_('All tasks'))):''),h('span',{class:'pcgo'},_('Tap to edit the plan')+' ›')))}

/* ---- plan templates ---- */
const TPL0=[
 {n:'Gentle start',days:[0,2,4],weeks:4,minutes:10,mode:'adaptive',d:[],k:[]},
 {n:'Standard plan',days:[0,2,4],weeks:8,minutes:15,mode:'adaptive',d:[],k:[]},
 {n:'Intensive plan',days:[0,1,2,3,4],weeks:12,minutes:30,mode:'adaptive',d:[],k:[]},
 {n:'Attention and memory',days:[0,2,4],weeks:8,minutes:20,mode:'adaptive',d:[0,1],k:[]},
 {n:'Executive functions and language',days:[1,3,5],weeks:8,minutes:20,mode:'adaptive',d:[2,3],k:[]},
 {n:'Weekly full sessions',days:[1,4],weeks:8,minutes:30,mode:'session',d:[],k:[],match:true},
 {n:'Maintenance',days:[1,4],weeks:0,minutes:10,mode:'adaptive',d:[],k:[]}];
function tplSum(t){return [_('{0} sessions per week',t.days.length),_('{0} minutes',t.minutes),t.weeks?_('{0} weeks',t.weeks):'∞ '+_('Permanent'),t.mode=='session'?_('Full session'):_('Adaptive training')].join(' · ')+(t.mode=='adaptive'&&(t.d.length||t.k.length)?' · '+[...t.d.map(i=>_(DIMS[i])),...t.k.map(tn)].join(', '):'')}
function tplModal(){const p=P();if(!p)return;let o,tab=0,hint='';
 const apply=t=>{const rx=rxOf(p);Object.assign(rx,{days:[...t.days],weeks:t.weeks,minutes:t.minutes,mode:t.mode,d:[...t.d],k:[...t.k]});if(t.match!=null)rx.match=t.match;rx.on=true;rx.from=Date.now();saveP(true);o.remove();rRx()},
  draw=()=>{const U=LS.get('tg2_tpl',[]),msg=h('p',{class:'dmsg'},hint),fi=h('input',{type:'file',accept:'.json,application/json',class:'hid',onchange(){const f=fi.files[0];if(!f)return;const rd=new FileReader();rd.onload=()=>{try{const j=JSON.parse(String(rd.result)),it=(j&&j.tgTemplates&&Array.isArray(j.items)?j.items:[]).filter(t=>t&&typeof t.n=='string'&&Array.isArray(t.days)&&t.days.every(d=>d>=0&&d<7)&&['adaptive','session'].includes(t.mode)&&+t.minutes>0).map(t=>({n:t.n.slice(0,40),days:t.days.map(Number),weeks:+t.weeks||0,minutes:+t.minutes,mode:t.mode,d:(t.d||[]).filter(i=>i>=0&&i<4),k:(t.k||[]).filter(k=>KS.includes(k)),match:t.match}));if(!it.length)throw 0;let n=0;it.forEach(t=>{const i=U.findIndex(u=>u.n==t.n);if(i<0){U.push(t);n++}else U[i]=t});LS.set('tg2_tpl',U);hint=_('{0} templates imported ✓',it.length);draw()}catch(e){hint=_('This file is not a valid templates file.');draw()}};rd.readAsText(f)}}),nm=h('input',{class:'fld',type:'text',placeholder:_('Template name'),maxlength:40,style:'width:100%;margin:6px 0'}),
   row=(t,i)=>h('div',{class:'tplr'},h('button',{class:'tplb',onclick(){apply(t)}},h('b',{},i==null?_(t.n):t.n),h('small',{class:'mut'},tplSum(t))),i!=null?h('button',{class:'btn alt tpld','aria-label':_('Delete'),onclick(){U.splice(i,1);LS.set('tg2_tpl',U);draw()}},'✕'):'');
   o.querySelector('.mbox').replaceChildren(h('h2',{class:'ctr'},_('Plan templates')),h('p',{class:'mut xs'},_('Choose one to fill in the plan; you can then adjust anything by hand.')),
    h('div',{class:'ftabs',role:'tablist'},h('button',{role:'tab',class:'ftab'+(tab==0?' on':''),onclick(){tab=0;draw()}},_('Ready-made')),h('button',{role:'tab',class:'ftab'+(tab==1?' on':''),onclick(){tab=1;draw()}},_('My templates')+' ('+U.length+')')),
    ...(tab==0?TPL0.map(t=>row(t,null)):[...(U.length?U.map((t,i)=>row(t,i)):[h('p',{class:'mut xs'},_('None yet.'))]),
    h('h3',{},_('Save the current plan as a template')),nm,
    h('button',{class:'btn',onclick(){const r=rxOf(p),name=nm.value.trim();if(!name){nm.focus();return}U.push({n:name,days:[...r.days],weeks:r.weeks||0,minutes:r.minutes,mode:r.mode,d:[...r.d],k:[...r.k],match:r.match});LS.set('tg2_tpl',U);draw()}},_('Save template')),
    h('h3',{},_('Download or import')),msg,
    h('div',{class:'two'},h('button',{class:'btn alt',onclick:async()=>{if(!U.length){msg.textContent=_('None yet.');return}const r=await saveFile('plan-templates.json',JSON.stringify({tgTemplates:1,items:U},null,1));msg.textContent=r=='ok'?_('Templates file ready ✓'):r=='declined'?'':_('Could not save the file.')}},'⬇ '+_('Download my templates')),
     h('button',{class:'btn alt',onclick(){fi.click()}},'⬆ '+_('Import templates'))),fi]),
    h('button',{class:'btn alt',onclick(){o.remove()}},_('Close')))};
 o=mdl();draw()}

/* ===================== reports, worksheets (print / PDF) and calendar reminders ===================== */
const PW=794,PH=1123;
let prn={sel:null,copies:1,key:true,rep:true},pvPages=[],pvBase='';
const fmime=n=>/\.pdf$/.test(n)?'application/pdf':/\.ics$/.test(n)?'text/calendar':/\.html$/.test(n)?'text/html':'application/json';
async function saveBin(name,data){
  if(bridgeSave(name,data,fmime(name)))return'ok';
  try{const dl=window.claude&&claude.use?await claude.use('downloads'):null;
    if(dl){await dl.save({filename:name,data});return'ok'}}catch(e){if(e&&e.code=='declined')return'declined';if(e&&e.code=='rejected_extension'&&/\.ics$/.test(name)){try{await(await claude.use('downloads')).save({filename:name+'.txt',data});return'txt'}catch(e2){}}}
  try{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data],{type:fmime(name)}));a.download=name;document.body.append(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},800);return'ok'}catch(e){return'fail'}}

/* ---- calendar reminder ---- */
const icsEsc=s=>String(s).replace(/[\;,]/g,m=>'\\'+m).replace(/\n/g,'\\n');
function makeIcs(name,rx){const t=(rx.time||'10:00').split(':'),H=+t[0]||10,M=+t[1]||0,p2=n=>String(n).padStart(2,'0'),now=new Date(),
  codes=['MO','TU','WE','TH','FR','SA','SU'],days=(rx.days&&rx.days.length?rx.days:[0,2,4]).slice().sort();
  let d=new Date(now.getFullYear(),now.getMonth(),now.getDate());for(let i=0;i<8&&!days.includes((d.getDay()+6)%7);i++)d=new Date(d.getFullYear(),d.getMonth(),d.getDate()+1);
  const ds=`${d.getFullYear()}${p2(d.getMonth()+1)}${p2(d.getDate())}T${p2(H)}${p2(M)}00`,utc=now.toISOString().replace(/[-:]/g,'').replace(/\.\d+/,'');
  const L=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//NeuroRehabLab//Task Generator//EN','CALSCALE:GREGORIAN','BEGIN:VEVENT',`UID:${Date.now()}-${encodeURIComponent(name)}@neurorehablab`,`DTSTAMP:${utc}`,`DTSTART:${ds}`,`DURATION:PT${+rx.minutes||15}M`,
   `RRULE:FREQ=WEEKLY;BYDAY=${days.map(i=>codes[i]).join(',')}`+(rx.weeks?(e=>`;UNTIL=${e.getFullYear()}${p2(e.getMonth()+1)}${p2(e.getDate())}T235959`)(new Date(rxEnd(rx)-DAYMS)):''),'SUMMARY:'+icsEsc(_('Cognitive training')+' · '+name),'DESCRIPTION:'+icsEsc(_('{0} minutes',+rx.minutes||15)),
   'BEGIN:VALARM','ACTION:DISPLAY','TRIGGER:-PT'+(rx.alarm==null?10:+rx.alarm)+'M','DESCRIPTION:'+icsEsc(_('Cognitive training')),'END:VALARM','END:VEVENT','END:VCALENDAR'];
  return L.join('\r\n')+'\r\n'}
async function sendIcs(name,rx){const r=await saveBin('neurorehab-'+name.replace(/[^\w-]+/g,'_')+'-reminder.ics',makeIcs(name,rx));return r=='txt'?_('Saved as .txt: rename it to .ics to open it in your calendar.'):r=='ok'?_('Reminder file ready ✓'):r=='declined'?'':_('Could not save the file.')}

/* ---- A4 pages ---- */
function mkPage(title,sub,cont){const logo=document.querySelector('#logo img'),body=h('div',{class:'pgb'}),
  el=h('div',{class:'pg'},h('div',{class:'pgh'},logo?h('img',{src:logo.src,alt:''}):'',h('div',{class:'pgt'},h('b',{},title),sub?h('span',{},sub):'')),
  cont===2?'':h('div',{class:'pgn'},h('span',{},_('Name')+': ',h('b',{class:'pgv'},CUR||'')),h('span',{},_('Date')+': ',h('b',{class:'pgv'},new Date().toLocaleDateString(LANG)))),body,
  h('div',{class:'pgf'},'NeuroRehabLab · LifeTech OpenQoL'));return{el,body}}
function weeksTable(p,n){const rx=p.rx,done=p.done||[],now=new Date(),t0=new Date(now.getFullYear(),now.getMonth(),now.getDate()),ti=(t0.getDay()+6)%7,out=[];
  for(let k=n-1;k>=0;k--){const a=new Date(t0.getFullYear(),t0.getMonth(),t0.getDate()-ti-7*k),b=new Date(a.getFullYear(),a.getMonth(),a.getDate()+7),
    S=done.filter(x=>x>=+a&&x<+b).length,pl=rx&&rx.on&&+b>(rx.from||0)?rx.days.length:0;out.push({l:a.toLocaleDateString(LANG,{day:'2-digit',month:'2-digit'}),S,pl})}return out}
function buildReport(name){const p=PS[name],H=hist.filter(x=>(x.u||'')==name),pg=mkPage(_('Training report'),name+' · '+new Date().toLocaleDateString(LANG),2),b=pg.body,rx=weekInfo(p).rx;
  b.append(h('h3',{},_('Profile')),rowBars(DIMS.slice(0,4).map((d,i)=>({l:_(d),v:Math.round(p.v[i]*10)}))));
  b.append(h('h3',{},_('Training plan')),h('p',{},rx?_('{0} sessions per week',rx.days.length)+' ('+rx.days.map(dname).join(', ')+') · '+_('{0} minutes',rx.minutes)+' · '+(rx.mode=='session'?_('Full session'):_('Adaptive training'))+' · '+(rx.weeks?_('{0} weeks',rx.weeks):_('Permanent')):_('No plan')));
  const wt=weeksTable(p,8),mx=Math.max(1,...wt.map(x=>Math.max(x.S,x.pl)));
  b.append(h('h3',{},_('Sessions per week (last 8 weeks)')),h('div',{class:'wbars'},...wt.map(x=>h('div',{class:'wbc'},h('div',{class:'wbt'},h('div',{class:'wbp',style:`height:${100*x.pl/mx}%`}),h('div',{class:'wbd',style:`height:${100*x.S/mx}%`})),h('span',{},x.l),h('b',{},x.S+(x.pl?'/'+x.pl:''))))),h('p',{class:'mut xs'},_('Dark bar = sessions done; outline = sessions prescribed.')));
  const last=H.slice(-30),avg=last.length?Math.round(last.reduce((a,x)=>a+x.pct,0)/last.length):0;
  b.append(h('h3',{},_('Performance')),h('div',{class:'stats'},h('div',{},h('b',{},H.length),h('span',{},_('attempts'))),h('div',{},h('b',{},avg+'%'),h('span',{},_('last 10'))),h('div',{},h('b',{},(p.done||[]).length),h('span',{},_('sessions')))));
  if(last.length){b.append(chart(last.map(x=>x.pct),{h:84}),h('p',{class:'mut xs'},_('% correct per attempt. Green band = 50–70% target zone; blue above, red below.')));
    const dom=DIMS.slice(0,4).map((d,i)=>{let a=0,w=0;last.forEach(x=>{const q=Math.max(0,x.v[i]);a+=x.pct*q;w+=q});return{l:_(d),v:w?Math.round(a/w):0}});b.append(h('h3',{},_('By cognitive domain')),rowBars(dom));
    const rows=KS.map(k=>{const a=H.filter(x=>x.k==k);return a.length?h('tr',{},h('td',{},tn(k)),h('td',{},a.length),h('td',{},Math.round(a.reduce((s,x)=>s+x.pct,0)/a.length)+'%'),h('td',{},(PS[name].lev&&PS[name].lev[k]!=null?PS[name].lev[k]+1:1)+'/'+ladder(k).length)):null}).filter(Boolean);
    b.append(h('h3',{},_('By task')),h('table',{class:'pgtab'},h('tr',{},h('th',{},_('Task')),h('th',{},_('attempts')),h('th',{},_('average')),h('th',{},_('Level'))),...rows))}
  else b.append(h('p',{class:'mut'},_('No results yet for {0}. Finish an exercise and your graphs appear here.',name)));
  return[pg.el]}
const pgOver=W=>W.body.scrollHeight>W.body.clientHeight+2;
/* fit a task into A4 pages: enlarge to use the space, and split across several pages when it is longer than one */
function paginate(W,box,ttl,g){let z=1.45;box.style.zoom=z;
  while(pgOver(W)&&z>1){z=Math.round((z-.1)*100)/100;box.style.zoom=z}
  const pgs=[{W,box}];
  if(pgOver(W)&&box.children.length>1){const kids=[...box.children];kids.slice(1).forEach(k=>k.remove());let cur=pgs[0];
    kids.slice(1).forEach(k=>{cur.box.append(k);if(pgOver(cur.W)&&cur.box.children.length>1){k.remove();const N=mkPage(ttl+' ('+(pgs.length+1)+')',null,true);N.el.classList.add('ws');const nb=h('div',{class:'tbox'});nb.style.zoom=z;N.body.append(nb);g.append(N.el);cur={W:N,box:nb};pgs.push(cur);nb.append(k)}})}
  pgs.forEach(o=>{let q=o.box.style.zoom||1;while(pgOver(o.W)&&q>0.5){q=Math.round((q-.1)*100)/100;o.box.style.zoom=q}});
  return pgs.map(o=>o.W.el)}
function buildSheets(name,ks,copies,key,pm,pfx){const out=[],keys=[],keep=CUR;CUR=name;PRT=true;const g=$('#pv .pgs');
  const mkKey=(chk,box,ttl)=>{const pristine=box.cloneNode(true);let ok=true;try{chk()}catch(e){ok=false}if(!ok)return null;
    box.querySelectorAll('input,textarea').forEach(i=>i.setAttribute('value',i.value));
    const K=mkPage(_('Answer key')+' · '+ttl);K.el.classList.add('ws','kp');K.body.append(box);g.append(K.el);keys.push(...paginate(K,box,_('Answer key')+' · '+ttl,g));return pristine};
  ks.forEach(k=>{for(let c=1;c<=copies;c++){
    const pr=clampP(k,pm&&pm[k]?{...pm[k]}:{...def(k),...ladder(k)[lvl(k)]});if(k=='assoc'||k=='pairs')pr.type=pick(['c','p']);
    const ttl=(pfx?pfx+' · ':'')+tn(k)+(copies>1?` (${c}/${copies})`:''),W=mkPage(ttl);W.el.classList.add('ws');let box=h('div',{class:'tbox'});W.body.append(box);g.append(W.el);
    let r;try{r=T[k].b(pr,box)}catch(e){W.el.remove();continue}
    if(r&&r.two){r.study(box,()=>{});out.push(...paginate(W,box,ttl,g));
      const W2=mkPage(ttl+' · '+_('Recall'));W2.el.classList.add('ws');let b2=h('div',{class:'tbox'});W2.body.append(b2);g.append(W2.el);
      const f=r.recall(b2);if(key&&k!='stories'&&typeof f=='function'){const pr2=mkKey(f,b2,ttl);if(pr2){W2.body.replaceChildren(pr2);b2=pr2}}
      out.push(...paginate(W2,b2,ttl+' · '+_('Recall'),g))}
    else{if(key&&typeof r=='function'){const pr2=mkKey(r,box,ttl);if(pr2){W.body.replaceChildren(pr2);box=pr2}}out.push(...paginate(W,box,ttl,g))}}});
  PRT=false;CUR=keep;return out.concat(keys)}
function pvOpen(pages,base){pvBase=base;pvPages=pages;const pv=$('#pv');pv.classList.remove('hid');const g=pv.querySelector('.pgs');g.replaceChildren(...pages);pvFit()}
function pvFit(){const g=document.querySelector('#pv .pgs');if(!g)return;g.style.zoom=Math.min(1,(window.innerWidth-24)/PW)}
function pvClose(){const pv=$('#pv');pv.classList.add('hid');pv.querySelector('.pgs').replaceChildren();pvPages=[]}
async function pvPdf(msg){msg.textContent=_('Preparing the PDF…');
  try{const css=[...document.querySelectorAll('style')].map(s=>s.textContent).join('\n').replace(/:root/g,'.pgroot'),doc=await PDFLib.PDFDocument.create();
    for(const pg of pvPages){const c=pg.cloneNode(true);c.style.zoom='1';c.querySelectorAll('input,textarea').forEach(i=>i.setAttribute('value',i.value));
      const xml=new XMLSerializer().serializeToString(c),svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${PW}" height="${PH}"><foreignObject width="100%" height="100%"><div xmlns="http://www.w3.org/1999/xhtml" class="pgroot" style="width:${PW}px;height:${PH}px"><style>${css}</style>${xml}</div></foreignObject></svg>`,
        img=new Image();img.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg);await img.decode();
      const cv=document.createElement('canvas');cv.width=PW*2;cv.height=PH*2;const x=cv.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,cv.width,cv.height);x.drawImage(img,0,0,cv.width,cv.height);
      const jb=await new Promise(r=>cv.toBlob(r,'image/jpeg',.92)),j=await doc.embedJpg(await jb.arrayBuffer()),pp=doc.addPage([595.28,841.89]);pp.drawImage(j,{x:0,y:0,width:595.28,height:841.89})}
    const bytes=await doc.save(),r=await saveBin(pvBase+'-'+stamp()+'.pdf',bytes);msg.textContent=r=='ok'?_('PDF ready ✓'):r=='declined'?'':_('Could not create the PDF. Use Print and choose “Save as PDF”.')}
  catch(e){msg.textContent=_('Could not create the PDF. Use Print and choose “Save as PDF”.')}}
function rPrn(){const p=P();if(!p){show('clin');return}if(!prn.sel)prn.sel=[...KS];
  const msg=h('p',{class:'dmsg'}),tg=k=>{const i=prn.sel.indexOf(k);i<0?prn.sel.push(k):prn.sel.splice(i,1);rPrn()},
    open=(pages,base)=>{pvOpen(pages,base)};
  $('#prn').replaceChildren(h('h2',{},_('Print and PDF for {0}',CUR)),
    h('div',{class:'dcard'},h('b',{},_('Progress report')),h('p',{class:'mut xs'},_('Profile, plan, sessions per week and performance. One page.')),
      h('button',{class:'btn',onclick(){open(buildReport(CUR),'neurorehab-report-'+CUR.replace(/[^\w-]+/g,'_'))}},_('Open report'))),
    h('div',{class:'dcard'},h('b',{},_('Exercise sheets')),h('p',{class:'mut xs'},_('Paper versions of the exercises at {0}’s current level.',CUR)),
      h('div',{class:'chips'},...KS.map(k=>h('button',{class:'tab'+(prn.sel.includes(k)?' on':''),onclick(){tg(k)}},tn(k)))),
      copiesField(),
      h('label',{class:'chk'},(()=>{const c=h('input',{type:'checkbox',onchange(){prn.key=c.checked}});c.checked=prn.key;return c})(),h('span',{},_('Include the answer key'))),
      h('button',{class:'btn',onclick(){if(!prn.sel.length)return;pvOpen([],'');const pg=buildSheets(CUR,KS.filter(k=>prn.sel.includes(k)),prn.copies,prn.key);pvOpen(pg,'neurorehab-sheets-'+CUR.replace(/[^\w-]+/g,'_'))}},_('Create sheets'))),
    msg)}

(function(){const pv=h('div',{id:'pv',class:'hid'}),m=h('span',{class:'pvm'});
  pv.append(h('div',{class:'pvt'},h('button',{class:'btn',onclick(){try{window.print()}catch(e){m.textContent=_('Printing is not available here. Use Download PDF.')}}},'🖨 '+_('Print')),
    h('button',{class:'btn',onclick(){pvPdf(m)}},'⬇ '+_('Download PDF')),h('button',{class:'btn alt',onclick(){m.textContent='';pvClose()}},'✕ '+_('Close')),m),h('div',{class:'pgs'}));
  try{document.body.append(pv);window.addEventListener('resize',pvFit)}catch(e){}})();

/* print box: version count + answer key + button; spec() -> {ks, pm, base} */
const copiesField=()=>{const i=h('input',{type:'number',min:'1',max:'10',step:'1',inputmode:'numeric',class:'cpn',onchange(){let n=Math.round(+i.value);if(!(n>=1))n=1;if(n>10)n=10;prn.copies=n;i.value=n},oninput(){const n=Math.round(+i.value);if(n>=1&&n<=10)prn.copies=n}});i.value=prn.copies||1;return h('label',{class:'cpl'},h('span',{},_('Versions')),i)};
function printBox(spec,title){const m=h('p',{class:'dmsg'});
  return h('div',{class:'dcard'},h('b',{},'🖨 '+(title||_('Print this'))),
    copiesField(),
    h('label',{class:'chk'},(()=>{const c=h('input',{type:'checkbox',onchange(){prn.key=c.checked}});c.checked=prn.key;return c})(),h('span',{},_('Include the answer key'))),
    h('button',{class:'btn',onclick(){const s=spec();if(!s.ks.length){m.textContent=_('Nothing to print.');return}pvOpen([],'');const pg=buildSheets(CUR,s.ks,prn.copies,prn.key,s.pm);pvOpen(pg,'neurorehab-'+s.base+'-'+CUR.replace(/[^\w-]+/g,'_'))}},_('Create sheets')),m)}
const weekSpec=(rx,ov)=>()=>{const ds=(rx.days||[]).slice().sort(),days=[];let ks,pm={};
  if(rx.mode=='session'){buildPlan(ov);plan.forEach(it=>pm[it.k]=it.p);ks=plan.map(x=>x.k);ds.forEach(d=>days.push({l:dname(d),ks,pm}))}
  else{const old=FOC;FOC={d:rx.d||[],k:rx.k||[]};let E;try{E=elig().slice()}finally{FOC=old}
    const per=Math.max(1,Math.min(E.length,Math.round((+rx.minutes||15)/5)));
    ds.forEach((d,i)=>{const t=[];for(let j=0;j<per;j++){const k=E[(i*per+j)%E.length];if(!t.includes(k))t.push(k)}days.push({l:dname(d),ks:t,pm:{}})})}
  return{days,ks:days.length?['x']:[],base:'week'}};
function weekBox(spec,ad){const m=h('p',{class:'dmsg'});
  return h('div',{class:'dcard'},h('b',{},'🖨 '+_('Print the whole week')),h('p',{class:'mut xs'},_('One set of sheets for each training day, with the day on every page.')),ad?h('p',{class:'mut xs'},_('Adaptive: the tasks follow the chosen domains or tasks, about one every 5 minutes, rotated over the week.')):'',
    h('label',{class:'chk'},(()=>{const c=h('input',{type:'checkbox',onchange(){prn.key=c.checked}});c.checked=prn.key;return c})(),h('span',{},_('Include the answer key'))),
    h('button',{class:'btn',onclick(){const s=spec();if(!s.days.length){m.textContent=_('Nothing to print.');return}pvOpen([],'');let pg=[];s.days.forEach(d=>pg.push(...buildSheets(CUR,d.ks,1,prn.key,d.pm,d.l)));pvOpen(pg,'neurorehab-week-'+CUR.replace(/[^\w-]+/g,'_'))}},_('Create sheets')),m)}
const sessSpec=ov=>()=>{buildPlan(ov);const pm={};plan.forEach(it=>pm[it.k]=it.p);return{ks:plan.map(x=>x.k),pm,base:'session'}};

function printModal(spec,title){let o;const m=h('p',{class:'dmsg'}),cp=h('div');
  cp.append(copiesField());
  o=mdl(h('h2',{class:'ctr'},'🖨 '+title),cp,
    h('label',{class:'chk'},(()=>{const c=h('input',{type:'checkbox',onchange(){prn.key=c.checked}});c.checked=prn.key;return c})(),h('span',{},_('Include the answer key'))),
    h('button',{class:'btn big',onclick(){const s=spec();if(!s.ks.length){m.textContent=_('Nothing to print.');return}o.remove();pvOpen([],'');const pg=buildSheets(CUR,s.ks,prn.copies,prn.key,s.pm);pvOpen(pg,'neurorehab-'+s.base+'-'+CUR.replace(/[^\w-]+/g,'_'))}},_('Create sheets')),m,
    h('button',{class:'link ctr',onclick(){o.remove()}},_('Cancel')))}

/* ---- minimal QR Code encoder (byte mode, ECC L/M/Q/H, versions 1-40, auto mask) ---- */
const QR=(()=>{
  const ECC_CW={L:[-1,7,10,15,20,26,18,20,24,30,18,20,24,26,30,22,24,28,30,28,28,28,28,30,30,26,28,30,30,30,30,30,30,30,30,30,30,30,30,30,30],
    M:[-1,10,16,26,18,24,16,18,22,22,26,30,22,22,24,24,28,28,26,26,26,26,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28]},
  ECC_BL={L:[-1,1,1,1,1,1,2,2,2,2,4,4,4,4,4,6,6,6,6,7,8,8,9,9,10,12,12,12,13,14,15,16,17,18,19,19,20,21,22,24,25],
    M:[-1,1,1,1,2,2,4,4,4,5,5,5,8,9,9,10,10,11,13,14,16,17,17,18,20,21,23,25,26,28,29,31,33,35,37,38,40,43,45,47,49]},
  FMT={L:1,M:0};
  const rawModules=v=>{let r=(16*v+128)*v+64;if(v>=2){const a=Math.floor(v/7)+2;r-=(25*a-10)*a-55;if(v>=7)r-=36}return r};
  const dataCw=(v,e)=>Math.floor(rawModules(v)/8)-ECC_CW[e][v]*ECC_BL[e][v];
  const bit=(x,i)=>((x>>>i)&1)!==0;
  function rsDiv(deg){const r=new Array(deg).fill(0);r[deg-1]=1;let root=1;for(let i=0;i<deg;i++){for(let j=0;j<r.length;j++){r[j]=mul(r[j],root);if(j+1<r.length)r[j]^=r[j+1]}root=mul(root,2)}return r}
  function mul(x,y){let z=0;for(let i=7;i>=0;i--){z=(z<<1)^((z>>>7)*0x11D);z^=((y>>>i)&1)*x}return z&255}
  function rsRem(data,div){const r=div.map(()=>0);for(const b of data){const f=b^r.shift();r.push(0);div.forEach((c,i)=>r[i]^=mul(c,f))}return r}
  function make(text,ecc,fm){
    ecc=ecc||'M';
    const bytes=typeof text=='string'?Array.from(new TextEncoder().encode(text)):Array.from(text);
    let ver=1;
    for(;;ver++){if(ver>40)throw new Error('QR too long');const cc=ver<10?8:16;if(4+cc+8*bytes.length<=dataCw(ver,ecc)*8)break}
    const bits=[];const put=(v,n)=>{for(let i=n-1;i>=0;i--)bits.push((v>>>i)&1)};
    put(4,4);put(bytes.length,ver<10?8:16);bytes.forEach(b=>put(b,8));
    const cap=dataCw(ver,ecc)*8;put(0,Math.min(4,cap-bits.length));put(0,(8-bits.length%8)%8);
    for(let p=0xEC;bits.length<cap;p^=0xEC^0x11)put(p,8);
    const data=[];for(let i=0;i<bits.length;i+=8){let b=0;for(let j=0;j<8;j++)b=(b<<1)|bits[i+j];data.push(b)}
    // ecc + interleave
    const nb=ECC_BL[ecc][ver],el=ECC_CW[ecc][ver],raw=Math.floor(rawModules(ver)/8),ns=nb-raw%nb,sl=Math.floor(raw/nb),div=rsDiv(el),blocks=[];
    for(let i=0,k=0;i<nb;i++){const len=sl-el+(i<ns?0:1),d=data.slice(k,k+len);k+=len;const e=rsRem(d,div);if(i<ns)d.push(0);blocks.push(d.concat(e))}
    const all=[];for(let i=0;i<blocks[0].length;i++)blocks.forEach((b,j)=>{if(i!=sl-el||j>=ns)all.push(b[i])});
    // matrix
    const size=ver*4+17,m=[],f=[];for(let i=0;i<size;i++){m.push(new Array(size).fill(false));f.push(new Array(size).fill(false))}
    const setf=(x,y,d)=>{m[y][x]=d;f[y][x]=true};
    for(let i=0;i<size;i++){setf(6,i,i%2==0);setf(i,6,i%2==0)}
    const finder=(cx,cy)=>{for(let dy=-4;dy<=4;dy++)for(let dx=-4;dx<=4;dx++){const d=Math.max(Math.abs(dx),Math.abs(dy)),x=cx+dx,y=cy+dy;if(x>=0&&x<size&&y>=0&&y<size)setf(x,y,d!=2&&d!=4)}};
    finder(3,3);finder(size-4,3);finder(3,size-4);
    const al=[];if(ver>1){const n=Math.floor(ver/7)+2,st=ver==32?26:Math.ceil((ver*4+4)/(n*2-2))*2,r=[6];for(let p=size-7;r.length<n;p-=st)r.splice(1,0,p);r.forEach((a,i)=>r.forEach((b,j)=>{if(!((i==0&&j==0)||(i==0&&j==n-1)||(i==n-1&&j==0)))al.push([a,b])}))}
    al.forEach(([cx,cy])=>{for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++)setf(cx+dx,cy+dy,Math.max(Math.abs(dx),Math.abs(dy))!=1)});
    const fmt=(mask)=>{const d=(FMT[ecc]<<3)|mask;let r=d;for(let i=0;i<10;i++)r=(r<<1)^((r>>>9)*0x537);const b=((d<<10)|r)^0x5412;
      for(let i=0;i<=5;i++)setf(8,i,bit(b,i));setf(8,7,bit(b,6));setf(8,8,bit(b,7));setf(7,8,bit(b,8));for(let i=9;i<15;i++)setf(14-i,8,bit(b,i));
      for(let i=0;i<8;i++)setf(size-1-i,8,bit(b,i));for(let i=8;i<15;i++)setf(8,size-15+i,bit(b,i));setf(8,size-8,true)};
    fmt(0);
    if(ver>=7){let r=ver;for(let i=0;i<12;i++)r=(r<<1)^((r>>>11)*0x1F25);const b=(ver<<12)|r;for(let i=0;i<18;i++){const a=size-11+i%3,c=Math.floor(i/3);setf(a,c,bit(b,i));setf(c,a,bit(b,i))}}
    // codewords
    for(let i=0,right=size-1;right>=1;right-=2){if(right==6)right=5;for(let v=0;v<size;v++)for(let j=0;j<2;j++){const x=right-j,up=((right+1)&2)==0,y=up?size-1-v:v;if(!f[y][x]&&i<all.length*8){m[y][x]=bit(all[i>>>3],7-(i&7));i++}}}
    const MASK=[(x,y)=>(x+y)%2==0,(x,y)=>y%2==0,(x,y)=>x%3==0,(x,y)=>(x+y)%3==0,(x,y)=>(Math.floor(x/3)+Math.floor(y/2))%2==0,(x,y)=>x*y%2+x*y%3==0,(x,y)=>(x*y%2+x*y%3)%2==0,(x,y)=>((x+y)%2+x*y%3)%2==0];
    const apply=k=>{for(let y=0;y<size;y++)for(let x=0;x<size;x++)if(!f[y][x]&&MASK[k](x,y))m[y][x]=!m[y][x]};
    const pen=()=>{let r=0;const run=(a)=>{let s=0,c=1;for(let i=1;i<=a.length;i++){if(i<a.length&&a[i]==a[i-1])c++;else{if(c>=5)s+=c-2;c=1}}return s};
      for(let y=0;y<size;y++){r+=run(m[y]);r+=run(m.map(row=>row[y]))}
      for(let y=0;y<size-1;y++)for(let x=0;x<size-1;x++){const c=m[y][x];if(c==m[y][x+1]&&c==m[y+1][x]&&c==m[y+1][x+1])r+=3}
      const pat=[true,false,true,true,true,false,true],chk=(a,i)=>{for(let k=0;k<7;k++)if(a[i+k]!==pat[k])return 0;const l=i-4>=0&&a.slice(i-4,i).every(v=>!v),rr=i+11<=a.length&&a.slice(i+7,i+11).every(v=>!v);return(l||rr)?40:0};
      for(let y=0;y<size;y++){const row=m[y],col=m.map(q=>q[y]);for(let i=0;i<=size-7;i++){r+=chk(row,i);r+=chk(col,i)}}
      let d=0;m.forEach(row=>row.forEach(c=>{if(c)d++}));r+=Math.floor(Math.abs(d*20-size*size*10)/(size*size))*10;return r};
    let bm=0,bp=1e9;for(let k=0;k<8;k++){apply(k);fmt(k);const p=pen();if(p<bp){bp=p;bm=k}apply(k)}
    if(fm!=null)bm=fm;apply(bm);fmt(bm);
    return{size,ver,get:(x,y)=>m[y][x]}}
  function draw(cv,q,px){const s=q.size+8;px=px||Math.max(3,Math.floor(300/s));cv.width=cv.height=s*px;const c=cv.getContext('2d');c.fillStyle='#fff';c.fillRect(0,0,cv.width,cv.height);c.fillStyle='#000';
    for(let y=0;y<q.size;y++)for(let x=0;x<q.size;x++)if(q.get(x,y))c.fillRect((x+4)*px,(y+4)*px,px,px)}
  return{make,draw}})();

/* ---- QR decoder (byte mode, ECC L/M) for webcams and photos when BarcodeDetector is missing ---- */
const QRD=(()=>{
  const EXP=new Array(512),LOG=new Array(256);{let x=1;for(let i=0;i<255;i++){EXP[i]=x;LOG[x]=i;x<<=1;if(x&256)x^=0x11D}for(let i=255;i<512;i++)EXP[i]=EXP[i-255]}
  const gm=(a,b)=>a&&b?EXP[LOG[a]+LOG[b]]:0,gd=(a,b)=>a?EXP[(LOG[a]+255-LOG[b])%255]:0;
  const ECC_CW={L:[-1,7,10,15,20,26,18,20,24,30,18,20,24,26,30,22,24,28,30,28,28,28,28,30,30,26,28,30,30,30,30,30,30,30,30,30,30,30,30,30,30],M:[-1,10,16,26,18,24,16,18,22,22,26,30,22,22,24,24,28,28,26,26,26,26,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28]},
    ECC_BL={L:[-1,1,1,1,1,1,2,2,2,2,4,4,4,4,4,6,6,6,6,7,8,8,9,9,10,12,12,12,13,14,15,16,17,18,19,19,20,21,22,24,25],M:[-1,1,1,1,2,2,4,4,4,5,5,5,8,9,9,10,10,11,13,14,16,17,17,18,20,21,23,25,26,28,29,31,33,35,37,38,40,43,45,47,49]};
  const rawM=v=>{let r=(16*v+128)*v+64;if(v>=2){const a=Math.floor(v/7)+2;r-=(25*a-10)*a-55;if(v>=7)r-=36}return r};
  function rsCorrect(cw,ne){ // cw: array (data+ecc), corrects in place; returns false if uncorrectable
    const n=cw.length,S=[];let bad=false;
    for(let i=0;i<ne;i++){let s=0;for(let j=0;j<n;j++)s=gm(s,EXP[i])^cw[j];S.push(s);if(s)bad=true}
    if(!bad)return true;
    let C=[1],B=[1],L=0,m=1,b=1;
    for(let k=0;k<ne;k++){let d=S[k];for(let i=1;i<=L;i++)d^=gm(C[i]||0,S[k-i]);
      if(d==0){m++}else{const T=C.slice(),co=gd(d,b);const sh=B.map(x=>gm(x,co));while(C.length<sh.length+m)C.push(0);sh.forEach((x,i)=>C[i+m]^=x);
        if(2*L<=k){L=k+1-L;B=T;b=d;m=1}else m++}}
    if(L*2>ne)return false;
    // Chien search (explicit evaluation)
    const ev=(poly,x)=>{let r=0,xp=1;for(let i=0;i<poly.length;i++){r^=gm(poly[i],xp);xp=gm(xp,x)}return r};
    const locs=[];for(let p=0;p<n;p++){if(ev(C,EXP[(255-p)%255])==0)locs.push(p)}
    if(locs.length!=L)return false;
    const O=[];for(let i=0;i<ne;i++){let v=0;for(let j=0;j<=i;j++)v^=gm(C[j]||0,S[i-j]);O.push(v)}
    const dC=new Array(C.length).fill(0);for(let i=1;i<C.length;i+=2)dC[i-1]=C[i];
    for(const p of locs){const X=EXP[p],Xi=EXP[(255-p)%255];const num=ev(O,Xi),den=ev(dC,Xi);if(!den)return false;cw[n-1-p]^=gm(X,gd(num,den))}
    for(let i=0;i<ne;i++){let s=0;for(let j=0;j<n;j++)s=gm(s,EXP[i])^cw[j];if(s)return false}
    return true}
  function layout(ver){const size=ver*4+17,f=[];for(let i=0;i<size;i++)f.push(new Array(size).fill(false));
    const set=(x,y)=>{if(x>=0&&y>=0&&x<size&&y<size)f[y][x]=true};
    for(let i=0;i<size;i++){set(6,i);set(i,6)}
    [[3,3],[size-4,3],[3,size-4]].forEach(([cx,cy])=>{for(let dy=-4;dy<=4;dy++)for(let dx=-4;dx<=4;dx++)set(cx+dx,cy+dy)});
    if(ver>1){const n=Math.floor(ver/7)+2,st=ver==32?26:Math.ceil((ver*4+4)/(n*2-2))*2,r=[6];for(let p=size-7;r.length<n;p-=st)r.splice(1,0,p);
      r.forEach((a,i)=>r.forEach((b,j)=>{if(!((i==0&&j==0)||(i==0&&j==n-1)||(i==n-1&&j==0)))for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++)set(a+dx,b+dy)}))}
    for(let i=0;i<=8;i++){set(8,i);set(i,8)}for(let i=0;i<8;i++){set(size-1-i,8);set(8,size-1-i)}
    if(ver>=7)for(let i=0;i<6;i++)for(let j=0;j<3;j++){set(size-11+j,i);set(i,size-11+j)}
    return f}
  const FW=(()=>{const a=[];for(let d=0;d<32;d++){let r=d;for(let i=0;i<10;i++)r=(r<<1)^((r>>>9)*0x537);a.push({d,w:((d<<10)|r)^0x5412})}return a})();
  const pc=x=>{let c=0;while(x){c+=x&1;x>>>=1}return c};
  const MASK=[(x,y)=>(x+y)%2==0,(x,y)=>y%2==0,(x,y)=>x%3==0,(x,y)=>(x+y)%3==0,(x,y)=>(Math.floor(x/3)+Math.floor(y/2))%2==0,(x,y)=>x*y%2+x*y%3==0,(x,y)=>(x*y%2+x*y%3)%2==0,(x,y)=>((x+y)%2+x*y%3)%2==0];
  function decodeGrid(g,size){ // g(x,y)->0/1
    const ver=(size-17)/4;if(ver<1||ver>40||ver%1)return null;
    const bit=(x,y)=>g(x,y)?1:0;
    const rd=(pts)=>{let v=0;pts.forEach((p,i)=>{v|=bit(p[0],p[1])<<i});return v};
    const a=[];for(let i=0;i<=5;i++)a.push([8,i]);a.push([8,7],[8,8],[7,8]);for(let i=9;i<15;i++)a.push([14-i,8]);
    const b=[];for(let i=0;i<8;i++)b.push([size-1-i,8]);for(let i=8;i<15;i++)b.push([8,size-15+i]);
    let best=null,bd=99;for(const w of [rd(a),rd(b)])for(const c of FW){const d=pc(w^c.w);if(d<bd){bd=d;best=c.d}}
    if(bd>3)return null;
    const eccBits=best>>3,mask=best&7,ecc=eccBits==1?'L':eccBits==0?'M':null;if(!ecc)return null;
    const f=layout(ver),bits=[];
    for(let right=size-1;right>=1;right-=2){if(right==6)right=5;for(let v=0;v<size;v++)for(let j=0;j<2;j++){const x=right-j,up=((right+1)&2)==0,y=up?size-1-v:v;if(!f[y][x])bits.push(bit(x,y)^(MASK[mask](x,y)?1:0))}}
    const total=Math.floor(rawM(ver)/8),cw=[];for(let i=0;i<total;i++){let v=0;for(let j=0;j<8;j++)v=(v<<1)|bits[i*8+j];cw.push(v)}
    const nb=ECC_BL[ecc][ver],el=ECC_CW[ecc][ver],ns=nb-total%nb,sl=Math.floor(total/nb),blocks=[];for(let i=0;i<nb;i++)blocks.push(new Array(sl+1).fill(0));
    let k=0;for(let i=0;i<=sl;i++)for(let j=0;j<nb;j++){if(i!=sl-el||j>=ns)blocks[j][i]=cw[k++]}
    const data=[];
    for(let j=0;j<nb;j++){const arr=j<ns?blocks[j].filter((_x,i)=>i!=sl-el):blocks[j].slice();
      if(!rsCorrect(arr,el))return null;data.push(...arr.slice(0,arr.length-el))}
    // parse byte mode
    let p=0;const rb=n=>{let v=0;for(let i=0;i<n;i++){const by=data[p>>3];if(by===undefined)return -1;v=(v<<1)|((by>>(7-(p&7)))&1);p++}return v};
    const out=[];for(;;){const m=rb(4);if(m<=0)break;if(m!=4)return null;const n=rb(ver<10?8:16);if(n<0)return null;const u=new Uint8Array(n);for(let i=0;i<n;i++){const v=rb(8);if(v<0)return null;u[i]=v}out.push(u)}
    const all=new Uint8Array(out.reduce((s,u)=>s+u.length,0));let o=0;out.forEach(u=>{all.set(u,o);o+=u.length});
    return new TextDecoder().decode(all)}
  /* ---- image side ---- */
  function binarize(gray,w,h,kf){kf=kf||0.92;const s=Math.max(15,(Math.min(w,h)/8)|0)|1,I=new Float64Array((w+1)*(h+1));
    for(let y=0;y<h;y++){let r=0;for(let x=0;x<w;x++){r+=gray[y*w+x];I[(y+1)*(w+1)+x+1]=I[y*(w+1)+x+1]+r}}
    const bin=new Uint8Array(w*h),hs=s>>1;
    for(let y=0;y<h;y++){const y0=Math.max(0,y-hs),y1=Math.min(h,y+hs+1);for(let x=0;x<w;x++){const x0=Math.max(0,x-hs),x1=Math.min(w,x+hs+1),sum=I[y1*(w+1)+x1]-I[y0*(w+1)+x1]-I[y1*(w+1)+x0]+I[y0*(w+1)+x0],mean=sum/((x1-x0)*(y1-y0));bin[y*w+x]=gray[y*w+x]<mean*kf?1:0}}
    return bin}
  const ratioOk=(r)=>{const t=r[0]+r[1]+r[2]+r[3]+r[4];if(t<7)return 0;const m=t/7,v=m*0.7;return Math.abs(r[0]-m)<v&&Math.abs(r[1]-m)<v&&Math.abs(r[2]-3*m)<3*v&&Math.abs(r[3]-m)<v&&Math.abs(r[4]-m)<v?m:0};
  function crossV(bin,w,h,cx,cy){ // vertical run lengths through (cx,cy) which is black
    const run=(dy)=>{let n=0,y=cy;while(y>=0&&y<h&&bin[y*w+cx]==1){n++;y+=dy}const a=n;n=0;while(y>=0&&y<h&&bin[y*w+cx]==0){n++;y+=dy}const b=n;n=0;while(y>=0&&y<h&&bin[y*w+cx]==1){n++;y+=dy}return[a,b,n]};
    const u=run(-1),d=run(1);const c=u[0]+d[0]-1,r=[u[2],u[1],c,d[1],d[2]];const m=ratioOk(r);return m?{m,cy:cy-u[0]+c/2}:null}
  function findFinders(bin,w,h){const cand=[];
    for(let y=0;y<h;y++){let x=0;const runs=[];let cur=bin[y*w],len=0;for(x=0;x<w;x++){if(bin[y*w+x]==cur)len++;else{runs.push([cur,len,x-len]);cur=bin[y*w+x];len=1}}runs.push([cur,len,w-len]);
      for(let i=0;i+4<runs.length;i++){if(runs[i][0]!=1)continue;const r=[runs[i][1],runs[i+1][1],runs[i+2][1],runs[i+3][1],runs[i+4][1]],m=ratioOk(r);if(!m)continue;
        const cx=Math.round(runs[i+2][2]+runs[i+2][1]/2);const v=crossV(bin,w,h,Math.min(w-1,cx),y);if(!v)continue;
        // horizontal re-check at refined y
        const yy=Math.round(v.cy);let x0=cx,x1=cx;while(x0>0&&bin[yy*w+x0-1]==1)x0--;while(x1<w-1&&bin[yy*w+x1+1]==1)x1++;
        const ex=(x0+x1)/2+.5,mm=(m+v.m)/2;let hit=null;for(const c of cand){if(Math.hypot(c.x-ex,c.y-(v.cy+.5))<mm*2.5&&Math.abs(c.m-mm)<mm*.5){hit=c;break}}
        if(hit){hit.x=(hit.x*hit.n+ex)/(hit.n+1);hit.y=(hit.y*hit.n+v.cy+.5)/(hit.n+1);hit.m=(hit.m*hit.n+mm)/(hit.n+1);hit.n++}else cand.push({x:ex,y:v.cy+.5,m:mm,n:1})}}
    return cand.filter(c=>c.n>=1).sort((a,b)=>b.n-a.n).slice(0,12)}
  function homog(src,dst){ // 4 point correspondences -> 3x3 (h33=1)
    const A=[],B=[];for(let i=0;i<4;i++){const[x,y]=src[i],[u,v]=dst[i];A.push([x,y,1,0,0,0,-u*x,-u*y]);B.push(u);A.push([0,0,0,x,y,1,-v*x,-v*y]);B.push(v)}
    for(let i=0;i<8;i++){let p=i;for(let r=i+1;r<8;r++)if(Math.abs(A[r][i])>Math.abs(A[p][i]))p=r;if(Math.abs(A[p][i])<1e-12)return null;[A[i],A[p]]=[A[p],A[i]];[B[i],B[p]]=[B[p],B[i]];
      for(let r=0;r<8;r++)if(r!=i){const f=A[r][i]/A[i][i];for(let c=i;c<8;c++)A[r][c]-=f*A[i][c];B[r]-=f*B[i]}}
    const h=B.map((b,i)=>b/A[i][i]);return h}
  const ap=(H,x,y)=>{const d=H[6]*x+H[7]*y+1;return[(H[0]*x+H[1]*y+H[2])/d,(H[3]*x+H[4]*y+H[5])/d]};
  function findAlign(bin,w,h,px,py,m){const R=Math.round(m*5);let best=null,bd=1e9;
    const at=(x,y)=>x>=0&&y>=0&&x<w&&y<h?bin[y*w+x]:0;
    for(let y=Math.max(0,Math.round(py)-R);y<=Math.min(h-1,Math.round(py)+R);y++)for(let x=Math.max(0,Math.round(px)-R);x<=Math.min(w-1,Math.round(px)+R);x++){
      if(!at(x,y))continue;const mm=Math.max(1,Math.round(m));if(!(!at(x-mm,y)&&!at(x+mm,y)&&!at(x,y-mm)&&!at(x,y+mm)&&at(x-2*mm,y)&&at(x+2*mm,y)&&at(x,y-2*mm)&&at(x,y+2*mm)))continue;
      const d=Math.hypot(x-px,y-py);if(d<bd){bd=d;best=[x+.5,y+.5]}}
    return best}
  function tryTriple(bin,gray,w,h,a,b,c){ // a,b,c finder candidates
    const d=(p,q)=>Math.hypot(p.x-q.x,p.y-q.y);const tri=[[a,b,c],[b,a,c],[c,a,b]];
    for(const[tl,p,q]of tri){const v1=[p.x-tl.x,p.y-tl.y],v2=[q.x-tl.x,q.y-tl.y],l1=Math.hypot(...v1),l2=Math.hypot(...v2);if(l1<10||l2<10||Math.abs(l1-l2)>.3*Math.max(l1,l2))continue;
      const cs=(v1[0]*v2[0]+v1[1]*v2[1])/(l1*l2);if(Math.abs(cs)>.35)continue;
      let tr=p,bl=q;if(v1[0]*v2[1]-v1[1]*v2[0]<0){tr=q;bl=p}
      const m=(tl.m+tr.m+bl.m)/3,dist=(d(tl,tr)+d(tl,bl))/2,est=dist/m+7,ver0=Math.round((est-17)/4);
      for(const ver of [ver0,ver0+1,ver0-1,ver0+2,ver0+3,ver0-2]){if(ver<1||ver>40)continue;const size=ver*4+17,s=size-7;
        const V=[[3.5,3.5,tl],[size-3.5,3.5,tr],[3.5,size-3.5,bl]];const par=[tr.x+bl.x-tl.x,tr.y+bl.y-tl.y];
        let H=homog([[3.5,3.5],[size-3.5,3.5],[3.5,size-3.5],[size-3.5,size-3.5]],[[tl.x,tl.y],[tr.x,tr.y],[bl.x,bl.y],par]);if(!H)continue;
        const tries=[H];
        if(ver>1){const pr=ap(H,size-6.5,size-6.5),found=findAlign(bin,w,h,pr[0],pr[1],dist/s);if(found){const H2=homog([[3.5,3.5],[size-3.5,3.5],[3.5,size-3.5],[size-6.5,size-6.5]],[[tl.x,tl.y],[tr.x,tr.y],[bl.x,bl.y],found]);if(H2)tries.unshift(H2)}}
        for(const T of tries){const mp=dist/s,g=(x,y)=>{let vote=0;for(const[dx,dy]of[[0,0],[.25,0],[-.25,0],[0,.25],[0,-.25]]){const[u,v]=ap(T,x+.5+dx,y+.5+dy),ix=Math.round(u-.5),iy=Math.round(v-.5);if(ix>=0&&iy>=0&&ix<w&&iy<h)vote+=bin[iy*w+ix]}return vote>=3};
          const r=decodeGrid(g,size);if(r!=null)return r}}}
    return null}
  function decodeGray(gray,w,h){for(const kf of [0.92,0.84,1.0]){const bin=binarize(gray,w,h,kf),F=findFinders(bin,w,h);if(F.length<3)continue;
    for(let i=0;i<F.length;i++)for(let j=i+1;j<F.length;j++)for(let k=j+1;k<F.length;k++){const m=[F[i].m,F[j].m,F[k].m];if(Math.max(...m)/Math.min(...m)>1.6)continue;const r=tryTriple(bin,gray,w,h,F[i],F[j],F[k]);if(r!=null)return r}}
    return null}
  function decode(img){ // ImageData-like {data,width,height}
    const w=img.width,h=img.height,d=img.data,g=new Uint8Array(w*h);for(let i=0,j=0;i<g.length;i++,j+=4)g[i]=(d[j]*77+d[j+1]*150+d[j+2]*29)>>8;
    try{return decodeGray(g,w,h)}catch(e){return null}}
  return{decode,decodeGrid,rsCorrect}})();

/* ---- share by QR: serialize, split in numbered QR codes, cycle; reader for the receiving side ---- */
const SH_CH=250,b64u=u=>{let s='';for(let i=0;i<u.length;i+=8192)s+=String.fromCharCode.apply(null,u.subarray(i,i+8192));return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')},
  unb64u=s=>{s=s.replace(/-/g,'+').replace(/_/g,'/');while(s.length%4)s+='=';const b=atob(s),u=new Uint8Array(b.length);for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return u},
  crc32=s=>{let c,t=crc32.t;if(!t){t=crc32.t=[];for(let n=0;n<256;n++){c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0}}let r=0xFFFFFFFF;for(let i=0;i<s.length;i++)r=t[(r^s.charCodeAt(i))&255]^(r>>>8);return((r^0xFFFFFFFF)>>>0).toString(16).padStart(8,'0')};
async function shPack(obj){const u=new TextEncoder().encode(JSON.stringify(obj));let f='r',d=u;
  try{if(window.CompressionStream){d=new Uint8Array(await new Response(new Blob([u]).stream().pipeThrough(new CompressionStream('deflate-raw'))).arrayBuffer());f='z'}}catch(e){d=u;f='r'}
  return{f,s:b64u(d)}}
async function shUnpack(f,s){let d=unb64u(s);if(f=='z')d=new Uint8Array(await new Response(new Blob([d]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer());return new TextDecoder().decode(d)}
function shParts(p){const id=Math.random().toString(36).slice(2,6),n=Math.max(1,Math.ceil(p.s.length/SH_CH)),c=crc32(p.s);
  return[...Array(n)].map((_x,i)=>`TG1.${id}.${i+1}.${n}.${p.f}${c}.${p.s.slice(i*SH_CH,(i+1)*SH_CH)}`)}
function shPayload(kind,names){const users={};names.forEach(n=>{if(PS[n])users[n]={...PS[n]}});
  const hs=kind=='p'?[]:hist.filter(x=>users[x.u||'']).map(x=>({t:x.t,k:x.k,m:x.m,u:x.u||'',pct:x.pct,v:x.v}));
  return{app:'task-generator',format:1,kind,exportedAt:new Date().toISOString(),scope:kind=='a'?'all':'one',users,history:hs}}

/* sender */
function shareModal(){let o;const close=()=>o&&o.remove(),
  pickWho=kind=>{const names=Object.keys(PS);if(!names.length){return}if(names.length==1)return go(kind,names);
    const b=names.map(n=>h('button',{class:'btn alt big',onclick(){go(kind,[n])}},n));o.querySelector('.mbox').replaceChildren(h('h2',{class:'ctr'},kind=='p'?_('Which profile?'):_('Whose history?')),...b,h('button',{class:'link ctr',onclick(){close();shareModal()}},_('Back')))},
  go=async(kind,names)=>{const box=o.querySelector('.mbox');box.replaceChildren(h('p',{class:'mut ctr'},_('Preparing the codes…')));
    const parts=shParts(await shPack(shPayload(kind,names)));qrCycle(box,parts,close)},
  opt=(ic,t,d,fn)=>h('button',{class:'shopt',onclick:fn},h('span',{class:'shic'},ic),h('span',{},h('b',{},t),h('small',{},d)));
  o=mdl(h('h2',{class:'ctr'},_('Share by QR')),h('p',{class:'mut ctr xs'},_('What do you want to share?')),
    opt('👤',_('A patient profile'),_('Profile and plan'),()=>pickWho('p')),
    opt('📈',_('A patient’s history'),_('Results of one patient'),()=>pickWho('h')),
    opt('🗂',_('Everything'),_('All patients and all history'),()=>go('a',Object.keys(PS))),
    h('button',{class:'link ctr',onclick(){close();recvModal()}},'📷 '+_('Receive by QR')),
    h('button',{class:'link ctr',onclick:close},_('Cancel')))}
function shareSelected(){if(!PS[CUR])return;let o;const close=()=>o&&o.remove();o=mdl(h('p',{class:'mut ctr'},_('Preparing the codes…')));
  (async()=>{const parts=shParts(await shPack(shPayload('p',[CUR])));qrCycle(o.querySelector('.mbox'),parts,close,CUR)})()}
function qrCycle(box,parts,close,who){let i=0,run=true,t=null;const n=parts.length,cv=h('canvas',{class:'qrcv'}),lab=h('b',{class:'qrlab'}),dots=h('div',{class:'qrdots'}),
    pb=h('button',{class:'btn alt',onclick(){run=!run;pb.textContent=run?'⏸':'▶';if(run)tick()}},'⏸');
  const qc={},draw=()=>{try{const q=qc[i]||(qc[i]=QR.make(parts[i],'M'));QR.draw(cv,q,Math.max(3,Math.floor(320/(q.size+8))))}catch(e){}lab.textContent=_('Part {0}/{1}',i+1,n);dots.replaceChildren(...(n<=40?parts.map((_x,j)=>h('i',{class:j==i?'on':''})):[]))};
  const tick=()=>{clearTimeout(t);draw();if(run&&n>1)t=setTimeout(()=>{i=(i+1)%n;tick()},1300)};
  const stop=()=>{clearTimeout(t);run=false};
  box.replaceChildren(h('h2',{class:'ctr'},_('Scan with the other device')),who?h('p',{class:'mut ctr xs'},_('Profile and plan: {0}',who)):'',cv,lab,dots,
    h('p',{class:'mut ctr xs'},n>1?_('{0} codes repeat in a loop. Scan them in any order until the other device has all parts.',n):_('One code. Scan it with the other device.')),
    h('div',{class:'two'},h('button',{class:'btn alt',onclick(){i=(i-1+n)%n;run=false;pb.textContent='▶';tick()}},'‹'),pb,h('button',{class:'btn alt',onclick(){i=(i+1)%n;run=false;pb.textContent='▶';tick()}},'›')),
    h('button',{class:'btn big',onclick(){stop();close()}},_('Done')),who?h('button',{class:'link ctr',onclick(){stop();close();shareModal()}},_('More options: history, everything, receive')):'');
  tick();new MutationObserver((_m,ob)=>{if(!document.body.contains(cv)){stop();ob.disconnect()}}).observe(document.body,{childList:true,subtree:true})}

/* receiver */
function recvModal(){const got={};let meta=null,stream=null,alive=false,det=null,busy=false,o,gen=0;
  const st=h('p',{class:'mut ctr xs qrst'},_('Point the camera at the QR codes.')),prog=h('div',{class:'qrdots rc'}),vid=h('video',{class:'qrvid hid',playsinline:'',muted:'',autoplay:''}),
    sel=h('select',{class:'hid qrsel','aria-label':_('Camera'),onchange(){startCam(sel.value)}}),
    stopCam=()=>{alive=false;gen++;try{stream&&stream.getTracks().forEach(t=>t.stop())}catch(e){}stream=null},
    shut=()=>{stopCam();o.remove()};
  vid.muted=true;
  const draw=()=>{if(!meta)return;prog.replaceChildren(...[...Array(meta.n)].map((_x,j)=>h('i',{class:got[j+1]?'on':''},String(j+1))));st.textContent=_('Parts received: {0}/{1}',Object.keys(got).length,meta.n)};
  const cvs=document.createElement('canvas'),grab=(src,sw,sh,maxW,crop)=>{const cx=crop?crop[0]:0,cy=crop?crop[1]:0,cw=crop?crop[2]:sw,ch=crop?crop[3]:sh,k=Math.min(1,maxW/cw),w=Math.max(1,Math.round(cw*k)),h_=Math.max(1,Math.round(ch*k));cvs.width=w;cvs.height=h_;const c=cvs.getContext('2d',{willReadFrequently:true});c.drawImage(src,cx,cy,cw,ch,0,0,w,h_);try{return QRD.decode(c.getImageData(0,0,w,h_))}catch(e){return null}};
  async function ingest(txt){txt=String(txt||'').trim();const m=/^TG1\.([a-z0-9]{1,8})\.(\d+)\.(\d+)\.([rz])([0-9a-f]{8})\.([A-Za-z0-9_-]*)$/.exec(txt);if(!m)return false;
    const[,id,i,n,f,c,d]=m;if(+i<1||+i>+n)return false;
    if(!meta||meta.id!=id){meta={id,n:+n,f,c};for(const k in got)delete got[k]}
    if(got[+i]===undefined){got[+i]=d;try{navigator.vibrate&&navigator.vibrate(40)}catch(e){}}draw();
    if(Object.keys(got).length==meta.n){const s=[...Array(meta.n)].map((_x,j)=>got[j+1]).join('');stopCam();
      if(crc32(s)!=meta.c){st.textContent=_('The data is damaged. Scan again.');meta=null;return true}
      try{review(await shUnpack(meta.f,s))}catch(e){st.textContent=_('The data could not be read.')}}
    return true}
  function review(txt){const im=parseImport(txt);if(im.err){st.textContent=_('This is not a Task Generator file.');return}
    const names=Object.keys(im.users),box=o.querySelector('.mbox');
    box.replaceChildren(h('h2',{class:'ctr'},'✓ '+_('Received')),h('p',{class:'ctr'},_('{0} profile(s) · {1} result(s)',names.length,im.hist.length)),h('p',{class:'mut ctr xs'},names.join(', ')),
      h('button',{class:'btn big',onclick(){applyImport(im,names,'merge');if(names.length){CUR=names[0];try{pickMode=false}catch(e){}saveP()}o.remove();try{hdr()}catch(e){}show(ROLE=='patient'?'phome':'home');typeof toast=='function'&&toast(_('Imported ✓'))}},_('Add to this device')),
      h('p',{class:'mut ctr xs'},_('Existing data is merged: nothing is deleted and duplicates are skipped.')),
      h('button',{class:'link ctr',onclick:()=>o.remove()},_('Cancel')))}
  async function fromImage(src,w,h_){let tx=[];if(det){try{tx=(await det.detect(src)).map(c=>c.rawValue)}catch(e){}}
    if(!tx.length){for(const W of [1000,1600,2400,700]){const r=grab(src,w,h_,W);if(r){tx=[r];break}}}
    if(!tx.length){const cw=w*.6,ch=h_*.6;for(const[x,y]of[[0,0],[w-cw,0],[0,h_-ch],[w-cw,h_-ch],[(w-cw)/2,(h_-ch)/2]]){const r=grab(src,w,h_,1400,[x,y,cw,ch]);if(r){tx=[r];break}}}
    let ok=false;for(const x of tx)ok=(await ingest(x))||ok;return ok}
  async function files(list){let any=false,bad=0;st.textContent=_('Reading photo…');
    for(const f of list){try{const bm=await createImageBitmap(f);const ok=await fromImage(bm,bm.width,bm.height);any=any||ok;if(!ok)bad++;bm.close&&bm.close()}catch(e){bad++}}
    if(!any)st.textContent=_('No code found in the photo. Get closer so the code fills most of the picture, and keep it sharp.');else if(bad&&meta&&Object.keys(got).length<meta.n)draw()}
  const fin=h('input',{type:'file',accept:'image/*',capture:'environment',class:'qrfile',async onchange(){const l=[...fin.files];fin.value='';if(l.length)await files(l)}}),
    photoBtn=h('label',{class:'btn alt qrlbl'},'📷 '+_('Take a photo'),fin),
    tabBtn=h('button',{class:'btn alt hid',onclick(){try{window.open(location.href,'_blank','noopener')}catch(e){}}},'↗ '+_('Open in a new tab')),
    camBtn=h('button',{class:'btn alt',onclick(){startCam()}},'📷 '+_('Use the camera'));
  const touch=(navigator.maxTouchPoints>0&&/Android|iPhone|iPad|Mobile/i.test(navigator.userAgent)),emb=(()=>{try{return window.self!==window.top&&/^https?:/.test(location.href)}catch(e){return true}})();
  o=mdl(h('h2',{class:'ctr'},_('Receive by QR')),vid,sel,st,prog,
    h('div',{class:'two'},camBtn,touch?photoBtn:''),tabBtn,
    h('p',{class:'mut ctr xs'},touch?_('The live camera needs permission. If it stays blocked, “Take a photo” opens your camera app: take one photo per code.'):_('The camera needs permission from the browser. Allow it when asked.')),
    h('button',{class:'link ctr',onclick:shut},_('Close')));
  const blocked=m=>{st.textContent=m;if(emb)tabBtn.classList.remove('hid')};
  async function startCam(devId){stopCam();const my=++gen;vid.classList.add('hid');
    if(!window.isSecureContext||!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){blocked(_('The camera is not available in this view.'));return}
    try{if(navigator.permissions&&navigator.permissions.query){const ps=await navigator.permissions.query({name:'camera'});if(ps.state=='denied'){blocked(_('The camera is blocked for this site. Allow it in the browser settings (padlock in the address bar), then tap “Use the camera”.'));return}}}catch(e){}
    st.textContent=_('Starting the camera…');
    try{const vc=devId?{deviceId:{exact:devId}}:{facingMode:{ideal:'environment'}};stream=await navigator.mediaDevices.getUserMedia({video:{...vc,width:{ideal:1280},height:{ideal:720}},audio:false})}
    catch(e){const n=e&&e.name||'';let pol=true;try{const pp=document.permissionsPolicy||document.featurePolicy;if(pp&&pp.allowsFeature)pol=pp.allowsFeature('camera')}catch(e2){}
      if(!pol){blocked(_('This embedded view does not allow the camera. Open the app in its own tab to use it.'));return}
      blocked(n=='NotFoundError'||n=='OverconstrainedError'?_('No camera was found on this device.'):n=='NotAllowedError'||n=='SecurityError'?_('Camera permission was not given. Allow it in the browser (padlock in the address bar), then tap “Use the camera”.'):_('The camera could not be started.'));return}
    if(my!=gen||!document.body.contains(vid)){try{stream.getTracks().forEach(t=>t.stop())}catch(e){}return}
    vid.srcObject=stream;vid.classList.remove('hid');try{await vid.play()}catch(e){}
    try{const ds=(await navigator.mediaDevices.enumerateDevices()).filter(d=>d.kind=='videoinput');if(ds.length>1){const cur=stream.getVideoTracks()[0].getSettings().deviceId;sel.replaceChildren(...ds.map((d,i)=>h('option',{value:d.deviceId},d.label||(_('Camera')+' '+(i+1)))));sel.value=cur||ds[0].deviceId;sel.classList.remove('hid')}}catch(e){}
    st.textContent=_('Point the camera at the QR codes.');alive=true;busy=false;
    const loop=async()=>{if(!alive||my!=gen||!document.body.contains(vid))return stopCam();if(!busy&&vid.readyState>=2&&vid.videoWidth){busy=true;try{if(det){const r=await det.detect(vid);for(const c of r)await ingest(c.rawValue)}else{const r=grab(vid,vid.videoWidth,vid.videoHeight,720);if(r)await ingest(r)}}catch(e){}busy=false}setTimeout(loop,det?140:180)};loop()}
  try{if(window.BarcodeDetector)det=new BarcodeDetector({formats:['qr_code']})}catch(e){}
  startCam();
  new MutationObserver((_m,ob)=>{if(!document.body.contains(vid)){stopCam();ob.disconnect()}}).observe(document.body,{childList:true,subtree:true})}

/* ---------- in-app manual (adapted from the PARP-AVC technical manual) ---------- */
const MAN={
en:{ttl:'Manual',sub:'Adapted from the PARP-AVC technical manual (Faria & Bermúdez i Badia)',S:[
['Purpose',['Task Generator creates personalised cognitive training for people after a stroke. It was designed for health professionals in cognitive rehabilitation and can also be used at home, on screen or on paper.','It offers 11 tasks, built with the help of more than 20 clinicians (doctors, psychologists, nurses, occupational and speech therapists). Every task is generated anew each time, so it can be repeated without learning the answers.','Each task is rated for its load on four cognitive domains (attention, memory, executive functions, language) and for overall difficulty. The small bars on every task show this profile.']],
['How the app works',['• Profile: five values from 1 to 10 (attention, memory, executive functions, language, general difficulty). Take them from a screening such as the Addenbrooke’s Cognitive Examination or the Montreal Cognitive Assessment, or from a longer test battery.','• Clinician view: manages profiles and plans, prepares sessions, prints, follows adherence and results.','• Patient view: very simple screens, just today’s training. Switch with the button at the top; a PIN can protect the clinician view.','The app works offline on the device and saves everything in the browser; use Progress → Data and backup to move or back up data.']],
['Ways to train',['• Adaptive training: the app picks tasks and adjusts their difficulty after every exercise so that the person stays at about 50–70% correct, where learning is greatest.','• Full session: all 11 tasks, one after another, set to the profile. With “Only include tasks that closely match the profile” ticked, tasks too far from the profile are left out; unticked, all 11 are run and adapted to the profile.','• Free practice: choose one task and set each parameter yourself. The chart shows the cognitive demand of those settings.']],
['Clinician: plan and follow-up',['Open the plan from the home card. Choose the training days, minutes per session, type of session (adaptive or full session) and how long it lasts (weeks or permanent). Optionally focus on a domain or on chosen tasks, and add a calendar reminder (.ics).','The patient sees today’s training, the week’s sessions (done, missed, due) and a progress chart. If training is interrupted, it resumes next time from the task where it stopped. Missed sessions can be caught up within the same week.','Progress → Overview shows the week and the performance charts per task and cognitive domain. Export and import (Data and backup) carry plans and results between devices; a backup is made before every import.']],
['Paper version and PDF',['Full session and Free practice have a Print button: choose 1 to 3 versions and whether to include the answer key, then create the sheets. Long tasks continue on a new page and memory tasks include every step. Download PDF or print from the preview.','Progress has a one-page report with profile, plan, sessions per week and performance, ready to print or file.']],
['Scoring (on paper)',['On screen the app scores automatically. For paper sheets use these criteria and convert to a percentage of the items available, so results stay comparable between different sheets:','• Cancellation: items correctly circled minus items wrongly circled.','• Number sequences: sequences solved correctly.','• Problem solving: problems solved correctly.','• Association: correct associations (any coherent justification from the patient counts).','• Contexts: descriptions correctly identified minus those wrongly identified.','• Picture pairs: pairs recalled correctly.','• Word search: words found.','• Mazes: 100% only if the path from entrance to exit is drawn.','• Categorization: items correctly categorised.','• Action sequences: sequences correctly ordered.','• Story and picture memory: questions answered correctly. On screen these are marked by the user, as the original exercise has no answer key.']],
['Interpreting results',['Results are an aid to the clinician’s judgement. When performance reaches 80–100% with given settings, the next task or session should be harder; below about 50%, easier. Adaptive training does this automatically, aiming for 50–70%.','Chart colours: green is the 50–70% target zone, blue above it (too easy), red below it (too hard).']],
['About',['PARP-AVC (Programa Adaptável para a Reabilitação Personalizada do Acidente Vascular Cerebral), created by Ana Lúcia Faria and Sergi Bermúdez i Badia, NeuroRehabLab, LifeTech OpenQoL.','The translations of the app into Portuguese, Spanish and Italian should be reviewed by native-speaking clinicians.']]]},
pt:{ttl:'Manual',sub:'Adaptado do Manual Técnico do PARP-AVC (Faria & Bermúdez i Badia)',S:[
['Objetivo',['O Task Generator cria treino cognitivo personalizado para pessoas após um AVC. Foi desenvolvido para profissionais de saúde na reabilitação cognitiva e pode também ser usado em casa, no ecrã ou em papel.','Oferece 11 tarefas, construídas com a colaboração de mais de 20 profissionais (médicos, psicólogos, enfermeiros, terapeutas ocupacionais e da fala). Cada tarefa é gerada de novo de cada vez, por isso pode repetir-se sem decorar as respostas.','Cada tarefa tem uma sobrecarga estimada em quatro domínios cognitivos (atenção, memória, funções executivas, linguagem) e uma dificuldade geral. As barras pequenas em cada tarefa mostram esse perfil.']],
['Como funciona',['• Perfil: cinco valores de 1 a 10 (atenção, memória, funções executivas, linguagem, dificuldade geral). Podem obter-se de uma avaliação de rastreio, como o Exame Cognitivo de Addenbrooke ou a Avaliação Cognitiva de Montreal, ou de uma bateria de testes mais extensa.','• Vista do clínico: gere perfis e planos, prepara sessões, imprime, acompanha a adesão e os resultados.','• Vista do utente: ecrãs muito simples, só o treino de hoje. Mude com o botão no topo; um PIN pode proteger a vista do clínico.','A aplicação funciona sem ligação à internet e guarda tudo no navegador; use Progresso → Dados e cópia de segurança para mudar de dispositivo ou guardar uma cópia.']],
['Formas de treinar',['• Treino adaptativo: a aplicação escolhe as tarefas e ajusta a dificuldade após cada exercício para manter a pessoa com cerca de 50–70% de acertos, onde a aprendizagem é maior.','• Sessão completa: as 11 tarefas, uma a seguir à outra, ajustadas ao perfil. Com “Incluir só tarefas muito próximas do perfil” marcado, as tarefas demasiado distantes ficam de fora; desmarcado, fazem-se as 11, adaptadas ao perfil.','• Prática livre: escolha uma tarefa e defina cada parâmetro. O gráfico mostra a exigência cognitiva dessas definições.']],
['Clínico: plano e acompanhamento',['Abra o plano no cartão do ecrã inicial. Escolha os dias de treino, os minutos por sessão, o tipo de sessão (adaptativo ou sessão completa) e a duração (semanas ou permanente). Pode ainda dar foco a um domínio ou a tarefas escolhidas e juntar um lembrete no calendário (.ics).','O utente vê o treino de hoje, as sessões da semana (feitas, em falta, previstas) e um gráfico de progresso. Se o treino for interrompido, continua da próxima vez a partir da tarefa onde parou. As sessões em falta podem ser recuperadas na mesma semana.','Progresso → Visualização mostra a semana e os gráficos de desempenho por tarefa e domínio cognitivo. Exportar e importar (Dados e cópia de segurança) levam planos e resultados entre dispositivos; é feita uma cópia antes de cada importação.']],
['Versão em papel e PDF',['A Sessão completa e a Prática livre têm um botão Imprimir: escolha 1 a 3 versões e se inclui as soluções, e crie as fichas. As tarefas longas continuam numa nova página e as de memória incluem todos os passos. Descarregue o PDF ou imprima a partir da pré-visualização.','O Progresso tem um relatório de uma página com perfil, plano, sessões por semana e desempenho, pronto a imprimir ou arquivar.']],
['Correção (em papel)',['No ecrã a aplicação corrige automaticamente. Nas fichas em papel use estes critérios e converta em percentagem dos itens existentes, para que os resultados sejam comparáveis entre fichas diferentes:','• Cancelamento: elementos assinalados corretamente menos os assinalados incorretamente.','• Sequências numéricas: sequências resolvidas corretamente.','• Resolução de problemas: problemas resolvidos corretamente.','• Associação: associações corretas (conta qualquer justificação coerente do utente).','• Contextos: descrições identificadas corretamente menos as identificadas incorretamente.','• Pares de imagens: pares recordados corretamente.','• Sopa de letras: palavras encontradas.','• Labirintos: 100% só se o percurso da entrada à saída for traçado.','• Categorização: elementos categorizados corretamente.','• Sequências de ações: sequências ordenadas corretamente.','• Memória de histórias e imagens: perguntas respondidas corretamente. No ecrã são marcadas pelo utilizador, porque o exercício original não tem soluções.']],
['Interpretar os resultados',['Os resultados apoiam o juízo do clínico. Quando o desempenho chega aos 80–100% com determinados parâmetros, a tarefa ou sessão seguinte deve ser mais difícil; abaixo de cerca de 50%, mais fácil. O treino adaptativo faz isto automaticamente, com alvo de 50–70%.','Cores do gráfico: verde é a zona-alvo de 50–70%, azul acima (demasiado fácil), vermelho abaixo (demasiado difícil).']],
['Sobre',['PARP-AVC (Programa Adaptável para a Reabilitação Personalizada do Acidente Vascular Cerebral), criado por Ana Lúcia Faria e Sergi Bermúdez i Badia, NeuroRehabLab, LifeTech OpenQoL.','As traduções da aplicação para português, espanhol e italiano devem ser revistas por clínicos nativos.']]]},
es:{ttl:'Manual',sub:'Adaptado del Manual Técnico del PARP-AVC (Faria y Bermúdez i Badia)',S:[
['Objetivo',['Task Generator crea entrenamiento cognitivo personalizado para personas tras un ictus. Se diseñó para profesionales de la salud en rehabilitación cognitiva y también puede usarse en casa, en pantalla o en papel.','Ofrece 11 tareas, creadas con la colaboración de más de 20 profesionales (médicos, psicólogos, enfermeros, terapeutas ocupacionales y del habla). Cada tarea se genera de nuevo cada vez, así que puede repetirse sin memorizar las respuestas.','Cada tarea tiene una carga estimada en cuatro dominios cognitivos (atención, memoria, funciones ejecutivas, lenguaje) y una dificultad general. Las barras pequeñas de cada tarea muestran ese perfil.']],
['Cómo funciona',['• Perfil: cinco valores de 1 a 10 (atención, memoria, funciones ejecutivas, lenguaje, dificultad general). Pueden obtenerse de una evaluación de cribado, como el Examen Cognitivo de Addenbrooke o la Evaluación Cognitiva de Montreal, o de una batería de pruebas más amplia.','• Vista del clínico: gestiona perfiles y planes, prepara sesiones, imprime y sigue la adherencia y los resultados.','• Vista del paciente: pantallas muy simples, solo el entrenamiento de hoy. Se cambia con el botón superior; un PIN puede proteger la vista del clínico.','La aplicación funciona sin conexión y guarda todo en el navegador; use Progreso → Datos y copia de seguridad para cambiar de dispositivo o guardar una copia.']],
['Formas de entrenar',['• Entrenamiento adaptativo: la aplicación elige las tareas y ajusta la dificultad tras cada ejercicio para mantener a la persona en torno al 50–70% de aciertos, donde el aprendizaje es mayor.','• Sesión completa: las 11 tareas, una tras otra, ajustadas al perfil. Con “Incluir solo tareas muy cercanas al perfil” marcado, se omiten las tareas demasiado lejanas; sin marcar, se hacen las 11 adaptadas al perfil.','• Práctica libre: elija una tarea y defina cada parámetro. El gráfico muestra la exigencia cognitiva de esos ajustes.']],
['Clínico: plan y seguimiento',['Abra el plan desde la tarjeta de inicio. Elija los días de entrenamiento, los minutos por sesión, el tipo de sesión (adaptativo o sesión completa) y la duración (semanas o permanente). Puede enfocar un dominio o tareas concretas y añadir un recordatorio de calendario (.ics).','El paciente ve el entrenamiento de hoy, las sesiones de la semana (hechas, pendientes, previstas) y un gráfico de progreso. Si el entrenamiento se interrumpe, la próxima vez continúa desde la tarea donde se detuvo. Las sesiones pendientes pueden recuperarse en la misma semana.','Progreso → Visualización muestra la semana y los gráficos de rendimiento por tarea y dominio cognitivo. Exportar e importar (Datos y copia de seguridad) llevan planes y resultados entre dispositivos; se hace una copia antes de cada importación.']],
['Versión en papel y PDF',['La Sesión completa y la Práctica libre tienen un botón Imprimir: elija 1 a 3 versiones y si incluye las soluciones, y cree las fichas. Las tareas largas continúan en una página nueva y las de memoria incluyen todos los pasos. Descargue el PDF o imprima desde la vista previa.','Progreso tiene un informe de una página con perfil, plan, sesiones por semana y rendimiento, listo para imprimir o archivar.']],
['Corrección (en papel)',['En pantalla la aplicación corrige automáticamente. En las fichas en papel use estos criterios y convierta a porcentaje de los elementos existentes, para que los resultados sean comparables entre fichas distintas:','• Cancelación: elementos marcados correctamente menos los marcados incorrectamente.','• Secuencias numéricas: secuencias resueltas correctamente.','• Resolución de problemas: problemas resueltos correctamente.','• Asociación: asociaciones correctas (vale cualquier justificación coherente del paciente).','• Contextos: descripciones identificadas correctamente menos las identificadas incorrectamente.','• Pares de imágenes: pares recordados correctamente.','• Sopa de letras: palabras encontradas.','• Laberintos: 100% solo si se traza el camino de la entrada a la salida.','• Categorización: elementos categorizados correctamente.','• Secuencias de acciones: secuencias ordenadas correctamente.','• Memoria de historias e imágenes: preguntas respondidas correctamente. En pantalla las marca el usuario, porque el ejercicio original no tiene soluciones.']],
['Interpretar los resultados',['Los resultados apoyan el juicio del clínico. Cuando el rendimiento llega al 80–100% con unos parámetros, la tarea o sesión siguiente debe ser más difícil; por debajo de aproximadamente el 50%, más fácil. El entrenamiento adaptativo lo hace automáticamente, con objetivo del 50–70%.','Colores del gráfico: verde es la zona objetivo del 50–70%, azul por encima (demasiado fácil), rojo por debajo (demasiado difícil).']],
['Acerca de',['PARP-AVC (Programa Adaptável para a Reabilitação Personalizada do Acidente Vascular Cerebral), creado por Ana Lúcia Faria y Sergi Bermúdez i Badia, NeuroRehabLab, LifeTech OpenQoL.','Las traducciones de la aplicación al portugués, español e italiano deben ser revisadas por clínicos nativos.']]]},
it:{ttl:'Manuale',sub:'Adattato dal Manuale Tecnico PARP-AVC (Faria e Bermúdez i Badia)',S:[
['Scopo',['Task Generator crea un allenamento cognitivo personalizzato per le persone dopo un ictus. È pensato per i professionisti della salute nella riabilitazione cognitiva e può essere usato anche a casa, su schermo o su carta.','Offre 11 compiti, creati con la collaborazione di oltre 20 professionisti (medici, psicologi, infermieri, terapisti occupazionali e logopedisti). Ogni compito è generato ogni volta di nuovo, quindi si può ripetere senza memorizzare le risposte.','Ogni compito ha un carico stimato su quattro domini cognitivi (attenzione, memoria, funzioni esecutive, linguaggio) e una difficoltà generale. Le barre piccole su ogni compito mostrano questo profilo.']],
['Come funziona',['• Profilo: cinque valori da 1 a 10 (attenzione, memoria, funzioni esecutive, linguaggio, difficoltà generale). Si ricavano da una valutazione di screening, come l’Addenbrooke’s Cognitive Examination o la Montreal Cognitive Assessment, o da una batteria di test più ampia.','• Vista del clinico: gestisce profili e piani, prepara le sessioni, stampa, segue l’aderenza e i risultati.','• Vista del paziente: schermate molto semplici, solo l’allenamento di oggi. Si cambia con il pulsante in alto; un PIN può proteggere la vista del clinico.','L’app funziona senza connessione e salva tutto nel browser; usi Progressi → Dati e backup per cambiare dispositivo o salvare una copia.']],
['Modi di allenarsi',['• Allenamento adattivo: l’app sceglie i compiti e regola la difficoltà dopo ogni esercizio per mantenere la persona intorno al 50–70% di risposte corrette, dove l’apprendimento è maggiore.','• Sessione completa: tutti gli 11 compiti, uno dopo l’altro, regolati sul profilo. Con “Includi solo compiti molto vicini al profilo” selezionato, i compiti troppo lontani sono esclusi; deselezionato, si svolgono tutti gli 11 adattati al profilo.','• Pratica libera: scelga un compito e imposti ogni parametro. Il grafico mostra la richiesta cognitiva di quelle impostazioni.']],
['Clinico: piano e follow-up',['Apra il piano dalla scheda nella schermata iniziale. Scelga i giorni di allenamento, i minuti per sessione, il tipo di sessione (adattivo o sessione completa) e la durata (settimane o permanente). Può dare priorità a un dominio o a compiti scelti e aggiungere un promemoria nel calendario (.ics).','Il paziente vede l’allenamento di oggi, le sessioni della settimana (svolte, mancanti, previste) e un grafico dei progressi. Se l’allenamento si interrompe, la volta successiva riprende dal compito in cui si era fermato. Le sessioni mancanti si possono recuperare nella stessa settimana.','Progressi → Visualizzazione mostra la settimana e i grafici delle prestazioni per compito e dominio cognitivo. Esporta e importa (Dati e backup) portano piani e risultati tra dispositivi; prima di ogni importazione viene fatta una copia.']],
['Versione cartacea e PDF',['La Sessione completa e la Pratica libera hanno un pulsante Stampa: scelga da 1 a 3 versioni e se includere le soluzioni, poi crei le schede. I compiti lunghi continuano su una nuova pagina e quelli di memoria includono tutti i passaggi. Scarichi il PDF o stampi dall’anteprima.','Progressi ha un rapporto di una pagina con profilo, piano, sessioni a settimana e prestazioni, pronto da stampare o archiviare.']],
['Correzione (su carta)',['Su schermo l’app corregge automaticamente. Sulle schede cartacee usi questi criteri e converta in percentuale degli elementi presenti, così i risultati restano confrontabili tra schede diverse:','• Cancellazione: elementi cerchiati correttamente meno quelli cerchiati erroneamente.','• Sequenze numeriche: sequenze risolte correttamente.','• Risoluzione di problemi: problemi risolti correttamente.','• Associazione: associazioni corrette (vale ogni giustificazione coerente del paziente).','• Contesti: descrizioni identificate correttamente meno quelle identificate erroneamente.','• Coppie di immagini: coppie ricordate correttamente.','• Cruciverba di parole: parole trovate.','• Labirinti: 100% solo se il percorso dall’ingresso all’uscita è tracciato.','• Categorizzazione: elementi categorizzati correttamente.','• Sequenze di azioni: sequenze ordinate correttamente.','• Memoria di storie e immagini: domande risposte correttamente. Su schermo le segna l’utente, perché l’esercizio originale non ha soluzioni.']],
['Interpretare i risultati',['I risultati supportano il giudizio del clinico. Quando la prestazione raggiunge l’80–100% con certi parametri, il compito o la sessione successivi devono essere più difficili; sotto circa il 50%, più facili. L’allenamento adattivo lo fa automaticamente, con obiettivo 50–70%.','Colori del grafico: verde è la zona obiettivo 50–70%, blu sopra (troppo facile), rosso sotto (troppo difficile).']],
['Informazioni',['PARP-AVC (Programa Adaptável para a Reabilitação Personalizada do Acidente Vascular Cerebral), creato da Ana Lúcia Faria e Sergi Bermúdez i Badia, NeuroRehabLab, LifeTech OpenQoL.','Le traduzioni dell’app in portoghese, spagnolo e italiano dovrebbero essere riviste da clinici madrelingua.']]]}};
function rMan(){const M=MAN[LANG]||MAN.en;
  $('#man').replaceChildren(h('h2',{},M.ttl),h('p',{class:'mut xs'},M.sub),
    ...M.S.map(([t,ps],i)=>{const d=h('details',{class:'mansec'},h('summary',{},t),h('div',{class:'manb'},...ps.map(x=>x.startsWith('• ')?h('p',{class:'mli'},x.slice(2)):h('p',{},x))));if(i==0)d.open=true;return d}))}

/* ---------- navigation ---------- */
const SC=['home','profile','train','session','practice','progress','sum','wait','run','role','phome','pdone','clin','rx','prn','man'];let scr='home',draft=null,plan=[],skip=[],cur,curP,curMode='practice',info={},chk=null,runLog=[],sumMode='session',pend=[],pendP=null,nextIdx=0,wt=null;
const tn=k=>_(T[k].n),hdr=()=>{$('#pn').textContent=CUR||_('Profile')};
const BK=['man','profile','train','session','practice','progress','clin','rx','prn'];let navStack=[],goingBack=false;
function show(n){if(n=='home'&&ROLE=='patient')n='phome';const prev=scr;
  if(n=='home'||n=='phome'||n=='role'||n=='pdone')navStack.length=0;else if(!goingBack&&prev!=n&&BK.includes(n)&&(BK.includes(prev)||prev=='home'||prev=='phome'))navStack.push(prev=='phome'?'home':prev);
if(n!='wait')clearInterval(wt);if(document.querySelectorAll)document.querySelectorAll('.ov2').forEach(e=>e.remove());scr=n;if(n!='profile')draft=null;SC.forEach(s=>$('#'+s).classList.toggle('on',s==n));
  const pat=ROLE=='patient'||n=='role';const vs=$('#vsw');vs.classList.toggle('hid',ROLE!='clin'||n=='run'||n=='role');vs.replaceChildren(ic('user'),h('span',{},_('Patient view')));$('#top').classList.toggle('clin',ROLE=='clin');vs.onclick=()=>{setRole('patient');show('home')};$('#back').classList.toggle('hid',n=='home'||(n=='profile'&&!P())||pat);$('#pchip').classList.toggle('hid',n=='run'||pat||ROLE=='clin');$('#lang').classList.toggle('hid',n=='run');hdr();
  ({home:rHome,profile:rProf,train:rTrain,session:rSess,practice:rPrac,progress:rPg,sum:rSum,wait:rWait,role:rRole,phome:rPhome,pdone:rPdone,clin:rClin,rx:rRx,prn:rPrn,man:rMan}[n]||(()=>{}))();$('#scr').scrollTop=0}
const goBack=()=>{if(scr=='run')return exitRun();const t=navStack.pop()||({rx:'clin',prn:'rx'}[scr])||'home';goingBack=true;try{show(t)}finally{goingBack=false}},
 exitRun=()=>{if(RXs&&ROLE=='patient')return askStop();if((curMode=='adaptive'||curMode=='session')&&runLog.length)show('sum');else show({adaptive:'train',session:'session'}[curMode]||'practice')};

/* ---------- home ---------- */
function rHome(){const p=P();
  $('#home').replaceChildren(h('div',{class:'hello'},h('div',{class:'hrow'},h('h1',{},_('Clinician')),h('div',{class:'hbtn'},h('button',{class:'btn alt pinb','aria-label':(MAN[LANG]||MAN.en).ttl,title:(MAN[LANG]||MAN.en).ttl,onclick(){show('man')}},'📖 '+_('Manual')),h('button',{class:'btn alt pinb',onclick:pinModal},'🔒 PIN'))),h('p',{class:'mut xs'},_('Tools apply to the selected profile.'))),
    h('div',{class:'prrow'},h('button',{class:'pmanage','aria-label':_('Manage interventions'),title:_('Manage interventions'),onclick(){show('clin')}},h('span',{class:'pmi'},'👥'),h('small',{},_('Manage interventions'))),h('div',{class:'prsel'},h('button',{class:'pcard',onclick:pickPatient},ic('user'),h('div',{class:'pc',title:_('tap to change')},h('span',{},_('Selected profile')),h('b',{},(p?CUR:_('No profile selected'))+' ▾')),p?mini(pv()):''),p?h('button',{class:'pshare','aria-label':_('Share this profile and plan by QR'),title:_('Share this profile and plan by QR'),onclick:shareSelected},h('span',{class:'qrsv'}),h('small',{},'QR')):'')),planCard(),imgChips(),
    h('div',{class:'tiles'},...[['target','Adaptive training','Keeps you at 50–70% correct','train'],['list','Full session','Matched tasks, one after another','session'],['puzzle','Free practice','Choose a task and set it up','practice'],['chart','Progress','Your results over time','progress'],['db','Data','Backup, export, history','progress']]
      .map(([i,t,s,to])=>h('button',{class:'tile',onclick(){if(to=='progress')pgt=(i=='db'?'d':'t');show(to)}},ic(i),h('b',{},_(t)),h('span',{},_(s))))),
    h('p',{class:'credit'},'NeuroRehabLab · LifeTech OpenQoL'))}

/* ---------- profile ---------- */
function rProf(){
  if(!draft)draft={orig:P()?CUR:'',name:P()?CUR:'',v:[...pv()],cc:P()?P().cc!==false:true};
  const names=Object.keys(PS),sel=h('select',{class:'inp',onchange(){const x=sel.value;if(x=='__new')draft={orig:'',name:'',v:[3,3,3,3,3],cc:true};else{CUR=x;saveP();draft=null}hdr();rProf()}},
    ...names.map(n=>h('option',{value:n},n)),h('option',{value:'__new'},'＋ '+_('New profile')));sel.value=draft.orig||'__new';
  const nm=h('input',{class:'inp',type:'text',placeholder:_('Name or initials'),maxlength:24,oninput(){draft.name=nm.value}});nm.value=draft.name;
  const rows=DIMS.map((d,i)=>{const o=h('output',{},fmt(draft.v[i])),s=h('input',{type:'range',min:1,max:10,step:.5,oninput(){draft.v[i]=+s.value;o.textContent=fmt(+s.value)}});s.value=draft.v[i];
    return h('label',{class:'sl'},h('span',{},i==4?_('Overall difficulty'):_(d),o),s)});
  const save=()=>{let n=(draft.name||'').trim()||_('Me');if(n!=draft.orig&&PS[n])n+=' 2';
    const old=draft.orig?PS[draft.orig]:null,same=old&&old.v.join()==draft.v.join();
    if(old&&n!=draft.orig){delete PS[draft.orig];hist.forEach(x=>{if((x.u||'')==draft.orig)x.u=n});saveH()}
    PS[n]={...(old||{}),v:[...draft.v],cc:draft.cc,lev:same?(old.lev||{}):{}};CUR=n;saveP(true);show('home')};
  const del=h('button',{class:'link',onclick(){if(del.dataset.s){delete PS[draft.orig];CUR=Object.keys(PS)[0]||'';saveP();draft=null;rProf();hdr()}else{del.dataset.s=1;del.textContent=_('Tap again to delete this profile')}}},_('Delete profile'));
  $('#profile').replaceChildren(h('h2',{},_('Patient profile')),
    h('p',{class:'mut sm'},_('These levels (1 = very low, 10 = very high) set the starting difficulty of every exercise and the tasks in a full session.')),
    h('label',{class:'fld'},_('Name'),nm),...rows,
    h('div',{class:'grow'}),h('button',{class:'btn big',onclick:save},draft.orig?_('Save profile'):_('Create profile')),draft.orig&&names.length>1?del:'')}

/* ---------- adaptive training ---------- */
function rTrain(){
  const tg=(a,v)=>{const i=a.indexOf(v);i<0?a.push(v):a.splice(i,1);LS.set('tg2_f',FOC);rTrain()};
  const rs=h('button',{class:'link',onclick(){P().lev={};saveP(true);rs.textContent=_('Levels restarted from profile ✓')}},_('Restart levels from my profile'));
  $('#train').replaceChildren(h('h2',{},_('Adaptive training')),
    h('p',{class:'mut sm'},_('Each exercise keeps you between 50% and 70% correct: harder above 70%, easier below 50%. It starts from {0}’s profile.',CUR)),
    h('h3',{},_('Focus on a domain')),h('div',{class:'chips'},...DIMS.slice(0,4).map((d,i)=>h('button',{class:'tab'+(FOC.d.includes(i)?' on':''),onclick(){tg(FOC.d,i)}},_(d)))),
    h('h3',{},_('or choose tasks')),h('div',{class:'chips'},...KS.map(k=>h('button',{class:'tab'+(FOC.k.includes(k)?' on':''),onclick(){tg(FOC.k,k)}},tn(k)))),
    h('p',{class:'mut sm'},FOC.k.length?_('Training your chosen tasks.'):FOC.d.length?_('Training the tasks that load these domains most.'):_('Nothing chosen: training all tasks in turn.')),rs,
    h('div',{class:'grow'}),h('button',{class:'btn big',onclick(){runLog=[];pend=[];sumMode='adaptive';startA()}},_('Start training')))}

/* ---------- full session ---------- */
function buildPlan(ov){const cc=ov!=null?ov:P()&&P().cc!==false;plan=[];skip=[];
  KS.forEach(k=>{const b=best(k);if(cc&&b.e>10){skip.push(k);return}plan.push({k,p:b.p,v:b.m,e:b.e,r:null})})}
function rSess(){buildPlan();
  const mc=h('input',{type:'checkbox',onchange(){P().cc=mc.checked;saveP(true);rSess()}});mc.checked=!P()||P().cc!==false;
  $('#session').replaceChildren(h('h2',{},_('Full session')),h('label',{class:'chk'},mc,h('span',{},_('Only include tasks that closely match the profile'))),
    h('p',{class:'mut sm'},plan.length?_('{0} tasks matched to {1}’s profile, one after another. Results are shown briefly after each task and summarised at the end.',plan.length,CUR):_('No task is close enough to this profile. Untick “Only include tasks that closely match the profile” above.')),
    h('div',{class:'plist'},...plan.map((it,i)=>h('div',{class:'pli'},h('span',{class:'pn'},i+1),h('span',{},tn(it.k))))),
    skip.length?h('p',{class:'mut sm'},_('Left out as too far from the profile: {0}.',skip.map(tn).join(', '))):'',
    h('div',{class:'grow'}),plan.length?h('div',{class:'two'},h('button',{class:'btn big',onclick(){plan.forEach(x=>x.r=null);runLog=[];pend=[];sumMode='session';run(0)}},_('Start session')),h('button',{class:'btn alt big',onclick(){printModal(sessSpec(),_('Print this session'))}},'🖨 '+_('Print'))):'')}
const run=i=>{nextIdx=i+1;launch(plan[i].k,plan[i].p,'session',i)};

/* ---------- free practice ---------- */
let pk='cancel',pp=null;
function rPrac(){if(!pp)pp={...best(pk).p};
  const st=h('div',{class:'chips sm2'},...KS.map(k=>h('button',{class:'tab'+(k==pk?' on':''),onclick(){pk=k;pp=null;rPrac()}},tn(k)))),bx=h('div'),upd=()=>bx.replaceChildren(bars(M[pk](clampP(pk,pp))));
  const form=h('div',{class:'pgrid'},...T[pk].p.map(q=>{let x;
    if(q.o)x=pickBtn(q.o.map(([v,l])=>({v,l:_(l)+(l=='Clipart'||l=='Pictures'?' ✓':'')})),String(pp[q.id]),v=>{pp[q.id]=v;upd()},_(q.l));
    else{const o=h('output',{},String(pp[q.id])),s=h('input',{type:'range',min:q.min,max:q.max,step:1,inputmode:'none',oninput(){pp[q.id]=+s.value;o.textContent=s.value;upd()}});s.value=pp[q.id];
      return h('label',{class:'sl'},h('span',{},_(q.l),o),s)}
    return h('label',{},_(q.l),x)}));
  upd();
  $('#practice').replaceChildren(st,h('h2',{},tn(pk)),h('p',{class:'mut sm'},_(T[pk].d)),form,
    h('h3',{},_('Cognitive demand of these settings')),bx,
    h('button',{class:'link',onclick(){pp={...best(pk).p};rPrac()}},_('Match settings to my profile')),
    h('div',{class:'grow'}),h('div',{class:'two'},h('button',{class:'btn big',onclick(){launch(pk,pp,'practice')}},_('Start')),h('button',{class:'btn alt big',onclick(){printModal(()=>({ks:[pk],pm:{[pk]:pp},base:'practice-'+pk}),_('Print with these settings'))}},'🖨 '+_('Print'))))}

/* ---------- running a task ---------- */
function launch(k,p,m,i,rec){
  curMode=m;cur=k;const box=h('div',{class:'tbox'});
  if(rec){curP=rec.p;info={m,i:rec.i,rec:1};chk=rec.recall(box)}
  else{lastL[k]=Date.now();p=clampP(k,{...def(k),...p});if((k=='assoc'||k=='pairs')&&m!='practice')p.type=pickSrc();if((k=='cat'||k=='ctx')&&m!='practice'){const so=srcOn(),ok=k=='cat'?A.cmcat&&A.cmcat.some(x=>x.length>=(+p.per||3)):A.cmx&&A.cmx.length,hv=so.some(x=>x!='m'),hm=so.includes('m')&&ok;p.type=hv&&hm?pick(['c','m']):hm&&!hv?'m':'c'}if(k=='stories'&&m!='practice'&&+p.type>=3){const so=srcOn(),hv=so.some(x=>x!='m'),hm=so.includes('m')&&A.cmq;p.type=String(hv&&hm?pick([3,4]):hm&&!hv?4:3)}curP=p;info={m,i};
    const r=T[k].b(p,box);if(r&&r.two){chk=null;r.study(box,()=>studyDone(r,k,p,m,i,box))}else chk=r}
  $('#stage').replaceChildren(box);$('#fbar').classList.toggle('hid',!chk);$('#sheet').classList.add('hid');show('run');runBar();$('#stage').scrollTop=0}
/* two-phase tasks (image pairs, memory recall): study now, recall after the delay without blocking other tasks */
function studyDone(r,k,p,m,i,box){const d=+p.delay||0;
  if(d<=0){box.replaceChildren();chk=r.recall(box);$('#fbar').classList.remove('hid');$('#stage').scrollTop=0;return}
  const e={k,p,m,i,recall:r.recall,due:Date.now()+d*60000};
  if(m=='practice'){pendP=e;show('wait');return}
  pend.push(e);advance()}
function advance(){const now=Date.now(),due=pend.find(e=>e.due<=now);
  if(due){pend=pend.filter(e=>e!==due);launch(due.k,due.p,due.m,due.i,due);return}
  if(RXs){if(!rxOver())return RXs.mode=='session'?run(nextIdx):startA();if(pend.length)return show('wait');return finishRx()}
  if(curMode=='session'){if(nextIdx<plan.length)return run(nextIdx);if(pend.length)return show('wait');return show('sum')}
  if(curMode=='adaptive')return startA();show('home')}
const moreLeft=()=>nextIdx<plan.length||pend.length>0||curMode=='adaptive';
function rWait(){const e=pendP||[...pend].sort((a,b)=>a.due-b.due)[0];if(!e){show('home');return}
  const t=h('div',{class:'wtime'}),go=()=>{clearInterval(wt);if(pendP===e)pendP=null;else pend=pend.filter(x=>x!==e);launch(e.k,e.p,e.m,e.i,e)},
    upd=()=>{const s=Math.max(0,Math.round((e.due-Date.now())/1000));t.textContent=`${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;if(s<=0)go()};
  $('#wait').replaceChildren(h('div',{class:'grow'}),h('div',{class:'wic'},ic('timer')),h('h2',{class:'ctr'},_('Recall in')),t,
    h('p',{class:'mut sm ctr'},tn(e.k)+' · '+_('You can rest. The recall starts by itself.')),h('div',{class:'grow'}),
    h('button',{class:'btn big',onclick:go},_('Start recall now')),
    h('button',{class:'link ctr',onclick(){clearInterval(wt);if(pendP===e){pendP=null;show('practice')}else{pend=pend.filter(x=>x!==e);advance()}}},_('Skip the recall')));
  clearInterval(wt);wt=setInterval(upd,500);upd()}
function runBar(){const m=curMode,L=ladder(cur).length,pc=pend.length&&m!='practice'?h('span',{class:'pcb'},'⏱ '+pend.length):'';
  $('#runbar').replaceChildren(h('button',{class:'x',onclick:exitRun,'aria-label':_('Exit task')},'✕'),h('b',{},tn(cur)),
    m=='session'?h('div',{class:'dots'},pc,...plan.map((_x,j)=>h('i',{class:j<info.i?'d':j==info.i?'c':''}))):h('span',{class:'mut sm'},RXs&&m=='adaptive'&&rxOver()?'✓ '+_('Time is up: finish this task'):RXs&&m=='adaptive'?'⏱ '+_('{0} min left',Math.max(1,Math.ceil((RXs.min*60000-(Date.now()-RXs.start))/60000))):m=='adaptive'?_('Level {0} of {1}',lvl(cur)+1,L):_('Practice'),' ',pc))}
function record(r){const pct=r.t?Math.round(100*r.s/r.t):0;hist.push({t:Date.now(),k:cur,m:curMode,u:CUR,pct,v:M[cur](curP)});saveH();return pct}
function finish(){if(!chk)return;const r=chk();chk=null;try{if(!TGP&&window.parent&&window.parent!==window)window.parent.postMessage({mqWebScore:{task:cur,s:r.s,t:r.t}},'*')}catch(e){}const b=$('#stage').firstChild;if(b)b.inert=true;$('#fbar').classList.add('hid');openSheet(r,record(r))}

/* Slim result bar: score + one short line, one primary action. Details expand on tap. */
function openSheet(r,pct){
  const k=cur,m=curMode,sh=$('#sheet');let hint=r.n||'',tone='',act=[];
  const again=()=>launch(k,curP,m,info.i),ib=(l,f,s)=>h('button',{class:'ib','aria-label':l,title:l,onclick:f},s);
  if(m!='practice')runLog.push({k,pct,m});
  if(m=='adaptive'){const L=ladder(k).length,o=lvl(k);let n=o+(pct>90?2:pct>70?1:pct<25?-2:pct<50?-1:0);n=Math.max(0,Math.min(L-1,n));P().lev[k]=n;saveP(true);
    hint=pct>70?(n>o?'▲ '+_('Next one is harder'):'▲ '+_('Top level reached')):pct<50?(n<o?'▼ '+_('Next one is easier'):'▼ '+_('Easiest level reached')):'● '+_('In the 50–70% zone: same level');
    tone=pct>70?'hi':pct<50?'lo':'good';
    if(RXs&&rxOver()&&!pend.length){hint='✓ '+_('Training complete! You can finish.');tone='good'}
    act=[h('button',{class:'btn',onclick:advance},(rxOver()&&!pend.length?_('Finish'):_('Next'))+' ▶'),...(RXs?[]:[ib(_('Stop and see summary'),()=>show('sum'),'■')])]}
  else if(m=='session'){const i=info.i;plan[i].r=r;
    tone=pct>70?'hi':pct<50?'lo':'good';
    if(RXs&&!moreLeft()){hint='✓ '+_('Training complete! You can finish.');tone='good'}
    act=[h('button',{class:'btn',onclick:advance},moreLeft()?_('Next')+' ▶':RXs?_('Finish')+' ▶':_('Summary')+' ▶')]}
  else act=[h('button',{class:'btn',onclick:again},_('New version')),ib(_('Settings'),()=>show('practice'),'⚙')];
  if(window.MQ){const L1=lvl(k),Lt=ladder(k).length;MQRES={s:r.s,t:r.t,pct,n:r.n||'',hint:m=='adaptive'?hint:'',tone:tone||(pct>70?'hi':pct<50?'lo':'good'),lv:m=='adaptive'?(L1!=MQL0?mqs('lv',(MQL0+1)+' → '+(L1+1),Lt):mqs('lv',L1+1,Lt)):'',changed:m=='adaptive'&&L1!=MQL0};if(TGP)tgpDone(r,pct);sh.classList.add('hid');mqSide();mqFit();return}
  const txt=h('div',{class:'sh-txt',onclick(){sh.classList.toggle('open')}},h('b',{class:'sc '+tone},`${r.s}/${r.t} · ${pct}%`),h('span',{class:'ht'},hint));
  if(m=='adaptive'&&r.n)txt.append(h('span',{class:'ht more'},r.n));
  sh.replaceChildren(txt,h('div',{class:'sh-act'},...act));sh.classList.remove('hid','open')}

/* ---------- end-of-run summary (the only place a performance plot appears besides Progress) ---------- */
function rSum(){const L=runLog;
  if(!L.length){show('home');return}
  const avg=Math.round(L.reduce((a,x)=>a+x.pct,0)/L.length),by={};L.forEach(x=>(by[x.k]=by[x.k]||[]).push(x.pct));
  const rows=Object.entries(by).map(([k,a])=>({l:tn(k),v:Math.round(a.reduce((s,x)=>s+x,0)/a.length)})),zone=Math.round(100*L.filter(x=>x.pct>=50&&x.pct<=70).length/L.length),
    ses=sumMode=='session';
  $('#sum').replaceChildren(h('h2',{},ses?_('Session summary'):_('Training summary')),
    h('div',{class:'stats'},h('div',{},h('b',{},avg+'%'),h('span',{},_('average'))),h('div',{},h('b',{},L.length),h('span',{},_('tasks done'))),h('div',{},h('b',{},zone+'%'),h('span',{},_('in 50–70% zone')))),
    cx(L,{h:96}),h('p',{class:'mut xs'},_('% correct per task. Green band = 50–70% target zone; blue above, red below.')),
    rowBars(rows),h('div',{class:'grow'}),
    h('div',{class:'two'},ses?'':h('button',{class:'btn',onclick(){startA()}},_('Keep training')),h('button',{class:ses?'btn big':'tab',onclick(){show('home')}},_('Back to menu'))))}

/* ---------- progress ---------- */

let dscope='*',dmsg='',imp=null;
function dataPanel(){
  const names=Object.keys(PS),bk=LS.get('tg2_bk',null),re=()=>rPg();
  const sc=h('select',{class:'inp',onchange(){dscope=sc.value}},h('option',{value:'*'},_('All users ({0})',names.length)),...names.map(n=>h('option',{value:n},n)));
  sc.value=names.includes(dscope)||dscope=='*'?dscope:'*';dscope=sc.value;
  const exp=h('button',{class:'btn',async onclick(){const ns=dscope=='*'?names:[dscope];if(!ns.length)return;
    const r=await saveFile('neurorehab-'+(dscope=='*'?'all':dscope.replace(/[^\w-]+/g,'_'))+'-'+stamp()+'.json',JSON.stringify(buildExport(ns),null,1));
    dmsg=r=='ok'?_('Progress file ready ✓'):r=='declined'?'':_('Could not save the file.');re()}},_('Export'));
  const fi=h('input',{type:'file',accept:'.json,application/json',class:'hid',onchange(){const f=fi.files[0];if(!f)return;
    const rd=new FileReader();rd.onload=()=>{const r=parseImport(String(rd.result));
      if(r.err||!Object.keys(r.users).length){imp=null;dmsg=_('This file is not a valid progress export.')}
      else{const have=new Set(hist.map(hkey));r.sel={};Object.keys(r.users).forEach(n=>r.sel[n]=true);r.mode='merge';r.fresh={};
        Object.keys(r.users).forEach(n=>r.fresh[n]=r.hist.filter(x=>x.u==n&&!have.has(hkey(x))).length);imp=r;dmsg=''}re()};
    rd.onerror=()=>{dmsg=_('Could not read the file.');re()};rd.readAsText(f)}});
  const imb=h('button',{class:'btn alt',onclick(){fi.value='';fi.click()}},_('Import'));
  let card='';
  if(imp){const u=Object.keys(imp.users),chosen=()=>u.filter(n=>imp.sel[n]);
    const rows=u.map(n=>{const cb=h('input',{type:'checkbox',onchange(){imp.sel[n]=cb.checked;re()}});cb.checked=!!imp.sel[n];
      const tot=imp.hist.filter(x=>x.u==n).length;
      return h('label',{class:'drow'},cb,h('b',{},n),h('span',{class:'mut xs'},_('{0} entries, {1} new',tot,imp.fresh[n]),PS[n]?' · '+_('exists here'):' · '+_('new user')))});
    const mb=(m,t)=>h('button',{class:'tab'+(imp.mode==m?' on':''),onclick(){imp.mode=m;re()}},t);
    card=h('div',{class:'dcard'},h('b',{},_('File from {0}',imp.at?fdate(imp.at):'?')),...rows,
      h('div',{class:'two'},mb('merge',_('Merge')),mb('replace',_('Replace'))),
      h('p',{class:'mut xs'},imp.mode=='merge'?_('Merge keeps what is here, adds entries that are missing and keeps the newer profile settings.'):_('Replace overwrites the selected users’ profile and history with the file.')+' '+_('A backup is saved first.')),
      h('div',{class:'two'},h('button',{class:'btn',onclick(){const c=chosen();if(!c.length)return;const r=applyImport(imp,c,imp.mode);imp=null;
        dmsg=_('Imported: {0} new entries, {1} users added, {2} profiles updated.',r.added,r.newU,r.upd+r.rep);hdr();re()}},_('Import selected')),
        h('button',{class:'btn alt',onclick(){imp=null;re()}},_('Cancel'))))}
  let bkr='';
  if(bk){const rb=h('button',{class:'link',onclick(){if(rb.dataset.s){restoreBackup();imp=null;dmsg=_('Backup restored ✓');hdr();re()}else{rb.dataset.s=1;rb.textContent=_('Tap again to restore (current data becomes the backup)')}}},_('Restore backup'));
    const db=h('button',{class:'link',async onclick(){const r=await saveFile('neurorehab-backup-'+stamp(new Date(bk.at))+'.json',JSON.stringify(buildExportFrom(bk),null,1));dmsg=r=='ok'?_('Progress file ready ✓'):r=='declined'?'':_('Could not save the file.');re()}},_('Download backup'));
    bkr=h('div',{class:'drow bk'},h('span',{class:'mut xs'},_('Backup from {0}',fdate(bk.at))),rb,db)}
  return h('div',{class:'dpanel'},h('h3',{},_('Data and backup')),h('label',{class:'fld'},_('Users to export'),sc),h('div',{class:'two'},exp,imb),fi,
    dmsg?h('p',{class:'dmsg'},dmsg):'',card,bkr)}
function buildExportFrom(b){const p=PS,hh=hist,c=CUR;PS=b.ps||{};hist=b.hist||[];const r=buildExport(Object.keys(PS));PS=p;hist=hh;CUR=c;return r}
let pgk='',pgt='';
function rPg(){const H=myH(),S=pgk?H.filter(x=>x.k==pgk):H,L=S.slice(-30),last=S.slice(-10),n=last.length,
    avg=n?Math.round(last.reduce((a,x)=>a+x.pct,0)/n):0,zone=n?Math.round(100*last.filter(x=>x.pct>=50&&x.pct<=70).length/n):0,
    dom=DIMS.slice(0,4).map((d,i)=>{let a=0,w=0;H.slice(-30).forEach(x=>{const q=Math.max(0,x.v[i]);a+=x.pct*q;w+=q});return{l:_(d),v:w?Math.round(a/w):0}});
  const sel=h('select',{class:'inp',onchange(){pgk=sel.value;rPg()}},h('option',{value:''},_('All tasks')),...KS.map(k=>h('option',{value:k},tn(k))));sel.value=pgk;
  const clr=h('button',{class:'link',onclick(){if(clr.dataset.s){hist=hist.filter(x=>(x.u||'')!=CUR);saveH();rPg()}else{clr.dataset.s=1;clr.textContent=_('Tap again to clear {0}’s history',CUR)}}},_('Clear history'));
  const hasW=!!(P()&&weekInfo(P()).rx),tabs=[['t',_('Overview')],['d',_('Data and backup')]];
  if(pgt!='d')pgt='t';
  const tb=h('div',{class:'ftabs',role:'tablist'},...tabs.map(([k,l])=>h('button',{role:'tab',class:'ftab'+(pgt==k?' on':''),onclick(){pgt=k;rPg()}},l)));
  const tk=H.length?h('div',{class:'pgw'},h('label',{class:'fld'},_('Show'),sel),
      h('div',{class:'stats'},h('div',{},h('b',{},S.length),h('span',{},_('attempts'))),h('div',{},h('b',{},avg+'%'),h('span',{},_('last 10'))),h('div',{},h('b',{},zone+'%'),h('span',{},_('in 50–70% zone')))),
      cx(L,{h:110}),h('p',{class:'mut xs'},_('% correct per attempt. Green band = 50–70% target zone; blue above, red below.')),
      h('h3',{},_('By cognitive domain')),rowBars(dom),h('div',{class:'grow'})):h('div',{class:'pgw'},h('p',{class:'mut'},_('No results yet for {0}. Finish an exercise and your graphs appear here.',CUR)));
  $('#progress').replaceChildren(...(pgt=='d'?[dataPanel(),H.length?clr:'']:[h('h2',{},_('Progress')),h('div',{class:'pgw'},wkCard(),tk)]),pgt!='d'&&(H.length||hasW)?h('button',{class:'btn',onclick(){pvOpen(buildReport(CUR),'neurorehab-report-'+CUR.replace(/[^\w-]+/g,'_'))}},'🖨 '+_('Progress report')+' (PDF)'):'')}

/* ---------- start-up ---------- */
$('#bigb').onclick=()=>{const o=mdl(h('h2',{class:'ctr'},_('Text size')),
  ...[['A',0,16],['A+',1,20],['A++',2,24]].map(([l,v,px])=>h('button',{class:'btn big'+(getBig()==v?'':' alt'),style:'font-size:'+px+'px;min-height:'+(px*2+16)+'px',onclick(){setBig(v);o.remove();if(scr!='run')show(scr)}},_('Text size')+' '+l)),
  h('button',{class:'link ctr',onclick(){o.remove()}},_('Cancel')))};setBig(getBig());$('#back').onclick=goBack;$('#pchip').onclick=()=>show('profile');$('#fin').onclick=finish;
const ls=$('#lang');LANGS.forEach(([c,n])=>ls.append(h('option',{value:c},n)));ls.value=LANG;
ls.onchange=()=>{setLang(ls.value);$('#fin').textContent=_('Finish and check my answers');$('#back').setAttribute('aria-label',_('Back to menu'));draft&&(draft=null);show(scr)};
setLang(LANG,false);$('#fin').textContent=_('Finish and check my answers');
$('#logo').onclick=()=>{if(scr=='role')return;if(scr=='run'){if(ROLE=='patient')return;exitRun();return}show('home')};

/* ==== modo Musiquence (layout B2): UMA tarefa por página, repetida sem fim, com correção, feedback e adaptação como no Task Generator.
   Esquerda: dock com os parâmetros da tarefa em curso (atualizados a cada iteração), exigência cognitiva e evolução.
   Ao terminar, o resultado ocupa o lugar do dock até tocar em «Seguir». A navegação entre tarefas é a do Musiquence. ==== */
const MQS={pt:{lv:'Nível {0} de {1}',lvs:'Nível',de:'de {0}',cur:'Parâmetros da tarefa em curso',man:'Parâmetros escolhidos à mão (sem adaptação)',upd:'Atualizar',dem:'Exigência cognitiva',prof:'│ = perfil',evo:'Evolução (médias)',perf:'Desempenho',dif:'Dificuldade',goal:'faixa verde: objetivo de desempenho 50–70%',none:'Ainda sem resultados',res:'Resultado',seg:'Seguir',nxtp:'Os parâmetros foram atualizados para a próxima tarefa.',corr:'A correção está marcada na tarefa.',fin:'Terminar e verificar ✓',same:'Mesmos parâmetros na próxima tarefa.',hide:'Recolher',show:'Mostrar parâmetros'},
 en:{lv:'Level {0} of {1}',lvs:'Level',de:'of {0}',cur:'Settings of the current task',man:'Hand-picked settings (no adaptation)',upd:'Update',dem:'Cognitive demand',prof:'│ = profile',evo:'Progress (averages)',perf:'Performance',dif:'Difficulty',goal:'green band: performance target 50–70%',none:'No results yet',res:'Result',seg:'Continue',nxtp:'Settings were updated for the next task.',corr:'The correction is marked on the task.',fin:'Finish and check ✓',same:'Same settings for the next task.',hide:'Collapse',show:'Show settings'},
 es:{lv:'Nivel {0} de {1}',lvs:'Nivel',de:'de {0}',cur:'Parámetros de la tarea en curso',man:'Parámetros elegidos a mano (sin adaptación)',upd:'Actualizar',dem:'Exigencia cognitiva',prof:'│ = perfil',evo:'Evolución (medias)',perf:'Desempeño',dif:'Dificultad',goal:'franja verde: objetivo de desempeño 50–70%',none:'Aún sin resultados',res:'Resultado',seg:'Seguir',nxtp:'Los parámetros se actualizaron para la próxima tarea.',corr:'La corrección está marcada en la tarea.',fin:'Terminar y verificar ✓',same:'Mismos parámetros en la próxima tarea.',hide:'Recoger',show:'Mostrar parámetros'},
 it:{lv:'Livello {0} di {1}',lvs:'Livello',de:'di {0}',cur:'Parametri del compito in corso',man:'Parametri scelti a mano (nessun adattamento)',upd:'Aggiorna',dem:'Richiesta cognitiva',prof:'│ = profilo',evo:'Evoluzione (medie)',perf:'Prestazione',dif:'Difficoltà',goal:'banda verde: obiettivo di prestazione 50–70%',none:'Ancora nessun risultato',res:'Risultato',seg:'Continua',nxtp:'I parametri sono stati aggiornati per il prossimo compito.',corr:'La correzione è segnata nel compito.',fin:'Termina e verifica ✓',same:'Stessi parametri nel prossimo compito.',hide:'Riduci',show:'Mostra parametri'}};
const mqs=(k,...a)=>{let r=(MQS[LANG]||MQS.en)[k]||k;a.forEach((x,j)=>r=r.split('{'+j+'}').join(x));return r};
let MQK='cancel',MQP=null,MQD=null,MQM='adaptive',MQL0=0,MQRES=null,MQOPEN=true;
try{const v=localStorage.getItem('mq_dock');MQOPEN=v==null?Math.min(innerWidth,innerHeight)>=500:v!=='0'}catch(e){}
const mqShort=q=>{const l=_(q.l);return l.length>12?l.split(/\s+/)[0]:l};
function mqStart(){const c=window.MQ;try{if(c.lang&&LANGS.some(l=>l[0]==c.lang))setLang(c.lang)}catch(e){}
  if(!P()){CUR=CUR||'MQ';PS[CUR]={v:[3,3,3,3,3],cc:true,lev:{}};saveP(true)}
  MQK=T[c.k]?c.k:'cancel';document.body.classList.add('mqm');
  const P_=P();P_.lev=P_.lev||{};if(P_.lev[MQK]==null&&c.f!=null){P_.lev[MQK]=Math.round((+c.f)*(ladder(MQK).length-1));saveP()}
  document.body.append(h('aside',{id:'mqL'}));
  /* área virtual 1280×720 em ecrãs grandes; em ecrãs pequenos (telemóvel) usa-se o espaço real, com o dock mais estreito */
  const z=()=>{const sm=Math.min(innerWidth,innerHeight)<500;document.body.classList.toggle('mqsm',sm);
    document.documentElement.style.zoom=sm?String(Math.max(.7,Math.min(1,innerHeight/480))):String(Math.max(.6,Math.min(innerWidth/1280,innerHeight/720)));mqFit()};
  z();addEventListener('resize',z);if(!c.noRun)mqRun()}
/* custom = parâmetros escolhidos à mão (prática, sem adaptação); sem nada = nível adaptativo do perfil */
function mqRun(custom){const k=MQK;let p;MQRES=null;
  if(custom){p=clampP(k,custom);MQM='practice'}else{p={...ladder(k)[lvl(k)]};MQM='adaptive'}
  if('delay' in p)p.delay=0;MQL0=lvl(k);launch(k,p,MQM);MQP={...curP};MQD=null;if(TGP)tgpStarted();mqSide();mqFit();const f=$('#fin');if(f)f.textContent=mqs('fin')}
/* tudo tem de caber no ecrã: reduz o conteúdo da tarefa até caber na área central (sem barras de deslocação) */
function mqFit(){const go=()=>{const st=$('#stage'),c=st&&st.firstElementChild;if(!c)return;c.style.zoom='';
    const r=Math.min(1,(st.clientHeight-26)/Math.max(1,c.scrollHeight),(st.clientWidth-26)/Math.max(1,c.scrollWidth));c.style.zoom=String(Math.max(.4,r))};
  requestAnimationFrame(go);setTimeout(go,250);setTimeout(go,900);setTimeout(go,2500)}
addEventListener('load',e=>{if(e.target&&e.target.tagName==='IMG'&&window.MQ)mqFit()},true);
function mqToggle(){MQOPEN=!MQOPEN;try{localStorage.setItem('mq_dock',MQOPEN?'1':'0')}catch(e){}mqSide();mqFit()}
const mqCol=x=>x>=7?'#d9822b':x>=4?'#8fb83a':'#4caf50';
function mqChart(hs){const W=264,H=58,n=hs.length;if(!n)return h('p',{class:'mut xs'},mqs('none'));
  const X=i=>n<2?W/2:6+i*(W-12)/(n-1),pp=hs.map((x,i)=>X(i).toFixed(1)+','+(H-x.pct/100*(H-4)-2).toFixed(1)).join(' '),
    dd=hs.map((x,i)=>{const d=(x.v||[]).reduce((a,b)=>a+b,0)/Math.max(1,(x.v||[]).length);return X(i).toFixed(1)+','+(H-d/10*(H-4)-2).toFixed(1)}).join(' ');
  const NS='http://www.w3.org/2000/svg',el=(t,a)=>{const e=document.createElementNS(NS,t);for(const k in a)e.setAttribute(k,a[k]);return e};
  const sv=el('svg',{viewBox:`0 0 ${W} ${H}`,width:'100%',height:H,role:'img','aria-label':mqs('evo')});
  sv.append(el('rect',{x:0,y:H-.7*(H-4)-2,width:W,height:.2*(H-4),fill:'#dff1e3'}),el('line',{x1:0,y1:H-1,x2:W,y2:H-1,stroke:'#c9d8df','stroke-width':1.5}),
    el('polyline',{points:dd,fill:'none',stroke:'#d9822b','stroke-width':2.5,'stroke-dasharray':'6 4','stroke-linejoin':'round'}),
    el('polyline',{points:pp,fill:'none',stroke:'#2080a0','stroke-width':3,'stroke-linejoin':'round'}));
  hs.forEach((x,i)=>sv.append(el('circle',{cx:X(i),cy:H-x.pct/100*(H-4)-2,r:3,fill:'#2080a0'})));
  const ap=Math.round(hs.reduce((a,x)=>a+x.pct,0)/n),ad=hs.reduce((a,x)=>a+(x.v||[]).reduce((s,y)=>s+y,0)/Math.max(1,(x.v||[]).length),0)/n;
  return h('div',{class:'mqev'},h('div',{class:'mqevl'},h('span',{style:'color:#2080a0'},'● '+mqs('perf')+' '+ap+'%'),h('span',{style:'color:#d9822b'},'● '+mqs('dif')+' '+ad.toFixed(1)+' / 10')),sv,h('span',{class:'mqgoal'},mqs('goal')))}
function mqSide(){const k=MQK,L_=$('#mqL');if(!L_)return;const Ld=ladder(k),lv=lvl(k),hs=myH().filter(x=>x.k==k).slice(-12);
  document.body.classList.toggle('mqclosed',!MQOPEN&&!MQRES);document.body.classList.toggle('mqres',!!MQRES);
  if(MQRES){const r=MQRES;L_.replaceChildren(h('div',{class:'mqres'},
      h('span',{class:'mqcap'},mqs('res')),h('b',{class:'mqbig '+r.tone},r.pct+'%'),h('span',{class:'mqdet'},`${r.s}/${r.t}`+(r.n?' · '+r.n:'')),
      TGP&&!TGP.edit?h('span',{class:'mqchip tgpn'},TGP.done+' / '+TGP.rounds):'',h('i',{class:'mqsep'}),r.hint?h('b',{class:'mqhint'},r.hint):'',
      r.lv?h('span',{class:'mqchip'},r.lv):'',h('span',{class:'mut xs'},r.changed?mqs('nxtp'):MQM=='adaptive'?mqs('same'):''),
      h('div',{class:'grow'}),h('span',{class:'mut xs'},mqs('corr')),
      (TGP&&!TGP.edit&&TGP.done>=TGP.rounds?h('button',{class:'btn big mqseg tgpok',onclick:tgpFinish,'aria-label':'✔'},'✔'):h('button',{class:'btn big mqseg',onclick(){if(TGP)tgpNext();else mqRun(MQM=='practice'?MQP:null)}},mqs('seg')+' ▶'))));return}
  if(!MQOPEN){L_.replaceChildren(h('div',{class:'mqmini',onclick:mqToggle,title:mqs('show')},
      ...(TGP&&TGP.tv?[h('span',{class:'mqcap'},_(DIMS[4])),h('b',{class:'mqlvn'},fmt(TGP.tv[4]))]:[h('span',{class:'mqcap'},MQM=='adaptive'?mqs('lvs'):'✋'),MQM=='adaptive'?h('b',{class:'mqlvn'},String(lv+1)):'',MQM=='adaptive'?h('span',{class:'mqcap'},mqs('de',Ld.length)):'']),
      h('i',{class:'mqsep'}),...T[k].p.filter(q=>q.id!='delay').map(q=>{const v=MQP[q.id],o=q.o&&q.o.find(x=>String(x[0])==String(v));
        return h('div',{class:'mqmv'},h('b',{},o?_(o[1]).slice(0,10):String(v)),h('span',{},mqShort(q)))}),
      h('div',{class:'grow'}),h('span',{class:'mqtab'},'▸')));return}
  if(TGP&&TGP.tv){tgpSide(L_,k,hs);return}
  if(!MQD)MQD={...MQP};const bx=h('div',{class:'mqdem'}),upd=()=>{const m=M[k](clampP(k,MQD)),pr=TGP&&TGP.tv?TGP.tv:pv();
    bx.replaceChildren(...DIMS.map((d,i)=>h('div',{class:'mqdr'},h('span',{},_(d)),h('div',{class:'mqtrk'},h('div',{style:`width:${Math.min(100,m[i]*10)}%;background:${mqCol(m[i])}`}),h('i',{style:`left:${Math.min(100,pr[i]*10)}%`})),h('b',{},m[i].toFixed(1)))))};
  const form=h('div',{class:'mqpar'},...T[k].p.filter(q=>q.id!='delay').map(q=>{
    if(q.o)return h('label',{},h('span',{class:'mqpl'},_(q.l)),pickBtn(q.o.map(([v,l])=>({v,l:_(l)})),String(MQD[q.id]),v=>{MQD[q.id]=v;upd()},_(q.l)));
    const o=h('output',{},String(MQD[q.id])),sl=h('input',{type:'range',min:q.min,max:q.max,step:1,inputmode:'none',oninput(){MQD[q.id]=+sl.value;o.textContent=sl.value;upd()}});sl.value=MQD[q.id];
    return h('label',{class:'sl'},h('span',{class:'mqpl'},_(q.l),o),sl)}));
  upd();
  L_.replaceChildren(h('div',{class:'mqhd'},h('div',{},h('b',{class:'mqttl'},TGP&&TGP.tv?(TGP.cfg.by==='vars'?'🎚 ':'🎯 ')+_(DIMS[4])+' '+fmt(TGP.tv[4]):MQM=='adaptive'?mqs('lv',lv+1,Ld.length):'✋'),h('span',{class:'mut xs'},TGP&&TGP.tv?(TGP.cfg.adapt?'⇅ ±0.5':'🔒'):MQM=='adaptive'?mqs('cur'):mqs('man'))),
      h('button',{class:'mqtab',title:mqs('hide'),'aria-label':mqs('hide'),onclick:mqToggle},'◂')),
    form,h('i',{class:'mqsep'}),h('div',{class:'mqsh'},h('b',{},mqs('dem')),h('span',{class:'mut xs'},mqs('prof'))),bx,
    h('i',{class:'mqsep'}),h('b',{class:'mqsb'},mqs('evo')),mqChart(hs),h('div',{class:'grow'}),
    h('button',{class:'btn mqupd',onclick(){mqRun(MQD)}},mqs('upd')))}

/* ==== modo plugin MQ (contrato v1) ==== */
let TGP=null;
const TGP_SESSION_MS=30*60*1000;
const tgpKey=()=>'tgmq_sess:'+location.pathname.replace(/[^/]*$/,'');
function tgpSess(){try{const x=JSON.parse(localStorage.getItem(tgpKey())||'null');if(x&&Date.now()-x.t<TGP_SESSION_MS)return x}catch(e){}return null}
function tgpSessSave(){try{const x=tgpSess()||{};x.tv=x.tv||{};x.t=Date.now();x.tv[MQK]=TGP.tv.slice();localStorage.setItem(tgpKey(),JSON.stringify(x))}catch(e){}}
const tgpSec=()=>TGP?Math.round((performance.now()-TGP.t0)/10)/100:0;
function tgpLog(e){if(!TGP)return;e.positionInTime=tgpSec();TGP.log.push(e)}
let tgpStartedOnce=false;
function tgpBoot(){const c=window.MQ;
  const hear=()=>window.vuplex.addEventListener('message',ev=>{let x=ev.data;if(typeof x==='string'){try{x=JSON.parse(x||'{}')}catch(e){return}}
    if(!x||typeof x!=='object'||window.MQ.edit)return;const j=JSON.stringify(x);if(TGP&&TGP.j===j)return;tgpApply(x)});
  if(window.vuplex)hear();else addEventListener('vuplexready',hear);
  tgpLangButton();
  if(c.edit)return;                                     /* o editor aplica a configuração quando a recebe */
  if(c.cfg)tgpApply(c.cfg);else setTimeout(()=>{if(!TGP)tgpApply({})},2500)}
/* configuração: { k, by 'profile'|'vars', v [Atenção, Memória, Funções executivas, Linguagem, Dificuldade] (1–10),
   params (by 'vars'), adapt (true: >70% → dificuldade +0,5; <50% → −0,5), rounds, dock 'open'|'closed'|'hidden' }.
   Sem níveis: a tarefa gera-se para o perfil (o vetor-alvo) ou usa as variáveis dadas; a adaptação mexe na dificuldade
   do vetor-alvo. Configurações antigas ({ f, mode }) passam a variáveis (os parâmetros desse nível). */
const TGP_STEP=0.5;
const tgpR1=x=>Math.round(x*10)/10;
function tgpVec(k,v){let b=null,be=1e12;for(const c of G[k]()){const p=fixp(k,c),m=M[k](p),e=sq(m,v,5);if(e<be){be=e;b=p}}return b?{...b}:{...def(k)}}
function tgpNorm(cfg){cfg=Object.assign({},cfg||{});const k=T[cfg.k]?cfg.k:'cancel';cfg.k=k;
  if(!cfg.by){if(cfg.mode==='fixed'&&cfg.params)cfg.by='vars';else if(cfg.f!=null){const L=ladder(k);cfg.by='vars';cfg.params={...L[Math.max(0,Math.min(L.length-1,Math.round(+cfg.f*(L.length-1))))]}}else cfg.by='profile';
    if(cfg.adapt==null)cfg.adapt=cfg.mode!=='fixed'}
  cfg.by=cfg.by==='vars'?'vars':'profile';cfg.adapt=cfg.adapt!==false;
  cfg.v=Array.isArray(cfg.v)&&cfg.v.length===5?cfg.v.map(x=>Math.max(1,Math.min(10,+x||3))):[3,3,3,3,3];
  delete cfg.f;delete cfg.mode;delete cfg.level;return cfg}
function tgpApply(cfg0,edit){const cfg=tgpNorm(cfg0),k=cfg.k;
  window.MQ.k=k;window.MQ.noRun=true;MQK=k;
  if(!tgpStartedOnce){tgpStartedOnce=true;mqStart()}
  const s=edit?null:tgpSess();let p,tv;
  if(cfg.by==='vars'&&cfg.params&&typeof cfg.params==='object'){p=clampP(k,fixp(k,cfg.params));tv=M[k](p).map(tgpR1)}
  else{tv=cfg.v.slice();p=tgpVec(k,tv)}
  const cont=!!(cfg.adapt&&s&&s.tv&&Array.isArray(s.tv[k]));
  if(cont){tv=s.tv[k].slice();p=tgpVec(k,tv)}
  const dock=edit?'open':(cfg.dock||'open');MQOPEN=dock==='open';document.body.classList.toggle('tgphide',dock==='hidden');
  TGP_TAB=cfg.by;TGP_V=null;MQD=null;
  TGP={cfg,j:JSON.stringify(cfg0||{}),edit:!!edit,rounds:Math.max(1,Math.min(20,Math.round(+cfg.rounds||3))),done:0,res:[],log:[],t0:performance.now(),sent:false,tv,tv0:tv.slice(),p};
  tgpLog({state:'STARTED',task:k,by:cfg.by,adapt:cfg.adapt,target:tv.slice(),params:{...p},rounds:TGP.rounds,lang:LANG,continued:cont});
  mqRun(p)}
/* uma tarefa começou: se a pessoa mudou as variáveis no painel, o vetor-alvo passa a ser o dessas variáveis */
function tgpStarted(){TGP.ts=performance.now();
  const same=JSON.stringify(clampP(MQK,TGP.p))===JSON.stringify(clampP(MQK,curP));
  if(!same){TGP.p={...curP};delete TGP.p.delay;TGP.tv=M[MQK](clampP(MQK,curP)).map(tgpR1);if(TGP.edit)TGP.cfg.params={...TGP.p}}
  tgpLog({state:'TASK_STARTED',round:TGP.done+1,task:MQK,target:TGP.tv.slice(),params:{...curP}})}
/* exigência cognitiva dos parâmetros da tarefa (os eixos do Task Generator) */
function tgpDemand(){try{const m=M[MQK](clampP(MQK,curP)),o={};DIMS.forEach((d,i)=>o[d]=Math.round(m[i]*10)/10);return o}catch(e){return null}}
function tgpDone(r,pct){if(!TGP)return;TGP.done++;const perf={};for(const k in r)if(r[k]==null||typeof r[k]!=='object')perf[k]=r[k];
  const before=TGP.tv.slice();let delta=0;
  if(TGP.cfg.adapt){delta=pct>70?TGP_STEP:pct<50?-TGP_STEP:0;const d1=Math.max(1,Math.min(10,tgpR1(TGP.tv[4]+delta)));delta=tgpR1(d1-TGP.tv[4]);TGP.tv[4]=d1;
    if(delta)TGP.p=tgpVec(MQK,TGP.tv)}
  const e={round:TGP.done,task:MQK,name:T[MQK]&&T[MQK].n,by:TGP.cfg.by,adapt:TGP.cfg.adapt,score:r.s,maxScore:r.t,pct,
    taskTime:TGP.ts?Math.round((performance.now()-TGP.ts)/10)/100:null,target:before,difficulty:before[4],nextDifficulty:TGP.tv[4],change:delta,
    params:{...curP},demand:tgpDemand(),performance:perf,note:r.n||''};TGP.res.push(e);
  if(MQRES){MQRES.lv='';MQRES.changed=false;
    MQRES.hint=TGP.cfg.adapt?(delta>0?'▲ '+_('Next one is harder'):delta<0?'▼ '+_('Next one is easier'):pct>70?'▲ '+_('Top level reached'):pct<50?'▼ '+_('Easiest level reached'):'● '+_('In the 50–70% zone: same level')):''}
  tgpLog(Object.assign({state:'TASK_FINISHED'},e));if(!TGP.edit)tgpSessSave();
  if(!TGP.edit)tgpSend(e)}
/* painel da esquerda no plugin: dois separadores — 🎯 Perfil cognitivo (os cinco eixos) e 🎚 Variáveis da tarefa;
   «Atualizar» gera a tarefa com o que está no separador aberto, e isso passa a ser a configuração */
let TGP_TAB=null,TGP_V=null;
function tgpSide(L_,k,hs){const cfg=TGP.cfg;if(!TGP_TAB)TGP_TAB=cfg.by;if(!TGP_V||TGP_V.k!==k)TGP_V={k,v:(cfg.by==='profile'?cfg.v:TGP.tv).map(x=>Math.round(Math.max(1,Math.min(10,x))*2)/2)};
  if(!MQD)MQD={...MQP};
  const tab=(id,ic,t)=>h('button',{class:'tgptab'+(TGP_TAB===id?' on':''),onclick(){TGP_TAB=id;mqSide()}},ic+' '+t);
  const TX={profile:{pt:'Perfil',en:'Profile',es:'Perfil',it:'Profilo'},vars:{pt:'Variáveis',en:'Variables',es:'Variables',it:'Variabili'}},tx=x=>TX[x][LANG]||TX[x].en;
  const tabs=h('div',{class:'tgptabs'},tab('profile','🎯',tx('profile')),tab('vars','🎚',tx('vars')));
  const bx=h('div',{class:'mqdem'});
  const bars=(m,pr)=>bx.replaceChildren(...DIMS.map((d,i)=>h('div',{class:'mqdr'},h('span',{},_(d)),h('div',{class:'mqtrk'},h('div',{style:`width:${Math.min(100,m[i]*10)}%;background:${mqCol(m[i])}`}),h('i',{style:`left:${Math.min(100,pr[i]*10)}%`})),h('b',{},m[i].toFixed(1)))));
  let body,upd;
  if(TGP_TAB==='profile'){
    upd=()=>{const p=tgpVec(k,TGP_V.v);bars(M[k](p),TGP_V.v)};
    body=h('div',{class:'mqpar'},...DIMS.map((d,i)=>{const o=h('output',{},fmt(TGP_V.v[i])),sl=h('input',{type:'range',min:1,max:10,step:.5,inputmode:'none',oninput(){TGP_V.v[i]=+sl.value;o.textContent=fmt(+sl.value);upd()}});sl.value=TGP_V.v[i];
      return h('label',{class:'sl'},h('span',{class:'mqpl'},_(d),o),sl)}))}
  else{
    upd=()=>bars(M[k](clampP(k,MQD)),TGP.tv);
    body=h('div',{class:'mqpar'},...T[k].p.filter(q=>q.id!='delay').map(q=>{
      if(q.o)return h('label',{},h('span',{class:'mqpl'},_(q.l)),pickBtn(q.o.map(([v,l])=>({v,l:_(l)})),String(MQD[q.id]),v=>{MQD[q.id]=v;upd()},_(q.l)));
      const o=h('output',{},String(MQD[q.id])),sl=h('input',{type:'range',min:q.min,max:q.max,step:1,inputmode:'none',oninput(){MQD[q.id]=+sl.value;o.textContent=sl.value;upd()}});sl.value=MQD[q.id];
      return h('label',{class:'sl'},h('span',{class:'mqpl'},_(q.l),o),sl)}))}
  upd();
  const go=()=>{if(TGP_TAB==='profile'){cfg.by='profile';cfg.v=TGP_V.v.slice();delete cfg.params;TGP.tv=TGP_V.v.slice();TGP.p=tgpVec(k,TGP.tv);mqRun(TGP.p)}
    else{cfg.by='vars';const p=clampP(k,MQD);delete p.delay;cfg.params=p;TGP.p={...p};TGP.tv=M[k](p).map(tgpR1);mqRun(TGP.p)}
    TGP.j=JSON.stringify(cfg);tgpLog({state:'CONFIG',by:cfg.by,target:TGP.tv.slice(),params:{...TGP.p}})};
  L_.replaceChildren(h('div',{class:'mqhd'},h('div',{},h('b',{class:'mqttl'},(cfg.by==='vars'?'🎚 ':'🎯 ')+_(DIMS[4])+' '+fmt(TGP.tv[4])),h('span',{class:'mut xs'},cfg.adapt?'⇅ ±0.5':'🔒')),
      h('button',{class:'mqtab',title:mqs('hide'),'aria-label':mqs('hide'),onclick:mqToggle},'◂')),
    tabs,body,h('i',{class:'mqsep'}),h('div',{class:'mqsh'},h('b',{},mqs('dem')),h('span',{class:'mut xs'},mqs('prof'))),bx,
    h('i',{class:'mqsep'}),h('b',{class:'mqsb'},mqs('evo')),mqChart(hs),h('div',{class:'grow'}),
    h('button',{class:'btn mqupd',onclick:go},mqs('upd')))}
/* «Seguir»: a tarefa seguinte, com o vetor-alvo de agora */
function tgpNext(){mqRun(TGP.p)}
/* NeuroExercises a cada tarefa terminada (com a configuração e o desempenho dessa tarefa em lastTask) e no fim;
   o log vai sempre completo, como no TMT, e só o último (com FINISHED) faz o jogo passar ao ecrã seguinte */
function tgpSend(last){const R=TGP.res,s=R.reduce((a,x)=>a+x.score,0),t=R.reduce((a,x)=>a+x.maxScore,0);
  const d={type:'NeuroExercises',activity:'TaskGenerator',dataNE:{task:MQK,score:s,maxScore:t,
    pct:R.length?Math.round(R.reduce((a,x)=>a+x.pct,0)/R.length):0,difficultyStart:TGP.tv0[4],difficultyEnd:TGP.tv[4],target:TGP.tv.slice(),rounds:R.length,roundsPlanned:TGP.rounds,
    config:TGP.cfg,lastTask:last||null,finished:TGP.sent,duration:tgpSec(),log:TGP.log}};
  if(window.vuplex)window.vuplex.postMessage(JSON.stringify(d));else console.log('VUPLEX bridge not available',d)}
function tgpFinish(){if(!TGP||TGP.sent)return;TGP.sent=true;const R=TGP.res;
  tgpLog({state:'FINISHED',rounds:R.length,score:R.reduce((a,x)=>a+x.score,0),maxScore:R.reduce((a,x)=>a+x.maxScore,0),difficultyEnd:TGP.tv[4]});tgpSend(null)}
/* 🌐: mudar a língua sem texto para traduzir (os nomes das línguas estão na própria língua) */
function tgpLangButton(){if(document.getElementById('tgplang'))return;
  const menu=h('div',{id:'tgplangm',class:'hid'},...LANGS.map(([c,n])=>h('button',{class:'tgplo','data-l':c,onclick(){menu.classList.add('hid');tgpSetLang(c)}},n)));
  const b=h('button',{id:'tgplang','aria-label':'🌐',onclick(e){e.stopPropagation();menu.querySelectorAll('.tgplo').forEach(x=>x.classList.toggle('on',x.dataset.l===LANG));menu.style.left=getComputedStyle(b).left;menu.classList.toggle('hid')}},'🌐');
  document.addEventListener('click',e=>{if(!menu.contains(e.target)&&e.target!==b)menu.classList.add('hid')});
  document.body.append(b,menu)}
function tgpSetLang(c){if(c===LANG)return;setLang(c);tgpLog({state:'LANGUAGE',lang:c});
  if(!TGP)return;const f=$('#fin');if(f)f.textContent=mqs('fin');
  if(MQRES){mqSide();return}
  launch(MQK,{...curP},MQM);MQD=null;mqSide();mqFit();if(f)f.textContent=mqs('fin')}

if(window.MQ&&window.MQ.plugin)tgpBoot();else if(window.MQ)mqStart();else{!ROLE?show('role'):ROLE=='patient'?show('home'):(CUR&&P()?show('home'):show('profile'));}

/* ---- stuck in landscape? offer to force portrait ---- */
(function(){try{const H=document.documentElement,mq=q=>{try{return matchMedia(q).matches}catch(e){return false}};
  const set=m=>{LS.set('tg2_rot',m);apply()},
  apply=()=>{const w=innerWidth,h=innerHeight,land=w>h&&h<520&&mq('(pointer:coarse)'),m=LS.get('tg2_rot','');
    H.style.setProperty('--S',Math.min(w,h)+'px');H.style.setProperty('--L',Math.max(w,h)+'px');
    const on=land&&(m=='r'||m=='l');H.classList.toggle('rot',on&&m=='r');H.classList.toggle('rotl',on&&m=='l');
    let p=document.getElementById('rotp');
    if(land&&!on&&!window._rotNo){if(!p){p=h2('div',{id:'rotp'},h2('span',{},_('Stuck in landscape?')),h2('button',{title:'↻',onclick(){tryLock(()=>set('r'))}},'↻'),h2('button',{title:'↺',onclick(){tryLock(()=>set('l'))}},'↺'),h2('button',{class:'x',onclick(){window._rotNo=1;apply()}},'✕'));document.body.append(p)}}
    else if(p)p.remove()},
  h2=(t,a,...c)=>{const e=document.createElement(t);for(const k in a){if(k.startsWith('on'))e[k]=a[k];else e.setAttribute(k,a[k])}c.forEach(x=>e.append(x));return e},
  tryLock=fb=>{let ok=false;const t=setTimeout(()=>{if(!ok)fb()},700);try{const r=H.requestFullscreen&&H.requestFullscreen();Promise.resolve(r).then(()=>screen.orientation.lock('portrait')).then(()=>{ok=true;clearTimeout(t)},()=>{clearTimeout(t);fb()})}catch(e){clearTimeout(t);fb()}};
  window.addEventListener('resize',apply);window.addEventListener('orientationchange',()=>setTimeout(apply,200));apply()}catch(e){}})();
try{(function(){var l=document.createElement('link');l.rel='icon';l.type='image/png';l.href='data:image/png;base64,'+document.querySelector('link[rel=apple-touch-icon]').href.split(',')[1];document.querySelectorAll('link[rel=icon],link[rel="shortcut icon"]').forEach(function(x){x.remove()});document.head.appendChild(l)})()}catch(e){}

/* ---- long-press zoom, text fit, sliders, splash ---- */
try{(function(){let t=null,sx=0,sy=0,sw=false;
  const ok=im=>im&&/^data:image\//.test(im.getAttribute('src')||'')&&!im.closest('#top,#logo,#splash,.appic,.mdl .zoomo');
  const open=im=>{sw=true;setTimeout(()=>sw=false,900);const o=document.createElement('div');o.className='zoomo';const z=document.createElement('img');z.src=im.src;z.alt='';o.append(z);
    o.onclick=()=>o.remove();document.body.append(o)};
  document.addEventListener('pointerdown',e=>{const im=e.target.closest&&e.target.closest('img');if(!ok(im))return;sx=e.clientX;sy=e.clientY;clearTimeout(t);t=setTimeout(()=>{t=null;open(im)},420)},true);
  const cl=()=>{clearTimeout(t);t=null};
  document.addEventListener('pointerup',cl,true);document.addEventListener('pointercancel',cl,true);document.addEventListener('scroll',cl,true);
  document.addEventListener('pointermove',e=>{if(t&&Math.hypot(e.clientX-sx,e.clientY-sy)>12)cl()},true);
  document.addEventListener('click',e=>{if(sw){e.stopPropagation();e.preventDefault();sw=false}},true);
  document.addEventListener('contextmenu',e=>{if(e.target.closest&&ok(e.target.closest('img')))e.preventDefault()},true)})()}catch(e){}
try{(function(){const SEL='button,.tab,.tile,.badge,h1,h2,.pchip,.pcgo,.seqi,.opt,.ctx span,.cap,label.chk span';let q=0;
  const fit=el=>{if(!el.clientWidth||el.querySelector('img,canvas'))return;if(el.dataset.fs){el.style.fontSize='';}let s=parseFloat(getComputedStyle(el).fontSize),mn=s*.6,n=0;el.dataset.fs=1;
    while((el.scrollWidth>el.clientWidth+1||(el.style.height&&el.scrollHeight>el.clientHeight+1))&&s>mn&&n++<14){s*=.93;el.style.fontSize=s.toFixed(2)+'px'}};
  const run=()=>{q=0;document.querySelectorAll(SEL).forEach(fit)};
  const sched=()=>{if(!q)q=requestAnimationFrame(run)};
  new MutationObserver(sched).observe(document.body,{childList:true,subtree:true,characterData:true});
  window.addEventListener('resize',sched);if(document.fonts&&document.fonts.ready)document.fonts.ready.then(sched);sched()})()}catch(e){}
try{document.addEventListener('focusin',e=>{const t=e.target;if(t&&t.type=='range'&&matchMedia('(pointer:coarse)').matches){t.setAttribute('inputmode','none');t.blur()}},true)}catch(e){}
try{(function(){const s=document.getElementById('splash');if(!s)return;const left=Math.max(250,3800-performance.now());setTimeout(()=>{s.classList.add('out');setTimeout(()=>s.remove(),550)},left)})()}catch(e){}


