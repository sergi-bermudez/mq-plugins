'use strict';
/**
 * Task Generator — plugin editor (MQ Plugins contract v1).
 * The page runs the real Task Generator (tg_data.js + tg_app.js) as a live preview; this bar chooses the task,
 * a cognitive profile or the task's variables, adaptation, how many tasks the screen has and how the panel is shown.
 * Receives the configuration through window.vuplex ("{}" = new screen) and saves with
 *   window.vuplex.postMessage({ type: 'PluginConfig', config, files: {} })
 * Configuration: { k, by 'profile'|'vars', v [Attention, Memory, Executive functions, Language, Difficulty] 1–10 (profile),
 *                  params (vars), adapt (>70% → difficulty +0.5, <50% → −0.5), rounds, dock 'open'|'closed'|'hidden' }
 * No levels: the task is generated for the profile, or uses the variables given.
 */
(function () {
    const DEF = { k: 'cancel', by: 'profile', v: [3, 3, 3, 3, 3], adapt: true, rounds: 3, dock: 'open' };
    let cfg = Object.assign({}, DEF);
    const bar = document.getElementById('tged');
    document.body.classList.add('tged');

    const el = (tag, attrs, ...kids) => {
        const e = document.createElement(tag);
        Object.entries(attrs || {}).forEach(([k, v]) => { if (k.startsWith('on')) e[k] = v; else e.setAttribute(k, v); });
        kids.forEach((c) => e.append(c));
        return e;
    };
    const cap = (t) => el('span', { class: 'tgcap' }, t);

    const task = el('select', { 'aria-label': 'Tarefa' }, ...KS.map((k) => el('option', { value: k }, _(T[k].n))));
    const adapt = el('input', { type: 'checkbox' });
    const rounds = el('input', { type: 'number', min: 1, max: 20, step: 1, 'aria-label': 'Tarefas no ecrã' });
    const dock = el('select', { 'aria-label': 'Painel de parâmetros' },
        el('option', { value: 'open' }, 'Aberto'), el('option', { value: 'closed' }, 'Fechado'), el('option', { value: 'hidden' }, 'Escondido'));
    const msg = el('span', { class: 'tgmsg', role: 'status' });
    const save = el('button', { type: 'button' }, 'Guardar');

    bar.append(
        el('label', {}, cap('Tarefa'), task),
        el('label', { class: 'ck', title: 'Acima de 70% a dificuldade sobe 0,5; abaixo de 50% desce 0,5' }, adapt, cap('Adaptativo (±0,5)')),
        el('label', {}, cap('Tarefas no ecrã'), rounds),
        el('label', {}, cap('Painel'), dock),
        el('span', { class: 'grow' }), msg, save);

    const fitBar = () => { document.body.style.setProperty('--tgedh', bar.offsetHeight + 'px'); if (typeof mqFit === 'function') mqFit(); };
    if (typeof ResizeObserver === 'function') new ResizeObserver(fitBar).observe(bar);
    addEventListener('resize', fitBar);
    setTimeout(fitBar, 50);

    const say = (t, err) => { msg.textContent = t; msg.classList.toggle('err', !!err); if (t) setTimeout(() => { if (msg.textContent === t) msg.textContent = ''; }, 3000); };

    function sync() {
        if (typeof MQK === 'undefined' || !TGP) return;
        [...task.options].forEach((o) => { const t = _(T[o.value].n); if (o.textContent !== t) o.textContent = t; });   /* follows the language (🌐) */
        task.value = MQK;
        adapt.checked = cfg.adapt !== false;
        if (document.activeElement !== rounds) rounds.value = cfg.rounds;
        dock.value = cfg.dock;
    }
    setInterval(sync, 400);

    function apply() { tgpApply(cfg, true); sync(); }

    task.onchange = () => { cfg = Object.assign({}, cfg, { k: task.value, by: 'profile', params: undefined }); apply(); };
    adapt.onchange = () => { cfg.adapt = adapt.checked; if (TGP) { TGP.cfg.adapt = cfg.adapt; mqSide(); } };
    rounds.onchange = () => { cfg.rounds = Math.max(1, Math.min(20, Math.round(+rounds.value || 1))); rounds.value = cfg.rounds; };
    dock.onchange = () => { cfg.dock = dock.value; };

    /* what is saved is what the panel last applied («Atualizar»): the profile or the variables */
    function build() {
        const c = TGP ? TGP.cfg : cfg, by = c.by === 'vars' ? 'vars' : 'profile';
        const out = { k: MQK, by, adapt: cfg.adapt !== false, rounds: cfg.rounds, dock: cfg.dock };
        if (by === 'vars') { const p = Object.assign({}, TGP && TGP.p ? TGP.p : MQP); delete p.delay; out.params = p; }
        else out.v = (c.v || [3, 3, 3, 3, 3]).slice();
        return out;
    }

    save.onclick = () => {
        const config = build();
        if (window.vuplex) {
            window.vuplex.postMessage({ type: 'PluginConfig', config, files: {} });
            say('Guardado.');
        } else {
            const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
            const a = el('a', { href: URL.createObjectURL(blob), download: 'task-generator-' + config.k + '.json' });
            document.body.append(a); a.click(); a.remove();
        }
    };

    let got = false;
    const hear = () => window.vuplex.addEventListener('message', (event) => {
        let x = event.data;
        if (typeof x === 'string') { try { x = JSON.parse(x || '{}'); } catch (e) { say('JSON inválido', true); return; } }
        got = true;
        cfg = tgpNorm(Object.assign({}, DEF, x && typeof x === 'object' ? x : {}));
        if (cfg.by === 'profile' && (!x || !x.v)) cfg.v = DEF.v.slice();
        apply();
    });
    if (window.vuplex) hear(); else addEventListener('vuplexready', hear);
    setTimeout(() => { if (!got && !TGP) apply(); }, 1200);
})();
