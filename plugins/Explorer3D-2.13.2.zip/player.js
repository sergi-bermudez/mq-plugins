'use strict';
/**
 * Explorador 3D — plugin player (MQ Plugins contract v1).
 * Reads the level from window.MQ_CONFIG (<page>.config.js) or window.vuplex, lets the person walk around in first person
 * (keyboard, mouse drag to turn, on-screen buttons: a tap moves one cell or turns 45°, holding keeps moving),
 * collects objects, answers the questions placed in the level and ends at the exit.
 * The collection is always on screen (no bag to open): objects, keys, notes to read again (📜), compass, map. A question can give a key or open
 * the doors of a colour when answered correctly (a wrong answer leaves it open to try again).
 * Doors open with the key of their colour; hints help to find the exit (📜 note to read again, 🧭 compass that points to
 * the exit, 🗺 map that shows the mini map).
 * Result once, at the end: NeuroExercises / Explorer3D / dataNE { score, maxScore, items, answers, keys, doorsOpened,
 * hints, bumps, distance, cellsVisited, duration, path, log } with STARTED, ITEM, WRONG_ITEM, KEY, DOOR_OPENED,
 * DOOR_LOCKED, HINT, ANSWER, EXIT_BLOCKED, BUMP and FINISHED entries.
 */
class ExplorerPlayer {
    constructor(opts) {
        this.opts = opts || {};
        this.embed = !!this.opts.embed;      // inside the level editor («Testar»): no Vuplex, result goes to opts.onResult
        this.activity = 'Explorer3D';
        this.view = document.getElementById('view');
        this.itemsBox = document.getElementById('items');
        this.qsBox = document.getElementById('qs');
        /* a caixa 🎒 só aparece quando há alguma coisa lá dentro */
        const bag = document.getElementById('inv');
        if (bag && window.MutationObserver) {
            const upd = () => bag.classList.toggle('has', [...bag.children].some((c) => c.children.length));
            new MutationObserver(upd).observe(bag, { childList: true, subtree: true }); upd();
        }
        this.qbox = document.getElementById('qbox');
        this.msg = document.getElementById('msg');
        this.log = [];
        this.path = [];
        this.answers = [];
        this.sent = false;
        this.engine = null;
        this.sfx = window.MQSfx ? new MQSfx() : null;
        this.initializeInput();
        addEventListener('resize', () => this.fit());
        if (!this.embed) this.initializeConfigLoading();
    }

    /* editor: stop the test */
    close() {
        if (this.sfx) this.sfx.stopAll();
        if (this.engine) this.engine.stop();
        if (this.r3d) { this.r3d.dispose(); this.r3d = null; }
        clearInterval(this.sampler);
        this.stopSound(); this.qbox.classList.remove('open');
        this.msg.classList.remove('open');
        this.engine = null;
    }

    /* ---------- configuration ---------- */

    initializeConfigLoading() {
        if (window.MQ_CONFIG && typeof window.MQ_CONFIG === 'object') this.startLevel(window.MQ_CONFIG);
        const hear = () => window.vuplex.addEventListener('message', (event) => {
            let cfg = event.data;
            if (typeof cfg === 'string') { try { cfg = JSON.parse(cfg); } catch (e) { return; } }
            if (!cfg || typeof cfg !== 'object') return;
            const j = JSON.stringify(cfg);
            if (j === this.cfgJson) return;
            this.startLevel(cfg);
        });
        if (window.vuplex) hear(); else addEventListener('vuplexready', hear);
    }

    /** ↺ recomeçar: tudo volta ao início (blocos, portas, objetos, a pessoa), mas o registo e o tempo continuam —
        para quando se faz um movimento que não se pode desfazer (um 📦 encostado a um canto, um bloco partido de mais…) */
    async restart() {
        if (!this.engine || this.sent || !this.cfg) return;
        const keep = { t0: this.t0, log: this.log, path: this.path, answers: this.answers, wrongItems: this.wrongItems, resets: (this.resets || 0) + 1, avatar: this.engine.avatarAsset, cam: this.engine.camMode };
        this.qbox.classList.remove('open'); this.msg.classList.remove('open'); this.stopSound();
        await this.startLevel(this.cfg, keep);
    }

    async startLevel(cfg, keep) {
        this.cfgJson = JSON.stringify(cfg);
        this.cfg = cfg;
        if (this.sfx) { this.sfx.stopAll(); this.sfx.on = cfg.sfx !== false; }
        if (this.engine) this.engine.stop();
        if (this.r3d) { this.r3d.dispose(); this.r3d = null; }
        this.log = []; this.path = []; this.answers = []; this.sent = false; this.wrongItems = 0; this.resets = 0;
        if (keep) { this.log = keep.log; this.path = keep.path; this.answers = keep.answers; this.wrongItems = keep.wrongItems; this.resets = keep.resets; }
        /* sons: de onde vêm (mais fortes perto, do lado em que estão) */
        const snd = (name, x, y) => { if (this.sfx) this.sfx.play(name, x, y, this.engine); };
        const E = new Explorer3D.Engine(this.view, cfg, {
            item: (it) => { snd(it.target === false ? 'wrong' : 'item'); this.onItem(it); },
            question: (q) => { snd('question'); this.onQuestion(q); },
            exit: () => { snd('exit'); this.onExit(); },
            bump: () => { snd('bump'); this.pushLogEntry({ state: 'BUMP', x: this.r(E.px), y: this.r(E.py) }); },
            key: (k) => { snd('key'); this.onKey(k); },
            door: (c, opened, x, y) => { snd(opened ? 'door' : 'locked', x + 0.5, y + 0.5); this.onDoor(c, opened, x, y); },
            plate: (p, n) => { snd('plate', p.x + 0.5, p.y + 0.5); this.onPlate(p, n); },
            hint: (h) => { snd('hint'); this.onHint(h); },
            carStop: (m) => { snd('horn', m.fx, m.fy); this.pushLogEntry({ state: 'CAR_STOPPED', car: (E.L.assets[m.asset] || {}).name || m.asset, x: this.r(m.fx), y: this.r(m.fy) }); },
            road: (x, y, crossing) => this.pushLogEntry({ state: crossing ? 'ON_CROSSING' : 'ON_ROAD', x, y }),
            push: (x, y, tx, ty) => { snd('push', tx + 0.5, ty + 0.5); this.pushLogEntry({ state: 'BLOCK_PUSHED', x, y, toX: tx, toY: ty }); },
            breakBlock: (ok, x, y) => {
                snd(ok ? 'break' : 'locked', x + 0.5, y + 0.5);
                this.pushLogEntry({ state: ok ? 'BLOCK_BROKEN' : 'BLOCK_NEEDS_PICK', x, y });
                if (!ok) this.flashText('⛏️ ?', 1100);
            },
            frame: () => this.onFrame()
        });
        this.engine = E;
        await E.load();
        E.camMode = E.L.camera;
        /* maneira de ver: 3D (WebGL) se o nível o pede e o aparelho o permite; senão 2D */
        this.mode = '2d';
        const v3 = document.getElementById('view3d');
        if (E.L.view !== '2d' && v3 && window.Explorer3DView && Explorer3DView.webglOK()) {
            try {
                document.body.classList.add('v3d'); if (v3.parentElement) v3.parentElement.classList.add('v3d');
                /* a personagem: escolhida pela pessoa quando o nível tem mais do que uma */
                const av = (E.L.avatars || []).filter((id) => Explorer3D.walks(E.L.assets[id]));
                E.avatarAsset = keep ? (keep.avatar || null) : av.length > 1 ? await this.chooseAvatar(av) : (av[0] || null);
                const r = new Explorer3DView.Renderer3D(E, v3);
                await r.init();
                E.r3d = r; this.r3d = r; this.mode = '3d';
            } catch (e) { console.warn('Explorador: sem 3D', e); }
        }
        /* 👁 muda entre 1.ª e 3.ª pessoa (só em 3D) */
        /* 3.ª pessoa só com uma personagem que caminha (com animação de andar); sem ela, 1.ª pessoa */
        if (!E.avatarAsset) E.camMode = '1st';
        const cb = document.getElementById('camBtn');
        if (cb) {
            cb.hidden = this.mode !== '3d' || !E.avatarAsset;
            /* o botão diz para onde muda: na 1.ª pessoa «🧍 3.ª pessoa» (ver-se de fora), na 3.ª «👁 1.ª pessoa» (ver pelos olhos) */
            const show = () => { cb.innerHTML = E.camMode === '3rd' ? '<i>👁</i><span>' + MQT('1.ª pessoa') + '</span>' : '<i>🧍</i><span>' + MQT('3.ª pessoa') + '</span>'; cb.title = E.camMode === '3rd' ? MQT('Ver pelos olhos') : MQT('Ver-se de fora'); };
            show();
            cb.onclick = () => {
                if (this.overlayOpen()) return;
                E.camMode = E.camMode === '3rd' ? '1st' : '3rd';
                show();
                this.pushLogEntry({ state: 'CAMERA', camera: E.camMode });
            };
        }
        if (this.mode === '2d') { E.camMode = '1st'; document.body.classList.remove('v3d'); if (v3 && v3.parentElement) v3.parentElement.classList.remove('v3d'); }
        this.fit();
        this.buildHud();
        this.t0 = keep ? keep.t0 : performance.now();
        if (keep) { E.camMode = keep.cam || E.camMode; if (!E.avatarAsset) E.camMode = '1st'; }
        const rb = document.getElementById('resetBtn');
        if (rb) { rb.hidden = false; rb.onclick = () => { if (!this.overlayOpen()) this.restart(); }; }
        if (keep) this.pushLogEntry({ state: 'RESET', n: this.resets });
        else this.pushLogEntry({ state: 'STARTED', view: this.mode, camera: E.camMode, character: E.avatarAsset ? ((E.L.assets[E.avatarAsset] || {}).name || E.avatarAsset) : '', items: E.items.filter((i) => i.target !== false).length, questions: E.questions.length, exit: !!E.L.exit });
        E.start();
        clearInterval(this.sampler);
        this.sampler = setInterval(() => {
            if (this.sent || !this.engine) return;
            this.path.push([this.elapsedSeconds(), this.r(E.px), this.r(E.py), Math.round(E.pa * 180 / Math.PI) % 360]);
            const lim = +E.L.timeLimit || 0;
            if (lim > 0 && this.elapsedSeconds() >= lim) this.finish('time');
        }, 500);
    }

    /** the person picks a character (pictures only) */
    chooseAvatar(ids) {
        return new Promise((done) => {
            const ov = document.getElementById('who'), body = document.getElementById('whobody');
            body.innerHTML = '';
            ids.forEach((id) => {
                const a = this.engine.L.assets[id] || {}, b = document.createElement('button');
                b.type = 'button'; b.title = a.name || id;
                if (a.views && a.views[0]) { const im = document.createElement('img'); im.src = a.views[0]; im.alt = ''; b.append(im); } else b.textContent = '🧍';
                b.onclick = () => { ov.classList.remove('open'); done(id); };
                body.append(b);
            });
            ov.classList.add('open');
        });
    }

    fit() {
        const W = this.view.clientWidth || innerWidth, H = this.view.clientHeight || innerHeight, k = Math.min(1, 900 / Math.max(1, W));
        this.view.width = Math.max(320, Math.round(W * k));
        this.view.height = Math.max(200, Math.round(H * k));
        if (this.engine) this.engine.mmLeft = 0;
    }

    /* ---------- HUD (icons only) ---------- */

    buildHud() {
        const E = this.engine;
        this.itemsBox.innerHTML = '';
        this.itemEls = new Map();
        const targets = E.items.filter((it) => it.target !== false);
        if (targets.length) { this.countEl = document.createElement('div'); this.countEl.className = 'count'; this.itemsBox.append(this.countEl); }
        else this.countEl = null;
        this.updateCount = () => {
            if (!this.countEl) return;
            const got = targets.filter((it) => it.got).length;
            this.countEl.textContent = got + '/' + targets.length;
            this.countEl.classList.toggle('done', got === targets.length);
        };
        this.updateCount();
        targets.forEach((it) => {
            const d = document.createElement('div');
            d.className = 'it';
            if (it.img) { const im = document.createElement('img'); im.src = it.img; im.alt = it.name || ''; d.append(im); }
            else d.textContent = it.name || '•';
            this.itemsBox.append(d);
            this.itemEls.set(it.i, d);
        });
        document.getElementById('keys').innerHTML = '';
        document.getElementById('notes').innerHTML = '';
        document.getElementById('compass').hidden = true;
        this.notes = []; this.usedKeys = new Set(); this.rewardKeys = 0;
        document.getElementById('tools').innerHTML = '';
        this.bagCount();
        this.qsBox.innerHTML = '';
        this.qEls = new Map();
        E.questions.forEach((q) => {
            const d = document.createElement('div');
            d.className = 'q'; d.textContent = '?';
            this.qsBox.append(d);
            this.qEls.set(q.i, d);
        });
    }

    /* ---------- input ---------- */

    initializeInput() {
        const keys = {};
        const apply = () => {
            if (!this.engine) return;
            const busy = this.overlayOpen();
            this.engine.input.fwd = busy ? 0 : ((keys.up || keys.mup) ? 1 : 0) - ((keys.down || keys.mdown) ? 1 : 0);
            this.engine.input.turn = busy ? 0 : (keys.right ? 1 : 0) - (keys.left ? 1 : 0);
        };
        const map = { ArrowUp: 'up', KeyW: 'up', ArrowDown: 'down', KeyS: 'down', ArrowLeft: 'left', KeyA: 'left', ArrowRight: 'right', KeyD: 'right' };
        const typing = (e) => /^(INPUT|TEXTAREA|SELECT)$/.test((e.target && e.target.tagName) || '') || !this.engine;
        addEventListener('keydown', (e) => { const k = map[e.code]; if (!k || typing(e)) return; e.preventDefault(); keys[k] = true; apply(); });
        addEventListener('keyup', (e) => { const k = map[e.code]; if (!k) return; keys[k] = false; apply(); });
        addEventListener('blur', () => { Object.keys(keys).forEach((k) => { keys[k] = false; }); apply(); });

        /* rato: um clique na vista prende o rato (em 3D) — mexer o rato olha à volta, para os lados e para cima e para baixo;
           botão esquerdo carregado = andar para a frente, botão direito = para trás; Esc solta o rato.
           Dedo (ou sem prender o rato): arrastar olha à volta da mesma maneira. */
        const PMAX = 1.15;
        const look = (dx, dy) => {
            const E = this.engine;
            if (!E) return;
            E.pa += dx * 0.0042;
            if (this.mode === '3d') E.pitch = Math.max(-PMAX, Math.min(PMAX, (E.pitch || 0) - dy * 0.0036));
        };
        const locked = () => document.pointerLockElement === this.view;
        this.unlockMouse = () => { if (locked() && document.exitPointerLock) document.exitPointerLock(); keys.mup = keys.mdown = false; apply(); };
        let drag = null;
        this.view.addEventListener('contextmenu', (e) => e.preventDefault());
        this.view.addEventListener('pointerdown', (e) => {
            if (this.overlayOpen() || !this.engine) return;
            if (e.pointerType === 'mouse') {
                if (locked()) { if (e.button === 0) keys.mup = true; else if (e.button === 2) keys.mdown = true; apply(); return; }
                if (this.mode === '3d' && this.view.requestPointerLock && e.button === 0) {
                    try { const pr = this.view.requestPointerLock(); if (pr && pr.catch) pr.catch(() => {}); } catch (_) { /* sem pointer lock: arrastar */ }
                }
            }
            drag = { x: e.clientX, y: e.clientY }; this.view.classList.add('drag'); try { this.view.setPointerCapture(e.pointerId); } catch (_) {}
        });
        this.view.addEventListener('pointermove', (e) => {
            if (!this.engine) return;
            if (locked()) {
                if (this.overlayOpen()) { this.unlockMouse(); return; }
                const mx = e.movementX || 0, my = e.movementY || 0;
                if (Math.abs(mx) < 160 && Math.abs(my) < 160) look(mx, my);      /* alguns browsers dão um salto enorme logo a seguir a prender o rato */
                return;
            }
            if (!drag) return;
            look((e.clientX - drag.x) * 1.4, (e.clientY - drag.y) * 1.4);
            drag.x = e.clientX; drag.y = e.clientY;
        });
        const end = (e) => {
            if (e && e.pointerType === 'mouse' && locked()) { if (e.button === 0) keys.mup = false; else if (e.button === 2) keys.mdown = false; apply(); }
            drag = null; this.view.classList.remove('drag');
        };
        this.view.addEventListener('pointerup', end);
        this.view.addEventListener('pointercancel', end);
        document.addEventListener('pointerlockchange', () => {
            document.body.classList.toggle('mouselook', locked());
            if (!locked()) { keys.mup = keys.mdown = false; apply(); drag = null; }
        });

        /* on-screen buttons: a tap = one cell / 45°, holding = keeps going */
        const bind = (id, kind, inputKey, value) => {
            const b = document.getElementById(id);
            let t = null, held = false;
            const down = (e) => {
                e.preventDefault();
                if (!this.engine || this.overlayOpen()) return;
                b.classList.add('on');
                try { b.setPointerCapture(e.pointerId); } catch (_) {}
                held = false;
                clearTimeout(t);
                t = setTimeout(() => { held = true; this.engine.input[inputKey] = value; }, 230);
            };
            const up = () => {
                b.classList.remove('on');
                clearTimeout(t);
                if (!this.engine) return;
                if (held) this.engine.input[inputKey] = 0; else if (!this.overlayOpen()) this.engine.step(kind);
                held = false;
            };
            b.addEventListener('pointerdown', down);
            b.addEventListener('pointerup', up);
            b.addEventListener('pointercancel', up);
            b.addEventListener('contextmenu', (e) => e.preventDefault());
        };
        bind('bFwd', 'fwd', 'fwd', 1);
        bind('bBack', 'back', 'fwd', -1);
        bind('bLeft', 'left', 'turn', -1);
        bind('bRight', 'right', 'turn', 1);
    }

    overlayOpen() { return this.qbox.classList.contains('open') || this.msg.classList.contains('open') || this.sent; }

    pause(on) {
        if (!this.engine) return;
        this.engine.paused = on;
        this.engine.input.fwd = 0; this.engine.input.turn = 0; this.engine.anim = null;
    }

    /* ---------- events of the level ---------- */

    onItem(it) {
        const target = it.target !== false;
        this.pushLogEntry({ state: target ? 'ITEM' : 'WRONG_ITEM', name: it.name || '', x: it.x, y: it.y });
        if (it.audio) { try { this.stopSound(); this.audio = new Audio(it.audio); const p = this.audio.play(); if (p && p.catch) p.catch(() => {}); } catch (e) { /* nothing */ } }
        this.bagCount(true);
        if (it.msg) {           /* a mensagem do objeto (com o áudio dela, se houver): aparece ao apanhá-lo */
            const body = document.getElementById('msgbody');
            body.innerHTML = '';
            const t = document.createElement('div'); t.className = 'itmsg'; t.textContent = it.msg; body.append(t);
            this.flash(Math.max(2200, Math.min(9000, it.msg.length * 80)));
        }
        if (target) { const d = this.itemEls.get(it.i); if (d) d.classList.add('got'); if (this.updateCount) this.updateCount(); }
        else {
            this.wrongItems++;
            const d = document.createElement('div');
            d.className = 'it bad';
            if (it.img) { const im = document.createElement('img'); im.src = it.img; d.append(im); } else d.textContent = it.name || '•';
            this.itemsBox.append(d);
        }
    }

    onKey(k, source) {
        this.pushLogEntry({ state: 'KEY', color: Explorer3D.DOORS[k.color].name, source: source || 'level', x: k.x, y: k.y });
        const c = Explorer3D.keyIcon(Explorer3D.DOORS[k.color].color, 92);
        c.dataset.color = k.color;
        document.getElementById('keys').append(c);
        this.bagCount(true);
    }

    /* ---------- 🎒 inventory (icons; names only where the level gives them) ---------- */

    bagItems() {
        const E = this.engine;
        if (!E) return {};
        return {
            items: E.items.filter((it) => it.got),
            keys: [...E.held],
            notes: this.notes || [],
            tools: [E.hasPick ? '⛏️' : '', E.compass ? '🧭' : '', E.hints.some((h) => h.got && h.type === 'map') ? '🗺️' : ''].filter(Boolean)
        };
    }
    /** the collection on screen: notes (to read again) and tools; objects and keys are added where they are collected */
    bagCount(pulse) {
        const b = this.bagItems(), notes = document.getElementById('notes'), tools = document.getElementById('tools');
        if (!notes || !tools) return;
        while (notes.children.length < (b.notes || []).length) {
            const h = b.notes[notes.children.length], n = document.createElement('button');
            n.type = 'button'; n.textContent = '📜';
            n.onclick = () => { if (this.overlayOpen()) return; this.pushLogEntry({ state: 'HINT_REREAD', x: h.x, y: h.y }); this.showNote(h); };
            notes.append(n);
        }
        const want = (b.tools || []).join('');
        if (tools.dataset.t !== want) {
            tools.dataset.t = want; tools.innerHTML = '';
            (b.tools || []).forEach((t) => { const s = document.createElement('span'); s.textContent = t; tools.append(s); });
        }
        const hud = document.getElementById('hud');
        if (pulse && hud) { hud.classList.remove('pulse'); void hud.offsetWidth; hud.classList.add('pulse'); }
    }
    onDoor(c, opened, x, y) {
        const name = Explorer3D.DOORS[c].name;
        if (opened) {
            this.pushLogEntry({ state: 'DOOR_OPENED', color: name, x, y });
            this.usedKeys.add(c);
            const used = document.querySelector('#keys canvas[data-color="' + c + '"]');
            if (used) used.style.opacity = 0.4;
            return;
        }
        this.pushLogEntry({ state: 'DOOR_LOCKED', color: name, x, y });
        const body = document.getElementById('msgbody');
        body.innerHTML = '🔒';
        body.append(Explorer3D.keyIcon(Explorer3D.DOORS[c].color, 128));
        this.flash(1600);
    }

    onPlate(p, n) {
        const D = Explorer3D.DOORS[p.color];
        this.pushLogEntry({ state: 'PLATE', color: D.name, x: p.x, y: p.y, box: !!p.needBox, doors: n });
        this.platesOn = (this.platesOn || 0) + 1;
        const body = document.getElementById('msgbody');
        body.innerHTML = '🔓';
        const c = document.createElement('canvas'); c.width = c.height = 64; Explorer3D.door(c.getContext('2d'), D.color); body.append(c);
        this.flash(1400);
    }

    onHint(h) {
        this.pushLogEntry({ state: 'HINT', type: h.type, x: h.x, y: h.y });
        this.bagCount(true);
        if (h.type === 'compass') { document.getElementById('compass').hidden = false; this.flashText('🧭', 1200); return; }
        if (h.type === 'map') { this.flashText('🗺️', 1200); return; }
        if (h.type === 'pick') { this.flashText('⛏️', 1200); return; }
        this.notes.push(h);
        this.bagCount(true);
        this.showNote(h);
    }

    showNote(h) {
        const body = document.getElementById('msgbody');
        body.innerHTML = '';
        if (h.img) { const im = document.createElement('img'); im.className = 'noteimg'; im.src = h.img; body.append(im); }
        if (h.text) { const p = document.createElement('div'); p.className = 'note'; p.textContent = h.text; body.append(p); }
        if (!h.img && !h.text) body.textContent = '📜';
        if (h.audio) body.append(this.sound(h.audio));
        const ok = document.createElement('div'); ok.className = 'okmark'; ok.textContent = '✔';
        body.append(ok);
        this.pause(true);
        this.msg.classList.add('open', 'note');
        const close = () => { this.stopSound(); this.msg.classList.remove('open', 'note'); this.msg.onclick = null; this.pause(false); };
        setTimeout(() => { this.msg.onclick = close; }, 400);
    }

    /** plays a text's audio and gives a 🔊 button to hear it again */
    sound(src) {
        this.stopSound();
        const b = document.createElement('button');
        b.type = 'button'; b.className = 'snd'; b.textContent = '🔊'; b.setAttribute('aria-label', '🔊');
        const play = () => { try { this.stopSound(); this.audio = new Audio(src); const p = this.audio.play(); if (p && p.catch) p.catch(() => {}); } catch (e) { /* nothing */ } };
        b.onclick = (e) => { e.stopPropagation(); play(); this.pushLogEntry({ state: 'AUDIO_REPLAY' }); };
        setTimeout(play, 150);
        return b;
    }
    stopSound() { if (this.audio) { try { this.audio.pause(); } catch (e) { /* nothing */ } this.audio = null; } }

    flashText(t, ms) { document.getElementById('msgbody').textContent = t; this.flash(ms); }
    flash(ms) {
        this.pause(true);
        this.msg.classList.add('open');
        clearTimeout(this.flashT);
        this.flashT = setTimeout(() => { this.msg.classList.remove('open'); this.pause(false); }, ms);
    }

    /* 🧭: points to the exit, relative to where the person is looking */
    onFrame() {
        const E = this.engine;
        if (E && this.sfx) {
            this.sfx.update(E);
            if (this.lastPh != null && E.ph !== this.lastPh) this.sfx.play('step');      /* sobe ou desce um bloco */
            this.lastPh = E.ph;
        }
        if (!E || !E.compass || !E.L.exit) return;
        const a = Math.atan2(E.L.exit.y + 0.5 - E.py, E.L.exit.x + 0.5 - E.px) - E.pa;
        document.getElementById('needle').style.transform = 'rotate(' + (a * 180 / Math.PI) + 'deg)';
    }

    onQuestion(q) {
        this.pause(true);
        const img = document.getElementById('qimg'), text = document.getElementById('qtext'), opts = document.getElementById('qopts'), mark = document.getElementById('qmark');
        if (q.img) { img.src = q.img; img.style.display = 'block'; } else { img.removeAttribute('src'); img.style.display = 'none'; }
        text.textContent = q.text || '';
        if (q.audio) text.append(' ', this.sound(q.audio));
        mark.textContent = '';
        opts.innerHTML = '';
        const shown = performance.now();
        const list = (q.options || []).filter((o) => o && String(o.text || '').trim());
        if (!list.length) {
            const b = document.createElement('button');
            b.textContent = '✔';
            b.onclick = () => { q.done = true; this.stopSound(); this.qbox.classList.remove('open'); this.pause(false); };
            opts.append(b);
        }
        list.forEach((o) => {
            const b = document.createElement('button');
            b.type = 'button';
            b.textContent = o.text;
            b.onclick = () => {
                const correct = !!o.correct;
                q.tries = (q.tries || 0) + 1;
                q.done = correct || !q.reward;      // with a reward, a wrong answer can be tried again (step on the ? again)
                opts.querySelectorAll('button').forEach((x) => { x.disabled = true; });
                b.classList.add(correct ? 'ok' : 'no');
                mark.textContent = correct ? '✔' : '✖';
                mark.style.color = correct ? '#22a35a' : '#e04848';
                const rt = this.r((performance.now() - shown) / 1000);
                this.answers.push({ q: q.i + 1, question: q.text || '', answer: o.text, correct, attempt: q.tries, responseTime: rt });
                this.pushLogEntry({ state: 'ANSWER', question: q.i + 1, text: q.text || '', answer: o.text, correct, attempt: q.tries, score: correct && q.tries === 1 ? 1 : 0, responseTime: rt });
                const d = this.qEls.get(q.i);
                if (d && q.done) { d.classList.add(correct ? 'ok' : 'no'); d.textContent = correct ? '✔' : '✖'; }
                setTimeout(() => {
                    this.stopSound(); this.qbox.classList.remove('open');
                    this.pause(false);
                    if (correct && q.reward) this.giveReward(q);
                }, 1100);
            };
            opts.append(b);
        });
        this.qbox.classList.add('open');
    }

    /* recompensa de uma pergunta certa: a chave de uma cor, ou as portas dessa cor abrem-se logo */
    giveReward(q) {
        const E = this.engine, r = q.reward, D = Explorer3D.DOORS[r && r.color];
        if (!E || !D) return;
        const body = document.getElementById('msgbody');
        if (r.type === 'open') {
            const n = E.openDoors(r.color);
            this.usedKeys.add(r.color);
            this.pushLogEntry({ state: 'DOOR_OPENED', color: D.name, source: 'question', question: q.i + 1, doors: n });
            body.innerHTML = '🔓';
            const c = document.createElement('canvas'); c.width = c.height = 64; Explorer3D.door(c.getContext('2d'), D.color); body.append(c);
            this.flash(1600);
            return;
        }
        if (!E.held.has(r.color)) {
            E.held.add(r.color);
            this.onKey({ color: r.color, x: q.x, y: q.y }, 'question');
        }
        body.innerHTML = '✔';
        body.append(Explorer3D.keyIcon(D.color, 128));
        this.flash(1500);
    }

    onExit() {
        const E = this.engine;
        const missing = E.items.filter((it) => it.target !== false && !it.got);
        const openQ = E.questions.filter((q) => !q.done);
        if (E.L.needAll && (missing.length || openQ.length)) {
            this.pushLogEntry({ state: 'EXIT_BLOCKED', missingItems: missing.length, openQuestions: openQ.length });
            const body = document.getElementById('msgbody');
            body.innerHTML = '🔒';
            missing.forEach((it) => {
                const d = document.createElement('div'); d.className = 'it';
                if (it.img) { const im = document.createElement('img'); im.src = it.img; d.append(im); } else d.textContent = it.name || '•';
                body.append(d);
            });
            openQ.forEach(() => { const d = document.createElement('div'); d.className = 'q'; d.textContent = '?'; body.append(d); });
            this.flash(2200);
            return;
        }
        this.finish('exit');
    }

    finish(reason) {
        if (this.sent || !this.engine) return;
        const E = this.engine;
        this.pause(true);
        this.sent = true;
        clearInterval(this.sampler);
        document.getElementById('msgbody').textContent = reason === 'time' ? '⏱' : '🏁';
        this.msg.classList.add('open');
        const targets = E.items.filter((it) => it.target !== false), got = targets.filter((it) => it.got).length;
        const right = new Set(this.answers.filter((a) => a.correct).map((a) => a.q)).size;
        const firstTry = this.answers.filter((a) => a.correct && a.attempt === 1).length;
        this.result = {
            score: got + firstTry,
            maxScore: targets.length + E.questions.length,
            items: got, itemsTotal: targets.length, wrongItems: this.wrongItems,
            answersCorrect: right, answersFirstTry: firstTry, questions: E.questions.length,
            keys: E.held.size, keysFromQuestions: this.answers.filter((x) => x.correct).length ? [...E.held].filter((c) => !E.keys.some((k) => k.got && k.color === c)).length : 0, keysTotal: E.keys.length, doorsOpened: E.doorsOpened, platesPressed: E.plates.filter((p) => p.on).length, platesTotal: E.plates.length, blocksBroken: E.broken, blocksPushed: E.pushed, resets: this.resets || 0, roadSteps: E.roadSteps, crossingSteps: E.crossSteps, carsStopped: E.carStops,
            hints: E.hints.filter((h) => h.got).length, hintsTotal: E.hints.length,
            bumps: E.bumps, distance: this.r(E.dist), cellsVisited: E.visited.size, view: this.mode,
            reason
        };
        this.pushLogEntry(Object.assign({ state: 'FINISHED' }, this.result));
    }

    /* ---------- logging and sending (as in the TMT) ---------- */

    pushLogEntry(entry) {
        entry.positionInTime = this.elapsedSeconds();
        this.log.push(entry);
        if (entry.state === 'FINISHED') setTimeout(() => this.sendResults(), 900);
    }

    sendResults() {
        const data = {
            type: 'NeuroExercises',
            activity: this.activity,
            dataNE: Object.assign({}, this.result, { duration: this.elapsedSeconds(), answers: this.answers, path: this.path, log: this.log })
        };
        if (this.embed) { if (this.opts.onResult) this.opts.onResult(data); return; }
        if (window.vuplex) window.vuplex.postMessage(JSON.stringify(data));
        else console.log('VUPLEX bridge not available', data);
    }

    elapsedSeconds() { return this.t0 ? this.r((performance.now() - this.t0) / 1000) : 0; }
    r(v) { return Number.isFinite(v) ? Math.round(v * 100) / 100 : 0; }
}

if (!window.EX_EMBED) document.addEventListener('DOMContentLoaded', () => { window.explorerPlayer = new ExplorerPlayer(); });
