'use strict';
/**
 * MQ Plugins — languages (the same file in every official plugin).
 * The plugin defines window.MQ_I18N = { en: { 'Texto em português': 'English text', … }, es: {…}, … } (i18n.js),
 * with the Portuguese text as the key. The language comes from:
 *   window.MQ_HOST.lang  — editors inside MQ Creator;
 *   window.MQ_LANG       — players inside MQ Creator;
 *   the device language  — elsewhere (Unity, a browser).
 * MQT('texto', {n: 2}) translates a text (with {n} filled in); the page's text, title, placeholder and aria-label
 * are translated when the page is ready (only the texts that are in the dictionary).
 * MQI18N.watch(root) also translates what the page adds later (for editors that build their interface in code;
 * players should use MQT for their own texts, so that the creator's texts are never changed).
 */
(function (g) {
    const LANGS = ['pt', 'en', 'es', 'ca', 'fr', 'de', 'it'];
    function pick() {
        let l = (g.MQ_HOST && g.MQ_HOST.lang) || g.MQ_LANG || (navigator.languages && navigator.languages[0]) || navigator.language || 'pt';
        l = String(l).slice(0, 2).toLowerCase();
        return LANGS.indexOf(l) >= 0 ? l : 'en';
    }
    const lang = pick();
    const dict = () => (lang !== 'pt' && g.MQ_I18N && g.MQ_I18N[lang]) || null;
    function T(s, a) {
        const d = dict();
        let r = (d && d[s]) || s;
        if (a) r = r.replace(/\{(\w+)\}/g, (m, k) => (a[k] != null ? a[k] : m));
        return r;
    }
    function dom(root) {
        const d = dict();
        if (!d || !root) return;
        const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
        const nodes = [];
        while (w.nextNode()) nodes.push(w.currentNode);
        nodes.forEach((n) => {
            const t = n.nodeValue.trim();
            if (t && d[t] && d[t] !== t) n.nodeValue = n.nodeValue.replace(t, d[t]);
        });
        const els = root.querySelectorAll ? [root, ...root.querySelectorAll('[title],[placeholder],[aria-label]')] : [];
        els.forEach((el) => {
            if (!el.getAttribute) return;
            ['title', 'placeholder', 'aria-label'].forEach((at) => {
                const v = el.getAttribute(at);
                const t = v && d[v.trim()];
                if (t && t !== v) el.setAttribute(at, t);   // only when it changes (no endless loop with watch)
            });
        });
        if (root === document.body && d[document.title]) document.title = d[document.title];
    }
    function watch(root) {
        if (!dict() || !root || !g.MutationObserver) return;
        new MutationObserver((ms) => {
            ms.forEach((m) => {
                if (m.type === 'attributes') { const v = m.target.getAttribute(m.attributeName); const d = dict(); const t = v && d[v.trim()]; if (t && t !== v) m.target.setAttribute(m.attributeName, t); return; }
                m.addedNodes.forEach((n) => {
                    if (n.nodeType === 3) { const t = n.nodeValue.trim(); const d = dict(); if (t && d[t]) n.nodeValue = n.nodeValue.replace(t, d[t]); }
                    else if (n.nodeType === 1) dom(n);
                });
            });
        }).observe(root, { childList: true, subtree: true, attributes: true, attributeFilter: ['title', 'placeholder', 'aria-label'] });
    }
    g.MQT = T;
    g.MQI18N = { lang, T, dom, watch };
    try { document.documentElement.lang = lang; } catch (e) { /* no document yet */ }
    /* <script src="mqi18n.js" data-watch> : also translate what the editor builds later */
    const cs = document.currentScript, W = !!(cs && cs.hasAttribute('data-watch'));
    const start = () => { dom(document.body); if (W) watch(document.body); };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
    else start();
})(window);
