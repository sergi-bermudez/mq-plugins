/*
 * MQ 3D Blocks — game sounds (Web Audio, no files): short effects for what happens in the level, and sounds that
 * come from somewhere (cars, people walking, a model's own sound) heard louder near and softer far, and from the left
 * or the right side according to where the person is looking.
 */
(function (global) {
    'use strict';
    const RANGE = 14;                       // further than this (cells): silent

    class MQSfx {
        constructor() {
            this.on = true;
            this.ctx = null;
            this.loops = new Map();          // key -> { gain, pan, stop() }
            const unlock = () => this.ensure();
            ['pointerdown', 'keydown', 'touchstart'].forEach((t) => addEventListener(t, unlock, { capture: true, passive: true }));
        }
        ensure() {
            if (!this.on) return null;
            if (!this.ctx) {
                const C = global.AudioContext || global.webkitAudioContext;
                if (!C) return null;
                try { this.ctx = new C(); } catch (e) { return null; }
                this.master = this.ctx.createGain(); this.master.gain.value = 0.85;
                this.master.connect(this.ctx.destination);
            }
            if (this.ctx.state === 'suspended') { try { this.ctx.resume(); } catch (e) { /* nothing */ } }
            return this.ctx;
        }
        /** how loud (0..1) and from which side (-1 left .. 1 right) a sound at (x, y) is heard by the person */
        hear(E, x, y, k) {
            if (!E || x == null) return { g: 1, p: 0 };
            const dx = x - E.px, dy = y - E.py, d = Math.hypot(dx, dy);
            if (d > RANGE) return { g: 0, p: 0 };
            const g = Math.min(1, 1 / (1 + (k || 0.3) * d * d)) * (d > RANGE - 3 ? (RANGE - d) / 3 : 1);
            const rel = Math.atan2(dy, dx) - E.pa;
            return { g, p: d < 0.3 ? 0 : Math.max(-1, Math.min(1, Math.sin(rel))) };
        }
        /** the end of a chain: gain (distance) and pan (side), into the master */
        out(vol, x, y, E) {
            const c = this.ctx, h = this.hear(E, x, y), g = c.createGain();
            g.gain.value = vol * h.g;
            if (c.createStereoPanner) { const p = c.createStereoPanner(); p.pan.value = h.p; g.connect(p); p.connect(this.master); }
            else g.connect(this.master);
            return h.g > 0.002 ? g : null;
        }
        tone(dest, f, t0, dur, type, vol, f2) {
            const c = this.ctx, o = c.createOscillator(), g = c.createGain();
            o.type = type || 'sine'; o.frequency.setValueAtTime(f, t0);
            if (f2) o.frequency.exponentialRampToValueAtTime(f2, t0 + dur);
            g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(vol, t0 + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
            o.connect(g); g.connect(dest); o.start(t0); o.stop(t0 + dur + 0.05);
        }
        noise(dest, t0, dur, vol, freq, type) {
            const c = this.ctx, n = Math.max(1, Math.floor(c.sampleRate * dur)), buf = c.createBuffer(1, n, c.sampleRate), d = buf.getChannelData(0);
            for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
            const s = c.createBufferSource(); s.buffer = buf;
            const f = c.createBiquadFilter(); f.type = type || 'lowpass'; f.frequency.value = freq || 800;
            const g = c.createGain(); g.gain.value = vol;
            s.connect(f); f.connect(g); g.connect(dest); s.start(t0);
        }
        /** a short sound; with (x, y) it comes from there (louder near, from the side it is on) */
        play(name, x, y, E) {
            if (!this.on || !this.ensure()) return;
            const vol = { step: 0.35, bump: 0.5, foot: 0.22 }[name] || 0.6;
            const o = this.out(vol, x == null ? null : x, y, x == null ? null : E);
            if (!o) return;
            const t = this.ctx.currentTime;
            switch (name) {
            case 'item': this.tone(o, 660, t, 0.12, 'triangle', 0.5); this.tone(o, 990, t + 0.09, 0.22, 'triangle', 0.45); break;
            case 'wrong': this.tone(o, 220, t, 0.28, 'square', 0.18, 150); break;
            case 'key': this.tone(o, 1320, t, 0.08, 'sine', 0.4); this.tone(o, 1760, t + 0.07, 0.1, 'sine', 0.35); this.noise(o, t, 0.12, 0.25, 6000, 'highpass'); break;
            case 'door': this.noise(o, t, 0.45, 0.35, 500); this.tone(o, 180, t, 0.5, 'sawtooth', 0.08, 120); break;
            case 'locked': this.tone(o, 140, t, 0.12, 'square', 0.22); this.tone(o, 140, t + 0.16, 0.12, 'square', 0.22); break;
            case 'push': this.noise(o, t, 0.28, 0.7, 260); this.tone(o, 90, t, 0.2, 'sine', 0.4, 60); break;
            case 'break': this.noise(o, t, 0.5, 0.9, 2400, 'bandpass'); this.noise(o, t + 0.05, 0.35, 0.6, 700); break;
            case 'plate': this.tone(o, 300, t, 0.06, 'square', 0.25); [523, 659, 784].forEach((f, i) => this.tone(o, f, t + 0.08 + i * 0.08, 0.3, 'triangle', 0.3)); break;
            case 'horn': this.tone(o, 392, t, 0.35, 'sawtooth', 0.16); this.tone(o, 494, t, 0.35, 'sawtooth', 0.12); break;
            case 'bump': this.noise(o, t, 0.12, 0.5, 300); break;
            case 'step': this.tone(o, 200, t, 0.08, 'sine', 0.4, 280); break;
            case 'foot': this.noise(o, t, 0.06, 0.7, 1400); break;
            case 'hint': this.tone(o, 880, t, 0.15, 'sine', 0.35); this.tone(o, 1175, t + 0.12, 0.25, 'sine', 0.3); break;
            case 'question': this.tone(o, 587, t, 0.12, 'triangle', 0.35); this.tone(o, 784, t + 0.1, 0.18, 'triangle', 0.35); break;
            case 'exit': [523, 659, 784, 1047].forEach((f, i) => this.tone(o, f, t + i * 0.12, 0.35, 'triangle', 0.4)); break;
            default: this.tone(o, 600, t, 0.1, 'sine', 0.3);
            }
        }
        /** every frame: the sounds that keep going (cars, people walking, models with their own sound) follow the distance */
        update(E) {
            if (!E || !this.on) return;
            const c = this.ensure();
            const now = performance.now() / 1000, seen = new Set();
            for (const car of E.cars || []) {
                const m = car.m, key = 'm' + m.i;
                if (car.walk) {                 /* passos: um toque de cada vez, mais forte perto */
                    if (car.n && !car.pause && now - (car.footT || 0) > 0.42) { car.footT = now; if (c) this.play('foot', m.fx, m.fy, E); }
                    continue;
                }
                if (!c) continue;
                seen.add(key);
                let L = this.loops.get(key);
                if (!L) L = this.engineLoop(key);
                const h = this.hear(E, m.fx, m.fy, 0.18);
                L.gain.gain.setTargetAtTime(0.16 * h.g, c.currentTime, 0.08);
                if (L.pan) L.pan.pan.setTargetAtTime(h.p, c.currentTime, 0.08);
                L.osc.frequency.setTargetAtTime(car.wait || !car.n ? 38 : 58, c.currentTime, 0.3);
            }
            for (const m of E.models || []) {
                if (!m.sound) continue;
                const key = 's' + m.i;
                seen.add(key);
                let L = this.loops.get(key);
                if (!L) L = this.mediaLoop(key, m.sound);
                if (!L) continue;
                const x = m.fx != null ? m.fx : m.x + 0.5, y = m.fy != null ? m.fy : m.y + 0.5, h = this.hear(E, x, y, 0.12);
                if (L.gain && c) { L.gain.gain.setTargetAtTime(0.9 * h.g, c.currentTime, 0.1); if (L.pan) L.pan.pan.setTargetAtTime(h.p, c.currentTime, 0.1); }
                else if (L.el) L.el.volume = Math.max(0, Math.min(1, h.g));
            }
            for (const [k, L] of this.loops) if (!seen.has(k)) { L.stop(); this.loops.delete(k); }
        }
        engineLoop(key) {
            const c = this.ctx, osc = c.createOscillator(), o2 = c.createOscillator(), f = c.createBiquadFilter(), gain = c.createGain();
            osc.type = 'sawtooth'; osc.frequency.value = 50; o2.type = 'square'; o2.frequency.value = 25;
            const g2 = c.createGain(); g2.gain.value = 0.4; o2.connect(g2); g2.connect(f);
            f.type = 'lowpass'; f.frequency.value = 260; gain.gain.value = 0;
            osc.connect(f); f.connect(gain);
            let pan = null;
            if (c.createStereoPanner) { pan = c.createStereoPanner(); gain.connect(pan); pan.connect(this.master); } else gain.connect(this.master);
            osc.start(); o2.start();
            const L = { osc, gain, pan, stop: () => { try { osc.stop(); o2.stop(); gain.disconnect(); } catch (e) { /* nothing */ } } };
            this.loops.set(key, L);
            return L;
        }
        mediaLoop(key, src) {
            const el = new Audio(src);
            el.loop = true; el.crossOrigin = 'anonymous';
            let L = { el, stop: () => { try { el.pause(); el.src = ''; } catch (e) { /* nothing */ } } };
            const c = this.ctx;
            if (c && c.createMediaElementSource) {
                try {
                    const s = c.createMediaElementSource(el), gain = c.createGain();
                    gain.gain.value = 0; s.connect(gain);
                    let pan = null;
                    if (c.createStereoPanner) { pan = c.createStereoPanner(); gain.connect(pan); pan.connect(this.master); } else gain.connect(this.master);
                    L = Object.assign(L, { gain, pan });
                } catch (e) { el.volume = 0; }
            } else el.volume = 0;
            const p = el.play(); if (p && p.catch) p.catch(() => {});
            this.loops.set(key, L);
            return L;
        }
        stopAll() { for (const L of this.loops.values()) L.stop(); this.loops.clear(); }
    }
    global.MQSfx = MQSfx;
})(window);
