'use strict';
/**
 * Explorador 3D — motor partilhado pelo player e pelo editor (raycaster em grelha, tipo Wolfenstein 3D).
 * Sem fetch(), sem módulos: corre em file:// (Unity) e dentro do MQ Creator. As imagens vêm como data: URLs.
 *
 * Nível (configuração do plugin):
 * {
 *   "w": 12, "h": 9,
 *   "map": ["111111111111", "100000000001", …],   // por casela: 0 chão, 1–6 parede (estilos), a–z parede com imagem (images[...]),
 *                                                   // A–D porta (vermelha, azul, verde, amarela): abre-se com a chave da mesma cor
 *   "images": { "a": "data:image/…" },              // imagens das paredes (cartazes, quadros, fotografias)
 *   "start": { "x": 1, "y": 1, "dir": 0 },         // dir: 0 →, 1 ↓, 2 ←, 3 ↑
 *   "exit": { "x": 10, "y": 7 } | null,
 *   "items": [ { "x": 3, "y": 2, "name": "Maçã", "img": "data:…", "target": true } ],
 *   "questions": [ { "x": 5, "y": 4, "text": "…", "img": "data:…"|"", "options": [ { "text": "…", "correct": true } ],
 *                    "reward": { "type": "key"|"open", "color": "A" } } ],   // ao acertar: dá a chave ou abre as portas dessa cor
 *   "keys": [ { "x": 2, "y": 6, "color": "A" } ],                       // chave da porta A (vermelha)…
 *   map: S = bloco que se parte (com a picareta, pista "pick"), T = bloco que se empurra (anda uma casela)
 *   "hints": [ { "x": 4, "y": 4, "type": "note"|"compass"|"map"|"pick", "text": "…", "img": "" } ],  // pistas para encontrar a saída
 *   "assets": { "vaca": { "name": "Vaca", "glb": "data:model/gltf-binary;base64,…", "views": ["data:image/png…" ×8], "anims": ["Idle", …], "h": 1.5 } },
 *   "models": [ { "x": 6, "y": 2, "asset": "vaca", "rot": 90, "size": 0.8, "anim": "Idle", "solid": true } ],
 *                // modelos 3D (da biblioteca do MQ Creator): em 3D o próprio modelo, com animação; em 2D as 8 vistas
 *   "view": "3d" | "2d",      // maneira de ver o nível: 3D (WebGL; sem WebGL passa a 2D) ou 2D (leve)
 *   items[].asset: um objeto também pode ser um modelo 3D
 *   "floor": "#c9b99a", "ceiling": "#dfe9f2",
 *   "sky": true,              // céu aberto (sem teto): "ceiling" é a cor do céu
 *   "avatars": ["robot"], "camera": "3rd", // personagens (modelos de "assets") e câmara inicial: "1st" ou "3rd" pessoa
 *   "ground": { "3,4": "a" },    // chão de cada casela: a asfalto, z passadeira, p passeio, g relva, d terra, s areia
 *   "stack": { "4,2": "HHJ" }, // blocos empilhados por cima da casela (4,2): níveis 1, 2, 3 (cor, estilo ou imagem)
 *   "needAll": true,          // a saída só abre com todos os objetos certos recolhidos
 *   "minimap": true, "speed": 1, "timeLimit": 0
 * }
 */
(function (global) {
    const TEX = 64;

    /* estilos de parede desenhados à mão (sem ficheiros) */
    const STYLES = {
        1: { name: 'Tijolo', base: '#b5583c', draw: (g) => bricks(g, '#b5583c', '#8f3f29', '#e8d9c8') },
        2: { name: 'Pedra', base: '#8c9196', draw: (g) => stones(g) },
        3: { name: 'Madeira', base: '#9a6a3c', draw: (g) => planks(g) },
        4: { name: 'Azulejo', base: '#e8f0f6', draw: (g) => tiles(g, '#f3f7fa', '#7aa6c9') },
        5: { name: 'Parede clara', base: '#efe6d2', draw: (g) => plain(g, '#efe6d2', '#e2d6bd') },
        6: { name: 'Sebe', base: '#4f8a3a', draw: (g) => hedge(g) }
    };

    /** the cells a model covers on the floor, from its size (height) and the proportions of its box (a.dims =
        [width, height, depth], height = 1), turned by its direction. Small models cover only their own cell. */
    function footprint(m, a) {
        const own = [[m.x, m.y]];
        const d = a && a.dims;
        if (!d || !(d[1] > 0)) return own;
        if (/tree|palm|árvore|palmeira|arbre/i.test((a.name || '') + ' ' + (m.asset || ''))) return own;     /* uma árvore só ocupa o tronco */
        const size = m.size || 0.8, hx = size * d[0] / d[1] / 2, hz = size * d[2] / d[1] / 2;
        if (hx < 0.6 && hz < 0.6) return own;
        const th = Math.PI / 2 - (m.rot == null ? 90 : m.rot) * Math.PI / 180, c = Math.cos(th), s = Math.sin(th);
        const R = Math.ceil(Math.max(hx, hz)) + 1, out = [];
        for (let y = m.y - R; y <= m.y + R; y++) for (let x = m.x - R; x <= m.x + R; x++) {
            const wx = x - m.x, wz = y - m.y, lx = wx * c - wz * s, lz = wx * s + wz * c;
            if ((Math.abs(lx) < hx + 0.05 && Math.abs(lz) < hz + 0.05) || (x === m.x && y === m.y)) out.push([x, y]);
        }
        return out;
    }
    /** real heights (metres) of the models of MQ Creator's library; the level's scale: a person (1.75 m) = 0.8 */
    const REAL_H = { 'house1': 6.5, 'house-3': 7.5, 'tree-big': 7, 'palm-short': 4, 'ambulance': 2.7, 'firetruck': 3.1, 'police-car': 1.5,
        'taxi': 1.5, 'van': 2.1, 'tractor': 2.7, 'boat-small': 1.2, 'robot': 1.6, 'male': 1.5, 'cama': 0.6, 'cadeira': 0.9, 'secretaria': 0.76,
        'sofa': 0.85, 'mesa': 0.76, 'armario': 2, 'chest': 0.6 };
    const CAT_H = { people: 1.75, animals: 1.3, food: 0.15, home: 0.9, transport: 1.6, places: 6 };
    const M_PER_UNIT = 1.75 / 0.8;
    function realSize(id, cat) {
        const base = String(id || '').replace(/^.*[:/]/, '');
        const h = REAL_H[base] || CAT_H[cat] || 1.6;
        return Math.round(h / M_PER_UNIT * 100) / 100;
    }

    /* o chão de cada casela, para fazer ruas e jardins: a = asfalto, z = passadeira, p = passeio, g = relva, d = terra, s = areia */
    const GROUND = {
        a: { name: 'Asfalto', color: '#4b5058' }, z: { name: 'Passadeira', color: '#4b5058' }, p: { name: 'Passeio', color: '#c9c5bb' },
        g: { name: 'Relva', color: '#78b54e' }, d: { name: 'Terra', color: '#b68b58' }, s: { name: 'Areia', color: '#e4d29c' }
    };
    const ROAD = (c) => c === 'a' || c === 'z';
    /** draws the ground of the whole level (cs pixels per cell), as vectors: roads with their lines, zebra crossings,
        sidewalk tiles, grass; cells without ground get the level's floor colour */
    function drawGroundMap(g, L, cs, ox, oy) {
        ox = ox || 0; oy = oy || 0;
        const G = L.ground || {}, at = (x, y) => G[x + ',' + y] || '';
        g.fillStyle = L.floor; g.fillRect(ox, oy, L.w * cs, L.h * cs);
        const later = [];       /* as linhas do meio da estrada desenham-se no fim, por cima das caselas vizinhas */
        for (let y = 0; y < L.h; y++) for (let x = 0; x < L.w; x++) {
            const c = at(x, y), X = ox + x * cs, Y = oy + y * cs;
            if (!c) {
                g.strokeStyle = 'rgba(0,0,0,.10)'; g.lineWidth = Math.max(1, cs / 32); g.strokeRect(X + cs / 64, Y + cs / 64, cs - cs / 32, cs - cs / 32);
                continue;
            }
            g.fillStyle = GROUND[c].color; g.fillRect(X, Y, cs + 0.5, cs + 0.5);
            if (c === 'p') {
                g.strokeStyle = 'rgba(0,0,0,.13)'; g.lineWidth = Math.max(1, cs / 40);
                g.beginPath(); g.moveTo(X + cs / 2, Y); g.lineTo(X + cs / 2, Y + cs); g.moveTo(X, Y + cs / 2); g.lineTo(X + cs, Y + cs / 2); g.stroke();
                g.strokeStyle = 'rgba(255,255,255,.35)'; g.strokeRect(X + 1, Y + 1, cs - 2, cs - 2);
            } else if (c === 'g') {
                g.strokeStyle = 'rgba(40,90,30,.28)'; g.lineWidth = Math.max(1, cs / 32); g.lineCap = 'round';
                let s = x * 31 + y * 17;
                const r = () => ((s = (s * 9301 + 49297) % 233280) / 233280);
                for (let i = 0; i < 7; i++) { const a = X + r() * cs, b = Y + r() * cs; g.beginPath(); g.moveTo(a, b); g.lineTo(a + cs * 0.04, b - cs * 0.12); g.stroke(); }
            } else if (c === 'z') {
                const horiz = ROAD(at(x - 1, y)) && !ROAD(at(x, y - 1)) || ROAD(at(x + 1, y)) && at(x + 1, y) === 'a';
                g.fillStyle = '#f4f4ef';
                for (let i = 0; i < 4; i++) {
                    const t = (i + 0.15) * cs / 4, w = cs / 4 * 0.6;
                    if (horiz) g.fillRect(X + cs * 0.08, Y + t, cs * 0.84, w); else g.fillRect(X + t, Y + cs * 0.08, w, cs * 0.84);
                }
            }
            if (c === 'a') {
                /* linha a tracejado ao meio de uma estrada com duas caselas de largura */
                g.fillStyle = '#f2f0e6';
                const dash = (x0, y0, x1, y1) => {
                    const n = 2, len = Math.hypot(x1 - x0, y1 - y0);
                    for (let i = 0; i < n; i++) {
                        const t0 = (i + 0.2) / n, t1 = (i + 0.7) / n, w = Math.max(2, cs / 22);
                        const ax = x0 + (x1 - x0) * t0, ay = y0 + (y1 - y0) * t0, bx = x0 + (x1 - x0) * t1, by = y0 + (y1 - y0) * t1;
                        if (len && x0 === x1) later.push([ax - w / 2, ay, w, by - ay]); else later.push([ax, ay - w / 2, bx - ax, w]);
                    }
                };
                if (at(x + 1, y) === 'a' && !ROAD(at(x - 1, y)) && !ROAD(at(x + 2, y)) && (ROAD(at(x, y - 1)) || ROAD(at(x, y + 1)))) dash(X + cs, Y, X + cs, Y + cs);
                if (at(x, y + 1) === 'a' && !ROAD(at(x, y - 1)) && !ROAD(at(x, y + 2)) && (ROAD(at(x - 1, y)) || ROAD(at(x + 1, y)))) dash(X, Y + cs, X + cs, Y + cs);
                /* lancil: onde o asfalto encontra um passeio */
                g.fillStyle = 'rgba(255,255,255,.55)';
                const k = Math.max(1.5, cs / 28);
                if (at(x - 1, y) === 'p') g.fillRect(X, Y, k, cs);
                if (at(x + 1, y) === 'p') g.fillRect(X + cs - k, Y, k, cs);
                if (at(x, y - 1) === 'p') g.fillRect(X, Y, cs, k);
                if (at(x, y + 1) === 'p') g.fillRect(X, Y + cs - k, cs, k);
            }
        }
        g.fillStyle = '#f2f0e6';
        later.forEach((r) => g.fillRect(r[0], r[1], r[2], r[3]));
    }

    /* blocos especiais, com aspeto próprio: S parte-se com a picareta (⛏), T empurra-se ao andar contra ele */
    const SPECIAL = {
        S: { name: 'Parte-se', base: '#cdb48a', draw: (g) => cracked(g) },
        T: { name: 'Empurra-se', base: '#e0a43a', draw: (g) => crate(g) }
    };
    function cracked(g) {
        g.fillStyle = '#cdb48a'; g.fillRect(0, 0, 64, 64);
        g.fillStyle = '#e2cfa8'; g.fillRect(3, 3, 58, 4); g.fillRect(3, 3, 4, 58);
        g.fillStyle = '#a88d60'; g.fillRect(3, 57, 58, 4); g.fillRect(57, 3, 4, 58);
        g.strokeStyle = '#4e3b22'; g.lineWidth = 2.4; g.lineCap = 'round'; g.lineJoin = 'round';
        g.beginPath(); g.moveTo(8, 12); g.lineTo(20, 22); g.lineTo(18, 32); g.lineTo(31, 38); g.lineTo(35, 52); g.lineTo(44, 58); g.stroke();
        g.beginPath(); g.moveTo(31, 38); g.lineTo(46, 30); g.lineTo(55, 34); g.stroke();
        g.beginPath(); g.moveTo(20, 22); g.lineTo(30, 14); g.lineTo(36, 6); g.stroke();
        g.beginPath(); g.moveTo(18, 32); g.lineTo(9, 42); g.stroke();
        g.strokeStyle = '#3a2a16'; g.lineWidth = 1.4; g.strokeRect(1, 1, 62, 62);
    }
    function crate(g) {
        g.fillStyle = '#e0a43a'; g.fillRect(0, 0, 64, 64);
        g.fillStyle = '#b67722'; g.fillRect(0, 0, 64, 8); g.fillRect(0, 56, 64, 8); g.fillRect(0, 0, 8, 64); g.fillRect(56, 0, 8, 64);
        g.strokeStyle = '#b67722'; g.lineWidth = 6; g.beginPath(); g.moveTo(8, 8); g.lineTo(56, 56); g.stroke();
        g.fillStyle = '#fff'; g.strokeStyle = '#7a4c12'; g.lineWidth = 1.5;
        const arrow = (ang) => {
            g.save(); g.translate(32, 32); g.rotate(ang);
            g.beginPath(); g.moveTo(10, -5); g.lineTo(20, 0); g.lineTo(10, 5); g.closePath(); g.fill(); g.stroke();
            g.restore();
        };
        [0, Math.PI / 2, Math.PI, -Math.PI / 2].forEach(arrow);
        g.strokeStyle = '#5c3a0e'; g.lineWidth = 1.4; g.strokeRect(1, 1, 62, 62);
    }
    /* blocos de cor (estilo «Minecraft», mas lisos e nítidos): desenhados como vetores, a qualquer resolução */
    const BLOCKS = {
        E: { name: 'Branco', color: '#f2f1ec' }, F: { name: 'Cinzento', color: '#9aa3ab' }, G: { name: 'Preto', color: '#3a3f45' },
        H: { name: 'Vermelho', color: '#e0524a' }, I: { name: 'Laranja', color: '#f08c32' }, J: { name: 'Amarelo', color: '#f4c430' },
        K: { name: 'Lima', color: '#8ccf4a' }, L: { name: 'Verde', color: '#3f9a4a' }, M: { name: 'Ciano', color: '#36b5c4' },
        N: { name: 'Azul', color: '#3d6fd6' }, O: { name: 'Roxo', color: '#8a5cd0' }, P: { name: 'Rosa', color: '#ee7fb6' },
        Q: { name: 'Castanho', color: '#9a6a3c' }, R: { name: 'Areia', color: '#e3cf98' }
    };
    function shade(hex, k) {
        const n = parseInt(hex.slice(1), 16), f = (v) => Math.max(0, Math.min(255, Math.round(k > 0 ? v + (255 - v) * k : v * (1 + k))));
        return '#' + [n >> 16, (n >> 8) & 255, n & 255].map((v) => f(v).toString(16).padStart(2, '0')).join('');
    }
    /** a colour block face as a vector drawing on a canvas of size S: flat colour, a soft bevel and a fine outline */
    function blockFace(color, S, SH) {
        const W = S, H = SH || S, c = canvas(W, H), g = c.getContext('2d'), k = S / 64;
        g.fillStyle = color; g.fillRect(0, 0, W, H);
        g.lineJoin = 'round';
        g.fillStyle = shade(color, 0.22);
        g.beginPath(); g.moveTo(0, 0); g.lineTo(W, 0); g.lineTo(W - 5 * k, 5 * k); g.lineTo(5 * k, 5 * k); g.lineTo(5 * k, H - 5 * k); g.lineTo(0, H); g.closePath(); g.fill();
        g.fillStyle = shade(color, -0.18);
        g.beginPath(); g.moveTo(W, H); g.lineTo(0, H); g.lineTo(5 * k, H - 5 * k); g.lineTo(W - 5 * k, H - 5 * k); g.lineTo(W - 5 * k, 5 * k); g.lineTo(W, 0); g.closePath(); g.fill();
        g.strokeStyle = shade(color, -0.42); g.lineWidth = 1.6 * k; g.strokeRect(0.8 * k, 0.8 * k, W - 1.6 * k, H - 1.6 * k);
        return c;
    }
    /** texture of any block (style, colour, door) at size S — drawn bigger, so nothing looks pixelated */
    function blockTexture(ch, S) {
        if (BLOCKS[ch]) return blockFace(BLOCKS[ch].color, S);
        const c = canvas(S, S), g = c.getContext('2d');
        g.scale(S / TEX, S / TEX);
        if (DOORS[ch]) door(g, DOORS[ch].color);
        else if (STYLES[ch]) STYLES[ch].draw(g);
        else if (SPECIAL[ch]) SPECIAL[ch].draw(g);
        else return null;
        return c;
    }
    const MAX_STACK = 8;
    /** the blocks of a cell, bottom to top, in half-wall units ("slots"): a colour block is half a wall (1 slot),
        a wall, door or picture is a whole wall (2 slots). A stack over a free cell starts at wall height (a bridge). */
    function columnBlocks(ground, stack) {
        const out = [];
        let s = 0;
        /* os blocos de cor têm meia parede; o que se parte 💥 e a caixa 📦 que se empurra são cubos (uma parede inteira),
           como as paredes e as portas — para subir para uma caixa é preciso um bloco de cor ao lado, como degrau */
        const hOf = (ch) => (BLOCKS[ch] ? 1 : 2);
        if (ground && ground !== '0') { const h = hOf(ground); out.push({ ch: ground, b: 0, h, g: true }); s = h; }
        else if (stack) s = 2;
        for (const ch of String(stack || '')) { const h = hOf(ch); out.push({ ch, b: s, h }); s += h; }
        return out;
    }

    /** a que altura (em meias paredes) se está em cima da casela (x, y): 0 no chão; em cima de uma coluna de blocos, o topo dela.
        -1 onde não se pode estar (porta, bloco que se parte ou que se empurra). */
    function standLevel(map, stack, x, y) {
        const c = (map[y] || '')[x] || '1', st = stack && stack[x + ',' + y];
        if (c === '0' && !st) return 0;
        if (DOORS[c] && !st) return -1;
        const col = columnBlocks(c, st), t = col[col.length - 1];
        if (t && SPECIAL[t.ch]) return -1;          /* em cima de uma caixa ou de uma parede que se parte não se põe nada: mudam */
        return t ? t.b + t.h : 0;
    }
    /** as caselas (e a altura) a que se pode chegar a partir do início, a andar e a subir um bloco de cada vez (só em 3D com céu aberto).
        Portas e blocos especiais contam como passagens (abrem-se, partem-se, empurram-se); os modelos sólidos tapam à sua altura. */
    function reachable(L, boost) {
        const W = L.w, H = L.h, st = L.stack || {}, climb = L.view !== '2d' && !!L.sky;
        const pick = (L.hints || []).some((h) => h.type === 'pick');
        /* as portas abrem-se (há chave); as paredes que se partem só contam como passagem se houver picareta; a caixa 📦 conta
           como um degrau (com «boost», sobe-se mais um bloco: a caixa empurrada para junto do degrau) */
        const fill = (x, y, s) => {
            if (x < 0 || y < 0 || x >= W || y >= H || s < 0) return true;
            for (const b of columnBlocks(L.map[y][x], st[x + ',' + y])) {
                if (s < b.b || s >= b.b + b.h) continue;
                if (b.g && DOORS[b.ch]) return false;
                if (b.ch === 'S' && pick) return false;
                return true;
            }
            return false;
        };
        const maxUp = 1 + (boost || 0);
        const solidModel = {};
        (L.models || []).forEach((m) => { if (m.solid !== false && !m.drive) footprint(m, (L.assets || {})[m.asset]).forEach(([x, y]) => { solidModel[x + ',' + y] = standLevel(L.map, st, m.x, m.y); }); });
        const seen = new Set(), s0 = L.start || { x: 1, y: 1 }, q = [[s0.x, s0.y, 0]];
        seen.add(s0.x + ',' + s0.y + ',0');
        while (q.length) {
            const [x, y, h] = q.shift();
            for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
                const nx = x + dx, ny = y + dy;
                let nh = h;
                if (climb) {
                    let top = h;
                    while (top - h <= maxUp && fill(nx, ny, top)) top++;
                    if (top - h > maxUp || fill(nx, ny, top + 1)) continue;          /* alto de mais, ou bate com a cabeça */
                    nh = top;
                    while (nh > 0 && !fill(nx, ny, nh - 1)) nh--;
                } else {
                    const c = (L.map[ny] || '')[nx];
                    if (c !== '0' && !DOORS[c] && !(c === 'S' && pick) && c !== 'T') continue;
                }
                if (solidModel[nx + ',' + ny] === nh) continue;
                const k = nx + ',' + ny + ',' + nh;
                if (seen.has(k)) continue;
                seen.add(k); q.push([nx, ny, nh]);
            }
        }
        return seen;
    }

    /** uma personagem só serve para a 3.ª pessoa se tiver uma animação de andar */
    function walks(a) { return !!(a && a.glb && (a.anims || []).some((n) => /walk|andar|camin|marche|gehen|cammin|run|corr/i.test(n))); }

    /* portas: abrem-se com a chave da mesma cor */
    const DOORS = { A: { name: 'Vermelha', color: '#d64545' }, B: { name: 'Azul', color: '#2a7fdb' }, C: { name: 'Verde', color: '#2fa66a' }, D: { name: 'Amarela', color: '#e8b400' } };
    function door(g, color) {
        g.fillStyle = '#7a5230'; g.fillRect(0, 0, TEX, TEX);
        g.fillStyle = '#8f6038'; g.fillRect(6, 4, 52, 60);
        g.fillStyle = '#6a4526'; g.fillRect(6, 33, 52, 2);
        g.fillStyle = color; g.fillRect(6, 4, 52, 9); g.fillRect(6, 55, 52, 9);
        g.fillStyle = color; g.beginPath(); g.arc(48, 36, 4, 0, 7); g.fill();
        g.fillStyle = '#222'; g.fillRect(47, 38, 2, 5);
    }
    function keyIcon(color, S) {
        const c = canvas(S, S), g = c.getContext('2d'), k = S / 128;
        g.scale(k, k);
        g.strokeStyle = color; g.fillStyle = color; g.lineWidth = 14; g.lineCap = 'round';
        g.beginPath(); g.arc(40, 52, 22, 0, 7); g.stroke();
        g.beginPath(); g.moveTo(60, 52); g.lineTo(112, 52); g.stroke();
        g.beginPath(); g.moveTo(96, 52); g.lineTo(96, 74); g.moveTo(108, 52); g.lineTo(108, 68); g.stroke();
        g.fillStyle = 'rgba(0,0,0,.22)'; g.beginPath(); g.ellipse(64, 122, 30, 4, 0, 0, 7); g.fill();
        return c;
    }
    function badge(emoji, bg, S) {
        const c = canvas(S, S), g = c.getContext('2d');
        g.fillStyle = bg; g.beginPath(); g.arc(S / 2, S * 0.42, S * 0.32, 0, 7); g.fill();
        g.font = Math.round(S * 0.36) + 'px "Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif';
        g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(emoji, S / 2, S * 0.44);
        g.fillStyle = 'rgba(0,0,0,.22)'; g.beginPath(); g.ellipse(S / 2, S * 0.96, S * 0.2, S * 0.03, 0, 0, 7); g.fill();
        return c;
    }

    function canvas(w, h) {
        const c = document.createElement('canvas');
        c.width = w; c.height = h;
        return c;
    }
    function bricks(g, a, b, mortar) {
        g.fillStyle = mortar; g.fillRect(0, 0, TEX, TEX);
        for (let r = 0; r < 8; r++) {
            const off = r % 2 ? 8 : 0;
            for (let c = -1; c < 4; c++) {
                g.fillStyle = (r + c) % 3 ? a : b;
                g.fillRect(c * 16 + off + 1, r * 8 + 1, 14, 6);
            }
        }
    }
    function stones(g) {
        g.fillStyle = '#6f7479'; g.fillRect(0, 0, TEX, TEX);
        const cols = ['#8c9196', '#9aa0a5', '#7f858a', '#a6abaf'];
        let s = 7;
        const rnd = () => ((s = (s * 9301 + 49297) % 233280) / 233280);
        for (let r = 0; r < 4; r++) for (let c = 0; c < 3; c++) {
            g.fillStyle = cols[Math.floor(rnd() * cols.length)];
            g.fillRect(c * 22 + (r % 2) * 10 - 6 + 1, r * 16 + 1, 20, 14);
        }
    }
    function planks(g) {
        for (let i = 0; i < 4; i++) {
            g.fillStyle = i % 2 ? '#9a6a3c' : '#a8774a'; g.fillRect(i * 16, 0, 16, TEX);
            g.fillStyle = '#6e4826'; g.fillRect(i * 16, 0, 1, TEX);
            g.fillStyle = 'rgba(0,0,0,.12)'; g.fillRect(i * 16 + 6, 10 + i * 9, 3, 2);
        }
    }
    function tiles(g, a, line) {
        g.fillStyle = a; g.fillRect(0, 0, TEX, TEX);
        g.fillStyle = line;
        for (let i = 0; i <= TEX; i += 16) { g.fillRect(i, 0, 1, TEX); g.fillRect(0, i, TEX, 1); }
    }
    function plain(g, a, b) {
        g.fillStyle = a; g.fillRect(0, 0, TEX, TEX);
        g.fillStyle = b; g.fillRect(0, TEX - 8, TEX, 8);
    }
    function hedge(g) {
        g.fillStyle = '#3f7330'; g.fillRect(0, 0, TEX, TEX);
        let s = 3;
        const rnd = () => ((s = (s * 9301 + 49297) % 233280) / 233280);
        for (let i = 0; i < 220; i++) {
            g.fillStyle = ['#4f8a3a', '#5fa046', '#36652a'][Math.floor(rnd() * 3)];
            g.fillRect(Math.floor(rnd() * TEX), Math.floor(rnd() * TEX), 3, 3);
        }
    }

    function loadImage(src) {
        return new Promise((resolve) => {
            if (!src) { resolve(null); return; }
            const img = new Image();
            img.onload = () => resolve(img);
            img.onerror = () => resolve(null);
            img.src = src;
        });
    }

    /* textura de uma parede com imagem: a imagem num quadro, sobre parede clara */
    function framed(img) {
        const S = 256, c = canvas(S, S), g = c.getContext('2d');
        g.fillStyle = '#efe6d2'; g.fillRect(0, 0, S, S);
        if (img) {
            const m = 22, k = Math.min((S - 2 * m) / img.naturalWidth, (S - 2 * m) / img.naturalHeight);
            const w = img.naturalWidth * k, h = img.naturalHeight * k, x = (S - w) / 2, y = (S - h) / 2;
            g.fillStyle = '#6e4826'; g.fillRect(x - 8, y - 8, w + 16, h + 16);
            g.drawImage(img, x, y, w, h);
        }
        return c;
    }

    function normalize(cfg) {
        const L = Object.assign({ w: 12, h: 9, map: [], images: {}, start: { x: 1, y: 1, dir: 0 }, exit: null, items: [], questions: [],
            floor: '#c9b99a', ceiling: '#dfe9f2', needAll: true, minimap: true, speed: 1, timeLimit: 0, keys: [], hints: [], plates: [], assets: {}, models: [], view: '3d',
            stack: {}, sky: false }, cfg || {});
        L.w = Math.max(4, Math.min(64, Math.round(L.w)));
        L.h = Math.max(4, Math.min(64, Math.round(L.h)));
        const rows = [];
        for (let y = 0; y < L.h; y++) {
            let r = String(L.map[y] || '');
            r = (r + '0'.repeat(L.w)).slice(0, L.w);
            if (y === 0 || y === L.h - 1) r = r.replace(/0/g, '1');
            r = (r[0] === '0' ? '1' : r[0]) + r.slice(1, -1) + (r[L.w - 1] === '0' ? '1' : r[L.w - 1]);
            rows.push(r);
        }
        L.map = rows;
        L.items = (L.items || []).filter((i) => i && i.x > 0 && i.y > 0 && i.x < L.w - 1 && i.y < L.h - 1);
        L.questions = (L.questions || []).filter((q) => q && q.x > 0 && q.y > 0 && q.x < L.w - 1 && q.y < L.h - 1);
        const inner = (e) => e && e.x > 0 && e.y > 0 && e.x < L.w - 1 && e.y < L.h - 1;
        L.keys = (L.keys || []).filter((k) => inner(k) && DOORS[k.color]);
        L.hints = (L.hints || []).filter((h) => inner(h) && /^(note|compass|map|pick)$/.test(h.type || 'note'));
        L.plates = (L.plates || []).filter((p) => inner(p) && DOORS[p.color]);
        L.assets = L.assets && typeof L.assets === 'object' ? L.assets : {};
        L.models = (L.models || []).filter((m) => inner(m) && L.assets[m.asset]);
        /* blocos empilhados: "x,y" -> os blocos por cima da casela, de baixo para cima (nível 1, 2, …) */
        const okBlock = (ch) => !!(STYLES[ch] || BLOCKS[ch] || SPECIAL[ch] || L.images[ch]);
        const st = {};
        for (const [k, v] of Object.entries(L.stack && typeof L.stack === 'object' ? L.stack : {})) {
            const m = /^(\d+),(\d+)$/.exec(k);
            if (!m || +m[1] >= L.w || +m[2] >= L.h) continue;
            const s = String(v || '').split('').filter(okBlock).join('').slice(0, MAX_STACK);
            if (s) st[+m[1] + ',' + (+m[2])] = s;
        }
        L.stack = st;
        L.sky = !!L.sky;
        L.view = '3d';                  /* a vista 2D deixou de ser uma opção (só fica como recurso, se o aparelho não tiver WebGL) */
        const gr = {};
        for (const [k, v] of Object.entries(L.ground && typeof L.ground === 'object' ? L.ground : {})) {
            const m = /^(\d+),(\d+)$/.exec(k);
            if (m && +m[1] < L.w && +m[2] < L.h && GROUND[v]) gr[+m[1] + ',' + (+m[2])] = v;
        }
        L.ground = gr;
        /* personagens que se podem escolher para jogar (modelos 3D do nível) e a câmara inicial */
        L.avatars = (Array.isArray(L.avatars) ? L.avatars : []).filter((id) => L.assets[id] && L.assets[id].glb).slice(0, 6);
        L.camera = L.camera === '3rd' ? '3rd' : '1st';
        return L;
    }

    class Engine {
        constructor(canvasEl, cfg, hooks) {
            this.cv = canvasEl;
            this.g = canvasEl.getContext('2d');
            this.L = normalize(cfg);
            this.hooks = hooks || {};
            this.input = { fwd: 0, turn: 0 };
            this.anim = null;               // passo animado (botões tocados): { kind, left, rate }
            this.running = false;
            this.bumps = 0;
            this.dist = 0;
            this.zbuf = [];
            this.textures = {};
            this.sprites = [];
            this.visited = new Set();
            this.held = new Set();          // chaves que a pessoa tem
            this.doorsOpened = 0;
            this.compass = false;
        }

        async load() {
            for (const k of [...Object.keys(STYLES), ...Object.keys(BLOCKS), ...Object.keys(SPECIAL)]) this.textures[k] = blockTexture(k, 256);
            for (const [k, src] of Object.entries(this.L.images || {})) this.textures[k] = framed(await loadImage(src));
            for (const [k, d] of Object.entries(DOORS)) { this.textures[k] = blockTexture(k, 256); this.keyImgs = this.keyImgs || {}; this.keyImgs[k] = keyIcon(d.color, 128); }
            this.hintImgs = { note: badge('📜', '#f3e3b5', 128), compass: badge('🧭', '#d8eef6', 128), map: badge('🗺️', '#e3f1d9', 128), pick: badge('⛏️', '#f0dcc0', 128) };
            /* um objeto sem imagem mas com um emoji no nome (ex.: os recados da cidade) mostra o emoji */
            const emo = (t) => {
                const S = 128, c = canvas(S, S), g = c.getContext('2d');
                g.font = Math.round(S * 0.7) + 'px "Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif';
                g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(t, S / 2, S * 0.5);
                return c;
            };
            this.itemImgs = await Promise.all(this.L.items.map((i) => i.img ? loadImage(i.img) : (i.name && [...i.name].length <= 2 ? emo(i.name) : null)));
            this.assetViews = {};
            for (const [id, a] of Object.entries(this.L.assets)) this.assetViews[id] = await Promise.all((a.views || []).map(loadImage));
            this.flag = this.makeFlag();
            this.qmark = this.makeQuestionMark();
            this.reset();
        }

        reset() {
            const s = this.L.start || { x: 1, y: 1, dir: 0 };
            this.px = s.x + 0.5;
            this.py = s.y + 0.5;
            this.pa = [0, Math.PI / 2, Math.PI, -Math.PI / 2][((s.dir || 0) % 4 + 4) % 4];
            this.items = this.L.items.map((it, i) => Object.assign({ got: false, i }, it));
            this.questions = this.L.questions.map((q, i) => Object.assign({ done: false, i }, q));
            this.keys = (this.L.keys || []).map((k, i) => Object.assign({ got: false, i }, k));
            this.hints = (this.L.hints || []).map((h, i) => Object.assign({ got: false, i, type: 'note' }, h));
            this.map = this.L.map.slice();      // as portas abertas passam a chão nesta cópia
            this.models = this.L.models.map((m, i) => Object.assign({ i, rot: 90, size: 0.8, solid: true }, m));
            /* em cima de blocos: cada coisa fica à altura do topo da sua coluna (em meias paredes) */
            const lv = (e) => { e.lv = Math.max(0, standLevel(this.L.map, this.L.stack, e.x, e.y)); };
            [this.items, this.questions, this.keys, this.hints, this.models].forEach((a) => a.forEach(lv));
            this.exitLv = this.L.exit ? Math.max(0, standLevel(this.L.map, this.L.stack, this.L.exit.x, this.L.exit.y)) : 0;
            /* plataformas: abrem as portas da sua cor quando se pisam (ou, se pedem um bloco, quando se lhes empurra um 📦 para cima) */
            this.plates = (this.L.plates || []).map((p, i) => Object.assign({ on: false, i }, p));
            this.pitch = 0;
            /* carros que circulam: de casela em casela pelo asfalto (e passadeiras), ao acaso */
            const road = (x, y) => ROAD(this.L.ground[x + ',' + y]);
            /* só circulam carros (pelo asfalto, pela direita) e pessoas (pelo passeio e pelas passadeiras) */
            const side = (x, y) => { const c = this.L.ground[x + ',' + y]; return c === 'p' || c === 'z'; };
            const walkers = this.models.filter((m) => m.walk && !m.drive && side(m.x, m.y)).map((m) => {
                m.fx = m.x + 0.5; m.fy = m.y + 0.5; m.hd = (m.rot == null ? 90 : m.rot) * Math.PI / 180;
                return { m, cx: m.x, cy: m.y, n: null, t: 0, wait: false, walk: true };
            });
            this.cars = this.models.filter((m) => m.drive && road(m.x, m.y)).map((m) => {
                const hd = (m.rot == null ? 90 : m.rot) * Math.PI / 180;
                m.fx = m.x + 0.5; m.fy = m.y + 0.5; m.hd = hd;
                /* virado ao contrário da sua faixa (pela direita): dá a volta */
                const dx = Math.round(Math.cos(hd)), dy = Math.round(Math.sin(hd)), par = (x, y) => road(x, y) && (road(x + dx, y + dy) || road(x - dx, y - dy));
                if (par(m.x - dy, m.y + dx) && !par(m.x + dy, m.y - dx)) { m.hd = hd + Math.PI; m.rot = (m.hd * 180 / Math.PI) % 360; }
                return { m, cx: m.x, cy: m.y, n: null, t: 0, wait: false };
            }).concat(walkers);
            this.traffic = null; this.carStops = 0; this.roadSteps = 0; this.crossSteps = 0;
            this.blocked = new Set(); this.blockedFull = new Set(); this.mlv = {};
            this.models.filter((m) => m.solid !== false && !m.drive && !(m.walk && walkers.some((w) => w.m === m))).forEach((m) => {
                const f = footprint(m, this.L.assets[m.asset]);
                if (f.length > 1) f.forEach(([x, y]) => this.blockedFull.add(x + ',' + y)); else this.blocked.add(m.x + ',' + m.y);
                f.forEach(([x, y]) => { this.mlv[x + ',' + y] = m.lv || 0; });
            });
            this.held = new Set(); this.doorsOpened = 0; this.compass = false; this.mapOn = !!this.L.minimap;
            this.lastCell = null;
            this.ph = 0; this.pz = 0;
            /* blocos que se partem (S) e que se empurram (T): a vista 3D segue-os por esta lista */
            this.dyn = []; this.cols = {};
            for (let y = 0; y < this.L.h; y++) for (let x = 0; x < this.L.w; x++) {
                const k = x + ',' + y, col = [];
                for (const b of columnBlocks(this.L.map[y][x], this.L.stack[k])) {
                    if (SPECIAL[b.ch]) this.dyn.push({ ch: b.ch, x, y, b: b.b, h: b.h, gone: false, g: !!b.g });
                    else col.push(b);
                }
                if (col.length) this.cols[k] = col;
            }
            this.hasPick = false; this.broken = 0; this.pushed = 0;           // altura dos pés (em blocos) e a altura vista, que a acompanha suavemente
        }

        makeFlag() {
            const c = canvas(128, 128), g = c.getContext('2d');
            g.fillStyle = '#5b4a3a'; g.fillRect(58, 14, 8, 112);
            g.fillStyle = '#2fa66a'; g.beginPath(); g.moveTo(66, 16); g.lineTo(118, 34); g.lineTo(66, 54); g.closePath(); g.fill();
            g.fillStyle = 'rgba(0,0,0,.25)'; g.beginPath(); g.ellipse(62, 124, 26, 4, 0, 0, Math.PI * 2); g.fill();
            return c;
        }
        /** a plataforma vista de lado (2D) e de cima (mapa, 3D): um disco da cor das portas que abre; carregada, mais escura */
        plateImg(p) {
            const key = p.color + (p.on ? '1' : '0') + (p.needBox ? 'b' : '');
            this.plateCache = this.plateCache || {};
            if (this.plateCache[key]) return this.plateCache[key];
            const c = canvas(128, 128), g = c.getContext('2d'), col = DOORS[p.color].color;
            g.fillStyle = 'rgba(0,0,0,.25)'; g.beginPath(); g.ellipse(64, 112, 54, 13, 0, 0, 7); g.fill();
            g.fillStyle = shade(col, -0.35); g.beginPath(); g.ellipse(64, 106, 52, 13, 0, 0, 7); g.fill();
            g.fillStyle = p.on ? shade(col, -0.2) : col; g.beginPath(); g.ellipse(64, p.on ? 104 : 98, 46, 11, 0, 0, 7); g.fill();
            if (p.needBox) { g.font = 'bold 22px Arial'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('📦', 64, p.on ? 104 : 98); }
            return (this.plateCache[key] = c);
        }

        makeQuestionMark() {
            const c = canvas(128, 128), g = c.getContext('2d');
            g.fillStyle = '#2080a0'; g.beginPath(); g.arc(64, 54, 40, 0, Math.PI * 2); g.fill();
            g.fillStyle = '#fff'; g.font = 'bold 60px Arial'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('?', 64, 58);
            g.fillStyle = 'rgba(0,0,0,.25)'; g.beginPath(); g.ellipse(64, 124, 22, 4, 0, 0, Math.PI * 2); g.fill();
            return c;
        }

        cell(x, y) {
            if (x < 0 || y < 0 || x >= this.L.w || y >= this.L.h) return '1';
            return (this.map || this.L.map)[y][x];
        }
        isDoor(c) { return !!DOORS[c]; }
        /* subir blocos (como no Minecraft, sem saltar): só em 3D e com céu aberto */
        canClimb() { return !!(this.r3d && this.L.sky); }
        /** há um bloco na casela (cx, cy) à altura «slot» (em meias paredes: 0 = junto ao chão)? */
        filled(cx, cy, slot) {
            if (cx < 0 || cy < 0 || cx >= this.L.w || cy >= this.L.h) return true;
            if (slot < 0) return true;
            const col = this.cols && this.cols[cx + ',' + cy];
            if (!this.cols) { for (const b of columnBlocks(this.cell(cx, cy), this.L.stack[cx + ',' + cy])) if (slot >= b.b && slot < b.b + b.h) return true; return false; }
            if (col) for (const b of col) {
                if (b.g && this.map[cy][cx] !== b.ch) continue;          /* uma porta aberta */
                if (slot >= b.b && slot < b.b + b.h) return true;
            }
            for (const d of this.dyn) if (!d.gone && d.x === cx && d.y === cy && slot >= d.b && slot < d.b + d.h) return true;
            return false;
        }
        solid(x, y) {
            const cx = Math.floor(x), cy = Math.floor(y);
            if (this.canClimb()) {
                if (this.isDoor(this.cell(cx, cy))) return true;            /* uma porta fechada nunca se sobe */
                if (cx === Math.floor(this.px) && cy === Math.floor(this.py)) return false;
                /* a pessoa tem a altura de uma parede (2 meias); livre aí: passa (e cai, se não houver nada por baixo);
                   meia parede (um bloco de cor): sobe-a sozinha; mais do que isso (uma parede, dois blocos): não passa */
                const h = this.ph, f = (s) => this.filled(cx, cy, s);
                const crate = this.dyn.find((o) => !o.gone && o.ch === 'T' && o.x === cx && o.y === cy && o.b === h);
                if (crate) {            /* uma caixa à altura dos pés: se pode andar, empurra-se; se não pode, serve de degrau */
                    const fx = Math.floor(this.px), fy = Math.floor(this.py), sx = Math.abs(x - this.px) >= Math.abs(y - this.py) ? Math.sign(cx - fx) : 0, sy = sx ? 0 : Math.sign(cy - fy);
                    if (this.pushTarget(crate, sx, sy)) return true;
                }
                /* com a picareta, o bloco que se parte à altura dos pés parte-se (em vez de se subir) */
                if (this.hasPick && this.dyn.some((o) => !o.gone && o.ch === 'S' && o.x === cx && o.y === cy && o.b === h)) return true;
                if (f(h) ? (f(h + 1) || f(h + 2)) : f(h + 1)) return true;
                if ((this.mlv[cx + ',' + cy] || 0) !== h) return false;     /* os modelos só tapam à altura a que estão */
            } else if (this.cell(cx, cy) !== '0') return true;
            /* um modelo «sólido» ocupa o centro da sua casela */
            if (this.blockedFull && this.blockedFull.has(cx + ',' + cy)) return true;
            if (this.cars) for (const c of this.cars) if (Math.hypot(x - c.m.fx, y - c.m.fy) < 0.5) return true;   /* um carro é sólido */      /* um modelo grande (casa, carro) ocupa as caselas todas */
            return !!(this.blocked && this.blocked.has(cx + ',' + cy) && Math.hypot(x - cx - 0.5, y - cy - 0.5) < 0.36);
        }
        /* qual das vistas do modelo se vê daqui (vista 0 = de frente; o modelo olha para o ângulo rot) */
        viewOf(views, x, y, rot) {
            if (!views || !views.length) return null;
            const n = views.length, a = Math.atan2(this.py - y, this.px - x) - (rot == null ? 90 : rot) * Math.PI / 180;
            return views[((Math.round(a / (2 * Math.PI / n)) % n) + n) % n];
        }

        start() {
            if (this.running) return;
            this.running = true;
            this.t0 = performance.now();
            let last = performance.now();
            const frame = (now) => {
                if (!this.running) return;
                const dt = Math.min(0.06, (now - last) / 1000);
                last = now;
                this.update(dt);
                this.render();
                requestAnimationFrame(frame);
            };
            requestAnimationFrame(frame);
        }
        stop() { this.running = false; }

        /* passo de uma casela ou volta de 45°, para toques curtos (e o cursor da câmara) */
        step(kind) {
            if (this.anim || this.paused) return;
            if (kind === 'fwd' || kind === 'back') this.anim = { kind, left: 1, rate: 3.2 * this.L.speed };
            else this.anim = { kind, left: Math.PI / 4, rate: 3.4 };
        }

        update(dt) {
            if (this.paused) return;
            const sp = 2.4 * (this.L.speed || 1), rs = 2.1;
            let mv = this.input.fwd * sp * dt, tr = this.input.turn * rs * dt;
            if (this.anim) {
                const a = this.anim, d = Math.min(a.left, a.rate * dt);
                a.left -= d;
                if (a.kind === 'fwd') mv = d; else if (a.kind === 'back') mv = -d;
                else if (a.kind === 'left') tr = -d; else tr = d;
                if (a.left <= 1e-4) this.anim = null;
            }
            if (tr) this.pa += tr;
            if (mv) {
                const nx = this.px + Math.cos(this.pa) * mv, ny = this.py + Math.sin(this.pa) * mv, r = 0.22;
                let moved = false, hit = false;
                if (!this.solid(nx + Math.sign(nx - this.px) * r, this.py)) { this.dist += Math.abs(nx - this.px); this.px = nx; moved = true; } else hit = true;
                if (!this.solid(this.px, ny + Math.sign(ny - this.py) * r)) { this.dist += Math.abs(ny - this.py); this.py = ny; moved = true; } else hit = true;
                if (hit && (this.tryDoor(mv) || this.tryPush(mv) || this.tryBreak(mv))) hit = false;
                if (hit) {
                    if (this.anim && (this.anim.kind === 'fwd' || this.anim.kind === 'back')) this.anim = null;
                    const now = performance.now();
                    if (!this.lastBump || now - this.lastBump > 600) { this.bumps++; this.lastBump = now; if (this.hooks.bump) this.hooks.bump(); }
                }
                if (moved) { this.settle(); this.onMove(); }
            }
            this.pz += (this.ph - this.pz) * Math.min(1, dt * 9);
            if (this.cars && this.cars.length) this.driveCars(dt);
        }

        /** the cars: each one goes to a neighbouring road cell chosen at random (not back, unless it is a dead end),
            never into a cell another car has, and stops while the person is in its way */
        driveCars(dt) {
            const road = (x, y) => ROAD(this.L.ground[x + ',' + y]) && this.cell(x, y) === '0' && !(this.blockedFull && this.blockedFull.has(x + ',' + y));
            const taken = (x, y, me) => this.cars.some((c) => c !== me && ((c.cx === x && c.cy === y) || (c.n && c.n[0] === x && c.n[1] === y)));
            const V = 1.3;
            /* circula-se pela direita: numa estrada de duas faixas vai-se na da direita; só se vira nos cruzamentos ou no fim da estrada */
            const T = this.traffic || (this.traffic = (() => {
                const run = (x, y, dx, dy) => { let n = 0; while (road(x + dx * (n + 1), y + dy * (n + 1))) n++; return n; };
                const cross = (x, y) => road(x, y) && run(x, y, 1, 0) + run(x, y, -1, 0) >= 2 && run(x, y, 0, 1) + run(x, y, 0, -1) >= 2;
                const par = (x, y, dx, dy) => road(x, y) && (road(x + dx, y + dy) || road(x - dx, y - dy));
                /* à direita de quem vai em (dx, dy) — o y cresce para baixo */
                const laneOk = (x, y, dx, dy) => road(x, y) && !par(x - dy, y + dx, dx, dy);
                return { cross, laneOk };
            })());
            const ok = (x, y, dx, dy) => road(x, y) && (T.cross(x, y) || T.laneOk(x, y, dx, dy));
            const side = (x, y) => { const g = this.L.ground[x + ',' + y]; return (g === 'p' || g === 'z') && this.cell(x, y) === '0' && !(this.blockedFull && this.blockedFull.has(x + ',' + y)); };
            const walkerAt = (x, y) => this.cars.some((c) => c.walk && ((c.cx === x && c.cy === y) || (c.n && c.n[0] === x && c.n[1] === y)));
            for (const c of this.cars) {
                const m = c.m;
                if (c.walk) {
                    /* uma pessoa: anda pelo passeio, quase sempre em frente; atravessa a rua só nas passadeiras */
                    if (!c.n) {
                        if (c.pause > 0) { c.pause -= dt; continue; }
                        const d = c.d || [Math.round(Math.cos(m.hd)), Math.round(Math.sin(m.hd))];
                        const opts = [[1, 0], [-1, 0], [0, 1], [0, -1]].filter(([dx, dy]) => side(c.cx + dx, c.cy + dy) && !taken(c.cx + dx, c.cy + dy, c));
                        if (!opts.length) { c.pause = 0.6; continue; }
                        const fwd = opts.find(([dx, dy]) => dx === d[0] && dy === d[1]);
                        const notBack = opts.filter(([dx, dy]) => !(dx === -d[0] && dy === -d[1]));
                        const D = fwd && Math.random() < 0.8 ? fwd : (notBack.length ? notBack : opts)[Math.floor(Math.random() * (notBack.length ? notBack : opts).length)];
                        c.n = [c.cx + D[0], c.cy + D[1]]; c.t = 0; c.d = D;
                        if (Math.random() < 0.05) c.pause = 1 + Math.random() * 2;
                    }
                    const wx = c.n[0] + 0.5, wy = c.n[1] + 0.5;
                    if (Math.hypot(this.px - wx, this.py - wy) < 0.6) continue;               /* a pessoa (quem joga) à frente: espera */
                    c.t = Math.min(1, c.t + 0.55 * dt);
                    const ox = c.cx + 0.5, oy = c.cy + 0.5;
                    m.fx = ox + (wx - ox) * c.t; m.fy = oy + (wy - oy) * c.t;
                    let dd = Math.atan2(wy - oy, wx - ox) - m.hd; dd = Math.atan2(Math.sin(dd), Math.cos(dd));
                    m.hd += dd * Math.min(1, dt * 8); m.rot = m.hd * 180 / Math.PI;
                    if (c.t >= 1) { c.cx = c.n[0]; c.cy = c.n[1]; c.n = null; }
                    continue;
                }
                if (!c.n) {
                    const d = c.d || [Math.round(Math.cos(m.hd)), Math.round(Math.sin(m.hd))];
                    const right = [-d[1], d[0]], left = [d[1], -d[0]], back = [-d[0], -d[1]];
                    const free = ([dx, dy]) => road(c.cx + dx, c.cy + dy) && !this.cars.some((o) => o !== c && !o.walk && ((o.cx === c.cx + dx && o.cy === c.cy + dy) || (o.n && o.n[0] === c.cx + dx && o.n[1] === c.cy + dy)));
                    const good = (D) => free(D) && ok(c.cx + D[0], c.cy + D[1], D[0], D[1]);
                    let D = null;
                    if (T.cross(c.cx, c.cy)) {
                        /* no cruzamento: segue o plano (em frente, direita ou esquerda) escolhido ao entrar */
                        const P = c.plan || d;
                        D = [P, d, right, left].find(good) || null;
                    } else if (good(d)) D = d;                                  /* na estrada: sempre em frente */
                    else {
                        /* fim da estrada ou curva: vira para o lado que houver; senão muda de faixa ou dá a volta */
                        D = [right, left].find(good) || [right, left].find((S) => free(S) && T.laneOk(c.cx + S[0], c.cy + S[1], d[0], d[1])) || [right, left].find(free) || (free(back) ? back : null);
                    }
                    if (!D) continue;
                    const nx0 = c.cx + D[0], ny0 = c.cy + D[1];
                    if (walkerAt(nx0, ny0)) continue;                 /* alguém a atravessar na passadeira: o carro espera */
                    if (T.cross(nx0, ny0) && !T.cross(c.cx, c.cy)) {
                        const r = Math.random();
                        c.plan = r < 0.5 ? D : r < 0.75 ? [-D[1], D[0]] : [D[1], -D[0]];
                    } else if (!T.cross(nx0, ny0)) c.plan = null;
                    c.n = [nx0, ny0]; c.t = 0; c.d = D;
                }
                /* a pessoa à frente (na casela para onde vai, ou entre as duas): espera */
                const nx = c.n[0] + 0.5, ny = c.n[1] + 0.5;
                const ahead = Math.hypot(this.px - nx, this.py - ny) < 0.85 || Math.hypot(this.px - m.fx, this.py - m.fy) < 0.75;
                if (ahead) { if (!c.wait) { c.wait = true; this.carStops++; if (this.hooks.carStop) this.hooks.carStop(m); } continue; }
                c.wait = false;
                c.t = Math.min(1, c.t + V * dt);
                const ox = c.cx + 0.5, oy = c.cy + 0.5;
                m.fx = ox + (nx - ox) * c.t; m.fy = oy + (ny - oy) * c.t;
                const want = Math.atan2(ny - oy, nx - ox);
                let d = want - m.hd; d = Math.atan2(Math.sin(d), Math.cos(d));
                m.hd += d * Math.min(1, dt * 7);
                m.rot = m.hd * 180 / Math.PI;
                if (c.t >= 1) { c.cx = c.n[0]; c.cy = c.n[1]; c.n = null; }
            }
        }

        /** a altura dos pés na casela onde se está: sobe um bloco, ou cai até ao bloco de baixo */
        settle() {
            if (!this.canClimb()) { this.ph = 0; return; }
            const cx = Math.floor(this.px), cy = Math.floor(this.py);
            if (this.filled(cx, cy, this.ph) && !this.filled(cx, cy, this.ph + 1) && !this.filled(cx, cy, this.ph + 2)) this.ph++;
            while (this.ph > 0 && !this.filled(cx, cy, this.ph - 1)) this.ph--;
        }

        /* abre todas as portas de uma cor (recompensa de uma pergunta) */
        openDoors(color) {
            let n = 0;
            this.map = this.map.map((r) => r.replace(new RegExp(color, 'g'), () => { n++; return '0'; }));
            this.doorsOpened += n;
            return n;
        }

        /** the cell just ahead (in the direction of the movement) */
        ahead(mv) {
            const dx = Math.cos(this.pa) * Math.sign(mv), dy = Math.sin(this.pa) * Math.sign(mv);
            return { cx: Math.floor(this.px + dx * 0.6), cy: Math.floor(this.py + dy * 0.6), dx, dy };
        }
        setMap(x, y, c) { const r = this.map[y]; this.map[y] = r.slice(0, x) + c + r.slice(x + 1); }
        /** para onde iria a caixa empurrada na direção (sx, sy) (cai até ao que houver por baixo), ou null se não pode ir */
        pushTarget(d, sx, sy) {
            if (!d || (sx && sy) || (!sx && !sy)) return null;
            const tx = d.x + sx, ty = d.y + sy, k = tx + ',' + ty;
            if (tx <= 0 || ty <= 0 || tx >= this.L.w - 1 || ty >= this.L.h - 1) return null;
            if (this.filled(d.x, d.y, d.b + d.h)) return null;                /* com alguma coisa em cima, não se mexe */
            for (let k = 0; k < d.h; k++) if (this.filled(tx, ty, d.b + k)) return null;
            if (this.isDoor(this.cell(tx, ty))) return null;
            let nb = d.b;
            while (nb > 0 && !this.filled(tx, ty, nb - 1)) nb--;
            const busy = (e) => e.some((o) => o.x === tx && o.y === ty && !o.got && !o.done && (o.lv || 0) === nb);
            if (busy(this.items) || busy(this.questions) || busy(this.keys) || busy(this.hints)) return null;
            if (((this.blocked && this.blocked.has(k)) || (this.blockedFull && this.blockedFull.has(k))) && (this.mlv[k] || 0) === nb) return null;
            if (this.L.exit && this.L.exit.x === tx && this.L.exit.y === ty && this.exitLv === nb) return null;
            if (Math.floor(this.px) === tx && Math.floor(this.py) === ty) return null;
            if (this.cars && this.cars.some((c) => (c.cx === tx && c.cy === ty) || (c.n && c.n[0] === tx && c.n[1] === ty))) return null;
            return { tx, ty, nb };
        }
        /* contra uma caixa que se empurra (à altura dos pés): anda uma casela para onde se está a ir, se lá houver espaço,
           e cai até ao que houver por baixo — serve depois de degrau para chegar mais alto */
        tryPush(mv) {
            const { cx, cy, dx, dy } = this.ahead(mv);
            const d = this.dyn.find((o) => !o.gone && o.ch === 'T' && o.x === cx && o.y === cy && o.b === this.ph);
            if (!d) return false;
            const now = performance.now();
            if (this.pushT && now - this.pushT < 260) return false;          /* um passo de cada vez */
            const sx = Math.abs(dx) >= Math.abs(dy) ? Math.sign(dx) : 0, sy = sx ? 0 : Math.sign(dy);
            const t = this.pushTarget(d, sx, sy);
            if (!t) return false;
            if (d.b === 0 && this.cell(cx, cy) === 'T') this.setMap(cx, cy, '0');
            d.x = t.tx; d.y = t.ty; d.b = t.nb;
            if (d.b === 0 && this.cell(t.tx, t.ty) === '0') this.setMap(t.tx, t.ty, 'T');
            this.pushed++; this.pushT = now;
            if (this.hooks.push) this.hooks.push(cx, cy, t.tx, t.ty);
            if (this.plates.length) this.checkPlates(-1, -1);
            return true;       /* o bloco andou (não conta como chocar); a pessoa entra na casela a seguir */
        }
        /* contra uma parede que se parte (à altura do corpo): com a picareta parte-se; sem ela, avisa (uma vez por encontro) */
        tryBreak(mv) {
            const { cx, cy } = this.ahead(mv);
            const d = this.dyn.filter((o) => !o.gone && o.ch === 'S' && o.x === cx && o.y === cy && o.b + o.h > this.ph && o.b <= this.ph + 1).sort((a, b) => a.b - b.b)[0];
            if (!d) return false;
            const key = cx + ',' + cy, now = performance.now();
            if (!this.hasPick) {
                if (this.noPickAt !== key || now - (this.noPickT || 0) > 2500) { this.noPickAt = key; this.noPickT = now; if (this.hooks.breakBlock) this.hooks.breakBlock(false, cx, cy); }
                return false;
            }
            if (d.b === 0 && this.cell(cx, cy) === 'S') this.setMap(cx, cy, '0');
            d.gone = true; d.goneT = now;
            this.broken++;
            if (this.hooks.breakBlock) this.hooks.breakBlock(true, cx, cy);
            /* o que estava por cima (caixas) cai */
            for (const o of this.dyn) if (!o.gone && o.ch === 'T' && o.x === cx && o.y === cy && o.b > d.b) { while (o.b > 0 && !this.filled(cx, cy, o.b - 1)) o.b--; }
            return true;
        }

        /* encostado a uma porta: abre-se com a chave da cor dela; sem chave avisa (uma vez por encontro) */
        tryDoor(mv) {
            const dx = Math.cos(this.pa) * Math.sign(mv), dy = Math.sin(this.pa) * Math.sign(mv);
            const cx = Math.floor(this.px + dx * 0.6), cy = Math.floor(this.py + dy * 0.6), c = this.cell(cx, cy);
            if (!this.isDoor(c)) return false;
            if (this.held.has(c)) {
                const r = this.map[cy];
                this.map[cy] = r.slice(0, cx) + '0' + r.slice(cx + 1);
                this.doorsOpened++;
                if (this.hooks.door) this.hooks.door(c, true, cx, cy);
                return true;
            }
            const key = cx + ',' + cy, now = performance.now();
            if (this.lockedAt !== key || now - (this.lockedT || 0) > 2500) { this.lockedAt = key; this.lockedT = now; if (this.hooks.door) this.hooks.door(c, false, cx, cy); }
            return false;
        }

        /** a pessoa (à altura do chão) ou um 📦 em cima de uma plataforma: abrem-se as portas da cor dela, de vez */
        checkPlates(cx, cy) {
            for (const p of this.plates) {
                if (p.on) continue;
                const box = this.dyn.some((o) => !o.gone && o.ch === 'T' && o.x === p.x && o.y === p.y && o.b === 0), me = !p.needBox && cx === p.x && cy === p.y && this.ph === 0;
                if (!box && !me) continue;
                p.on = true; p.onT = performance.now();
                let n = 0;
                this.map.forEach((r, y) => { for (let x = 0; x < r.length; x++) if (r[x] === p.color && !(Math.floor(this.px) === x && Math.floor(this.py) === y)) { this.setMap(x, y, '0'); n++; } });
                this.doorsOpened += n;
                if (this.hooks.plate) this.hooks.plate(p, n);
            }
        }

        onMove() {
            const cx = Math.floor(this.px), cy = Math.floor(this.py), key = cx + ',' + cy;
            this.visited.add(key);
            if (key !== this.lastCell) {
                const gc = this.L.ground[key];
                if (gc === 'a') { this.roadSteps++; if (this.hooks.road) this.hooks.road(cx, cy, false); }
                else if (gc === 'z') { this.crossSteps++; if (this.hooks.road) this.hooks.road(cx, cy, true); }
            }
            const here = (e) => (e.lv || 0) === this.ph;          /* só se apanha o que está à mesma altura (no chão ou em cima dos blocos) */
            if (this.ph === 0) this.checkPlates(cx, cy);
            for (const it of this.items) {
                if (it.got || !here(it)) continue;
                if (Math.hypot(it.x + 0.5 - this.px, it.y + 0.5 - this.py) < 0.45) {
                    it.got = true;
                    if (this.hooks.item) this.hooks.item(it);
                }
            }
            for (const k of this.keys) {
                if (k.got || !here(k) || Math.hypot(k.x + 0.5 - this.px, k.y + 0.5 - this.py) > 0.45) continue;
                k.got = true; this.held.add(k.color);
                if (this.hooks.key) this.hooks.key(k);
            }
            for (const h of this.hints) {
                if (h.got || !here(h) || Math.hypot(h.x + 0.5 - this.px, h.y + 0.5 - this.py) > 0.45) continue;
                h.got = true;
                if (h.type === 'compass') this.compass = true;
                if (h.type === 'map') this.mapOn = true;
                if (h.type === 'pick') this.hasPick = true;
                this.anim = null;
                if (this.hooks.hint) this.hooks.hint(h);
            }
            if (key === this.lastCell) return;
            this.lastCell = key;
            for (const q of this.questions) if (!q.done && here(q) && q.x === cx && q.y === cy) { this.anim = null; if (this.hooks.question) this.hooks.question(q); }
            if (this.L.exit && this.exitLv === this.ph && this.L.exit.x === cx && this.L.exit.y === cy && this.hooks.exit) { this.anim = null; this.hooks.exit(); }
        }

        /** 2D: o chão (ruas, passeios, passadeiras, relva) visto em perspetiva — o mapa do chão desenhado uma vez e
            «projetado» linha a linha, numa imagem mais pequena que depois se estica (leve) */
        drawFloor2D(g, W, H, hz, dirX, dirY, plX, plY) {
            const CS = 16;
            if (!this.floorMap) {
                const c = canvas(this.L.w * CS, this.L.h * CS);
                drawGroundMap(c.getContext('2d'), this.L, CS);
                this.floorMap = { w: c.width, h: c.height, d: c.getContext('2d').getImageData(0, 0, c.width, c.height).data };
            }
            const k = 3, FW = Math.max(1, Math.ceil(W / k)), FH = Math.max(1, Math.ceil((H - hz) / k));
            if (!this.floorCv || this.floorCv.width !== FW || this.floorCv.height !== FH) {
                this.floorCv = canvas(FW, FH); this.floorCtx = this.floorCv.getContext('2d'); this.floorImg = this.floorCtx.createImageData(FW, FH);
            }
            const out = this.floorImg.data, M = this.floorMap, fr = parseInt(this.L.floor.slice(1, 3), 16), fgc = parseInt(this.L.floor.slice(3, 5), 16), fb = parseInt(this.L.floor.slice(5, 7), 16);
            const r0x = dirX - plX, r0y = dirY - plY, r1x = dirX + plX, r1y = dirY + plY;
            for (let yy = 0; yy < FH; yy++) {
                const p = (yy + 0.5) * k, dist = H / (2 * Math.max(0.5, p));
                const stx = dist * (r1x - r0x) / FW, sty = dist * (r1y - r0y) / FW;
                let fx = this.px + dist * r0x, fy = this.py + dist * r0y;
                const fog = Math.min(0.72, dist / 14), keep = 1 - fog;
                let o = yy * FW * 4;
                for (let xx = 0; xx < FW; xx++, fx += stx, fy += sty, o += 4) {
                    const mx = Math.floor(fx * CS), my = Math.floor(fy * CS);
                    let r = fr, gg = fgc, b = fb;
                    if (mx >= 0 && my >= 0 && mx < M.w && my < M.h) { const i = (my * M.w + mx) * 4; r = M.d[i]; gg = M.d[i + 1]; b = M.d[i + 2]; }
                    out[o] = r * keep + 20 * fog; out[o + 1] = gg * keep + 24 * fog; out[o + 2] = b * keep + 30 * fog; out[o + 3] = 255;
                }
            }
            this.floorCtx.putImageData(this.floorImg, 0, 0);
            g.imageSmoothingEnabled = true;
            g.drawImage(this.floorCv, 0, 0, FW, FH, 0, hz, W, H - hz);
        }

        render() {
            const cv = this.cv, g = this.g, W = cv.width, H = cv.height;
            if (!W || !H) return;
            if (this.r3d) {                     /* em 3D o desenho é do Renderer3D; esta tela fica só com o mapa pequeno */
                this.r3d.render();
                g.clearRect(0, 0, W, H);
                if (this.mapOn && this.hooks.minimap !== false) this.drawMinimap();
                if (this.hooks.frame) this.hooks.frame();
                return;
            }
            const hz = H / 2;
            let grd = g.createLinearGradient(0, 0, 0, hz);
            grd.addColorStop(0, shade(this.L.ceiling, -0.18)); grd.addColorStop(1, this.L.ceiling);
            g.fillStyle = grd; g.fillRect(0, 0, W, hz);
            const fov = Math.PI / 3, dirX = Math.cos(this.pa), dirY = Math.sin(this.pa);
            const plX = -dirY * Math.tan(fov / 2), plY = dirX * Math.tan(fov / 2);
            if (this.L.ground && Object.keys(this.L.ground).length) this.drawFloor2D(g, W, H, hz, dirX, dirY, plX, plY);
            else {
                grd = g.createLinearGradient(0, hz, 0, H);
                grd.addColorStop(0, shade(this.L.floor, -0.25)); grd.addColorStop(1, this.L.floor);
                g.fillStyle = grd; g.fillRect(0, hz, W, H - hz);
            }
            const cols = W, z = this.zbuf;
            z.length = cols;
            for (let x = 0; x < cols; x++) {
                const cam = 2 * x / cols - 1, rx = dirX + plX * cam, ry = dirY + plY * cam;
                let mx = Math.floor(this.px), my = Math.floor(this.py);
                const ddx = Math.abs(1 / rx), ddy = Math.abs(1 / ry);
                let sx, sy, sdx, sdy;
                if (rx < 0) { sx = -1; sdx = (this.px - mx) * ddx; } else { sx = 1; sdx = (mx + 1 - this.px) * ddx; }
                if (ry < 0) { sy = -1; sdy = (this.py - my) * ddy; } else { sy = 1; sdy = (my + 1 - this.py) * ddy; }
                let side = 0, c = '0', n = 0;
                while (n++ < 256) {
                    if (sdx < sdy) { sdx += ddx; mx += sx; side = 0; } else { sdy += ddy; my += sy; side = 1; }
                    c = this.cell(mx, my);
                    if (c !== '0') break;
                }
                const pd = side === 0 ? (mx - this.px + (1 - sx) / 2) / rx : (my - this.py + (1 - sy) / 2) / ry;
                const d = Math.max(0.05, pd);
                z[x] = d;
                const lh = H / d, y0 = hz - lh / 2;
                let wx = side === 0 ? this.py + d * ry : this.px + d * rx;
                wx -= Math.floor(wx);
                const tex = this.textures[c] || this.textures['5'];
                const tw = tex.width;
                let tx = Math.floor(wx * tw);
                if ((side === 0 && rx > 0) || (side === 1 && ry < 0)) tx = tw - tx - 1;
                g.drawImage(tex, tx, 0, 1, tex.height, x, y0, 1.02, lh);
                const fog = Math.min(0.72, d / 14) + (side ? 0.12 : 0);
                if (fog > 0.01) { g.fillStyle = 'rgba(20,24,30,' + fog.toFixed(3) + ')'; g.fillRect(x, y0, 1.02, lh); }
            }

            /* objetos, perguntas e saída (sprites), do mais longe para o mais perto */
            const sp = [];
            this.items.forEach((it) => {
                if (it.got) return;
                const av = it.asset && this.assetViews[it.asset];
                if (av && av.length) sp.push({ x: it.x + 0.5, y: it.y + 0.5, img: this.viewOf(av, it.x + 0.5, it.y + 0.5, 90), model: true, h: 0.45, float: true });
                else sp.push({ x: it.x + 0.5, y: it.y + 0.5, img: this.itemImgs[it.i] || this.qmark, s: 0.55, float: true });
            });
            this.models.forEach((m) => {
                const av = this.assetViews[m.asset];
                const mx = m.fx != null ? m.fx : m.x + 0.5, my = m.fy != null ? m.fy : m.y + 0.5;
                if (av && av.length) sp.push({ x: mx, y: my, img: this.viewOf(av, mx, my, m.rot), model: true, h: m.size || 0.8 });
            });
            this.questions.forEach((q) => { if (!q.done) sp.push({ x: q.x + 0.5, y: q.y + 0.5, img: this.qmark, s: 0.5, float: true }); });
            this.keys.forEach((k) => { if (!k.got) sp.push({ x: k.x + 0.5, y: k.y + 0.5, img: this.keyImgs[k.color], s: 0.5, float: true }); });
            this.hints.forEach((h) => { if (!h.got) sp.push({ x: h.x + 0.5, y: h.y + 0.5, img: this.hintImgs[h.type] || this.hintImgs.note, s: 0.5, float: true }); });
            this.plates.forEach((p) => sp.push({ x: p.x + 0.5, y: p.y + 0.5, img: this.plateImg(p), s: 0.5, ground: true }));
            if (this.L.exit) sp.push({ x: this.L.exit.x + 0.5, y: this.L.exit.y + 0.5, img: this.flag, s: 0.9 });
            const inv = 1 / (plX * dirY - dirX * plY), t = performance.now() / 1000;
            sp.forEach((s) => { s.d = (s.x - this.px) ** 2 + (s.y - this.py) ** 2; });
            sp.sort((a, b) => b.d - a.d);
            for (const s of sp) {
                if (!s.img) continue;
                const rx = s.x - this.px, ry = s.y - this.py;
                const tX = inv * (dirY * rx - dirX * ry), tY = inv * (-plY * rx + plX * ry);
                if (tY <= 0.1) continue;
                const scx = Math.floor((W / 2) * (1 + tX / tY));
                if (s.model) {                  /* modelo 3D visto em 2D: a vista do ângulo certo, com a altura do modelo, assente no chão */
                    const iw = s.img.naturalWidth || s.img.width, ih = s.img.naturalHeight || s.img.height;
                    const h = Math.abs(H / tY) * s.h, w = h * iw / ih, ground = hz + (H / tY) / 2;
                    const top = ground - h - (s.float ? h * 0.35 + Math.sin(t * 2 + s.x) * h * 0.05 : 0), left = scx - w / 2;
                    const x0 = Math.max(0, Math.floor(left)), x1 = Math.min(W - 1, Math.floor(left + w));
                    for (let x = x0; x <= x1; x++) {
                        if (tY >= z[x]) continue;
                        g.drawImage(s.img, Math.floor((x - left) / w * iw), 0, 1, ih, x, top, 1, h);
                    }
                    continue;
                }
                const size = Math.abs(H / tY) * s.s;
                const bob = s.float ? Math.sin(t * 2 + s.x) * size * 0.05 : 0;
                const ground = hz + (H / tY) / 2;
                const top = ground - size - (s.float ? size * 0.25 : 0) + bob;
                const iw = s.img.naturalWidth || s.img.width, ih = s.img.naturalHeight || s.img.height;
                const k = Math.min(size / iw, size / ih), w = iw * k, h = ih * k;
                const left = scx - w / 2;
                const x0 = Math.max(0, Math.floor(left)), x1 = Math.min(W - 1, Math.floor(left + w));
                for (let x = x0; x <= x1; x++) {
                    if (tY >= z[x]) continue;
                    const sx = Math.floor((x - left) / w * iw);
                    g.drawImage(s.img, sx, 0, 1, ih, x, top + (size - h), 1, h);
                }
            }

            if (this.mapOn && this.hooks.minimap !== false) this.drawMinimap();
            if (this.hooks.frame) this.hooks.frame();
        }

        drawMinimap() {
            const g = this.g, W = this.cv.width, H = this.cv.height;
            const cs = Math.max(4, Math.min(12, Math.floor(Math.min(W, H) * 0.28 / Math.max(this.L.w, this.L.h))));
            const mw = cs * this.L.w, mh = cs * this.L.h, ox = this.mmLeft || 12, oy = H - mh - 12;
            g.fillStyle = 'rgba(255,255,255,.9)'; g.fillRect(ox - 4, oy - 4, mw + 8, mh + 8); g.fillStyle = '#f4efe6'; g.fillRect(ox, oy, mw, mh);
            for (let y = 0; y < this.L.h; y++) for (let x = 0; x < this.L.w; x++) {
                const c = this.map[y][x];
                if (c !== '0') { g.fillStyle = (DOORS[c] && DOORS[c].color) || (STYLES[c] && STYLES[c].base) || (BLOCKS[c] && BLOCKS[c].color) || (SPECIAL[c] && SPECIAL[c].base) || '#7d6b5a'; g.fillRect(ox + x * cs, oy + y * cs, cs, cs); }
                else {
                    const gc = this.L.ground[x + ',' + y];
                    if (gc) { g.fillStyle = GROUND[gc].color; g.globalAlpha = 0.55; g.fillRect(ox + x * cs, oy + y * cs, cs, cs); g.globalAlpha = 1; }
                    if (this.visited.has(x + ',' + y)) { g.fillStyle = 'rgba(32,128,160,.16)'; g.fillRect(ox + x * cs, oy + y * cs, cs, cs); }
                }
            }
            if (this.L.exit) { g.fillStyle = '#2fa66a'; g.fillRect(ox + this.L.exit.x * cs + 1, oy + this.L.exit.y * cs + 1, cs - 2, cs - 2); }
            g.fillStyle = '#e0529c';
            this.items.forEach((it) => { if (!it.got) { g.beginPath(); g.arc(ox + (it.x + 0.5) * cs, oy + (it.y + 0.5) * cs, cs * 0.28, 0, 7); g.fill(); } });
            this.keys.forEach((k) => { if (!k.got) { g.fillStyle = DOORS[k.color].color; g.fillRect(ox + (k.x + 0.25) * cs, oy + (k.y + 0.4) * cs, cs * 0.5, cs * 0.2); } });
            g.fillStyle = '#5b4a3a';
            this.models.forEach((m) => { g.beginPath(); g.arc(ox + (m.fx != null ? m.fx : m.x + 0.5) * cs, oy + (m.fy != null ? m.fy : m.y + 0.5) * cs, cs * 0.3, 0, 7); g.fill(); });
            g.fillStyle = '#2080a0';
            this.questions.forEach((q) => { if (!q.done) { g.beginPath(); g.arc(ox + (q.x + 0.5) * cs, oy + (q.y + 0.5) * cs, cs * 0.28, 0, 7); g.fill(); } });
            const px = ox + this.px * cs, py = oy + this.py * cs;
            g.fillStyle = '#d64545'; g.beginPath();
            g.moveTo(px + Math.cos(this.pa) * cs * 0.7, py + Math.sin(this.pa) * cs * 0.7);
            g.lineTo(px + Math.cos(this.pa + 2.5) * cs * 0.45, py + Math.sin(this.pa + 2.5) * cs * 0.45);
            g.lineTo(px + Math.cos(this.pa - 2.5) * cs * 0.45, py + Math.sin(this.pa - 2.5) * cs * 0.45);
            g.closePath(); g.fill();
        }
    }

    function shade(hex, k) {
        const v = parseInt(String(hex || '#888888').slice(1), 16);
        if (!Number.isFinite(v)) return hex;
        const f = (c) => Math.max(0, Math.min(255, Math.round(c + (k < 0 ? c * k : (255 - c) * k))));
        return '#' + [(v >> 16) & 255, (v >> 8) & 255, v & 255].map((c) => f(c).toString(16).padStart(2, '0')).join('');
    }

    global.Explorer3D = { Engine, STYLES, DOORS, BLOCKS, MAX_STACK, door, keyIcon, badge, framed, normalize, loadImage, blockTexture, blockFace, columnBlocks, SPECIAL, GROUND, drawGroundMap, footprint, realSize, standLevel, reachable, walks };
})(window);
