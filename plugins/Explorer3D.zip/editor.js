'use strict';
/**
 * Explorador 3D — level editor (MQ Plugins contract v1).
 * Paint the grid (walls with styles or images, floor), place the start, the exit, objects and questions, set the level
 * options and test it with the real player («Testar»). Receives the level through window.vuplex ("{}" = new screen) and
 * saves with window.vuplex.postMessage({ type: 'PluginConfig', config, files: {} }). Images go inside the level as
 * data: URLs, so the player never reads files (works under file:// in Unity).
 */
class LevelEditor {
    constructor() {
        this.L = this.blank(14, 10);
        this.tool = 'w:1';
        this.sel = null;              // { kind: 'item'|'question', i }
        this.wallTex = {};
        this.imgCache = {};
        this.grid = document.getElementById('grid');
        this.g = this.grid.getContext('2d');
        this.msg = document.getElementById('editorMessage');
        this.buildTools();
        this.bindGrid();
        this.bindLevel();
        this.bindTest();
        this.bindUndo();
        this.bindPreview();
        document.getElementById('saveBtn').onclick = () => this.save();
        document.getElementById('downloadBtn').onclick = () => this.download();
        addEventListener('resize', () => this.draw());
        if (typeof ResizeObserver === 'function') new ResizeObserver(() => this.draw()).observe(document.getElementById('gridwrap'));
        this.initializeConfigLoading();
        this.refreshAll();
    }

    blank(w, h) {
        const map = [];
        for (let y = 0; y < h; y++) map.push(y === 0 || y === h - 1 ? '1'.repeat(w) : '1' + '0'.repeat(w - 2) + '1');
        return { w, h, map, images: {}, start: { x: 1, y: 1, dir: 0 }, exit: { x: w - 2, y: h - 2 }, items: [], questions: [], keys: [], hints: [], plates: [], assets: {}, models: [], view: '3d',
                 floor: '#9fc77a', ceiling: '#8ec5f0', sky: true, stack: {}, needAll: true, minimap: true, speed: 1, timeLimit: 0 };
    }

    say(t, err) { this.msg.textContent = t; this.msg.classList.toggle('error', !!err); if (t) setTimeout(() => { if (this.msg.textContent === t) this.msg.textContent = ''; }, 3000); }

    /* ---------- receiving the level ---------- */

    initializeConfigLoading() {
        const hear = () => window.vuplex.addEventListener('message', (event) => {
            if (window.MQHost && MQHost.handle(event.data)) return;     /* answers of the host services */
            let cfg = event.data;
            if (typeof cfg === 'string') { try { cfg = JSON.parse(cfg || '{}'); } catch (e) { this.say('JSON inválido', true); return; } }
            if (cfg && typeof cfg === 'object' && cfg.map) this.load(cfg);
        });
        if (window.vuplex) hear(); else addEventListener('vuplexready', hear);
    }

    /** áudio de um texto (nota, pergunta): gravar com o microfone ou escolher um ficheiro; ouve-se quando o texto aparece */
    audioRow(get, set, opt) {
        opt = opt || {};
        const row = document.createElement('div');
        row.className = 'audiorow';
        const draw = () => {
            row.innerHTML = opt.pick ? '' : '<span class="hint">🔊 Áudio</span>';
            const btn = (t, f, cls) => { const b = document.createElement('button'); b.type = 'button'; b.className = 'mini' + (cls ? ' ' + cls : ''); b.textContent = t; b.onclick = f; row.append(b); return b; };
            if (get()) {
                btn('▶', () => { try { if (this.audioEl) this.audioEl.pause(); this.audioEl = new Audio(get()); this.audioEl.play(); } catch (e) { /* nothing */ } });
                btn('✕', () => { this.checkpoint(); set(''); draw(); });
            }
            const canRec = opt.rec !== false && !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder);
            if (canRec) {
                const rec = btn(this.recording ? '⏹ Parar' : '🎙 Gravar', async () => {
                    if (this.recording) { this.recording.stop(); return; }
                    try {
                        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                        const mr = new MediaRecorder(stream), parts = [];
                        mr.ondataavailable = (e) => { if (e.data && e.data.size) parts.push(e.data); };
                        mr.onstop = async () => {
                            stream.getTracks().forEach((t) => t.stop());
                            this.recording = null;
                            const blob = new Blob(parts, { type: mr.mimeType || 'audio/webm' });
                            if (blob.size) { this.checkpoint(); set(await this.blobURL(blob)); this.say('🎙 ✔'); }
                            draw();
                        };
                        this.recording = mr; mr.start(); draw();
                        setTimeout(() => { if (this.recording === mr) mr.stop(); }, 60000);      /* no máximo 1 minuto */
                    } catch (e) { this.say('Não foi possível usar o microfone: escolha um ficheiro de áudio.', true); }
                }, this.recording ? 'rec' : '');
                rec.title = 'Gravar com o microfone (até 1 minuto)';
            }
            const lab = document.createElement('label'); lab.className = 'mini file-mini'; lab.textContent = opt.pick && !get() ? opt.pick : '📁';
            lab.title = 'Escolher um ficheiro de áudio (mp3, ogg, wav, webm)';
            const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'audio/*'; inp.hidden = true;
            inp.onchange = async () => {
                const f = inp.files[0]; inp.value = '';
                if (!f) return;
                if (f.size > 3e6) { this.say('O áudio é grande (mais de 3 MB): o nível fica pesado.', true); }
                this.checkpoint(); set(await this.blobURL(f)); draw();
            };
            lab.append(inp); row.append(lab);
        };
        draw();
        return row;
    }
    blobURL(b) { return new Promise((res) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => res(''); r.readAsDataURL(b); }); }

    /* ---------- undo / redo: snapshots of the level without the heavy parts (images, 3D models) ---------- */

    snap() { const L = Object.assign({}, this.L); delete L.assets; delete L.images; return JSON.stringify(L); }
    checkpoint() {
        const s = this.snap(), u = this.undoStack;
        if (u[u.length - 1] === s) return;
        u.push(s); if (u.length > 80) u.shift();
        this.redoStack = [];
        this.undoButtons();
    }
    restore(s) {
        const assets = this.L.assets, images = this.L.images;
        this.L = JSON.parse(s); this.L.assets = assets || {}; this.L.images = images || {};
        this.sel = null;
        this.refreshAll();
    }
    undo() {
        const cur = this.snap();
        let s = this.undoStack.pop();
        if (s === cur) s = this.undoStack.pop();
        if (!s) { this.undoButtons(); return; }
        this.redoStack.push(cur);
        this.restore(s);
        this.undoButtons();
    }
    redo() {
        const s = this.redoStack.pop();
        if (!s) return;
        this.undoStack.push(this.snap());
        this.restore(s);
        this.undoButtons();
    }
    undoButtons() {
        const u = document.getElementById('undoBtn'), r = document.getElementById('redoBtn');
        if (u) u.disabled = !this.undoStack.length; if (r) r.disabled = !this.redoStack.length;
    }
    bindUndo() {
        this.undoStack = []; this.redoStack = [];
        document.getElementById('undoBtn').onclick = () => this.undo();
        document.getElementById('redoBtn').onclick = () => this.redo();
        /* antes de cada gesto (clique, toque, começar a escrever) guarda-se o nível como estava */
        const before = (e) => { if (!e.target.closest || e.target.closest('#undoBtn, #redoBtn, #pv, #testBox, .test')) return; this.checkpoint(); };
        document.addEventListener('pointerdown', before, true);
        document.addEventListener('focusin', before, true);
        document.addEventListener('keydown', (e) => {
            if (!(e.ctrlKey || e.metaKey)) return;
            if (/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) return;      /* dentro de um texto: o desfazer do próprio texto */
            const k = e.key.toLowerCase();
            if (k === 'z' && !e.shiftKey) { e.preventDefault(); this.undo(); }
            else if (k === 'y' || (k === 'z' && e.shiftKey)) { e.preventDefault(); this.redo(); }
        });
    }

    /* ---------- 3D preview while editing ---------- */

    bindPreview() {
        const pv = document.getElementById('pv'), cv = document.getElementById('pvCanvas');
        this.orbit = { yaw: -2.3, pitch: 0.75, dist: 0 };
        const ok = window.Explorer3DView && Explorer3DView.webglOK();
        const btn = document.getElementById('pvBtn');
        if (!ok) { btn.disabled = true; btn.title = 'Sem WebGL neste aparelho.'; return; }
        btn.onclick = () => { pv.hidden = !pv.hidden; btn.classList.toggle('on', !pv.hidden); if (!pv.hidden) { this.pvSig = ''; this.previewSoon(0); this.pvLoop(); } else this.pvStop(); };
        document.getElementById('pvClose').onclick = () => { pv.hidden = true; btn.classList.remove('on'); this.pvStop(); };
        let drag = null;
        cv.addEventListener('pointerdown', (e) => { drag = [e.clientX, e.clientY]; try { cv.setPointerCapture(e.pointerId); } catch (_) {} });
        cv.addEventListener('pointermove', (e) => {
            if (!drag) return;
            this.orbit.yaw += (e.clientX - drag[0]) * 0.01;
            this.orbit.pitch = Math.max(0.12, Math.min(1.5, this.orbit.pitch + (e.clientY - drag[1]) * 0.008));
            drag = [e.clientX, e.clientY];
        });
        const up = () => { drag = null; };
        cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
        cv.addEventListener('wheel', (e) => { e.preventDefault(); this.orbit.dist = Math.max(3, Math.min(120, this.orbit.dist * (e.deltaY > 0 ? 1.12 : 0.89))); }, { passive: false });
    }
    /** rebuilds the preview a little after the last change (only while it is open) */
    previewSoon(ms) {
        const pv = document.getElementById('pv');
        if (!pv || pv.hidden) return;
        clearTimeout(this.pvT);
        this.pvT = setTimeout(() => this.buildPreview(), ms == null ? 700 : ms);
    }
    async buildPreview() {
        const L = this.build();
        const sig = JSON.stringify(Object.assign({}, L, { assets: Object.keys(L.assets || {}), images: Object.keys(L.images || {}) }));
        if (sig === this.pvSig) return;
        if (this.pvBusy) { this.pvAgain = true; return; }
        this.pvBusy = true; this.pvSig = sig;
        try {
            const off = document.createElement('canvas'); off.width = 64; off.height = 64;
            const E = new Explorer3D.Engine(off, L, {});
            await E.load();
            const r = new Explorer3DView.Renderer3D(E, document.getElementById('pvCanvas'));
            await r.init();
            if (!this.orbit.dist) this.orbit.dist = Math.max(E.L.w, E.L.h) * 1.15;
            r.orbit = this.orbit;
            if (this.pvR) this.pvR.dispose();
            this.pvR = r;
        } catch (e) { console.warn('pré-visualização', e); }
        this.pvBusy = false;
        if (this.pvAgain) { this.pvAgain = false; this.previewSoon(0); }
    }
    pvLoop() {
        if (this.pvRaf) return;
        const step = () => {
            const pv = document.getElementById('pv');
            if (!pv || pv.hidden) { this.pvRaf = 0; return; }
            if (this.pvR) this.pvR.render();
            this.pvRaf = requestAnimationFrame(step);
        };
        this.pvRaf = requestAnimationFrame(step);
    }
    pvStop() { cancelAnimationFrame(this.pvRaf); this.pvRaf = 0; if (this.pvR) { this.pvR.dispose(); this.pvR = null; } this.pvSig = ''; }

    load(cfg) {
        if (this.undoStack) { this.undoStack = []; this.redoStack = []; this.undoButtons(); }
        this.L = Explorer3D.normalize(JSON.parse(JSON.stringify(cfg)));
        this.L.images = this.L.images || {};
        this.sel = null;
        this.refreshAll();
        Object.keys(this.L.assets || {}).forEach((id) => this.measure(id));
    }

    /* ---------- tools ---------- */

    buildTools() {
        const bb = document.getElementById('blocks');
        for (const [k, b0] of Object.entries(Explorer3D.BLOCKS)) {
            const c = Explorer3D.blockFace(b0.color, 64);
            this.wallTex[k] = c;
            const b = document.createElement('button');
            b.type = 'button'; b.className = 'sw blk'; b.dataset.tool = 'w:' + k; b.title = b0.name;
            b.style.backgroundImage = 'url(' + c.toDataURL() + ')';
            bb.append(b);
        }
        const sm = document.getElementById('stackMode');
        this.stackMode = sm.checked;
        sm.onchange = () => { this.stackMode = sm.checked; };
        const gb = document.getElementById('grounds');
        for (const [k, d] of [...Object.entries(Explorer3D.GROUND), ['0', { name: 'Sem chão pintado' }]]) {
            const c = document.createElement('canvas'); c.width = c.height = 48;
            if (k !== '0') {
                const mini = { w: 3, h: 3, floor: '#c9b99a', ground: {} };
                for (let y = 0; y < 3; y++) for (let x = 0; x < 3; x++) mini.ground[x + ',' + y] = k === 'z' ? (x === 1 ? 'z' : 'a') : k;
                if (k === 'a') { mini.ground = { '0,0': 'a', '1,0': 'a', '2,0': 'a', '0,1': 'a', '1,1': 'a', '2,1': 'a', '0,2': 'p', '1,2': 'p', '2,2': 'p' }; }
                const big = document.createElement('canvas'); big.width = big.height = 96;
                Explorer3D.drawGroundMap(big.getContext('2d'), mini, 32);
                c.getContext('2d').drawImage(big, 24, k === 'a' ? 8 : 24, 48, 48, 0, 0, 48, 48);
            } else { const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, 48, 48); g.strokeStyle = '#c33'; g.lineWidth = 4; g.beginPath(); g.moveTo(8, 8); g.lineTo(40, 40); g.stroke(); }
            const b = document.createElement('button');
            b.type = 'button'; b.className = 'sw blk'; b.dataset.tool = 'g:' + k; b.title = d.name;
            b.style.backgroundImage = 'url(' + c.toDataURL() + ')';
            gb.append(b);
        }
        const sp = document.getElementById('specials'), pickBtn = sp.querySelector('[data-tool="hint:pick"]');
        for (const [k, d] of Object.entries(Explorer3D.SPECIAL)) {
            const c = Explorer3D.blockTexture(k, 64);
            this.wallTex[k] = c;
            const b = document.createElement('button');
            b.type = 'button'; b.className = 'sw'; b.dataset.tool = 'w:' + k; b.title = d.name;
            b.style.backgroundImage = 'url(' + c.toDataURL() + ')';
            b.innerHTML = '<span>' + (k === 'S' ? 'Parte-se' : 'Caixa') + '</span>'; b.title = k === 'S' ? '💥 Bloco que se parte (com a picareta)' : '📦 Caixa que se empurra (e serve de degrau)';
            sp.insertBefore(b, pickBtn);
        }
        const box = document.getElementById('walls');
        for (const [k, st] of Object.entries(Explorer3D.STYLES)) {
            const c = document.createElement('canvas'); c.width = c.height = 64; st.draw(c.getContext('2d'));
            this.wallTex[k] = c;
            const b = document.createElement('button');
            b.type = 'button'; b.className = 'sw'; b.dataset.tool = 'w:' + k; b.title = st.name;
            b.style.backgroundImage = 'url(' + c.toDataURL() + ')';
            b.innerHTML = '<span>' + st.name + '</span>';
            box.append(b);
        }
        const doors = document.getElementById('doors'), keyTools = document.getElementById('keyTools'), plates = document.getElementById('plates');
        for (const [k, d] of Object.entries(Explorer3D.DOORS)) {
            const c = document.createElement('canvas'); c.width = c.height = 64; Explorer3D.door(c.getContext('2d'), d.color);
            this.wallTex[k] = c;
            const b = document.createElement('button');
            b.type = 'button'; b.className = 'sw'; b.dataset.tool = 'w:' + k; b.title = 'Porta ' + d.name.toLowerCase();
            b.style.backgroundImage = 'url(' + c.toDataURL() + ')'; b.innerHTML = '<span>🚪 ' + d.name + '</span>';
            doors.append(b);
            const ki = Explorer3D.keyIcon(d.color, 64);
            this.keyTex = this.keyTex || {}; this.keyTex[k] = ki;
            const kb = document.createElement('button');
            kb.type = 'button'; kb.className = 'sw'; kb.dataset.tool = 'key:' + k; kb.title = 'Chave ' + d.name.toLowerCase();
            kb.style.backgroundImage = 'url(' + ki.toDataURL() + ')'; kb.style.backgroundSize = 'contain'; kb.style.backgroundRepeat = 'no-repeat'; kb.style.backgroundColor = '#fff';
            kb.innerHTML = '<span>' + d.name + '</span>';
            keyTools.append(kb);
            const pb = document.createElement('button');
            pb.type = 'button'; pb.className = 'sw'; pb.dataset.tool = 'plate:' + k; pb.title = 'Plataforma ' + d.name.toLowerCase() + ': pisar abre as portas ' + d.name.toLowerCase() + 's';
            const pc = document.createElement('canvas'); pc.width = pc.height = 64; const pg = pc.getContext('2d');
            pg.fillStyle = '#fff'; pg.fillRect(0, 0, 64, 64); pg.fillStyle = d.color; pg.beginPath(); pg.ellipse(32, 30, 26, 18, 0, 0, 7); pg.fill();
            pg.strokeStyle = 'rgba(0,0,0,.35)'; pg.lineWidth = 3; pg.stroke();
            pb.style.backgroundImage = 'url(' + pc.toDataURL() + ')'; pb.style.backgroundSize = 'contain'; pb.style.backgroundRepeat = 'no-repeat'; pb.style.backgroundColor = '#fff';
            pb.innerHTML = '<span>' + d.name + '</span>';
            plates.append(pb);
        }
        document.querySelector('.tools').addEventListener('click', (e) => {
            const b = e.target.closest('[data-tool]');
            if (!b) return;
            this.tool = b.dataset.tool;
            this.markTool();
        });
        document.querySelector('.selbtn').addEventListener('click', () => { this.tool = 'select'; this.markTool(); });
        this.bindTabs();
        const addWall = async (f) => {
            if (!f) return;
            const key = 'abcdefghijklmnopqrstuvwxyz'.split('').find((k) => !this.L.images[k]);
            if (!key) { this.say('No máximo 26 imagens de parede.', true); return; }
            this.L.images[key] = await this.shrink(f, 384, 'image/jpeg');
            this.tool = 'w:' + key;
            this.refreshImgWalls();
            this.markTool();
        };
        document.getElementById('imgWallInput').addEventListener('change', async (e) => { const f = e.target.files[0]; e.target.value = ''; await addWall(f); });
        const wh = document.getElementById('imgWallHost');
        if (window.MQHost && MQHost.has('PickImage')) {
            wh.hidden = false;
            wh.onclick = async () => { const f = await this.hostImage(1024); if (f) await addWall(f); };
        }
        const pm = document.getElementById('pickModel');
        if (!(window.MQHost && MQHost.has('PickModel'))) { pm.disabled = true; pm.title = 'Os modelos 3D escolhem-se no MQ Creator.'; }
        this.markTool();
    }

    /** tabs: on the left the tool groups (build / interaction), on the right the level's settings and the two generators */
    bindTabs() {
        const mem = (k, v) => { try { if (v === undefined) return localStorage.getItem('mq3d.tab.' + k); localStorage.setItem('mq3d.tab.' + k, v); } catch (_) { /* nothing */ } return null; };
        document.querySelectorAll('.tabs').forEach((bar) => {
            const side = bar.dataset.side, root = bar.parentElement;
            const show = (name) => {
                bar.querySelectorAll('[data-tab]').forEach((b) => b.classList.toggle('on', b.dataset.tab === name));
                root.querySelectorAll(':scope > .tabpane').forEach((p) => p.classList.toggle('on', p.dataset.pane === name));
                mem(side, name);
            };
            bar.addEventListener('click', (e) => { const b = e.target.closest('[data-tab]'); if (b) show(b.dataset.tab); });
            const first = bar.querySelector('[data-tab]').dataset.tab, saved = mem(side);
            show(saved && bar.querySelector('[data-tab="' + saved + '"]') ? saved : first);
            this['tab_' + side] = show;
        });
        document.getElementById('selDone').onclick = () => { this.sel = null; this.draw(); this.showSel(); };
        /* tamanhos «personalizado»: mostra o número */
        for (const id of ['cySize', 'wdSize']) {
            const sel = document.getElementById(id), row = document.getElementById(id + 'N').closest('label');
            sel.addEventListener('change', () => { row.hidden = sel.value !== 'custom'; });
        }
    }

    refreshImgWalls() {
        const box = document.getElementById('imgWalls');
        box.innerHTML = '';
        for (const [k, src] of Object.entries(this.L.images)) {
            const b = document.createElement('button');
            b.type = 'button'; b.className = 'sw'; b.dataset.tool = 'w:' + k; b.title = 'Imagem ' + k;
            b.style.backgroundImage = 'url(' + src + ')';
            box.append(b);
            if (!this.imgCache[k] || this.imgCache[k].src !== src) { const im = new Image(); im.onload = () => this.draw(); im.src = src; this.imgCache[k] = im; }
        }
    }

    markTool() {
        document.querySelectorAll('[data-tool]').forEach((b) => b.classList.toggle('on', b.dataset.tool === this.tool));
    }

    /* ---------- images: smaller, inside the level ---------- */

    shrink(file, max, type) {
        return new Promise((resolve) => {
            const url = URL.createObjectURL(file), im = new Image();
            im.onload = () => {
                const k = Math.min(1, max / Math.max(im.naturalWidth, im.naturalHeight));
                const c = document.createElement('canvas');
                c.width = Math.max(1, Math.round(im.naturalWidth * k)); c.height = Math.max(1, Math.round(im.naturalHeight * k));
                const g = c.getContext('2d');
                if (type === 'image/jpeg') { g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); }
                g.drawImage(im, 0, 0, c.width, c.height);
                URL.revokeObjectURL(url);
                resolve(c.toDataURL(type, 0.85));
            };
            im.onerror = () => { URL.revokeObjectURL(url); resolve(''); };
            im.src = url;
        });
    }

    /* ---------- grid ---------- */

    cellAt(e) {
        const r = this.grid.getBoundingClientRect();
        return { x: Math.floor((e.clientX - r.left) / r.width * this.L.w), y: Math.floor((e.clientY - r.top) / r.height * this.L.h) };
    }
    inside(x, y) { return x > 0 && y > 0 && x < this.L.w - 1 && y < this.L.h - 1; }
    floorAt(x, y) { return this.L.map[y][x] === '0'; }
    onRoad(x, y) { const c = (this.L.ground || {})[x + ',' + y]; return c === 'a' || c === 'z'; }
    /** the proportions of a model's box ([width, height, depth], height = 1), read from its GLB: for the cells it covers */
    async measure(id) {
        const a = this.L.assets[id];
        if (!a || a.dims || !a.glb || !window.THREE || !THREE.GLTFLoader) return;
        try {
            const b64 = a.glb.split(',')[1], bin = atob(b64), u = new Uint8Array(bin.length);
            for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
            const g = await new Promise((res, rej) => new THREE.GLTFLoader().parse(u.buffer, '', res, rej));
            g.scene.updateMatrixWorld(true);
            const s = new THREE.Box3().setFromObject(g.scene).getSize(new THREE.Vector3());
            if (s.y > 0) a.dims = [s.x / s.y, 1, s.z / s.y].map((v) => Math.round(v * 1000) / 1000);
            this.draw();
        } catch (e) { console.warn('medida', id, e); }
    }
    stackOf(x, y) { return (this.L.stack || {})[x + ',' + y] || ''; }
    setStack(x, y, s) {
        this.L.stack = this.L.stack || {};
        if (s) this.L.stack[x + ',' + y] = s; else delete this.L.stack[x + ',' + y];
    }
    /** a block on top of the cell: on the ground if it is free, otherwise on the stack */
    addBlock(x, y, c) {
        if (this.floorAt(x, y)) { if (this.inside(x, y)) this.setCell(x, y, c); return; }
        const s = this.stackOf(x, y);
        if (s.length >= Explorer3D.MAX_STACK) { this.say('No máximo ' + (Explorer3D.MAX_STACK + 1) + ' blocos de altura.', true); return; }
        if (Explorer3D.DOORS[c]) { this.say('As portas ficam no chão.', true); return; }
        this.setStack(x, y, s + c);
        if (!this.L.sky) { this.L.sky = true; document.getElementById('lvSky').checked = true; this.say('Céu aberto ligado, para se verem os blocos empilhados.'); }
    }
    /** the top block of the cell goes away (the stack first, then the ground) */
    removeTop(x, y) {
        const s = this.stackOf(x, y);
        if (s) this.setStack(x, y, s.slice(0, -1));
        else if (this.inside(x, y)) this.setCell(x, y, '0');
    }
    setCell(x, y, c) {
        const row = this.L.map[y];
        if (row[x] === c) return;
        this.L.map[y] = row.slice(0, x) + c + row.slice(x + 1);
        if (c !== '0') {
            this.L.items = this.L.items.filter((i) => !(i.x === x && i.y === y));
            this.L.models = this.L.models.filter((i) => !(i.x === x && i.y === y));
            this.L.questions = this.L.questions.filter((q) => !(q.x === x && q.y === y));
            this.L.keys = this.L.keys.filter((q) => !(q.x === x && q.y === y));
            this.L.hints = this.L.hints.filter((q) => !(q.x === x && q.y === y));
            this.L.plates = (this.L.plates || []).filter((q) => !(q.x === x && q.y === y));
            if (this.L.exit && this.L.exit.x === x && this.L.exit.y === y) this.L.exit = null;
            if (this.L.start.x === x && this.L.start.y === y) this.say('O início ficou dentro de uma parede: volte a colocá-lo.', true);
            this.sel = null;
        }
    }
    /** a casela (x, y) é coberta pela «caixa» de um modelo? (a pegada no chão, pelo tamanho real e a direção) */
    modelAt(x, y, except) {
        for (let i = 0; i < this.L.models.length; i++) {
            if (i === except) continue;
            const m = this.L.models[i];
            if (m.x === x && m.y === y) return i;
            if (Explorer3D.footprint(m, this.L.assets[m.asset]).some(([fx, fy]) => fx === x && fy === y)) return i;
        }
        return -1;
    }
    /** o que já está na casela (para não se sobreporem): devolve um nome, ou '' se está livre.
        «question»: uma pergunta pode ficar por cima de um objeto ou de um modelo. */
    clashAt(x, y, kind, self) {
        const at = (a, k) => a.some((t, i) => t.x === x && t.y === y && !(self && self.kind === k && self.i === i));
        if (kind !== 'item' && kind !== 'model' && at(this.L.questions, 'question')) return 'uma pergunta';
        if (at(this.L.keys, 'key')) return 'uma chave';
        if (at(this.L.hints, 'hint')) return 'uma pista';
        if (at(this.L.plates || [], 'plate')) return 'uma plataforma';
        if (this.L.start.x === x && this.L.start.y === y && kind !== 'start') return 'o início';
        if (this.L.exit && this.L.exit.x === x && this.L.exit.y === y && kind !== 'exit') return 'a saída';
        if (kind === 'question') return '';
        if (at(this.L.items, 'item')) return 'um objeto';
        if (this.modelAt(x, y, self && self.kind === 'model' ? self.i : -1) >= 0) return 'um modelo 3D';
        return '';
    }
    /** a altura a que se fica em cima da casela (0 = no chão; em meias paredes), ou -1 se lá não se pode pôr nada */
    levelAt(x, y) { return this.inside(x, y) ? Explorer3D.standLevel(this.L.map, this.L.stack || {}, x, y) : -1; }
    /** pode pôr-se aqui (chão, ou em cima de blocos a que se consegue chegar)? devolve a mensagem do problema, ou '' */
    placeProblem(x, y, kind, self) {
        const lv = this.levelAt(x, y);
        if (lv < 0) return 'Aqui não se pode pôr nada.';
        if (lv > 0) {
            if (kind === 'start' || kind === 'plate') return 'Coloque-o no chão.';
            if (!this.L.sky) return 'Em cima de blocos, só com céu aberto.';
            if (!Explorer3D.reachable(this.L).has(x + ',' + y + ',' + lv)) {
                /* uma caixa 📦 empurrada para junto do degrau dá mais um bloco de altura */
                if (this.L.map.join('').includes('T') || Object.values(this.L.stack || {}).join('').includes('T')) {
                    if (Explorer3D.reachable(this.L, 1).has(x + ',' + y + ',' + lv)) { this.say('Só se chega lá empurrando uma caixa 📦 para servir de degrau.'); return ''; }
                }
                return 'Não se consegue chegar lá acima: faça uma escada de blocos (sobe-se um de cada vez) ou use uma caixa 📦.';
            }
        }
        const c = this.clashAt(x, y, kind, self);
        return c ? 'Já lá está ' + c + ': as coisas não se sobrepõem.' : '';
    }
    /** a caixa de um modelo (todas as caselas que ocupa) cabe: chão à mesma altura, sem outras coisas lá */
    modelProblem(m, self) {
        const a = this.L.assets[m.asset], fp = Explorer3D.footprint(m, a), lv = this.levelAt(m.x, m.y);
        if (lv < 0) return 'Aqui não se pode pôr nada.';
        for (const [fx, fy] of fp) {
            if (this.levelAt(fx, fy) !== lv) return 'Não cabe: a caixa do modelo apanha paredes ou blocos.';
            const c = this.clashAt(fx, fy, 'model', self);
            if (c && c !== 'uma pergunta') return 'Não cabe: a caixa do modelo apanha ' + c + '.';
        }
        if (lv > 0) {
            if (!this.L.sky) return 'Em cima de blocos, só com céu aberto.';
            const r = Explorer3D.reachable(Object.assign({}, this.L, { models: this.L.models.filter((_, i) => !self || i !== self.i) }));
            if (!fp.some(([fx, fy]) => r.has(fx + ',' + fy + ',' + lv) || [[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dy]) => r.has((fx + dx) + ',' + (fy + dy) + ',' + lv)))) return 'Não se consegue chegar lá acima: faça uma escada de blocos.';
        }
        return '';
    }
    /** mudar um modelo (rodar, tamanho): se passar a sobrepor-se, volta atrás */
    tryModel(m, i, change) {
        const keep = { rot: m.rot, size: m.size, x: m.x, y: m.y };
        change();
        const p = this.modelProblem(m, { kind: 'model', i });
        if (p) { Object.assign(m, keep); this.say(p, true); return false; }
        return true;
    }
    entityAt(x, y) {
        const pi = (this.L.plates || []).findIndex((t) => t.x === x && t.y === y);
        if (pi >= 0) return { kind: 'plate', i: pi };
        const mi = this.L.models.findIndex((t) => t.x === x && t.y === y);
        if (mi >= 0) return { kind: 'model', i: mi };
        let i = this.L.items.findIndex((t) => t.x === x && t.y === y);
        if (i >= 0) return { kind: 'item', i };
        i = this.L.questions.findIndex((t) => t.x === x && t.y === y);
        if (i >= 0) return { kind: 'question', i };
        i = this.L.keys.findIndex((t) => t.x === x && t.y === y);
        if (i >= 0) return { kind: 'key', i };
        i = this.L.hints.findIndex((t) => t.x === x && t.y === y);
        if (i >= 0) return { kind: 'hint', i };
        const fi = this.modelAt(x, y);
        if (fi >= 0) return { kind: 'model', i: fi };
        return null;
    }

    bindGrid() {
        let painting = false, stroke = new Set();
        const act = (e, first) => {
            const { x, y } = this.cellAt(e);
            if (x < 0 || y < 0 || x >= this.L.w || y >= this.L.h) return;
            const t = this.tool;
            /* empilhar e apagar: uma vez por casela em cada traço (arrastar não faz torres) */
            const once = () => { const k = x + ',' + y; if (stroke.has(k)) return false; stroke.add(k); return true; };
            if (t.startsWith('g:')) {
                this.L.ground = this.L.ground || {};
                const k = x + ',' + y;
                if (t === 'g:0') delete this.L.ground[k]; else this.L.ground[k] = t.slice(2);
            }
            else if (t.startsWith('w:')) {
                if (this.stackMode) { if (once()) this.addBlock(x, y, t.slice(2)); }
                else if (this.inside(x, y)) this.setCell(x, y, t.slice(2));
            }
            else if (t === 'erase') { if (once()) this.removeTop(x, y); }
            else if (!first) return;
            else if (t === 'select') this.sel = this.entityAt(x, y);
            else if (!this.inside(x, y) || this.levelAt(x, y) < 0) { this.say('Coloque-o numa casela de chão ou em cima de blocos.', true); return; }
            else if (t === 'start') {
                if (this.L.start.x === x && this.L.start.y === y) this.L.start.dir = ((this.L.start.dir || 0) + 1) % 4;
                else { const p = this.placeProblem(x, y, 'start'); if (p) { this.say(p, true); return; } this.L.start = { x, y, dir: this.L.start.dir || 0 }; }
            } else if (t === 'exit') {
                if (this.L.exit && this.L.exit.x === x && this.L.exit.y === y) this.L.exit = null;
                else { const p = this.placeProblem(x, y, 'exit'); if (p) { this.say(p, true); return; } this.L.exit = { x, y }; }
            } else if (t.startsWith('key:') || t.startsWith('hint:') || t.startsWith('plate:')) {
                const here = this.entityAt(x, y), kind = t.split(':')[0];
                if (here && here.kind === kind) this.sel = here;
                else {
                    const p = this.placeProblem(x, y, kind);
                    if (p) { if (here) this.sel = here; this.say(p, true); this.draw(); this.showSel(); return; }
                    if (kind === 'key') { this.L.keys.push({ x, y, color: t.slice(4) }); this.sel = { kind: 'key', i: this.L.keys.length - 1 }; }
                    else if (kind === 'plate') { (this.L.plates = this.L.plates || []).push({ x, y, color: t.slice(6), needBox: false }); this.sel = { kind: 'plate', i: this.L.plates.length - 1 }; }
                    else { this.L.hints.push({ x, y, type: t.slice(5), text: '', img: '' }); this.sel = { kind: 'hint', i: this.L.hints.length - 1 }; }
                }
            } else if (t === 'item' || t === 'question') {
                const here = this.entityAt(x, y), p = here && here.kind === t ? '' : this.placeProblem(x, y, t);
                if (here && here.kind === t) this.sel = here;
                else if (p) { if (here) this.sel = here; this.say(p, true); this.draw(); this.showSel(); return; }
                else if (t === 'item') { this.L.items.push({ x, y, name: 'Objeto ' + (this.L.items.length + 1), img: '', target: true }); this.sel = { kind: 'item', i: this.L.items.length - 1 }; }
                else { this.L.questions.push({ x, y, text: '', img: '', options: [{ text: '', correct: true }, { text: '', correct: false }] }); this.sel = { kind: 'question', i: this.L.questions.length - 1 }; }
            } else if (t.startsWith('model:')) {
                const here = this.entityAt(x, y), id = t.slice(6), a = this.L.assets[id];
                if (here && here.kind === 'model') { const m = this.L.models[here.i]; if (this.sel && this.sel.kind === 'model' && this.sel.i === here.i) this.tryModel(m, here.i, () => { m.rot = ((m.rot == null ? 90 : m.rot) + 45) % 360; }); this.sel = here; }
                else if (here && here.kind !== 'question') this.sel = here;
                else if (a) {
                    /* altura por omissão pelo tipo (os ficheiros têm unidades diferentes); a parede tem altura 1 */
                    /* à escala real: uma pessoa (1,75 m) tem 0,8 de altura e uma parede 1 */
                    const size = a.size || Explorer3D.realSize(id, a.cat);
                    const m = { x, y, asset: id, rot: 90, size, anim: '', solid: a.cat !== 'food', drive: a.cat === 'transport' && !/boat/.test(id) && this.onRoad(x, y) };
                    /* a caixa do modelo não se sobrepõe a nada: experimenta as quatro direções antes de desistir */
                    let p = this.modelProblem(m);
                    for (const r of [0, 180, 270]) { if (!p) break; m.rot = r; p = this.modelProblem(m); }
                    if (p) { m.rot = 90; this.say(p, true); return; }
                    this.L.models.push(m);
                    this.sel = { kind: 'model', i: this.L.models.length - 1 };
                }
            }
            this.draw();
            this.showSel();
        };
        this.grid.addEventListener('contextmenu', (e) => e.preventDefault());
        /* arrastar: carregar numa coisa já posta (objeto, pergunta, chave, pista, plataforma, modelo, início, saída) e
           mexer leva-a para outra casela — só se lá couber (as mesmas regras de quando se põe) */
        let drag = null;
        const grab = (x, y) => {
            const t = this.tool;
            if (t === 'erase') return null;               /* com qualquer outra ferramenta, carregar numa coisa posta arrasta-a */
            const e = this.entityAt(x, y);
            if (e) { const list = { item: this.L.items, question: this.L.questions, key: this.L.keys, hint: this.L.hints, model: this.L.models, plate: this.L.plates || [] }[e.kind]; return { kind: e.kind, i: e.i, obj: list[e.i] }; }
            if (this.L.start.x === x && this.L.start.y === y) return { kind: 'start', obj: this.L.start };
            if (this.L.exit && this.L.exit.x === x && this.L.exit.y === y) return { kind: 'exit', obj: this.L.exit };
            return null;
        };
        const moveTo = (d, x, y) => {
            const o = d.obj, keep = { x: o.x, y: o.y };
            if (o.x === x && o.y === y) return false;
            if (d.kind === 'model') {
                o.x = x; o.y = y;
                const p = this.modelProblem(o, { kind: 'model', i: d.i });
                if (p) { Object.assign(o, keep); this.say(p, true); return false; }
                return true;
            }
            const p = this.placeProblem(x, y, d.kind, d.i != null ? { kind: d.kind, i: d.i } : null);
            if (p) { this.say(p, true); return false; }
            o.x = x; o.y = y;
            return true;
        };
        this.grid.addEventListener('pointerdown', (e) => {
            if (e.button === 2) { const { x, y } = this.cellAt(e); if (x >= 0 && y >= 0 && x < this.L.w && y < this.L.h) { this.removeTop(x, y); this.draw(); this.stats(); } return; }
            try { this.grid.setPointerCapture(e.pointerId); } catch (_) {}
            const { x, y } = this.cellAt(e);
            const g = x >= 0 && y >= 0 && x < this.L.w && y < this.L.h ? grab(x, y) : null;
            if (g) { drag = Object.assign(g, { ev: e, moved: false, x, y }); this.grid.style.cursor = 'grabbing'; return; }
            stroke = new Set(); painting = true; act(e, true); });
        this.grid.addEventListener('pointermove', (e) => {
            if (drag) {
                const { x, y } = this.cellAt(e);
                if (x < 0 || y < 0 || x >= this.L.w || y >= this.L.h || (x === drag.x && y === drag.y)) return;
                if (!drag.moved) { this.checkpoint(); drag.moved = true; }
                if (moveTo(drag, x, y)) { drag.x = x; drag.y = y; if (drag.kind !== 'start' && drag.kind !== 'exit') this.sel = { kind: drag.kind, i: drag.i }; this.draw(); this.showSel(); }
                return;
            }
            if (painting && (this.tool.startsWith('w:') || this.tool.startsWith('g:') || this.tool === 'erase')) act(e, false);
        });
        const stop = () => {
            if (drag) {
                const d = drag; drag = null; this.grid.style.cursor = '';
                if (!d.moved) {                 /* não se mexeu: um clique — com as ferramentas de pintar, seleciona (não pinta por cima) */
                    if (/^(w|g):/.test(this.tool)) { this.sel = d.kind === 'start' || d.kind === 'exit' ? null : { kind: d.kind, i: d.i }; this.draw(); this.showSel(); }
                    else { stroke = new Set(); act(d.ev, true); }
                }
                else if (d.kind === 'model' && d.obj.drive && !this.onRoad(d.obj.x, d.obj.y)) this.say('O carro só circula numa casela de asfalto.', true);
                this.stats();
                return;
            }
            painting = false; this.stats(); };
        this.grid.addEventListener('pointerup', stop);
        this.grid.addEventListener('pointercancel', stop);
    }

    draw() {
        this.previewSoon();
        const wrap = document.getElementById('gridwrap');
        const W = wrap.clientWidth - 32, H = wrap.clientHeight - 32;
        if (W <= 0 || H <= 0) return;
        const cs = Math.max(8, Math.floor(Math.min(W / this.L.w, H / this.L.h)));
        const dpr = window.devicePixelRatio || 1;
        this.grid.style.width = cs * this.L.w + 'px'; this.grid.style.height = cs * this.L.h + 'px';
        this.grid.width = Math.round(cs * this.L.w * dpr); this.grid.height = Math.round(cs * this.L.h * dpr);
        const g = this.g;
        g.setTransform(dpr, 0, 0, dpr, 0, 0);
        Explorer3D.drawGroundMap(g, Object.assign({}, this.L, { ground: this.L.ground || {} }), cs);
        g.globalAlpha = 0.5; g.fillStyle = '#fff';
        for (let y = 0; y < this.L.h; y++) for (let x = 0; x < this.L.w; x++) if (!(this.L.ground || {})[x + ',' + y]) g.fillRect(x * cs, y * cs, cs, cs);
        g.globalAlpha = 1;
        for (let y = 0; y < this.L.h; y++) for (let x = 0; x < this.L.w; x++) {
            const c = this.L.map[y][x];
            if (c === '0') continue;
            const tex = this.wallTex[c] || (this.imgCache[c] && this.imgCache[c].complete ? this.imgCache[c] : null);
            if (tex) g.drawImage(tex, x * cs, y * cs, cs, cs); else { g.fillStyle = '#7d6b5a'; g.fillRect(x * cs, y * cs, cs, cs); }
            if (this.L.images[c]) { g.strokeStyle = '#6e4826'; g.lineWidth = 2; g.strokeRect(x * cs + 1, y * cs + 1, cs - 2, cs - 2); }
        }
        /* blocos empilhados: vê-se o de cima e a altura total */
        for (const [k, s] of Object.entries(this.L.stack || {})) {
            const [x, y] = k.split(',').map(Number), top = s[s.length - 1];
            const tex = this.wallTex[top] || (this.imgCache[top] && this.imgCache[top].complete ? this.imgCache[top] : null);
            const pad = this.floorAt(x, y) ? cs * 0.18 : cs * 0.1;     /* a flutuar (por cima de chão livre): mais pequeno */
            if (tex) g.drawImage(tex, x * cs + pad, y * cs + pad, cs - 2 * pad, cs - 2 * pad);
            const h = s.length + (this.floorAt(x, y) ? 0 : 1);
            g.fillStyle = 'rgba(20,24,30,.78)'; g.beginPath(); g.arc((x + 0.78) * cs, (y + 0.78) * cs, cs * 0.2, 0, 7); g.fill();
            g.fillStyle = '#fff'; g.font = 'bold ' + Math.round(cs * 0.26) + 'px Arial'; g.textAlign = 'center'; g.textBaseline = 'middle';
            g.fillText((this.floorAt(x, y) ? '↑' : '') + h, (x + 0.78) * cs, (y + 0.8) * cs);
        }
        g.strokeStyle = 'rgba(0,0,0,.08)'; g.lineWidth = 1;
        for (let x = 0; x <= this.L.w; x++) { g.beginPath(); g.moveTo(x * cs + 0.5, 0); g.lineTo(x * cs + 0.5, this.L.h * cs); g.stroke(); }
        for (let y = 0; y <= this.L.h; y++) { g.beginPath(); g.moveTo(0, y * cs + 0.5); g.lineTo(this.L.w * cs, y * cs + 0.5); g.stroke(); }
        const emoji = (t, x, y, k) => { g.font = Math.round(cs * (k || 0.7)) + 'px "Segoe UI Emoji","Noto Color Emoji",sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(t, (x + 0.5) * cs, (y + 0.54) * cs); };
        if (this.L.exit) emoji('🏁', this.L.exit.x, this.L.exit.y);
        this.L.models.forEach((m, i) => {
            const a = this.L.assets[m.asset], v = a && a.views && a.views[0] && this.itemImg(a.views[0]);
            if (v && v.complete && v.naturalWidth) { const k = Math.min(cs * 0.9 / v.naturalWidth, cs * 0.9 / v.naturalHeight); g.drawImage(v, (m.x + 0.5) * cs - v.naturalWidth * k / 2, (m.y + 0.95) * cs - v.naturalHeight * k, v.naturalWidth * k, v.naturalHeight * k); }
            else emoji('🧊', m.x, m.y);
            const r = (m.rot == null ? 90 : m.rot) * Math.PI / 180, cx = (m.x + 0.5) * cs, cy = (m.y + 0.5) * cs;
            g.strokeStyle = '#7b61ff'; g.lineWidth = 2.5; g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + Math.cos(r) * cs * 0.45, cy + Math.sin(r) * cs * 0.45); g.stroke();
            const fp = Explorer3D.footprint(m, a);
            if (fp.length > 1) {
                g.fillStyle = 'rgba(123,97,255,.16)'; g.strokeStyle = 'rgba(123,97,255,.7)'; g.lineWidth = 1.5;
                fp.forEach(([fx, fy]) => { g.fillRect(fx * cs + 1, fy * cs + 1, cs - 2, cs - 2); g.strokeRect(fx * cs + 1.5, fy * cs + 1.5, cs - 3, cs - 3); });
            }
            if (m.drive || m.walk) emoji(m.walk ? '🚶' : '↻', m.x + 0.3, m.y - 0.3, 0.4);
            if (m.solid === false) { g.setLineDash([4, 3]); g.strokeStyle = '#7b61ff'; g.strokeRect(m.x * cs + 2, m.y * cs + 2, cs - 4, cs - 4); g.setLineDash([]); }
            if (this.sel && this.sel.kind === 'model' && this.sel.i === i) this.ring(m.x, m.y, cs);
        });
        this.L.items.forEach((it, i) => {
            const im = it.img && this.itemImg(it.img);
            if (im && im.complete && im.naturalWidth) { const k = Math.min(cs * 0.8 / im.naturalWidth, cs * 0.8 / im.naturalHeight); g.drawImage(im, (it.x + 0.5) * cs - im.naturalWidth * k / 2, (it.y + 0.5) * cs - im.naturalHeight * k / 2, im.naturalWidth * k, im.naturalHeight * k); }
            else emoji(it.target === false ? '✖' : (it.name && [...it.name].length <= 2 ? it.name : '🍎'), it.x, it.y);
            if (it.target === false) { g.strokeStyle = '#e04848'; g.lineWidth = 3; g.strokeRect(it.x * cs + 3, it.y * cs + 3, cs - 6, cs - 6); }
            if (this.sel && this.sel.kind === 'item' && this.sel.i === i) this.ring(it.x, it.y, cs);
        });
        this.L.questions.forEach((q, i) => {
            g.fillStyle = '#2080a0'; g.beginPath(); g.arc((q.x + 0.5) * cs, (q.y + 0.5) * cs, cs * 0.34, 0, 7); g.fill();
            g.fillStyle = '#fff'; g.font = 'bold ' + Math.round(cs * 0.45) + 'px Arial'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('?', (q.x + 0.5) * cs, (q.y + 0.53) * cs);
            if (q.reward && Explorer3D.DOORS[q.reward.color]) { g.fillStyle = Explorer3D.DOORS[q.reward.color].color; g.beginPath(); g.arc((q.x + 0.82) * cs, (q.y + 0.2) * cs, cs * 0.14, 0, 7); g.fill(); g.strokeStyle = '#fff'; g.lineWidth = 2; g.stroke(); }
            if (this.sel && this.sel.kind === 'question' && this.sel.i === i) this.ring(q.x, q.y, cs);
        });
        (this.L.plates || []).forEach((p, i) => {
            const D = Explorer3D.DOORS[p.color], cx = (p.x + 0.5) * cs, cy = (p.y + 0.5) * cs;
            g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(cx, cy + cs * 0.05, cs * 0.4, cs * 0.3, 0, 0, 7); g.fill();
            g.fillStyle = D.color; g.beginPath(); g.ellipse(cx, cy, cs * 0.38, cs * 0.28, 0, 0, 7); g.fill();
            g.strokeStyle = '#fff'; g.lineWidth = 2; g.stroke();
            if (p.needBox) emoji('📦', p.x, p.y, 0.36);
            if (this.sel && this.sel.kind === 'plate' && this.sel.i === i) this.ring(p.x, p.y, cs);
        });
        this.L.keys.forEach((k, i) => {
            const ki = this.keyTex && this.keyTex[k.color];
            if (ki) g.drawImage(ki, k.x * cs + cs * 0.08, k.y * cs + cs * 0.08, cs * 0.84, cs * 0.84);
            if (this.sel && this.sel.kind === 'key' && this.sel.i === i) this.ring(k.x, k.y, cs);
        });
        this.L.hints.forEach((h, i) => {
            emoji({ note: '📜', compass: '🧭', map: '🗺️', pick: '⛏️' }[h.type] || '📜', h.x, h.y, 0.62);
            if (this.sel && this.sel.kind === 'hint' && this.sel.i === i) this.ring(h.x, h.y, cs);
        });
        /* em cima de blocos: um ⬆ pequeno, a dizer a que altura está */
        const up = (e) => { const lv = this.levelAt(e.x, e.y); if (lv > 0) { g.fillStyle = '#2080a0'; g.font = 'bold ' + Math.round(cs * 0.24) + 'px Arial'; g.textAlign = 'left'; g.textBaseline = 'top'; g.fillText('⬆' + lv, e.x * cs + 2, e.y * cs + 1); } };
        [...this.L.items, ...this.L.questions, ...this.L.keys, ...this.L.hints, ...this.L.models].forEach(up);
        if (this.L.exit) up(this.L.exit);
        const s = this.L.start, a = [0, Math.PI / 2, Math.PI, -Math.PI / 2][s.dir || 0], cx = (s.x + 0.5) * cs, cy = (s.y + 0.5) * cs;
        g.fillStyle = '#d64545'; g.beginPath();
        g.moveTo(cx + Math.cos(a) * cs * 0.4, cy + Math.sin(a) * cs * 0.4);
        g.lineTo(cx + Math.cos(a + 2.4) * cs * 0.32, cy + Math.sin(a + 2.4) * cs * 0.32);
        g.lineTo(cx + Math.cos(a - 2.4) * cs * 0.32, cy + Math.sin(a - 2.4) * cs * 0.32);
        g.closePath(); g.fill();
    }
    ring(x, y, cs) { const g = this.g; g.strokeStyle = 'rgba(255,255,255,.95)'; g.lineWidth = 6; g.strokeRect(x * cs, y * cs, cs, cs); g.strokeStyle = '#ff7a00'; g.lineWidth = 3; g.strokeRect(x * cs, y * cs, cs, cs); }
    itemImg(src) {
        if (!this.imgCache[src]) { const im = new Image(); im.onload = () => this.draw(); im.src = src; this.imgCache[src] = im; }
        return this.imgCache[src];
    }

    stats() {
        const t = this.L.items.filter((i) => i.target !== false).length, d = this.L.items.length - t;
        const doors = new Set(this.L.map.join('').replace(/[^A-D]/g, '').split('').filter(Boolean));
        const keys = new Set([...this.L.keys.map((k) => k.color), ...this.L.questions.filter((q) => q.reward).map((q) => q.reward.color)]);
        const lock = [...doors].filter((c) => !keys.has(c)).map((c) => Explorer3D.DOORS[c].name.toLowerCase());
        document.getElementById('stats').textContent = `${this.L.w}×${this.L.h} · 🧊 ${this.L.models.length} · 🍎 ${t}${d ? ' (+' + d + ' ✖)' : ''} · ❓ ${this.L.questions.length} · 🔑 ${this.L.keys.length} · 💡 ${this.L.hints.length} · ${this.L.exit ? '🏁' : 'sem saída'}`
            + (lock.length ? ' · ⚠ porta sem chave: ' + lock.join(', ') : '')
            + (this.L.map.join('').includes('S') && !this.L.hints.some((h) => h.type === 'pick') ? ' · ⚠ há blocos que se partem sem picareta' : '')
            + ((this.L.plates || []).length ? ' · 🔘 ' + this.L.plates.length : '')
            + (this.unreachableUp() ? ' · ⚠ há coisas em cima de blocos aonde não se chega' : '');
    }

    unreachableUp() {
        const ents = [...this.L.items, ...this.L.questions, ...this.L.keys, ...this.L.hints].filter((e) => this.levelAt(e.x, e.y) > 0);
        if (!ents.length) return false;
        if (!this.L.sky) return true;
        const crates = this.L.map.join('').includes('T') || Object.values(this.L.stack || {}).join('').includes('T');
        const r = Explorer3D.reachable(this.L, crates ? 1 : 0);
        return ents.some((e) => !r.has(e.x + ',' + e.y + ',' + this.levelAt(e.x, e.y)));
    }

    /* ---------- selected object / question ---------- */

    showSel() {
        const box = document.getElementById('selBox'), body = document.getElementById('selBody'), title = document.getElementById('selTitle');
        const s = this.sel;
        const list = s && { item: this.L.items, question: this.L.questions, key: this.L.keys, hint: this.L.hints, model: this.L.models, plate: this.L.plates || [] }[s.kind];
        /* à direita: as propriedades do que está selecionado; sem seleção, as tabs do nível */
        const lv = document.getElementById('lvBox');
        if (!s || !list || !list[s.i]) { box.hidden = true; if (lv) lv.hidden = false; return; }
        box.hidden = false; if (lv) lv.hidden = true;
        body.innerHTML = '';
        const el = (h) => { const d = document.createElement('div'); d.innerHTML = h; return d.firstElementChild; };
        const imgPick = (cur, onPick, onClear) => {
            const wrap = document.createElement('div');
            wrap.style.display = 'flex'; wrap.style.flexDirection = 'column'; wrap.style.gap = '6px';
            if (cur) { const im = document.createElement('img'); im.className = 'thumb'; im.src = cur; wrap.append(im); }
            const l = el('<label class="file-btn">🖼 ' + (cur ? 'Mudar a imagem…' : 'Escolher imagem…') + '<input type="file" accept="image/*" hidden></label>');
            l.querySelector('input').onchange = async (e) => { const f = e.target.files[0]; if (f) { await onPick(f); this.draw(); this.showSel(); } };
            wrap.append(l);
            if (window.MQHost && MQHost.has('PickImage')) {
                const h = el('<button type="button" class="mini">🙂 Clipart / internet / 3D…</button>');
                h.onclick = async () => { const f = await this.hostImage(1024); if (f) { await onPick(f); this.draw(); this.showSel(); } };
                wrap.append(h);
            }
            if (cur) { const b = el('<button type="button" class="mini">Sem imagem</button>'); b.onclick = () => { onClear(); this.draw(); this.showSel(); }; wrap.append(b); }
            return wrap;
        };
        const del = el('<button type="button" class="mini danger">🗑 Apagar</button>');
        {   /* onde está: a casela e a altura (no chão ou em cima de blocos) */
            const e = list[s.i], lv = this.levelAt(e.x, e.y);
            const w = el('<p class="where"></p>');
            w.textContent = '📍 Coluna ' + (e.x + 1) + ', linha ' + (e.y + 1) + ' · ' + (lv > 0 ? '⬆ em cima de blocos (altura ' + lv + ')' : 'no chão');
            body.append(w);
        }
        if (s.kind === 'plate') {
            const pl = this.L.plates[s.i];
            title.textContent = '🔘 Plataforma';
            const sel = el('<label class="row">Abre as portas <select></select></label>');
            for (const [c, d] of Object.entries(Explorer3D.DOORS)) { const o = document.createElement('option'); o.value = c; o.textContent = d.name; sel.querySelector('select').append(o); }
            sel.querySelector('select').value = pl.color;
            sel.querySelector('select').onchange = (e) => { pl.color = e.target.value; this.draw(); this.stats(); };
            const nb = el('<label class="ck"><input type="checkbox"> 📦 Só com um bloco empurrado para cima dela</label>');
            nb.querySelector('input').checked = !!pl.needBox;
            nb.querySelector('input').onchange = (e) => { pl.needBox = e.target.checked; this.draw(); this.stats(); };
            body.append(sel, nb, el('<p class="hint">Ao pisá-la (ou, com 📦, ao empurrar-lhe um bloco 📦 para cima) abrem-se de vez todas as portas desta cor.</p>'));
            del.onclick = () => { this.L.plates.splice(s.i, 1); this.sel = null; this.draw(); this.showSel(); this.stats(); };
        } else if (s.kind === 'key') {
            const k = this.L.keys[s.i];
            title.textContent = '🔑 Chave';
            const sel = el('<label class="row">Cor <select></select></label>');
            for (const [c, d] of Object.entries(Explorer3D.DOORS)) { const o = document.createElement('option'); o.value = c; o.textContent = d.name; sel.querySelector('select').append(o); }
            sel.querySelector('select').value = k.color;
            sel.querySelector('select').onchange = (e) => { k.color = e.target.value; this.draw(); this.stats(); };
            body.append(sel, el('<p class="hint">Abre as portas da mesma cor.</p>'));
            del.onclick = () => { this.L.keys.splice(s.i, 1); this.sel = null; this.draw(); this.showSel(); this.stats(); };
        } else if (s.kind === 'hint') {
            const h = this.L.hints[s.i];
            title.textContent = '💡 Pista';
            const sel = el('<label class="row">Tipo <select><option value="note">📜 Nota</option><option value="compass">🧭 Bússola</option><option value="map">🗺️ Mapa</option><option value="pick">⛏️ Picareta</option></select></label>');
            sel.querySelector('select').value = h.type;
            sel.querySelector('select').onchange = (e) => { h.type = e.target.value; this.draw(); this.showSel(); };
            body.append(sel);
            if (h.type === 'note') {
                const tx = el('<textarea placeholder="Texto da pista (ex.: «A chave está perto da janela»)"></textarea>');
                tx.value = h.text || ''; tx.oninput = () => { h.text = tx.value; };
                body.append(tx, imgPick(h.img, async (f) => { h.img = await this.shrink(f, 640, 'image/jpeg'); }, () => { h.img = ''; }));
                body.append(this.audioRow(() => h.audio, (v) => { h.audio = v; }));
                body.append(el('<p class="hint">Aparece ao apanhar a pista e pode voltar a ler-se no 📜 em cima.</p>'));
            } else body.append(el('<p class="hint">' + (h.type === 'compass' ? 'Depois de a apanhar, uma seta em cima aponta sempre para a saída.' : 'Depois de o apanhar, aparece o mapa pequeno (desligue «Mostrar o mapa pequeno» no nível).') + '</p>'));
            del.onclick = () => { this.L.hints.splice(s.i, 1); this.sel = null; this.draw(); this.showSel(); this.stats(); };
        } else if (s.kind === 'model') {
            const m = this.L.models[s.i], a = this.L.assets[m.asset] || {};
            title.textContent = '🧊 ' + (a.name || 'Modelo 3D');
            if (a.views && a.views[0]) { const im = document.createElement('img'); im.className = 'thumb mthumb'; im.src = a.views[0]; body.append(im); }
            /* um formulário arrumado: etiqueta à esquerda, controlo à direita */
            const form = el('<div class="pform"></div>');
            const line = (label, ctl) => { const r = el('<div class="prow"><span class="plab"></span><span class="pctl"></span></div>'); r.firstChild.textContent = label; r.lastChild.append(ctl); form.append(r); return r; };
            const rotC = el('<span class="seg"><button type="button" class="mini" title="Rodar para a esquerda">⟲</button><b></b><button type="button" class="mini" title="Rodar para a direita">⟳</button></span>');
            const [rl, rv, rr] = rotC.querySelectorAll('button, b');
            const showRot = () => { rv.textContent = ['→', '↘', '↓', '↙', '←', '↖', '↑', '↗'][Math.round(((m.rot == null ? 90 : m.rot) % 360) / 45) % 8]; };
            rl.onclick = () => { this.tryModel(m, s.i, () => { m.rot = ((m.rot == null ? 90 : m.rot) + 315) % 360; }); showRot(); this.draw(); };
            rr.onclick = () => { this.tryModel(m, s.i, () => { m.rot = ((m.rot == null ? 90 : m.rot) + 45) % 360; }); showRot(); this.draw(); };
            showRot();
            line('Direção', rotC);
            const szC = el('<span class="seg grow"><input type="range" min="0.1" max="4" step="0.05"><b class="val"></b></span>');
            const szIn = szC.querySelector('input'), szv = szC.querySelector('b');
            const showSz = () => { szv.textContent = (Math.round((m.size || 0.8) * 1.75 / 0.8 * 10) / 10) + ' m'; };
            szIn.value = m.size || 0.8;
            szIn.oninput = (e) => { if (!this.tryModel(m, s.i, () => { m.size = +e.target.value; })) e.target.value = m.size || 0.8; showSz(); this.draw(); };
            showSz();
            line('Altura', szC);
            const real = el('<button type="button" class="mini" title="O tamanho real deste modelo (uma pessoa = 1,75 m)">📏 Escala real</button>');
            real.onclick = () => { this.tryModel(m, s.i, () => { m.size = Explorer3D.realSize(m.asset, a.cat); }); szIn.value = m.size; showSz(); this.draw(); };
            line('', real);
            if (a.anims && a.anims.length) {
                const an = el('<select></select>');
                an.append(new Option('Parado', ''));
                a.anims.forEach((n) => an.append(new Option(n, n)));
                an.value = m.anim || '';
                an.onchange = (e) => { m.anim = e.target.value; };
                line('Animação', an);
            }
            /* o som do próprio modelo (uma fonte, um rádio, um cão…): só um ficheiro, que se repete; ouve-se mais forte perto */
            line('Som', this.audioRow(() => m.sound, (v) => { m.sound = v; }, { rec: false, pick: '📁 Ficheiro…' })).title = 'Repete-se e ouve-se mais forte perto do modelo e do lado em que está';
            body.append(form);
            const opts = el('<div class="pchecks"></div>');
            const so = el('<label class="ck"><input type="checkbox"> Bloqueia a passagem</label>');
            so.querySelector('input').checked = m.solid !== false;
            so.querySelector('input').onchange = (e) => { m.solid = e.target.checked; this.draw(); };
            opts.append(so);
            /* só circulam carros (pelo asfalto, pela direita) e pessoas (pelo passeio, atravessando nas passadeiras) */
            const isCar = a.cat === 'transport' && !/boat|barco|plane|avi/i.test(m.asset + ' ' + (a.name || ''));
            const isPerson = Explorer3D.walks(a);
            if (isCar) {
                const dr = el('<label class="ck"><input type="checkbox"> 🚗 Circula pelo asfalto</label>');
                dr.title = 'Anda pela direita; segue a rua e só vira nos cruzamentos ou no fim da estrada. Para quando alguém está à frente ou a atravessar na passadeira.';
                dr.querySelector('input').checked = !!m.drive;
                dr.querySelector('input').onchange = (e) => { m.drive = e.target.checked; if (m.drive && !this.onRoad(m.x, m.y)) this.say('Ponha-o numa casela de asfalto.', true); this.draw(); };
                opts.append(dr);
            } else if (isPerson) {
                const wk = el('<label class="ck"><input type="checkbox"> 🚶 Passeia pelo passeio</label>');
                wk.title = 'Anda pelo passeio ao acaso e atravessa a rua só nas passadeiras (aí os carros esperam).';
                wk.querySelector('input').checked = !!m.walk;
                wk.querySelector('input').onchange = (e) => {
                    m.walk = e.target.checked; m.drive = false;
                    const g = (this.L.ground || {})[m.x + ',' + m.y];
                    if (m.walk && g !== 'p' && g !== 'z') this.say('Ponha-a numa casela de passeio.', true);
                    if (m.walk && !m.anim) m.anim = (a.anims || []).find((n) => /walk|andar|camin|marche|gehen|cammin/i.test(n)) || m.anim;
                    this.draw(); this.showSel();
                };
                opts.append(wk);
            }
            body.append(opts);
            del.onclick = () => { this.L.models.splice(s.i, 1); this.sel = null; this.draw(); this.showSel(); this.stats(); };
        } else if (s.kind === 'item') {
            const it = this.L.items[s.i];
            title.textContent = '🍎 Objeto';
            const name = el('<input type="text" placeholder="Nome (aparece se não houver imagem)">');
            name.value = it.name || ''; name.oninput = () => { it.name = name.value; };
            body.append(name, imgPick(it.img, async (f) => { it.img = await this.shrink(f, 256, 'image/png'); }, () => { it.img = ''; }));
            /* a mensagem que aparece ao apanhá-lo — o áudio vai com ela (só onde há texto) */
            const msg = el('<textarea rows="2" placeholder="Mensagem ao apanhar (opcional)"></textarea>');
            msg.value = it.msg || ''; msg.oninput = () => { it.msg = msg.value; };
            body.append(msg, this.audioRow(() => it.audio, (v) => { it.audio = v; }));
            const mb = el('<button type="button" class="mini">🧊 ' + (it.asset ? 'Mudar o modelo 3D…' : 'Usar um modelo 3D…') + '</button>');
            mb.onclick = () => this.pickModel('item:' + s.i);
            body.append(mb);
            if (it.asset) {
                const a = this.L.assets[it.asset] || {};
                const nb = el('<button type="button" class="mini">Sem modelo (' + (a.name || '') + ')</button>');
                nb.onclick = () => { delete it.asset; this.draw(); this.showSel(); };
                body.append(nb);
            }
            const ck = el('<label class="ck"><input type="checkbox"> Objeto a recolher (se não, é um distrator: apanhá-lo conta como erro)</label>');
            ck.querySelector('input').checked = it.target !== false;
            ck.querySelector('input').onchange = (e) => { it.target = e.target.checked; this.draw(); this.stats(); };
            body.append(ck);
            del.onclick = () => { this.L.items.splice(s.i, 1); this.sel = null; this.draw(); this.showSel(); this.stats(); };
        } else {
            const q = this.L.questions[s.i];
            title.textContent = '❓ Pergunta';
            const tx = el('<textarea placeholder="Texto da pergunta"></textarea>');
            tx.value = q.text || ''; tx.oninput = () => { q.text = tx.value; };
            body.append(tx, imgPick(q.img, async (f) => { q.img = await this.shrink(f, 640, 'image/jpeg'); }, () => { q.img = ''; }));
            body.append(this.audioRow(() => q.audio, (v) => { q.audio = v; }));
            const opts = document.createElement('div'); opts.style.display = 'flex'; opts.style.flexDirection = 'column'; opts.style.gap = '6px';
            const drawOpts = () => {
                opts.innerHTML = '<span class="hint">Respostas (marque a certa; sem respostas = só informação, com ✔)</span>';
                q.options.forEach((o, k) => {
                    const r = el('<div class="opt"><input type="radio" name="qc"><input type="text" placeholder="Resposta"><button type="button" class="mini">✕</button></div>');
                    const [radio, text, rm] = r.children;
                    radio.checked = !!o.correct;
                    radio.onchange = () => { q.options.forEach((x, j) => { x.correct = j === k; }); };
                    text.value = o.text || ''; text.oninput = () => { o.text = text.value; };
                    rm.onclick = () => { q.options.splice(k, 1); drawOpts(); };
                    opts.append(r);
                });
                const add = el('<button type="button" class="mini">＋ Resposta</button>');
                add.onclick = () => { q.options.push({ text: '', correct: !q.options.length }); drawOpts(); };
                opts.append(add);
            };
            drawOpts();
            body.append(opts);
            const rw = el('<label class="row">Ao acertar <select><option value="">—</option></select></label>');
            const rs = rw.querySelector('select');
            for (const [c, d] of Object.entries(Explorer3D.DOORS)) {
                const a = document.createElement('option'); a.value = 'key:' + c; a.textContent = '🔑 Dá a chave ' + d.name.toLowerCase(); rs.append(a);
                const b = document.createElement('option'); b.value = 'open:' + c; b.textContent = '🔓 Abre as portas ' + d.name.toLowerCase() + 's'; rs.append(b);
            }
            rs.value = q.reward ? q.reward.type + ':' + q.reward.color : '';
            rs.onchange = () => { const [t, c] = rs.value.split(':'); if (t) q.reward = { type: t, color: c }; else delete q.reward; this.draw(); this.stats(); };
            body.append(rw, el('<p class="hint">Com recompensa, uma resposta errada deixa a pergunta por responder: volta a aparecer ao pisar outra vez o «?».</p>'));
            del.onclick = () => { this.L.questions.splice(s.i, 1); this.sel = null; this.draw(); this.showSel(); this.stats(); };
        }
        const foot = el('<div class="pfoot"></div>'); const done = el('<button type="button" class="mini done">✔ Feito</button>'); done.onclick = () => { this.sel = null; this.draw(); this.showSel(); }; foot.append(del, done); body.append(foot);
    }

    /* ---------- 3D models: the MQ Creator's library (plugin contract service «PickModel») ---------- */

    /* an image chosen with MQ Creator's picker (clipart, internet search, photo of a 3D model, file), as a File */
    async hostImage(max) {
        const r = await MQHost.pickImage({ max, png: true });
        if (!r || !r.img) return null;
        const [head, b64] = r.img.split(','), type = (head.match(/data:([^;]+)/) || [])[1] || 'image/png';
        const bin = atob(b64), u = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
        return new File([u], (r.name || 'imagem') + (type === 'image/png' ? '.png' : '.jpg'), { type });
    }

    async pickModel(req) {
        /* MQ Creator answers PickModel with its 3D library (contract service); outside it there is no library */
        if (!(window.MQHost && MQHost.has('PickModel'))) { this.say('Os modelos 3D escolhem-se no MQ Creator.', true); return; }
        this.say('🧊 …');
        const r = await MQHost.pickModel({ glb: true, views: 8, size: 256 });
        this.onPicked(r, req);
    }

    onPicked(r, reqIn) {
        if (!r || !r.views || !r.views.length) { this.say(''); return; }
        const id = String(r.id || r.name || 'modelo').replace(/[^a-z0-9_-]+/gi, '_').slice(0, 40) || 'modelo';
        this.L.assets[id] = { name: r.name || id, glb: r.glb || '', views: r.views, anims: r.anims || [], h: r.h || 1.6, cat: r.cat || '' };
        this.measure(id);
        const req = String(reqIn || 'model');
        if (req.startsWith('item:')) { const it = this.L.items[+req.slice(5)]; if (it) it.asset = id; }
        else if (req === 'avatar') {
            if (!r.glb) { this.say('Este modelo não tem ficheiro 3D.', true); return; }
            if (!Explorer3D.walks(this.L.assets[id])) { this.say('Esta personagem não tem animação de andar: não serve para a 3.ª pessoa (fica a 1.ª pessoa).', true); this.refreshAvatars(); return; }
            this.L.avatars = (this.L.avatars || []).filter((a) => a !== id).concat(id).slice(-6);
            if (this.L.camera !== '3rd') { this.L.camera = '3rd'; document.getElementById('lvCam').value = '3rd'; }
            this.refreshAvatars();
        }
        else { this.tool = 'model:' + id; this.markTool(); }
        this.refreshAssets();
        this.draw();
        this.showSel();
        this.stats();
        this.say('🧊 ' + (r.name || id));
    }

    /** a random city: streets two cells wide (dashed line), zebra crossings at the corners, sidewalks, grass, houses,
        trees and cars at real scale (from MQ Creator's library) and errands (objects) on the sidewalks */
    async makeCity() {
        const $ = (id) => document.getElementById(id), num = (id, d) => { const v = Math.round(+$(id).value); return Number.isFinite(v) ? v : d; };
        const N = Math.max(16, Math.min(64, $('cySize').value === 'custom' ? num('cySizeN', 40) : num('cySize', 28))), nHouse = num('cyHouses', 4), nCar = num('cyCars', 3), nTree = num('cyTrees', 6), nErr = num('cyErr', 3);
        const R = (n) => Math.floor(Math.random() * n), pick = (a) => a[R(a.length)];
        const bandsOf = () => { const out = []; let p = 2 + R(3); while (p + 1 <= N - 3) { out.push(p); p += 2 + 7 + R(6); } return out; };
        const bx = bandsOf(), by = bandsOf();
        const L = this.blank(N, N), g = {}, k = (x, y) => x + ',' + y;
        /* as ruas: não uma quadrícula — uma árvore ao acaso de ruas entre os cruzamentos possíveis (curvas, ruas sem saída, entroncamentos),
           mais umas ligações a fazer voltas (quarteirões); às vezes uma rua acaba a meio (beco) */
        const NX = bx.length, NY = by.length, id = (i, j) => j * NX + i, E = [];
        for (let j = 0; j < NY; j++) for (let i = 0; i < NX; i++) { if (i + 1 < NX) E.push([id(i, j), id(i + 1, j)]); if (j + 1 < NY) E.push([id(i, j), id(i, j + 1)]); }
        E.sort(() => Math.random() - 0.5);
        const par = [...Array(NX * NY).keys()], root = (a) => (par[a] === a ? a : (par[a] = root(par[a])));
        const edges = [], spare = [];
        for (const e of E) { const ra = root(e[0]), rb = root(e[1]); if (ra !== rb) { par[ra] = rb; edges.push(e); } else spare.push(e); }
        spare.forEach((e) => { if (Math.random() < 0.3) edges.push(e); });
        /* umas pontas ficam a meio do caminho: becos sem saída */
        const deg = new Array(NX * NY).fill(0);
        edges.forEach(([a0, b0]) => { deg[a0]++; deg[b0]++; });
        const half = new Set();
        edges.forEach((e, n) => { const leaf = deg[e[0]] === 1 ? e[0] : deg[e[1]] === 1 ? e[1] : -1; if (leaf >= 0 && Math.random() < 0.45) { half.add(n); e.leaf = leaf; } });
        const pos = (n) => [bx[n % NX], by[Math.floor(n / NX)]];
        const paint = (x, y) => { if (x > 0 && y > 0 && x < N - 1 && y < N - 1) g[k(x, y)] = 'a'; };
        edges.forEach((e, n) => {
            let [x0, y0] = pos(e[0]), [x1, y1] = pos(e[1]);
            if (half.has(n)) { const [lx, ly] = pos(e.leaf), [ox, oy] = pos(e.leaf === e[0] ? e[1] : e[0]); [x0, y0] = [ox, oy]; [x1, y1] = [Math.round((lx + ox) / 2), Math.round((ly + oy) / 2)]; }
            for (let y = Math.min(y0, y1); y <= Math.max(y0, y1) + 1; y++) for (let x = Math.min(x0, x1); x <= Math.max(x0, x1) + 1; x++) paint(x, y);
        });
        const isRoad = (x, y) => g[k(x, y)] === 'a';
        for (let y = 1; y < N - 1; y++) for (let x = 1; x < N - 1; x++) {
            if (g[k(x, y)]) continue;
            let near = false;
            for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if (isRoad(x + dx, y + dy)) near = true;
            g[k(x, y)] = near ? 'p' : 'g';
        }
        /* passadeiras: à saída dos cruzamentos e entroncamentos (três ou quatro braços) */
        for (const r of by) for (const c of bx) {
            if (!isRoad(c, r)) continue;
            const arms = [[c - 1, r, 'h'], [c + 2, r, 'h'], [c, r - 1, 'v'], [c, r + 2, 'v']].filter(([x, y]) => isRoad(x, y));
            if (arms.length < 3) continue;
            for (const [x, y, o] of arms) { if (o === 'h') { g[k(x, y)] = 'z'; if (isRoad(x, y + 1)) g[k(x, y + 1)] = 'z'; } else { g[k(x, y)] = 'z'; if (isRoad(x + 1, y)) g[k(x + 1, y)] = 'z'; } }
        }
        const roadX = (x) => bx.some((b) => x === b || x === b + 1), roadY = (y) => by.some((b) => y === b || y === b + 1);
        const cells = (t) => Object.entries(g).filter(([, v]) => v === t).map(([kk]) => kk.split(',').map(Number));
        /* os modelos vêm primeiro (uma vez por sessão): é preciso saber o tamanho de cada casa para a pôr na relva */
        const host = !!(window.MQHost && MQHost.has('PickModel'));
        const LIB = { house: ['house1', 'house-3'], tree: ['tree-big', 'palm-short'], car: ['taxi', 'police-car', 'van', 'ambulance'] };
        this.libCache = this.libCache || {};
        if (host) {
            for (const id of [...LIB.house, ...LIB.tree, ...LIB.car]) {
                if (this.libCache[id] !== undefined) continue;
                this.say('🏙️ ' + id + '…');
                const r = await MQHost.pickModel({ id, glb: true, views: 8, size: 256 });
                const a = r && r.views ? { name: r.name || id, glb: r.glb || '', views: r.views, anims: r.anims || [], h: r.h || 1.6, cat: r.cat || '' } : null;
                if (a) { const keep = this.L.assets[id]; this.L.assets[id] = a; await this.measure(id); if (keep) this.L.assets[id] = keep; else delete this.L.assets[id]; }
                this.libCache[id] = a;
            }
        }
        const lib = (id) => this.libCache[id] || null;
        const used = new Set(), box = (x, y, r) => { for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) if (used.has(k(x + dx, y + dy))) return false; return true; };
        const mark = (x, y, r) => { for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) used.add(k(x + dx, y + dy)); };
        /* casas: todas as caselas que ocupam são relva livre, viradas para a rua mais perto */
        const houses = [], grass = cells('g');
        for (let t = 0; t < 600 && houses.length < nHouse; t++) {
            const [x, y] = pick(grass), id = pick(LIB.house), a = lib(id);
            const dist = (dx, dy) => { for (let s = 1; s < N; s++) { const c = g[k(x + dx * s, y + dy * s)]; if (!c || c === 'a' || c === 'z') return s; } return N; };
            const rot = [[0, 1, 0], [90, 0, 1], [180, -1, 0], [270, 0, -1]].map(([r0, dx, dy]) => [r0, dist(dx, dy)]).sort((p, q) => p[1] - q[1])[0][0];
            const m = { x, y, asset: id, rot, size: Explorer3D.realSize(id, a ? a.cat : 'places') };
            const fp = a ? Explorer3D.footprint(m, a) : [[x - 1, y - 1], [x + 1, y + 1], [x, y]];
            if (!fp.every(([fx, fy]) => g[k(fx, fy)] === 'g' && !used.has(k(fx, fy)))) continue;
            houses.push([id, x, y, rot]);
            fp.forEach(([fx, fy]) => mark(fx, fy, 1));
        }
        const trees = [];
        for (let t = 0; t < 400 && trees.length < nTree; t++) {
            const [x, y] = pick(grass);
            if (!box(x, y, 0)) continue;
            trees.push([pick(['tree-big', 'tree-big', 'palm-short']), x, y, R(4) * 90]);
            mark(x, y, 0);
        }
        const cars = [], asphalt = cells('a');
        for (let t = 0; t < 400 && cars.length < nCar; t++) {
            const [x, y] = pick(asphalt);
            if (!box(x, y, 1)) continue;
            const rd = (xx, yy) => g[k(xx, yy)] === 'a' || g[k(xx, yy)] === 'z';
            const horiz = (rd(x - 1, y) && rd(x + 1, y)) && !(rd(x, y - 1) && rd(x, y + 1) && rd(x, y - 2) + rd(x, y + 2) > 0);
            cars.push([pick(LIB.car), x, y, horiz ? pick([0, 180]) : pick([90, 270])]);
            mark(x, y, 1);
        }
        const side = cells('p').filter(([x, y]) => !used.has(k(x, y)));
        const take = () => { for (let t = 0; t < 200; t++) { const c = pick(side); if (!used.has(k(c[0], c[1]))) { used.add(k(c[0], c[1])); return c; } } return null; };
        const start = take() || [1, 1];
        let exit = null, far = -1;
        for (const [x, y] of side) { const d = Math.abs(x - start[0]) + Math.abs(y - start[1]); if (!used.has(k(x, y)) && d > far) { far = d; exit = [x, y]; } }
        if (exit) used.add(k(exit[0], exit[1]));
        const icons = ['🍞', '🥛', '🍎', '💊', '📰', '🧀', '🍌', '✉️'].sort(() => Math.random() - 0.5);
        const items = [];
        for (let i = 0; i < nErr; i++) { const c = take(); if (c) items.push({ x: c[0], y: c[1], name: icons[i % icons.length], img: '', target: true }); }
        const sdir = [[1, 0], [0, 1], [-1, 0], [0, -1]].findIndex(([dx, dy]) => g[k(start[0] + dx, start[1] + dy)] === 'p');
        Object.assign(L, { ground: g, sky: true, floor: '#9fc77a', ceiling: '#8ec5f0', start: { x: start[0], y: start[1], dir: Math.max(0, sdir) },
            exit: exit ? { x: exit[0], y: exit[1] } : null, needAll: true, minimap: true, items });
        const keepAssets = this.L.assets || {}, keepAv = this.L.avatars || [], keepCam = this.L.camera;
        this.L = Explorer3D.normalize(L);
        this.L.images = {};
        /* as personagens escolhidas continuam */
        keepAv.forEach((id) => { if (keepAssets[id]) this.L.assets[id] = keepAssets[id]; });
        this.L.avatars = keepAv.filter((id) => keepAssets[id]); this.L.camera = keepCam || '1st';
        this.sel = null;
        this.refreshAll();
        if (!host) { this.say('Ruas feitas. As casas, as árvores e os carros vêm do MQ Creator.', true); return; }
        for (const [id, x, y, rot] of [...houses, ...trees, ...cars]) {
            const a = lib(id);
            if (!a) continue;
            if (!this.L.assets[id]) this.L.assets[id] = a;
            this.L.models.push({ x, y, asset: id, rot, size: Explorer3D.realSize(id, a.cat), anim: '', solid: true, drive: a.cat === 'transport' });
        }
        this.refreshAll();
        this.say('🏙️ Cidade pronta: ' + this.L.models.length + ' modelos.');
    }

    /** a random world of colour blocks: hills (a smooth height map), a maze, or towers joined by bridges.
        The way from the start to the exit (and to every object) is checked with the same rule as the game:
        one colour block (half a wall) up at a time, any height down. */
    makeWorld() {
        const $ = (id) => document.getElementById(id);
        const kind = $('wdKind').value, N = Math.max(10, Math.min(64, ($('wdSize').value === 'custom' ? +$('wdSizeN').value : +$('wdSize').value) || 20));
        const HM = Math.max(1, Math.min(8, Math.round(+$('wdH').value || 4))), nItems = Math.max(0, Math.min(10, Math.round(+$('wdItems').value || 0)));
        const R = (n) => Math.floor(Math.random() * n), pick = (a) => a[R(a.length)], k = (x, y) => x + ',' + y;
        const ramp = ['R', 'K', 'L', 'L', 'Q', 'F', 'F', 'E', 'E'];          /* areia, lima, verde, castanho, cinzento, branco */
        const bright = ['H', 'I', 'J', 'M', 'N', 'O', 'P', 'K'];
        for (let attempt = 0; attempt < 40; attempt++) {
            const L = this.blank(N, N);
            const h = [...Array(N)].map(() => Array(N).fill(0));       /* altura em blocos de cor (meias paredes) */
            const col = [...Array(N)].map(() => Array(N).fill(''));
            const wall = [...Array(N)].map(() => Array(N).fill(false));
            const stack = {};
            if (kind === 'hills') {
                let f = [...Array(N)].map(() => [...Array(N)].map(() => Math.random()));
                for (let it = 0; it < 4; it++) f = f.map((r, y) => r.map((_, x) => { let s = 0, c = 0; for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) { const v = f[y + dy] && f[y + dy][x + dx]; if (v != null) { s += v; c++; } } return s / c; }));
                /* alturas por percentil: há de tudo, de vales a cumes */
                const all = []; for (let y = 1; y < N - 1; y++) for (let x = 1; x < N - 1; x++) all.push(f[y][x]);
                all.sort((a, b) => a - b);
                const rank = (v) => { let lo = 0, hi = all.length - 1; while (lo < hi) { const m = (lo + hi) >> 1; if (all[m] < v) lo = m + 1; else hi = m; } return lo / Math.max(1, all.length - 1); };
                for (let y = 1; y < N - 1; y++) for (let x = 1; x < N - 1; x++) {
                    const t = rank(f[y][x]);
                    h[y][x] = Math.max(0, Math.round(t * (HM + 1.4) - 1));
                    col[y][x] = ramp[Math.min(ramp.length - 1, Math.round(h[y][x] / Math.max(1, HM) * (ramp.length - 1)))];
                }
            } else if (kind === 'maze') {
                /* labirinto «perfeito»: paredes de 2 blocos de altura (não se sobem) em caselas ímpares */
                for (let y = 1; y < N - 1; y++) for (let x = 1; x < N - 1; x++) wall[y][x] = !(x % 2 === 1 && y % 2 === 1);
                const seen = new Set(['1,1']), st = [[1, 1]];
                while (st.length) {
                    const [cx, cy] = st[st.length - 1];
                    const nb = [[2, 0], [-2, 0], [0, 2], [0, -2]].map(([dx, dy]) => [cx + dx, cy + dy, dx, dy]).filter(([x, y]) => x > 0 && y > 0 && x < N - 1 && y < N - 1 && !seen.has(k(x, y)));
                    if (!nb.length) { st.pop(); continue; }
                    const [nx, ny, dx, dy] = pick(nb);
                    wall[cy + dy / 2][cx + dx / 2] = false; seen.add(k(nx, ny)); st.push([nx, ny]);
                }
                /* algumas paredes a mais abertas: há mais do que um caminho */
                for (let i = 0; i < N; i++) { const x = 1 + R(N - 2), y = 1 + R(N - 2); if (wall[y][x] && (x % 2) !== (y % 2)) wall[y][x] = false; }
                const c0 = pick(bright);
                for (let y = 1; y < N - 1; y++) for (let x = 1; x < N - 1; x++) if (wall[y][x]) { h[y][x] = Math.max(2, Math.min(HM, 2 + R(2))); col[y][x] = Math.random() < 0.85 ? c0 : pick(bright); }
                /* degraus aqui e ali, para subir e ver o labirinto de cima */
                for (let i = 0; i < N / 3; i++) { const x = 1 + R(N - 2), y = 1 + R(N - 2); if (!wall[y][x] && h[y][x] === 0) { h[y][x] = 1; col[y][x] = 'J'; } }
            } else {
                /* torres de blocos, com escadas à volta, e pontes entre algumas delas */
                const towers = [];
                for (let t = 0; t < 300 && towers.length < Math.max(4, Math.round(N * N / 40)); t++) {
                    const x = 2 + R(N - 4), y = 2 + R(N - 4);
                    if (towers.some((o) => Math.abs(o.x - x) < 3 && Math.abs(o.y - y) < 3)) continue;
                    towers.push({ x, y, h: Math.max(Math.min(3, HM), Math.min(HM, 3 + R(HM))), c: pick(bright) });
                }
                for (const o of towers) {
                    h[o.y][o.x] = o.h; col[o.y][o.x] = o.c;
                    /* uma escada em caracol: cada degrau meio bloco mais baixo */
                    const around = [[1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1]], s0 = R(8);
                    for (let i = 0; i < o.h - 1 && i < 8; i++) {
                        const [dx, dy] = around[(s0 + i) % 8], x = o.x + dx, y = o.y + dy;
                        if (x < 1 || y < 1 || x > N - 2 || y > N - 2 || h[y][x]) continue;
                        h[y][x] = o.h - 1 - i; col[y][x] = o.c;
                    }
                }
                for (let i = 0; i + 1 < towers.length; i++) {
                    const a = towers[i], b = towers[i + 1];
                    if (Math.random() < 0.6 && a.y === b.y) continue;
                    /* ponte reta (por cima de chão livre), à altura de uma parede */
                    if (Math.abs(a.x - b.x) <= 6 && Math.random() < 0.7) {
                        const y = a.y;
                        for (let x = Math.min(a.x, b.x) + 1; x < Math.max(a.x, b.x); x++) if (!h[y][x] && !stack[k(x, y)]) stack[k(x, y)] = 'Q';
                    }
                }
            }
            /* o mapa: o bloco de baixo no chão e o resto empilhado (cada bloco de cor é meia parede) */
            for (let y = 1; y < N - 1; y++) for (let x = 1; x < N - 1; x++) {
                if (h[y][x] > 0) { L.map[y] = L.map[y].slice(0, x) + col[y][x] + L.map[y].slice(x + 1); if (h[y][x] > 1) stack[k(x, y)] = col[y][x].repeat(h[y][x] - 1); }
            }
            L.stack = stack;
            /* caminho: a mesma regra do jogo (sobe meio bloco de cada vez; desce o que for) */
            const H = (x, y) => (x <= 0 || y <= 0 || x >= N - 1 || y >= N - 1) ? 99 : h[y][x];
            const free0 = [];
            for (let y = 1; y < N - 1; y++) for (let x = 1; x < N - 1; x++) if (h[y][x] === 0) free0.push([x, y]);
            if (free0.length < 4 + nItems) continue;
            const start = pick(free0);
            const reach = new Set([k(start[0], start[1])]), q = [start];
            while (q.length) {
                const [x, y] = q.shift();
                for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
                    const nx = x + dx, ny = y + dy;
                    if (reach.has(k(nx, ny)) || H(nx, ny) - H(x, y) > 1 || H(nx, ny) >= 99) continue;
                    reach.add(k(nx, ny)); q.push([nx, ny]);
                }
            }
            const ok0 = free0.filter(([x, y]) => reach.has(k(x, y)) && !(x === start[0] && y === start[1]));
            if (ok0.length < 1 + nItems) continue;
            let exit = ok0[0], far = -1;
            ok0.forEach(([x, y]) => { const d = Math.abs(x - start[0]) + Math.abs(y - start[1]); if (d > far) { far = d; exit = [x, y]; } });
            const rest = ok0.filter(([x, y]) => !(x === exit[0] && y === exit[1])).sort(() => Math.random() - 0.5);
            const icons = ['⭐', '💎', '🍎', '🔔', '🎈', '🍀', '🪙', '🧩', '🎁', '🌸'].sort(() => Math.random() - 0.5);
            L.items = rest.slice(0, nItems).map(([x, y], i) => ({ x, y, name: icons[i % icons.length], img: '', target: true }));
            const sdir = [[1, 0], [0, 1], [-1, 0], [0, -1]].findIndex(([dx, dy]) => H(start[0] + dx, start[1] + dy) === 0);
            Object.assign(L, { start: { x: start[0], y: start[1], dir: Math.max(0, sdir) }, exit: { x: exit[0], y: exit[1] }, sky: true, view: '3d',
                floor: kind === 'hills' ? '#9fc77a' : '#d9cfb8', ceiling: '#8ec5f0', needAll: nItems > 0, minimap: true });
            const keepAssets = this.L.assets || {}, keepAv = this.L.avatars || [], keepCam = this.L.camera;
            this.L = Explorer3D.normalize(L);
            this.L.images = {};
            keepAv.forEach((id) => { if (keepAssets[id]) this.L.assets[id] = keepAssets[id]; });
            this.L.avatars = keepAv.filter((id) => keepAssets[id]); this.L.camera = keepCam || '1st';
            if ($('wdUp').checked && this.L.items.length) {
                /* metade dos objetos lá em cima (em topos de blocos a que se chega) */
                const r = Explorer3D.reachable(this.L), tops = [];
                for (let y = 1; y < N - 1; y++) for (let x = 1; x < N - 1; x++) { const lv = this.levelAt(x, y); if (lv > 0 && r.has(x + ',' + y + ',' + lv)) tops.push([x, y]); }
                tops.sort(() => Math.random() - 0.5);
                this.L.items.forEach((it, i) => { if (i % 2 === 0 && tops.length) { const [x, y] = tops.pop(); it.x = x; it.y = y; } });
            }
            this.sel = null;
            this.refreshAll();
            this.say('🎲 ' + ({ hills: 'Colinas', maze: 'Labirinto', towers: 'Torres e pontes' }[kind]) + ' · ' + N + '×' + N + ' · ' + L.items.length + ' objetos');
            return true;
        }
        this.say('Não saiu um mundo com caminho: experimente outra vez ou mude a altura.', true);
        return false;
    }

    refreshAvatars() {
        const box = document.getElementById('avatars');
        if (!box) return;
        box.innerHTML = '';
        /* só personagens que caminham; sem nenhuma, só a 1.ª pessoa */
        this.L.avatars = (this.L.avatars || []).filter((id) => Explorer3D.walks(this.L.assets[id]));
        const cam = document.getElementById('lvCam'), o3 = cam && cam.querySelector('option[value="3rd"]');
        if (o3) { o3.disabled = !this.L.avatars.length; o3.textContent = '🧍 3.ª pessoa' + (this.L.avatars.length ? '' : ' (precisa de uma personagem que caminhe)'); }
        if (!this.L.avatars.length && this.L.camera === '3rd') this.L.camera = '1st';
        if (cam) cam.value = this.L.camera === '3rd' ? '3rd' : '1st';
        (this.L.avatars || []).forEach((id) => {
            const a = this.L.assets[id];
            if (!a) return;
            const b = document.createElement('button');
            b.type = 'button'; b.className = 'sw'; b.title = (a.name || id) + ' — clique para tirar';
            if (a.views && a.views[0]) { b.style.backgroundImage = 'url(' + a.views[0] + ')'; b.style.backgroundSize = 'contain'; b.style.backgroundRepeat = 'no-repeat'; b.style.backgroundColor = '#fff'; }
            b.innerHTML = '<span>✕ ' + (a.name || id) + '</span>';
            b.onclick = () => { this.L.avatars = this.L.avatars.filter((x) => x !== id); this.refreshAvatars(); };
            b.innerHTML += '<em class="walk">🚶</em>';
            box.append(b);
        });
    }

    refreshAssets() {
        const box = document.getElementById('assets');
        if (!box) return;
        box.innerHTML = '';
        for (const [id, a] of Object.entries(this.L.assets || {})) {
            const b = document.createElement('button');
            b.type = 'button'; b.className = 'sw'; b.dataset.tool = 'model:' + id; b.title = a.name || id;
            if (a.views && a.views[0]) { b.style.backgroundImage = 'url(' + a.views[0] + ')'; b.style.backgroundSize = 'contain'; b.style.backgroundRepeat = 'no-repeat'; b.style.backgroundColor = '#fff'; }
            b.innerHTML = '<span>' + (a.name || id) + '</span>';
            box.append(b);
        }
        this.markTool();
    }

    /* ---------- level options ---------- */

    bindLevel() {
        const $ = (id) => document.getElementById(id);
        const resize = () => {
            const w = Math.max(5, Math.min(48, Math.round(+$('lvW').value || this.L.w))), h = Math.max(5, Math.min(48, Math.round(+$('lvH').value || this.L.h)));
            if (w === this.L.w && h === this.L.h) return;
            const old = this.L, nb = this.blank(w, h);
            for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) {
                const c = y < old.h - 1 && x < old.w - 1 ? old.map[y][x] : '0';
                nb.map[y] = nb.map[y].slice(0, x) + c + nb.map[y].slice(x + 1);
            }
            const ok = (p) => p && p.x < w - 1 && p.y < h - 1;
            const st = {};
            for (const [k, v] of Object.entries(old.stack || {})) { const [x, y] = k.split(',').map(Number); if (x < w && y < h) st[k] = v; }
            const gr = {};
            for (const [k, v] of Object.entries(old.ground || {})) { const [x, y] = k.split(',').map(Number); if (x < w && y < h) gr[k] = v; }
            Object.assign(old, { w, h, map: nb.map, stack: st, ground: gr, items: old.items.filter(ok), questions: old.questions.filter(ok), keys: old.keys.filter(ok), hints: old.hints.filter(ok), plates: (old.plates || []).filter(ok), models: old.models.filter(ok) });
            if (!ok(old.exit)) old.exit = null;
            if (!ok(old.start)) old.start = { x: 1, y: 1, dir: 0 };
            this.sel = null;
            this.refreshAll();
        };
        $('lvW').onchange = resize; $('lvH').onchange = resize;
        $('lvFloor').oninput = (e) => { this.L.floor = e.target.value; this.draw(); };
        $('lvCeil').oninput = (e) => { this.L.ceiling = e.target.value; };
        $('lvSpeed').oninput = (e) => { this.L.speed = +e.target.value; };
        $('lvTime').onchange = (e) => { this.L.timeLimit = Math.max(0, +e.target.value || 0); };
        $('lvNeed').onchange = (e) => { this.L.needAll = e.target.checked; };
        $('lvMini').onchange = (e) => { this.L.minimap = e.target.checked; };
        $('lvSfx').onchange = (e) => { this.L.sfx = e.target.checked; };
        $('lvSky').onchange = (e) => {
            this.L.sky = e.target.checked;
            if (this.L.sky && this.L.ceiling === '#dfe9f2') { this.L.ceiling = '#8ec5f0'; $('lvCeil').value = this.L.ceiling; }
        };
        $('pickModel').onclick = () => this.pickModel('model');
        $('lvCam').onchange = (e) => { this.L.camera = e.target.value; };
        $('worldBtn').onclick = () => this.makeWorld();
        $('cityBtn').onclick = () => {
            if (this.cityBusy) return;
            this.cityBusy = true;
            this.makeCity().catch((e) => { console.error(e); this.say('Não foi possível gerar a cidade.', true); }).finally(() => { this.cityBusy = false; });
        };
        const pa = $('pickAvatar');
        if (!(window.MQHost && MQHost.has('PickModel'))) { pa.disabled = true; pa.title = 'As personagens escolhem-se no MQ Creator.'; }
        pa.onclick = () => this.pickModel('avatar');
    }

    refreshAll() {
        const $ = (id) => document.getElementById(id);
        $('lvW').value = this.L.w; $('lvH').value = this.L.h;
        $('lvFloor').value = this.L.floor; $('lvCeil').value = this.L.ceiling;
        $('lvSpeed').value = this.L.speed || 1; $('lvTime').value = this.L.timeLimit || 0;
        $('lvNeed').checked = this.L.needAll !== false; $('lvMini').checked = this.L.minimap !== false; $('lvSfx').checked = this.L.sfx !== false;
        this.L.view = '3d';            /* só há a vista 3D */
        $('lvSky').checked = !!this.L.sky;
        $('lvCam').value = this.L.camera === '3rd' ? '3rd' : '1st';
        this.refreshAvatars();
        this.refreshAssets();
        this.refreshImgWalls();
        this.markTool();
        this.draw();
        this.showSel();
        this.stats();
    }

    /* ---------- test with the real player ---------- */

    bindTest() {
        const ov = document.getElementById('testOv'), out = document.getElementById('testResult');
        document.getElementById('testBtn').onclick = () => {
            if (this.L.map[this.L.start.y][this.L.start.x] !== '0') { this.say('O início está numa parede.', true); return; }
            out.hidden = true;
            ov.hidden = false;
            if (!this.player) this.player = new ExplorerPlayer({ embed: true, onResult: (d) => {
                const r = d.dataNE;
                out.textContent = `🏁  ${r.score} / ${r.maxScore}\n🍎  ${r.items} / ${r.itemsTotal}   ✖ ${r.wrongItems}\n❓  ${r.answersCorrect} / ${r.questions}\n⏱  ${r.duration} s   🧱 ${r.bumps}   📏 ${r.distance}`;
                out.hidden = false;
            } });
            this.player.startLevel(this.build());
        };
        document.getElementById('testClose').onclick = () => { if (this.player) this.player.close(); ov.hidden = true; };
    }

    /* ---------- saving ---------- */

    build() {
        const L = JSON.parse(JSON.stringify(this.L));
        L.stack = Object.fromEntries(Object.entries(L.stack || {}).filter(([, v]) => v));
        const used = new Set(L.map.join('') + Object.values(L.stack).join(''));
        for (const k of Object.keys(L.images)) if (!used.has(k)) delete L.images[k];
        const ua = new Set([...L.models.map((m) => m.asset), ...L.items.filter((i) => i.asset).map((i) => i.asset), ...(L.avatars || [])]);
        for (const k of Object.keys(L.assets || {})) if (!ua.has(k)) delete L.assets[k];
        L.questions.forEach((q) => { q.options = (q.options || []).filter((o) => String(o.text || '').trim()); });
        return L;
    }

    save() {
        if (this.L.map[this.L.start.y][this.L.start.x] !== '0') { this.say('O início está numa parede.', true); return; }
        const config = this.build();
        if (window.vuplex) { window.vuplex.postMessage({ type: 'PluginConfig', config, files: {} }); this.say('Guardado.'); }
        else this.download();
    }

    download() {
        const blob = new Blob([JSON.stringify(this.build())], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob); a.download = 'nivel.json';
        document.body.append(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    }
}

document.addEventListener('DOMContentLoaded', () => { window.levelEditor = new LevelEditor(); });
