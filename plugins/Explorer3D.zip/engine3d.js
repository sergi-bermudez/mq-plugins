'use strict';
/**
 * Explorador 3D — visualização 3D (three.js / WebGL) do mesmo nível e do mesmo jogo do motor 2D (engine.js).
 * O Engine continua a tratar do movimento, colisões, objetos, perguntas, portas e pistas; aqui só se desenha:
 * paredes e portas em cubos, chão e teto, objetos/chaves/pistas como imagens viradas para a câmara, e os modelos 3D
 * (GLB da biblioteca do MQ Creator) com as suas animações. Sem WebGL, o player fica no 2D.
 * Precisa de three.classic.js (window.THREE com GLTFLoader e SkeletonUtils).
 */
(function (global) {
    function webglOK() {
        try {
            const c = document.createElement('canvas');
            return !!(global.THREE && (c.getContext('webgl2') || c.getContext('webgl')));
        } catch (e) { return false; }
    }

    function dataToBuffer(url) {
        const b64 = String(url).split(',')[1] || '';
        const bin = atob(b64), u = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
        return u.buffer;
    }

    class Renderer3D {
        constructor(engine, canvas) {
            this.E = engine;
            this.cv = canvas;
            this.clock = performance.now();
            this.mixers = [];
            this.spr = [];          // { obj, alive(), float, base }
            this.doorInst = [];     // { mesh, i, x, y }
        }

        async init() {
            const T = global.THREE, E = this.E, L = E.L;
            this.R = new T.WebGLRenderer({ canvas: this.cv, antialias: true, powerPreference: 'high-performance' });
            this.R.setPixelRatio(Math.min(global.devicePixelRatio || 1, 1.5));
            if ('outputColorSpace' in this.R) this.R.outputColorSpace = T.SRGBColorSpace;
            const S = this.scene = new T.Scene();
            S.background = new T.Color(L.ceiling);
            S.fog = L.sky ? new T.Fog(new T.Color(L.ceiling), 14, 48) : new T.Fog(new T.Color(L.ceiling), 6, 22);
            S.add(new T.HemisphereLight(0xffffff, new T.Color(L.floor), 1.7));
            S.add(new T.AmbientLight(0xffffff, 1.1));        /* cores vivas também nas faces à sombra (estilo blocos) */
            const sun = new T.DirectionalLight(0xffffff, 1.3);
            sun.position.set(L.w * 0.3, 6, L.h * 0.2);
            S.add(sun);
            this.cam = new T.PerspectiveCamera(60, 1, 0.05, 120);
            const aniso = Math.min(8, this.R.capabilities.getMaxAnisotropy ? this.R.capabilities.getMaxAnisotropy() : 4);

            const tex = (canvas) => {
                const t = new T.CanvasTexture(canvas);
                if ('colorSpace' in t) t.colorSpace = T.SRGBColorSpace;
                t.anisotropy = aniso;
                return t;
            };
            /* chão: a cor do nível e o chão pintado (ruas, passeios, relva…), desenhado como vetor numa só imagem */
            const gcs = Math.max(16, Math.min(64, Math.floor(4096 / Math.max(L.w, L.h))));
            const fc = document.createElement('canvas'); fc.width = L.w * gcs; fc.height = L.h * gcs;
            global.Explorer3D.drawGroundMap(fc.getContext('2d'), L, gcs);
            const ft = tex(fc);
            const floor = new T.Mesh(new T.PlaneGeometry(L.w, L.h), new T.MeshLambertMaterial({ map: ft }));
            floor.rotation.x = -Math.PI / 2; floor.position.set(L.w / 2, 0, L.h / 2);
            S.add(floor);
            if (L.sky) {
                /* céu aberto: um chão largo à volta, para não se ver o fim do mundo */
                const out = new T.Mesh(new T.PlaneGeometry(400, 400), new T.MeshLambertMaterial({ color: new T.Color(L.floor).multiplyScalar(0.9) }));
                out.rotation.x = -Math.PI / 2; out.position.set(L.w / 2, -0.01, L.h / 2);
                S.add(out);
            } else {
                const ceil = new T.Mesh(new T.PlaneGeometry(L.w, L.h), new T.MeshBasicMaterial({ color: new T.Color(L.ceiling).multiplyScalar(0.92) }));
                ceil.rotation.x = Math.PI / 2; ceil.position.set(L.w / 2, 1, L.h / 2);
                S.add(ceil);
            }

            /* blocos: paredes, portas e os que estão empilhados por cima — um InstancedMesh por textura */
            /* os blocos de cor têm meia altura de uma parede */
            const box = new T.BoxGeometry(1, 1, 1), half = new T.BoxGeometry(1, 0.5, 1), byKey = {};
            const X = global.Explorer3D;
            for (let y = 0; y < L.h; y++) for (let x = 0; x < L.w; x++) {
                for (const b of X.columnBlocks(E.map[y][x], L.stack[x + ',' + y])) {
                    if (X.SPECIAL[b.ch]) continue;      /* os que se partem ou se empurram: um a um, mais abaixo */
                    const k = b.ch + (b.h === 1 ? '~' : '');
                    (byKey[k] = byKey[k] || []).push([x, y, b.b, b.h]);
                }
            }
            const m4 = new T.Matrix4();
            for (const [k, cells] of Object.entries(byKey)) {
                const c = k[0], isHalf = k.length > 1;
                let mat;
                if (isHalf && X.BLOCKS[c]) {
                    /* lados com meia altura, em cima e em baixo quadrados: o rebordo fica igual em todas as faces */
                    const side = new T.MeshLambertMaterial({ map: tex(X.blockFace(X.BLOCKS[c].color, 256, 128)) });
                    const topm = new T.MeshLambertMaterial({ map: tex(X.blockFace(X.BLOCKS[c].color, 256)) });
                    mat = [side, side, topm, topm, side, side];
                } else mat = new T.MeshLambertMaterial({ map: tex(E.textures[c] || E.textures['5']) });
                const mesh = new T.InstancedMesh(isHalf ? half : box, mat, cells.length);
                cells.forEach(([x, y, b, h], i) => {
                    mesh.setMatrixAt(i, m4.makeTranslation(x + 0.5, (b + h / 2) * 0.5, y + 0.5));
                    if (b === 0 && E.isDoor(c)) this.doorInst.push({ mesh, i, x, y });
                });
                mesh.instanceMatrix.needsUpdate = true;
                S.add(mesh);
            }

            /* blocos que se partem (S) e que se empurram (T): uma malha cada, para se poderem mover ou desaparecer */
            this.dynMesh = new Map();
            const dmat = {};
            for (const d of E.dyn) {
                if (!dmat[d.ch]) {
                    /* meia altura: dos lados a textura fica achatada para caber; em cima e em baixo, inteira */
                    const src = E.textures[d.ch], sc = document.createElement('canvas');
                    sc.width = src.width; sc.height = Math.round(src.height / 2);
                    sc.getContext('2d').drawImage(src, 0, 0, sc.width, sc.height);
                    const side = new T.MeshLambertMaterial({ map: tex(sc) }), topm = new T.MeshLambertMaterial({ map: tex(src) });
                    dmat[d.ch] = { half: [side, side, topm, topm, side, side], full: new T.MeshLambertMaterial({ map: tex(src) }) };
                }
                const m = new T.Mesh(d.h === 1 ? half : box, d.h === 1 ? dmat[d.ch].half : dmat[d.ch].full);
                m.position.set(d.x + 0.5, (d.b + d.h / 2) * 0.5, d.y + 0.5);
                S.add(m);
                this.dynMesh.set(d, m);
            }

            /* imagens (objetos, perguntas, chaves, pistas, saída) */
            const sprite = (img, size, x, y, alive, float, ground, lv) => {
                if (!img) return;
                const c = document.createElement('canvas');
                c.width = img.naturalWidth || img.width; c.height = img.naturalHeight || img.height;
                c.getContext('2d').drawImage(img, 0, 0);
                const sp = new T.Sprite(new T.SpriteMaterial({ map: tex(c), transparent: true, alphaTest: 0.05 }));
                const k = c.width / c.height;
                sp.scale.set(size * Math.min(1, k), size / Math.max(1, k), 1);
                const base = (ground ? sp.scale.y / 2 : 0.42) + (lv || 0) * 0.5;      /* em cima de blocos: meia parede por bloco */
                sp.position.set(x + 0.5, base, y + 0.5);
                S.add(sp);
                this.spr.push({ obj: sp, alive, float, base, x });
            };
            E.items.forEach((it) => { if (!it.asset) sprite(E.itemImgs[it.i] || E.qmark, 0.42, it.x, it.y, () => !it.got, true, false, it.lv); });
            E.questions.forEach((q) => sprite(E.qmark, 0.38, q.x, q.y, () => !q.done, true, false, q.lv));
            E.keys.forEach((k) => sprite(E.keyImgs[k.color], 0.36, k.x, k.y, () => !k.got, true, false, k.lv));
            E.hints.forEach((h) => sprite(E.hintImgs[h.type] || E.hintImgs.note, 0.36, h.x, h.y, () => !h.got, true, false, h.lv));
            if (L.exit) sprite(E.flag, 0.8, L.exit.x, L.exit.y, () => true, false, true, E.exitLv);
            /* plataformas: um disco baixo da cor das portas que abre; desce quando se carrega */
            this.plateObjs = (E.plates || []).map((p) => {
                const col = new T.Color(Explorer3D.DOORS[p.color].color);
                const g = new T.Group();
                const rim = new T.Mesh(new T.CylinderGeometry(0.42, 0.44, 0.03, 32), new T.MeshLambertMaterial({ color: col.clone().multiplyScalar(0.55) }));
                rim.position.y = 0.015;
                const top = new T.Mesh(new T.CylinderGeometry(0.34, 0.36, 0.05, 32), new T.MeshLambertMaterial({ color: col, emissive: col.clone().multiplyScalar(0.15) }));
                top.position.y = 0.045;
                g.add(rim, top);
                if (p.needBox) {          /* pede um 📦: um quadrado desenhado no disco */
                    const sq = new T.Mesh(new T.BoxGeometry(0.3, 0.012, 0.3), new T.MeshLambertMaterial({ color: 0xa0784a }));
                    sq.position.y = 0.075; top.add(sq); sq.position.y = 0.03;
                }
                g.position.set(p.x + 0.5, 0, p.y + 0.5);
                S.add(g);
                return { p, top };
            });

            /* modelos 3D: cada asset carregado uma vez, e clonado para cada sítio onde está */
            const loader = new T.GLTFLoader(), gl = {};
            const used = new Set([...E.models.map((m) => m.asset), ...E.items.filter((i) => i.asset).map((i) => i.asset)]);
            for (const id of used) {
                const a = L.assets[id];
                if (!a || !a.glb) continue;
                try {
                    gl[id] = await new Promise((res, rej) => loader.parse(dataToBuffer(a.glb), '', res, rej));
                    /* materiais «metálicos» ficam pretos sem um ambiente à volta: menos metal, cores como na biblioteca */
                    gl[id].scene.traverse((o) => { if (o.isMesh) [].concat(o.material).forEach((mt) => { if (mt && 'metalness' in mt && mt.metalness > 0.3) { mt.metalness = 0.1; mt.roughness = Math.max(mt.roughness || 0, 0.6); } }); });
                }
                catch (e) { console.warn('Explorador: modelo', id, e); }
            }
            const place = (id, x, y, rot, size, anim, alive, float, lv) => {
                const g = gl[id];
                if (!g) {               /* sem GLB (ex.: nível feito só para 2D): a vista de frente como imagem */
                    const v = E.assetViews[id] && E.assetViews[id][0];
                    if (v) sprite(v, size, x, y, alive, float, !float, lv);
                    return;
                }
                if (!g.box) { g.scene.updateMatrixWorld(true); g.box = new T.Box3().setFromObject(g.scene); }
                const obj = T.SkeletonUtils.clone(g.scene);
                const bb = g.box, sz = bb.getSize(new T.Vector3()), ct = bb.getCenter(new T.Vector3());
                const k = size / (sz.y || 1);
                const pivot = new T.Group();
                obj.position.set(-ct.x, -bb.min.y, -ct.z);
                pivot.add(obj);
                pivot.scale.setScalar(k);
                pivot.rotation.y = Math.PI / 2 - (rot == null ? 90 : rot) * Math.PI / 180;
                pivot.position.set(x + 0.5, (float ? 0.2 : 0) + (lv || 0) * 0.5, y + 0.5);
                S.add(pivot);
                if (g.animations && g.animations.length && anim !== '') {
                    const clip = g.animations.find((c) => c.name === anim) || g.animations.find((c) => /idle/i.test(c.name)) || g.animations.find((c) => /breath|parad/i.test(c.name)) || g.animations[0];
                    const mx = new T.AnimationMixer(obj);
                    mx.clipAction(clip).play();
                    mx.update(Math.random() * 2);
                    this.mixers.push(mx);
                }
                this.spr.push({ obj: pivot, alive, float, base: pivot.position.y, x, spin: float });
                return pivot;
            };
            this.carObjs = [];
            E.models.forEach((m) => {
                const p = place(m.asset, m.x, m.y, m.rot, m.size || 0.8, m.anim, () => true, false, m.lv);
                if (p && E.cars && E.cars.some((c) => c.m === m)) this.carObjs.push({ m, obj: p });
            });

            /* a personagem (3.ª pessoa): o modelo escolhido, com «parado» e «a andar»; sem modelo, um boneco simples */
            const av = new T.Group(), body = new T.Group();
            av.add(body);
            let avGl = null;
            const aid = E.avatarAsset, aa = aid && L.assets[aid];
            if (aa && aa.glb) {
                try { avGl = gl[aid] || await new Promise((res, rej) => loader.parse(dataToBuffer(aa.glb), '', res, rej)); } catch (e) { console.warn('Explorador: personagem', e); }
            }
            if (avGl) {
                const sc = T.SkeletonUtils.clone(avGl.scene);
                avGl.scene.updateMatrixWorld(true);
                const bb = new T.Box3().setFromObject(avGl.scene), sz = bb.getSize(new T.Vector3()), ct = bb.getCenter(new T.Vector3());
                sc.position.set(-ct.x, -bb.min.y, -ct.z);
                body.add(sc);
                body.scale.setScalar(Math.min(0.78 / (sz.y || 1), 0.8 / (Math.max(sz.x, sz.z) || 1)));   /* cabe numa casela */
                const clips = avGl.animations || [];
                if (clips.length) {
                    this.avMixer = new T.AnimationMixer(sc);
                    const find = (re) => clips.find((c) => re.test(c.name));
                    /* «parado»: Idle primeiro (Standing, nas personagens da biblioteca, é levantar-se do chão — parecia agachar-se) */
                    const idle = find(/idle/i) || find(/breath|parad/i) || clips.find((c) => !/stand|sit|crouch|jump|walk|run|death|die/i.test(c.name)) || clips[0];
                    const walk = find(/walk|andar|camin/i) || find(/run|jog/i) || null;
                    this.avIdle = this.avMixer.clipAction(idle); this.avIdle.play();
                    if (walk && walk !== idle) { this.avWalk = this.avMixer.clipAction(walk); this.avWalk.play(); this.avWalk.setEffectiveWeight(0); }
                }
            } else {
                const mat = new T.MeshLambertMaterial({ color: 0x3d6fd6 });
                const trunk = new T.Mesh(new T.CylinderGeometry(0.14, 0.18, 0.5, 20), mat); trunk.position.y = 0.3;
                const head = new T.Mesh(new T.SphereGeometry(0.15, 24, 16), new T.MeshLambertMaterial({ color: 0xf2c9a0 })); head.position.y = 0.68;
                const nose = new T.Mesh(new T.SphereGeometry(0.04, 12, 8), mat); nose.position.set(0, 0.68, 0.15);
                body.add(trunk, head, nose);
            }
            av.visible = false;
            S.add(av);
            this.avatar = av; this.walkW = 0; this.lastP = [E.px, E.py];
            E.items.forEach((it) => { if (it.asset) place(it.asset, it.x, it.y, 90, 0.4, '', () => !it.got, true, it.lv); });
            this.fit();
        }

        fit() {
            const w = this.cv.clientWidth || 640, h = this.cv.clientHeight || 360;
            if (w === this.w && h === this.h) return;
            this.w = w; this.h = h;
            this.R.setSize(w, h, false);
            const aspect = w / h;
            this.cam.aspect = aspect;
            /* o mesmo campo de visão horizontal do 2D (60°) */
            this.cam.fov = 2 * Math.atan(Math.tan(Math.PI / 6) / aspect) * 180 / Math.PI;
            this.cam.updateProjectionMatrix();
        }

        render() {
            const E = this.E, now = performance.now(), dt = Math.min(0.1, (now - this.clock) / 1000), t = now / 1000;
            this.clock = now;
            this.fit();
            for (const d of this.doorInst) {
                if (!d.gone && E.map[d.y][d.x] === '0') {
                    d.gone = true;
                    d.mesh.setMatrixAt(d.i, new global.THREE.Matrix4().makeScale(0, 0, 0));
                    d.mesh.instanceMatrix.needsUpdate = true;
                }
            }
            for (const o of this.plateObjs || []) o.top.position.y += ((o.p.on ? 0.02 : 0.045) - o.top.position.y) * Math.min(1, dt * 10);
            for (const c of this.carObjs) { c.obj.position.x = c.m.fx; c.obj.position.z = c.m.fy; c.obj.rotation.y = Math.PI / 2 - c.m.hd; }
            for (const [d, m] of this.dynMesh) {
                if (d.gone) {
                    /* partido: encolhe e roda um pouco antes de desaparecer */
                    const k = Math.max(0, 1 - (now - d.goneT) / 280);
                    m.scale.setScalar(k); m.rotation.y += dt * 6; m.visible = k > 0;
                } else {
                    /* empurrado: desliza até à casela nova */
                    m.position.x += (d.x + 0.5 - m.position.x) * Math.min(1, dt * 12);
                    m.position.z += (d.y + 0.5 - m.position.z) * Math.min(1, dt * 12);
                    m.position.y += ((d.b + d.h / 2) * 0.5 - m.position.y) * Math.min(1, dt * 10);      /* e cai, se ficou no ar */
                }
            }
            for (const s of this.spr) {
                const on = s.alive();
                s.obj.visible = on;
                if (on && s.float) s.obj.position.y = s.base + Math.sin(t * 2 + s.x) * 0.03;
                if (on && s.spin) s.obj.rotation.y += dt * 0.8;
            }
            for (const m of this.mixers) m.update(dt);
            const pz = (E.pz || 0) * 0.5, third = E.camMode === '3rd' && this.avatar;      /* E.pz em meias paredes */
            if (this.orbit) {
                /* pré-visualização do editor: a câmara roda à volta do nível, vista de cima */
                const o = this.orbit, L = E.L, cx = L.w / 2, cz = L.h / 2;
                if (this.scene.fog) this.scene.fog = null;
                if (this.avatar) this.avatar.visible = false;
                this.cam.far = 400; this.cam.updateProjectionMatrix();
                this.cam.position.set(cx + o.dist * Math.cos(o.pitch) * Math.cos(o.yaw), o.dist * Math.sin(o.pitch), cz + o.dist * Math.cos(o.pitch) * Math.sin(o.yaw));
                this.cam.lookAt(cx, 0, cz);
                this.R.render(this.scene, this.cam);
                return;
            }
            if (this.avatar) {
                this.avatar.visible = !!third;
                this.avatar.position.set(E.px, pz, E.py);
                this.avatar.rotation.y = Math.PI / 2 - E.pa;
                /* anda ou está parado: mistura as duas animações */
                const mv = Math.hypot(E.px - this.lastP[0], E.py - this.lastP[1]) > 0.0008;
                this.lastP = [E.px, E.py];
                this.walkW += ((mv ? 1 : 0) - this.walkW) * Math.min(1, dt * 8);
                if (this.avWalk) { this.avWalk.setEffectiveWeight(this.walkW); this.avIdle.setEffectiveWeight(1 - this.walkW); }
                if (this.avMixer) this.avMixer.update(dt);
            }
            if (third) {
                /* atrás da personagem e pouco acima da cabeça, a olhar em frente: vê-se a personagem de costas, o caminho e o céu */
                const sky = !!E.L.sky, up = sky ? 0.5 : 0.3, far = sky ? 2.4 : 1.3;
                const cx = Math.cos(E.pa), cy = Math.sin(E.pa), camY = pz + 0.5 + up;
                let d = 0.2;
                for (let t = 0.2; t <= far + 1e-6; t += 0.05) {
                    const x = E.px - cx * t, y = E.py - cy * t;
                    if (E.filled(Math.floor(x), Math.floor(y), Math.floor(camY * 2)) || E.filled(Math.floor(x), Math.floor(y), Math.floor((pz + 0.5) * 2))) break;
                    d = t;
                }
                d = Math.max(0.2, d - 0.12);
                /* encostada a uma parede: a câmara sobe um pouco, para continuar a ver-se a personagem */
                const lift = sky ? Math.min(0.7, (far - d) * 0.5) : 0;
                this.cam.position.set(E.px - cx * d, camY + lift, E.py - cy * d);
                /* o alvo fica longe e à altura dos olhos: o horizonte a meio do ecrã (o rato sobe e desce o olhar) */
                const ahead = 4;
                this.cam.lookAt(E.px + cx * ahead, pz + 0.75 + lift * 0.3 + Math.tan(E.pitch || 0) * ahead, E.py + cy * ahead);
            } else {
                const eye = pz + 0.5;
                this.cam.position.set(E.px, eye, E.py);
                const pc = Math.cos(E.pitch || 0);
                this.cam.lookAt(E.px + Math.cos(E.pa) * pc, eye + Math.sin(E.pitch || 0), E.py + Math.sin(E.pa) * pc);
            }
            this.R.render(this.scene, this.cam);
        }

        dispose() {
            try { this.R.dispose(); } catch (e) { /* nothing */ }
        }
    }

    global.Explorer3DView = { Renderer3D, webglOK };
})(window);
