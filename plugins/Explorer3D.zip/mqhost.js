'use strict';
/**
 * MQ Plugins — services of the host for plugin EDITORS (contract v1).
 * MQ Creator announces what it offers in window.MQ_HOST = { name, services: ['PickImage', 'PickVideo', 'PickModel'], lang }.
 *   MQHost.has('PickImage')                         → true inside MQ Creator
 *   await MQHost.pickImage({ max: 1024, png: false }) → { name, img: 'data:image/…', w, h } or null (cancelled)
 *   await MQHost.pickVideo()                          → { name, ext, mime, size, file: Blob, w, h, duration } or null
 *   await MQHost.pickModel({ glb: true, views: 8, size: 256 })
 *                                                    → { id, name, cat, views: [8 × PNG data URL], anims, h, w, glb? } or null
 * Requests go out as window.vuplex.postMessage({ type: 'PickImage' | 'PickModel', req, … }) and the answer comes back
 * as a vuplex «message» { type: 'PickedImage' | 'PickedModel', req, … } (or { cancel: true }).
 * In the editor's own vuplex message listener, call MQHost.handle(data) first: it returns true for these answers.
 */
(function (global) {
    const pending = {};
    let n = 0;
    function request(type, opts) {
        return new Promise((resolve) => {
            if (!global.vuplex) { resolve(null); return; }
            const req = type + ':' + (++n) + ':' + Date.now();
            pending[req] = resolve;
            global.vuplex.postMessage(Object.assign({ type, req }, opts || {}));
        });
    }
    global.MQHost = {
        has: (s) => !!(global.MQ_HOST && Array.isArray(global.MQ_HOST.services) && global.MQ_HOST.services.indexOf(s) >= 0),
        pickImage: (opts) => request('PickImage', opts),
        pickVideo: (opts) => request('PickVideo', opts),
        pickModel: (opts) => request('PickModel', opts),
        handle(data) {
            let d = data;
            if (typeof d === 'string') { if (d.indexOf('"Picked') < 0) return false; try { d = JSON.parse(d); } catch (e) { return false; } }
            if (!d || !/^Picked(Image|Video|Model)$/.test(d.type) || !pending[d.req]) return false;
            const done = pending[d.req];
            delete pending[d.req];
            done(d.cancel ? null : d);
            return true;
        }
    };
})(window);
