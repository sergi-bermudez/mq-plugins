'use strict';

/**
 * VideoQuiz — forms editor (MQ Plugins contract v1).
 *
 * Receives the form through window.vuplex ("{}" = new screen) and, on save, returns it with
 *   window.vuplex.postMessage({ type: 'PluginConfig', config, files })
 * where files = { "./Videos/x.webm": Blob } for the videos chosen in this edit.
 * Uses MQ Creator's services when it offers them (mqhost.js): PickImage (clipart, internet, 3D) and PickVideo.
 * Outside MQ Creator (no window.vuplex) it opens and downloads the JSON.
 * The format is described at the top of VideoQuiz.js; older forms (Pontuacao_0…3) open as single-choice questions.
 */
const TYPES = [
    ['single', '◉ Escolha única'],
    ['multi', '☑ Escolha múltipla'],
    ['text', '✎ Resposta escrita'],
    ['number', '# Número'],
    ['scale', '★ Escala'],
    ['date', '📅 Data'],
    ['info', 'ℹ Texto / imagem (sem resposta)']
];
const SCORES = [-3, -2, -1, 0, 1, 2, 3];
const VIDEO_FOLDER = './Videos/';
const AUDIO_FOLDER = './Audio/';

class VideoQuizEditor {
    constructor() {
        this.files = {};                 // path -> Blob (videos chosen in this edit)
        this.form = this.blankForm();
        this.host = (s) => !!(window.MQHost && MQHost.has(s));
        this.ui();
        this.listen();
        this.render();
    }

    blankForm() {
        return {
            version: 2, title: '', description: '', path: '',
            allowReplay: false, showResult: true, shuffle: false, allowBack: true, showProgress: true,
            questions: [this.blankQuestion('single')]
        };
    }

    blankQuestion(type) {
        const q = { type, question: '', help: '', required: type !== 'info' && type !== 'text', image: '', video: '', watchFirst: false };
        if (type === 'single' || type === 'multi') Object.assign(q, { options: [{ text: '', score: 0 }, { text: '', score: 0 }], other: false, minSel: 0, maxSel: 0 });
        if (type === 'text') q.multiline = false;
        if (type === 'number') Object.assign(q, { min: '', max: '', step: 1, unit: '', correct: '', points: 1 });
        if (type === 'scale') Object.assign(q, { scaleMin: 1, scaleMax: 5, labelMin: '', labelMax: '', style: 'numbers', scored: false });
        return q;
    }

    /* ---------- loading ---------- */

    listen() {
        const hear = () => window.vuplex.addEventListener('message', (event) => {
            if (window.MQHost && MQHost.handle(event.data)) return;     /* answers of the host services */
            let cfg;
            try { cfg = typeof event.data === 'string' ? JSON.parse(event.data || '{}') : (event.data || {}); }
            catch (e) { this.say('O JSON recebido não é válido.', true); return; }
            this.load(cfg || {});
        });
        if (window.vuplex) hear(); else window.addEventListener('vuplexready', hear);
        document.body.classList.toggle('in-host', !!window.vuplex);
    }

    load(s) {
        this.files = {};
        if (!s || !Array.isArray(s.questions)) { this.form = this.blankForm(); this.render(); return; }
        const legacy = !(s.version >= 2);
        this.form = {
            version: 2,
            title: s.title || '', description: s.description || '', path: s.path || '',
            allowReplay: s.allowReplay === true, showResult: s.showResult !== false,
            shuffle: legacy ? true : s.shuffle === true,
            allowBack: legacy ? false : s.allowBack !== false,
            showProgress: legacy ? false : s.showProgress !== false,
            questions: s.questions.map((q) => this.fromSaved(q))
        };
        if (!this.form.questions.length) this.form.questions.push(this.blankQuestion('single'));
        this.render();
    }

    fromSaved(q) {
        const type = TYPES.some(([t]) => t === q.type) ? q.type : 'single';
        const out = Object.assign(this.blankQuestion(type), q, { type, question: q.question || '' });
        if (type === 'single' || type === 'multi') {
            if (Array.isArray(q.options)) out.options = q.options.map((o) => ({ text: o.text || '', score: Number(o.score) || 0, image: o.image || '', goto: o.goto == null ? '' : o.goto }));
            else {
                out.options = [];
                Object.keys(q).forEach((k) => {
                    const m = /^Pontuacao_(\d+)$/.exec(k);
                    if (m && Array.isArray(q[k])) q[k].forEach((t) => out.options.push({ text: String(t), score: +m[1], image: '', goto: '' }));
                    if (m) delete out[k];
                });
                out.required = out.options.length > 0;
            }
        }
        return out;
    }

    /* ---------- interface ---------- */

    $(id) { return document.getElementById(id); }

    ui() {
        const bind = (id, key, prop = 'value') => {
            const el = this.$(id);
            el.addEventListener('input', () => { this.form[key] = prop === 'checked' ? el.checked : el.value; });
            el.addEventListener('change', () => { this.form[key] = prop === 'checked' ? el.checked : el.value; });
        };
        bind('form-title', 'title'); bind('form-desc', 'description');
        bind('opt-allow-replay', 'allowReplay', 'checked'); bind('opt-show-result', 'showResult', 'checked');
        bind('opt-shuffle', 'shuffle', 'checked'); bind('opt-back', 'allowBack', 'checked'); bind('opt-progress', 'showProgress', 'checked');
        this.$('createBtn').addEventListener('click', () => this.save());
        this.$('downloadBtn').addEventListener('click', () => this.download());
        this.$('JSON-input').addEventListener('change', (e) => {
            const f = e.target.files[0]; e.target.value = '';
            if (!f) return;
            f.text().then((t) => { try { this.load(JSON.parse(t)); this.say('Formulário aberto.'); } catch (err) { this.say('Este ficheiro não é um JSON válido.', true); } });
        });
        const add = this.$('addBar');
        add.innerHTML = '<span>＋ Acrescentar:</span>' + TYPES.map(([t, n]) => `<button type="button" class="btn" data-add="${t}">${n}</button>`).join('');
        add.addEventListener('click', (e) => {
            const b = e.target.closest('[data-add]');
            if (!b) return;
            this.form.questions.push(this.blankQuestion(b.dataset.add));
            this.render();
            const cards = document.querySelectorAll('.qcard');
            const last = cards[cards.length - 1];
            if (last) { last.scrollIntoView({ behavior: 'smooth', block: 'center' }); const i = last.querySelector('.qtext'); if (i) i.focus(); }
        });
    }

    render() {
        const F = this.form;
        this.$('form-title').value = F.title;
        this.$('form-desc').value = F.description;
        this.$('opt-allow-replay').checked = F.allowReplay;
        this.$('opt-show-result').checked = F.showResult;
        this.$('opt-shuffle').checked = F.shuffle;
        this.$('opt-back').checked = F.allowBack;
        this.$('opt-progress').checked = F.showProgress;
        this.mediaButtons(this.$('introBtns'), 'video', () => F.path, (v) => { F.path = v; this.render(); });
        this.$('introVideo').textContent = F.path ? '🎬 ' + F.path.replace(VIDEO_FOLDER, '') : '— nenhum —';
        const box = this.$('questions');
        box.innerHTML = '';
        F.questions.forEach((q, i) => box.appendChild(this.card(q, i)));
    }

    el(html) { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstChild; }
    esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

    card(q, i) {
        const n = this.form.questions.length;
        const c = this.el(`<section class="card qcard${q.type === 'info' ? ' info' : ''}">
            <div class="qhead">
                <b class="num">${i + 1}</b>
                <select class="qtype">${TYPES.map(([t, name]) => `<option value="${t}"${t === q.type ? ' selected' : ''}>${name}</option>`).join('')}</select>
                <span class="sp"></span>
                <button type="button" class="icon" data-a="up" title="Subir"${i === 0 ? ' disabled' : ''}>↑</button>
                <button type="button" class="icon" data-a="down" title="Descer"${i === n - 1 ? ' disabled' : ''}>↓</button>
                <button type="button" class="icon" data-a="dup" title="Duplicar">⧉</button>
                <button type="button" class="icon danger" data-a="del" title="Apagar"${n === 1 ? ' disabled' : ''}>🗑</button>
            </div>
            <input type="text" class="qtext" placeholder="${q.type === 'info' ? 'Título ou texto' : 'Pergunta'}" value="${this.esc(q.question)}">
            <textarea class="qhelp" rows="1" placeholder="Explicação (opcional)">${this.esc(q.help)}</textarea>
            <div class="media"></div>
            <div class="body"></div>
            <div class="foot">${q.type === 'info' ? '' : `<label><input type="checkbox" class="req"${q.required ? ' checked' : ''}> Obrigatória</label>`}</div>
        </section>`);
        const on = (sel, ev, f) => { const e = c.querySelector(sel); if (e) e.addEventListener(ev, f); };
        on('.qtext', 'input', (e) => { q.question = e.target.value; });
        on('.qhelp', 'input', (e) => { q.help = e.target.value; });
        on('.req', 'change', (e) => { q.required = e.target.checked; });
        on('.qtype', 'change', (e) => this.changeType(i, e.target.value));
        c.querySelector('.qhead').addEventListener('click', (e) => {
            const b = e.target.closest('[data-a]');
            if (!b) return;
            const Q = this.form.questions;
            if (b.dataset.a === 'up' && i > 0) [Q[i - 1], Q[i]] = [Q[i], Q[i - 1]];
            if (b.dataset.a === 'down' && i < Q.length - 1) [Q[i + 1], Q[i]] = [Q[i], Q[i + 1]];
            if (b.dataset.a === 'dup') Q.splice(i + 1, 0, JSON.parse(JSON.stringify(q)));
            if (b.dataset.a === 'del' && Q.length > 1) Q.splice(i, 1);
            this.render();
        });
        this.mediaRow(c.querySelector('.media'), q);
        this.body(c.querySelector('.body'), q, i);
        return c;
    }

    changeType(i, type) {
        const old = this.form.questions[i];
        const q = this.blankQuestion(type);
        ['question', 'help', 'image', 'video', 'watchFirst'].forEach((k) => { q[k] = old[k]; });
        if (old.options && q.options) { q.options = old.options; q.other = old.other; }
        this.form.questions[i] = q;
        this.render();
    }

    /* image and video of a question */
    mediaRow(box, q) {
        const img = this.el(`<div class="mrow"><span class="lbl">🖼 Imagem</span>${q.image ? `<img class="thumb" src="${q.image}" alt="">` : ''}<span class="btns"></span></div>`);
        this.mediaButtons(img.querySelector('.btns'), 'image', () => q.image, (v) => { q.image = v; this.render(); });
        const vid = this.el(`<div class="mrow"><span class="lbl">🎬 Vídeo</span>${q.video ? `<span class="media-name">${this.esc(q.video.replace(VIDEO_FOLDER, ''))}</span>` : ''}<span class="btns"></span>
            ${q.video && q.type !== 'info' ? `<label class="small"><input type="checkbox" class="wf"${q.watchFirst ? ' checked' : ''}> ver o vídeo até ao fim antes de responder</label>` : ''}</div>`);
        this.mediaButtons(vid.querySelector('.btns'), 'video', () => q.video, (v) => { q.video = v; if (!v) q.watchFirst = false; this.render(); });
        const wf = vid.querySelector('.wf');
        if (wf) wf.addEventListener('change', () => { q.watchFirst = wf.checked; });
        box.append(img, vid, this.audioRow(() => q.audio, (v) => { q.audio = v; this.render(); }));
    }

    /** buttons: file, MQ Creator picker (when offered), remove */
    mediaButtons(box, kind, get, set) {
        box.innerHTML = '';
        const file = this.el(`<label class="btn small">📁 ${get() ? 'Mudar' : 'Ficheiro'}…<input type="file" hidden accept="${kind === 'image' ? 'image/*' : 'video/webm,video/mp4,.webm,.mp4'}"></label>`);
        file.querySelector('input').addEventListener('change', async (e) => {
            const f = e.target.files[0]; e.target.value = '';
            if (!f) return;
            if (kind === 'image') set(await this.shrink(f, 900));
            else set(this.addVideo(f, f.name.replace(/\.[^.]+$/, ''), (/\.(\w+)$/.exec(f.name) || [, 'webm'])[1]));
        });
        box.appendChild(file);
        if (this.host(kind === 'image' ? 'PickImage' : 'PickVideo')) {
            const h = this.el(`<button type="button" class="btn small">${kind === 'image' ? '🙂 Clipart / internet / 3D…' : '🎬 Do MQ Creator…'}</button>`);
            h.addEventListener('click', async () => {
                if (kind === 'image') {
                    const r = await MQHost.pickImage({ max: 900 });
                    if (r && r.img) set(r.img);
                } else {
                    const r = await MQHost.pickVideo({});
                    if (r && r.file) set(this.addVideo(r.file, r.name || 'video', r.ext || 'webm'));
                }
            });
            box.appendChild(h);
        }
        if (get()) {
            const x = this.el('<button type="button" class="btn small danger" title="Tirar">✕</button>');
            x.addEventListener('click', () => set(''));
            box.appendChild(x);
        }
    }

    /** 🔊 the question read aloud (or any sound): record with the microphone or choose a file; it plays when the
        question appears, with 🔊 to hear it again */
    audioRow(get, set) {
        const row = this.el(`<div class="mrow"><span class="lbl">🔊 Áudio</span>${get() ? `<span class="media-name">${this.esc(get().replace(AUDIO_FOLDER, ''))}</span>` : ''}<span class="btns"></span></div>`);
        const btns = row.querySelector('.btns');
        const add = (html, f) => { const b = this.el(html); b.addEventListener('click', f); btns.appendChild(b); return b; };
        if (get() && this.files[get()]) add('<button type="button" class="btn small">▶</button>', () => { try { if (this.au) this.au.pause(); this.au = new Audio(URL.createObjectURL(this.files[get()])); this.au.play(); } catch (e) { /* nothing */ } });
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder) {
            add(`<button type="button" class="btn small${this.rec ? ' rec' : ''}">${this.rec ? '⏹ Parar' : '🎙 Gravar'}</button>`, async () => {
                if (this.rec) { this.rec.stop(); return; }
                try {
                    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                    const mr = new MediaRecorder(stream), parts = [];
                    mr.ondataavailable = (e) => { if (e.data && e.data.size) parts.push(e.data); };
                    mr.onstop = () => {
                        stream.getTracks().forEach((t) => t.stop());
                        this.rec = null;
                        const blob = new Blob(parts, { type: mr.mimeType || 'audio/webm' });
                        if (blob.size) set(this.addMedia(blob, 'gravacao', /ogg/.test(blob.type) ? 'ogg' : 'webm', AUDIO_FOLDER)); else this.render();
                    };
                    this.rec = mr; mr.start(); this.render();
                    setTimeout(() => { if (this.rec === mr) mr.stop(); }, 120000);
                } catch (e) { this.say('Não foi possível usar o microfone: escolha um ficheiro de áudio.', true); }
            });
        }
        const file = this.el('<label class="btn small">📁 Ficheiro…<input type="file" hidden accept="audio/*,.mp3,.wav,.ogg,.webm,.m4a"></label>');
        file.querySelector('input').addEventListener('change', (e) => {
            const f = e.target.files[0]; e.target.value = '';
            if (f) set(this.addMedia(f, f.name.replace(/\.[^.]+$/, ''), (/\.(\w+)$/.exec(f.name) || [, 'mp3'])[1], AUDIO_FOLDER));
        });
        btns.appendChild(file);
        if (get()) add('<button type="button" class="btn small danger" title="Tirar">✕</button>', () => set(''));
        return row;
    }

    addVideo(blob, name, ext) { return this.addMedia(blob, name, ext, VIDEO_FOLDER); }

    addMedia(blob, name, ext, folder) {
        const base = (String(name).normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\w.-]+/g, '_').replace(/^_+|_+$/g, '') || 'media');
        /* a name already used (in this edit, or by a video of the form saved before) gets _2, _3…; the same file is reused */
        const used = new Set([this.form.path, ...this.form.questions.map((q) => q.video), ...this.form.questions.map((q) => q.audio)].filter(Boolean));
        const same = (p) => this.files[p] && (this.files[p] === blob || this.files[p].size === blob.size);
        let p = folder + base + '.' + String(ext).toLowerCase(), k = 2;
        while (!same(p) && (this.files[p] || used.has(p))) p = folder + base + '_' + (k++) + '.' + ext;
        this.files[p] = blob;
        return p;
    }

    shrink(file, max) {
        return new Promise((res) => {
            const u = URL.createObjectURL(file), im = new Image();
            im.onload = () => {
                const k = Math.min(1, max / Math.max(im.naturalWidth, im.naturalHeight));
                const c = document.createElement('canvas');
                c.width = Math.max(1, Math.round(im.naturalWidth * k)); c.height = Math.max(1, Math.round(im.naturalHeight * k));
                const g = c.getContext('2d');
                const png = /png|gif|svg|webp/i.test(file.type);
                if (!png) { g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); }
                g.drawImage(im, 0, 0, c.width, c.height);
                URL.revokeObjectURL(u);
                res(c.toDataURL(png ? 'image/png' : 'image/jpeg', 0.86));
            };
            im.onerror = () => { URL.revokeObjectURL(u); this.say('Não foi possível abrir a imagem.', true); res(''); };
            im.src = u;
        });
    }

    /* ---------- the part that depends on the type ---------- */

    body(box, q, i) {
        const field = (label, html) => `<label class="f"><span>${label}</span>${html}</label>`;
        const num = (k, v, extra = '') => `<input type="number" data-k="${k}" value="${this.esc(v)}" ${extra}>`;
        const bindAll = () => box.querySelectorAll('[data-k]').forEach((e) => {
            const k = e.dataset.k;
            const upd = () => { q[k] = e.type === 'checkbox' ? e.checked : (e.type === 'number' ? (e.value === '' ? '' : +e.value) : e.value); };
            e.addEventListener('input', upd); e.addEventListener('change', upd);
        });

        if (q.type === 'single' || q.type === 'multi') {
            const Q = this.form.questions;
            const gotoSel = (o) => `<select class="goto" title="Depois desta resposta">
                <option value="">→ seguinte</option>${Q.map((_, j) => j > i ? `<option value="${j + 1}"${String(o.goto) === String(j + 1) ? ' selected' : ''}>${MQT('→ pergunta {n}', { n: j + 1 })}</option>` : '').join('')}
                <option value="end"${o.goto === 'end' ? ' selected' : ''}>→ fim</option></select>`;
            const list = this.el('<div class="opts-list"></div>');
            q.options.forEach((o, k) => {
                const row = this.el(`<div class="opt">
                    <b class="mark">${q.type === 'single' ? '◯' : '☐'}</b>
                    ${o.image ? `<img class="thumb small" src="${o.image}" alt="">` : ''}
                    <input type="text" class="otext" placeholder="${MQT('Opção {n}', { n: k + 1 })}" value="${this.esc(o.text)}">
                    <span class="pick"></span>
                    <label class="pts" title="Pontos desta resposta">pts <select class="score">${SCORES.map((s) => `<option${s === (o.score || 0) ? ' selected' : ''}>${s}</option>`).join('')}</select></label>
                    ${q.type === 'single' ? gotoSel(o) : ''}
                    <button type="button" class="icon" data-o="up" title="Subir"${k === 0 ? ' disabled' : ''}>↑</button>
                    <button type="button" class="icon danger" data-o="del" title="Apagar">✕</button>
                </div>`);
                row.querySelector('.otext').addEventListener('input', (e) => { o.text = e.target.value; });
                row.querySelector('.score').addEventListener('change', (e) => { o.score = +e.target.value; });
                const g = row.querySelector('.goto');
                if (g) g.addEventListener('change', () => { o.goto = g.value === '' ? '' : (g.value === 'end' ? 'end' : +g.value); });
                this.optionImage(row.querySelector('.pick'), o);
                row.addEventListener('click', (e) => {
                    const b = e.target.closest('[data-o]');
                    if (!b) return;
                    if (b.dataset.o === 'del') q.options.splice(k, 1);
                    if (b.dataset.o === 'up' && k > 0) [q.options[k - 1], q.options[k]] = [q.options[k], q.options[k - 1]];
                    this.render();
                });
                list.appendChild(row);
            });
            box.appendChild(list);
            const more = this.el(`<div class="row">
                <button type="button" class="btn small" data-add-opt>＋ Opção</button>
                <label class="small"><input type="checkbox" data-k="other"${q.other ? ' checked' : ''}> «Outro» com texto livre</label>
                ${q.type === 'multi' ? `${field('mín.', num('minSel', q.minSel || 0, 'min="0" class="tiny"'))}${field('máx.', num('maxSel', q.maxSel || 0, 'min="0" class="tiny" title="0 = sem limite"'))}` : ''}
            </div>`);
            more.querySelector('[data-add-opt]').addEventListener('click', () => { q.options.push({ text: '', score: 0, image: '', goto: '' }); this.render(); });
            box.appendChild(more);
            if (q.type === 'multi') box.appendChild(this.el('<p class="hint">Pontos: soma das opções marcadas (pode dar pontos negativos às erradas). Máx. 0 = sem limite.</p>'));
            else box.appendChild(this.el('<p class="hint">«→ pergunta N» salta para outra pergunta conforme a resposta (as que ficam pelo caminho não contam).</p>'));
        } else if (q.type === 'text') {
            box.appendChild(this.el(`<div class="row"><label class="small"><input type="checkbox" data-k="multiline"${q.multiline ? ' checked' : ''}> Resposta longa (várias linhas)</label></div>`));
        } else if (q.type === 'number') {
            box.appendChild(this.el(`<div class="row">${field('Mínimo', num('min', q.min))}${field('Máximo', num('max', q.max))}${field('Passo', num('step', q.step, 'min="0" step="any"'))}
                ${field('Unidade', `<input type="text" data-k="unit" value="${this.esc(q.unit)}" placeholder="kg, anos…">`)}</div>`));
            box.appendChild(this.el(`<div class="row">${field('Resposta certa (opcional)', num('correct', q.correct, 'step="any"'))}${field('Pontos', num('points', q.points, 'min="0" class="tiny"'))}</div>`));
        } else if (q.type === 'scale') {
            box.appendChild(this.el(`<div class="row">${field('De', num('scaleMin', q.scaleMin, 'class="tiny"'))}${field('a', num('scaleMax', q.scaleMax, 'class="tiny"'))}
                ${field('Aspeto', `<select data-k="style">${[['numbers', '1 2 3 4 5'], ['stars', '★★★★★'], ['faces', '😣 🙁 😐 🙂 😄']].map(([v, t]) => `<option value="${v}"${q.style === v ? ' selected' : ''}>${t}</option>`).join('')}</select>`)}</div>`));
            box.appendChild(this.el(`<div class="row">${field('Rótulo do mínimo', `<input type="text" data-k="labelMin" value="${this.esc(q.labelMin)}" placeholder="Nada">`)}
                ${field('Rótulo do máximo', `<input type="text" data-k="labelMax" value="${this.esc(q.labelMax)}" placeholder="Muito">`)}
                <label class="small"><input type="checkbox" data-k="scored"${q.scored ? ' checked' : ''}> Conta pontos (valor − mínimo)</label></div>`));
        }
        bindAll();
    }

    optionImage(box, o) {
        const set = (v) => { o.image = v; this.render(); };
        const f = this.el('<label class="icon" title="Imagem da opção">🖼<input type="file" accept="image/*" hidden></label>');
        f.querySelector('input').addEventListener('change', async (e) => { const x = e.target.files[0]; e.target.value = ''; if (x) set(await this.shrink(x, 500)); });
        box.appendChild(f);
        if (this.host('PickImage')) {
            const h = this.el('<button type="button" class="icon" title="Clipart / internet / 3D">🙂</button>');
            h.addEventListener('click', async () => { const r = await MQHost.pickImage({ max: 500 }); if (r && r.img) set(r.img); });
            box.appendChild(h);
        }
        if (o.image) {
            const x = this.el('<button type="button" class="icon danger" title="Tirar a imagem">⊘</button>');
            x.addEventListener('click', () => set(''));
            box.appendChild(x);
        }
    }

    /* ---------- saving ---------- */

    build() {
        const F = this.form;
        const questions = F.questions.map((q) => {
            const o = { type: q.type, question: q.question.trim() };
            if (q.help && q.help.trim()) o.help = q.help.trim();
            if (q.type !== 'info') o.required = !!q.required;
            if (q.image) o.image = q.image;
            if (q.video) { o.video = q.video; if (q.watchFirst && q.type !== 'info') o.watchFirst = true; }
            if (q.audio) o.audio = q.audio;
            if (q.type === 'single' || q.type === 'multi') {
                o.options = q.options.filter((x) => x.text.trim() || x.image).map((x) => {
                    const r = { text: x.text.trim(), score: Number(x.score) || 0 };
                    if (x.image) r.image = x.image;
                    if (q.type === 'single' && x.goto !== '' && x.goto != null) r.goto = x.goto;
                    return r;
                });
                if (q.other) o.other = true;
                if (q.type === 'multi') { if (q.minSel > 0) o.minSel = +q.minSel; if (q.maxSel > 0) o.maxSel = +q.maxSel; }
            }
            if (q.type === 'text' && q.multiline) o.multiline = true;
            if (q.type === 'number') ['min', 'max', 'step', 'unit', 'correct', 'points'].forEach((k) => { if (q[k] !== '' && q[k] != null) o[k] = q[k]; });
            if (q.type === 'scale') Object.assign(o, { scaleMin: +q.scaleMin, scaleMax: +q.scaleMax, labelMin: q.labelMin || '', labelMax: q.labelMax || '', style: q.style, scored: !!q.scored });
            return o;
        });
        return {
            version: 2, title: F.title.trim(), description: F.description.trim(), path: F.path,
            allowReplay: F.allowReplay, showResult: F.showResult, shuffle: F.shuffle, allowBack: F.allowBack, showProgress: F.showProgress,
            questions
        };
    }

    check(cfg) {
        if (!cfg.title) return MQT('Escreva o título do formulário.');
        for (let i = 0; i < cfg.questions.length; i++) {
            const q = cfg.questions[i], n = MQT('Pergunta {n}: ', { n: i + 1 });
            if (!q.question && !q.image && !q.video) return n + MQT('escreva o texto.');
            if ((q.type === 'single' || q.type === 'multi') && q.options.length + (q.other ? 1 : 0) < 2) return n + MQT('precisa de pelo menos 2 opções.');
            if (q.options) { const t = q.options.map((o) => o.text).filter(Boolean); if (new Set(t).size !== t.length) return n + MQT('há opções repetidas.'); }
            if (q.type === 'scale' && !(q.scaleMax > q.scaleMin)) return n + MQT('o máximo da escala tem de ser maior do que o mínimo.');
            if (q.type === 'scale' && q.scaleMax - q.scaleMin > 10) return n + MQT('a escala tem no máximo 11 pontos.');
        }
        return '';
    }

    save() {
        const cfg = this.build();
        const err = this.check(cfg);
        if (err) {
            this.say(err, true);
            if (!cfg.title) { const t = this.$('form-title'); t.classList.add('bad'); t.focus(); t.scrollIntoView({ block: 'center', behavior: 'smooth' }); t.addEventListener('input', () => t.classList.remove('bad'), { once: true }); }
            return;
        }
        if (!window.vuplex) { this.download(); return; }
        const used = new Set([cfg.path, ...cfg.questions.map((q) => q.video), ...cfg.questions.map((q) => q.audio)].filter(Boolean));
        const files = {};
        Object.entries(this.files).forEach(([p, b]) => { if (used.has(p)) files[p] = b; });
        window.vuplex.postMessage({ type: 'PluginConfig', config: cfg, files });
        this.files = {};
        this.say('Formulário guardado.');
    }

    download() {
        const cfg = this.build();
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob([JSON.stringify(cfg, null, 2)], { type: 'application/json' }));
        a.download = (cfg.title || 'formulario').replace(/[\\/:*?"<>|]+/g, '_') + '.json';
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(a.href), 1000);
        const vids = Object.keys(this.files);
        this.say(vids.length ? MQT('JSON descarregado. Copie também os vídeos para {d}: {f}', { d: VIDEO_FOLDER, f: vids.map((p) => p.replace(VIDEO_FOLDER, '')).join(', ') }) : MQT('JSON descarregado.'));
    }

    say(t, err = false) {
        const m = this.$('editorMessage');
        m.textContent = t;
        m.classList.toggle('error', err);
        clearTimeout(this.sayT);
        if (!err && t) this.sayT = setTimeout(() => { m.textContent = ''; }, 4000);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.videoQuizEditor = new VideoQuizEditor();
});
