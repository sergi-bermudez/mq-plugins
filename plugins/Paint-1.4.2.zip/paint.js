'use strict';

/**
 * Paint — plugin player (MQ Plugins contract v1).
 *
 * Reads the configuration from window.MQ_CONFIG (file <page>.config.js next to the page) or receives it
 * through window.vuplex, shows the drawing to colour (or a blank sheet), and when ✔ is pressed returns the
 * result in the NeuroExercises format. Icons only: there is no text to translate. No fetch(): runs under file://.
 *
 * Configuration:
 * {
 *   "lineArt": "data:image/png;base64,…",   // black lines on transparent, drawn above the paint ("" = blank sheet)
 *   "width": 1600, "height": 1000,          // sheet size when there is no drawing
 *   "source": "data:image/jpeg;base64,…",   // the original image (only the editor uses it)
 *   "mode": "edges", "threshold": 60, "detail": 1, "thickness": 1   // conversion settings (editor only)
 * }
 * The drawing is embedded as a data: URL so that the canvas is never "tainted" under file:// (Unity), which would
 * block the paint bucket, printing and saving.
 */
class PaintManager {
    constructor() {
        this.activity = 'Paint';
        this.COLORS = ['#ff4757', '#ffa502', '#ffd32a', '#2ed573', '#1e90ff', '#3742fa', '#9b59b6', '#ff6b81',
                       '#8b5a2b', '#f5c6a5', '#a4b0be', '#2f3542'];
        this.MAX_UNDO = 15;
        this.setupState();
        this.initializeUI();
        this.initializeConfigLoading();
    }

    /* ---------- state ---------- */

    setupState() {
        this.config = null;
        this.width = 1600;
        this.height = 1000;
        this.tool = 'pencil';
        this.color = this.COLORS[0];
        this.drawing = false;
        this.last = null;
        this.strokeStart = 0;
        this.undoStack = [];
        this.lineMask = null;          // 1 where the drawing has a line (the paint bucket stops there)
        this.log = [];
        this.startTime = null;
        this.counts = { strokes: 0, fills: 0, undos: 0, clears: 0, prints: 0 };
        this.colorsUsed = new Set();
        this.toolsUsed = new Set();
        this.sent = false;
    }

    /* ---------- interface ---------- */

    initializeUI() {
        this.sheet = document.getElementById('sheet');
        this.stack = document.getElementById('stack');
        this.paintCanvas = document.getElementById('paintCanvas');
        this.lineCanvas = document.getElementById('lineCanvas');
        this.paint = this.paintCanvas.getContext('2d', { willReadFrequently: true });
        this.lines = this.lineCanvas.getContext('2d', { willReadFrequently: true });
        this.palette = document.getElementById('palette');
        this.undoButton = document.getElementById('undoBtn');
        this.confirmClear = document.getElementById('confirmClear');
        this.printImage = document.getElementById('printImage');

        this.COLORS.forEach((color, index) => {
            const dot = document.createElement('button');
            dot.type = 'button';
            dot.className = 'color-dot' + (index === 0 ? ' active' : '');
            dot.style.background = color;
            dot.dataset.color = color;
            dot.addEventListener('click', () => this.selectColor(color, dot));
            this.palette.appendChild(dot);
        });

        document.querySelectorAll('.tool-btn').forEach((button) =>
            button.addEventListener('click', () => this.selectTool(button.dataset.tool, button)));

        this.undoButton.addEventListener('click', () => this.undo());
        document.getElementById('clearBtn').addEventListener('click', () => this.confirmClear.classList.add('open'));
        document.getElementById('clearNo').addEventListener('click', () => this.confirmClear.classList.remove('open'));
        document.getElementById('clearYes').addEventListener('click', () => {
            this.confirmClear.classList.remove('open');
            this.clearSheet();
        });
        document.getElementById('printBtn').addEventListener('click', () => this.print());
        document.getElementById('doneBtn').addEventListener('click', () => this.finish());

        this.paintCanvas.addEventListener('pointerdown', (event) => this.pointerDown(event));
        this.paintCanvas.addEventListener('pointermove', (event) => this.pointerMove(event));
        ['pointerup', 'pointercancel', 'pointerleave'].forEach((type) =>
            this.paintCanvas.addEventListener(type, () => this.pointerUp()));

        window.addEventListener('resize', () => this.fit());
        if (typeof ResizeObserver === 'function') new ResizeObserver(() => this.fit()).observe(this.sheet);

        this.updateUndo();
        this.setSize(this.width, this.height);   // a blank sheet until a configuration arrives
    }

    /* ---------- receiving the configuration ---------- */

    initializeConfigLoading() {
        if (window.MQ_CONFIG && typeof window.MQ_CONFIG === 'object') {
            this.initializeConfig(window.MQ_CONFIG);
        } else {
            this.startTime = performance.now();
        }
        if (window.vuplex) {
            this.registerMessageReceiver();
        } else {
            window.addEventListener('vuplexready', () => this.registerMessageReceiver());
        }
    }

    registerMessageReceiver() {
        window.vuplex.addEventListener('message', (event) => {
            let config;
            try {
                config = typeof event.data === 'string' ? JSON.parse(event.data) : event.data;
            } catch (error) {
                console.error('Paint: invalid JSON', error);
                return;
            }
            if (config && typeof config === 'object') this.initializeConfig(config);
        });
    }

    initializeConfig(config) {
        const keep = { tool: this.tool, color: this.color };
        this.setupState();
        Object.assign(this, keep);
        this.config = config;
        this.startTime = performance.now();
        this.updateUndo();

        const width = Math.max(200, Math.min(4000, Number(config.width) || 1600));
        const height = Math.max(200, Math.min(4000, Number(config.height) || 1000));
        if (!config.lineArt) {
            /* folha em branco: do tamanho da área de pintar no ecrã do jogo */
            this.whenSized().then((box) => {
                const s = box ? this.sheetSize(box.width, box.height, box) : { w: width, h: height };
                this.setSize(s.w, s.h);
                this.pushLogEntry({ state: 'STARTED', drawing: false, width: s.w, height: s.h });
            });
            return;
        }
        const image = new Image();
        image.onload = async () => {
            /* o desenho fica do tamanho que tem no ecrã do jogo (não do da imagem original): cabe inteiro na área de pintar */
            /* a folha ocupa a área de pintar toda; a imagem fica do maior tamanho que cabe nela, inteira (sem recortar), ao centro */
            const box = await this.whenSized();
            const s = box ? this.sheetSize(box.width, box.height, box) : this.sheetSize(image.naturalWidth, image.naturalHeight, null);
            this.setSize(s.w, s.h);
            const k = Math.min(s.w / image.naturalWidth, s.h / image.naturalHeight), iw = image.naturalWidth * k, ih = image.naturalHeight * k;
            this.lines.imageSmoothingQuality = 'high';
            this.lines.drawImage(image, (s.w - iw) / 2, (s.h - ih) / 2, iw, ih);
            this.buildLineMask();
            this.pushLogEntry({ state: 'STARTED', drawing: true, width: this.width, height: this.height, imageWidth: image.naturalWidth, imageHeight: image.naturalHeight });
        };
        image.onerror = () => {
            this.setSize(width, height);
            this.pushLogEntry({ state: 'IMAGE_ERROR' });
        };
        image.src = config.lineArt;
    }

    /** waits (up to 1 s) until the painting area has a size on screen */
    whenSized() {
        return new Promise((done) => {
            const t0 = performance.now();
            const look = () => {
                const r = this.sheet.getBoundingClientRect();
                if (r.width > 20 && r.height > 20) { done(r); return; }
                if (performance.now() - t0 > 1000) { done(null); return; }
                requestAnimationFrame(look);
            };
            look();
        });
    }

    /** pixel size of the sheet: the image's proportions, as big as it shows in the game (× screen density) */
    sheetSize(w, h, box) {
        const dpr = Math.min(2, window.devicePixelRatio || 1);
        let W, H;
        if (box) { const k = Math.min(box.width / w, box.height / h); W = w * k * dpr; H = h * k * dpr; }
        else { const k = Math.min(1, 1600 / Math.max(w, h)); W = w * k; H = h * k; }
        const cap = Math.min(1, 2400 / Math.max(W, H));
        return { w: Math.max(100, Math.round(W * cap)), h: Math.max(100, Math.round(H * cap)) };
    }

    /* ---------- sheet size ---------- */

    setSize(width, height) {
        this.width = width;
        this.height = height;
        [this.paintCanvas, this.lineCanvas].forEach((canvas) => {
            canvas.width = width;
            canvas.height = height;
        });
        this.paint.fillStyle = '#ffffff';
        this.paint.fillRect(0, 0, width, height);
        this.lines.clearRect(0, 0, width, height);
        this.lineMask = null;
        this.fit();
    }

    /** a barra da direita: as cores são quadrados que enchem a altura toda (6 linhas de 2) e as ferramentas têm o mesmo
        tamanho; a barra fica tão larga quanto for preciso para isso (sem passar de ~40% da largura) */
    fitBar() {
        const bar = document.querySelector('.right-toolbars'), pal = document.getElementById('palette');
        if (!bar || !pal) return;
        const ws = document.querySelector('.workspace'), wcs = ws && getComputedStyle(ws);
        const hAvail = ws ? ws.clientHeight - parseFloat(wcs.paddingTop) - parseFloat(wcs.paddingBottom) : innerHeight;
        const cs = getComputedStyle(bar), padV = parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom) + parseFloat(cs.borderTopWidth) + parseFloat(cs.borderBottomWidth);
        const gap = 6, inner = 6 + 6 + 6 + 6;                 /* padding e borda da coluna das cores (e uma folga) */
        const rows = Math.max(1, Math.ceil(pal.children.length / 2));
        let sq = (hAvail - padV - inner - (rows - 1) * gap) / rows;
        const maxW = innerWidth * 0.42;                       /* barra: 2 quadrados + ferramentas (1,1 quadrado) + espaços */
        sq = Math.max(28, Math.min(sq, (maxW - 60) / 3.1));
        bar.style.setProperty('--sq', Math.floor(sq) + 'px');
    }

    /** Fits the sheet inside the white paper, keeping its proportions. */
    fit() {
        this.fitBar();
        const box = this.sheet.getBoundingClientRect();
        if (!box.width || !box.height) return;
        const scale = Math.min(box.width / this.width, box.height / this.height);
        this.stack.style.width = Math.floor(this.width * scale) + 'px';
        this.stack.style.height = Math.floor(this.height * scale) + 'px';
    }

    buildLineMask() {
        const data = this.lines.getImageData(0, 0, this.width, this.height).data;
        const mask = new Uint8Array(this.width * this.height);
        for (let i = 0, p = 3; i < mask.length; i++, p += 4) mask[i] = data[p] > 100 ? 1 : 0;
        this.lineMask = mask;
    }

    /* ---------- tools and colours ---------- */

    selectTool(tool, button) {
        this.tool = tool;
        document.querySelectorAll('.tool-btn').forEach((element) => element.classList.toggle('active', element === button));
    }

    selectColor(color, dot) {
        this.color = color;
        document.querySelectorAll('.color-dot').forEach((element) => element.classList.toggle('active', element === dot));
        if (this.tool === 'eraser') {
            const pencil = document.querySelector('.tool-btn[data-tool="pencil"]');
            this.selectTool('pencil', pencil);
        }
    }

    /** Sizes follow the sheet, so a stroke looks the same on any screen. */
    size(tool) {
        const unit = Math.max(this.width, this.height) / 1600;
        return { pencil: 6, brush: 26, crayon: 18, spray: 34, eraser: 44 }[tool] * unit;
    }

    position(event) {
        const rect = this.paintCanvas.getBoundingClientRect();
        return {
            x: (event.clientX - rect.left) * this.width / rect.width,
            y: (event.clientY - rect.top) * this.height / rect.height
        };
    }

    /* ---------- painting ---------- */

    pointerDown(event) {
        if (this.sent) return;
        event.preventDefault();
        const point = this.position(event);
        this.saveUndo();
        this.toolsUsed.add(this.tool);
        if (this.tool !== 'eraser') this.colorsUsed.add(this.color);

        if (this.tool === 'bucket') {
            const filled = this.floodFill(Math.floor(point.x), Math.floor(point.y), this.color);
            if (filled) {
                this.counts.fills++;
                this.pushLogEntry({ state: 'FILL', color: this.color, pixels: filled });
            } else {
                this.undoStack.pop();
                this.updateUndo();
            }
            return;
        }
        try { this.paintCanvas.setPointerCapture(event.pointerId); } catch (error) { /* not needed */ }
        this.drawing = true;
        this.strokeStart = performance.now();
        this.last = point;
        this.drawSegment(point, point);
    }

    pointerMove(event) {
        if (!this.drawing) return;
        event.preventDefault();
        const events = event.getCoalescedEvents ? event.getCoalescedEvents() : [event];
        (events.length ? events : [event]).forEach((item) => {
            const point = this.position(item);
            this.drawSegment(this.last, point);
            this.last = point;
        });
    }

    pointerUp() {
        if (!this.drawing) return;
        this.drawing = false;
        this.counts.strokes++;
        this.pushLogEntry({
            state: 'STROKE',
            tool: this.tool,
            color: this.tool === 'eraser' ? null : this.color,
            duration: this.round((performance.now() - this.strokeStart) / 1000)
        });
    }

    drawSegment(from, to) {
        const ctx = this.paint;
        const width = this.size(this.tool);
        ctx.save();
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.strokeStyle = this.tool === 'eraser' ? '#ffffff' : this.color;
        ctx.fillStyle = ctx.strokeStyle;

        if (this.tool === 'spray') {
            const steps = Math.max(1, Math.ceil(Math.hypot(to.x - from.x, to.y - from.y) / (width / 3)));
            const dot = Math.max(1.5, width / 16);
            for (let s = 0; s < steps; s++) {
                const cx = from.x + (to.x - from.x) * (s / steps);
                const cy = from.y + (to.y - from.y) * (s / steps);
                for (let i = 0; i < 28; i++) {
                    const angle = Math.random() * Math.PI * 2;
                    const radius = Math.sqrt(Math.random()) * width;
                    ctx.fillRect(cx + Math.cos(angle) * radius, cy + Math.sin(angle) * radius, dot, dot);
                }
            }
        } else if (this.tool === 'crayon') {
            // waxy: several thin, slightly shifted, translucent lines
            ctx.globalAlpha = 0.35;
            for (let i = 0; i < 4; i++) {
                const jx = (Math.random() - 0.5) * width * 0.5;
                const jy = (Math.random() - 0.5) * width * 0.5;
                ctx.lineWidth = width * (0.45 + Math.random() * 0.3);
                ctx.beginPath();
                ctx.moveTo(from.x + jx, from.y + jy);
                ctx.lineTo(to.x + jx, to.y + jy);
                ctx.stroke();
            }
        } else {
            ctx.lineWidth = width;
            ctx.beginPath();
            ctx.moveTo(from.x, from.y);
            ctx.lineTo(to.x === from.x && to.y === from.y ? to.x + 0.01 : to.x, to.y);
            ctx.stroke();
        }
        ctx.restore();
    }

    /** Paint bucket: fills the area under the pointer, stopping at the drawing's lines and at other colours. */
    floodFill(x, y, color) {
        const W = this.width, H = this.height;
        if (x < 0 || y < 0 || x >= W || y >= H) return 0;
        const mask = this.lineMask;
        if (mask && mask[y * W + x]) return 0;

        const image = this.paint.getImageData(0, 0, W, H);
        const data = image.data;
        const start = (y * W + x) * 4;
        const target = [data[start], data[start + 1], data[start + 2]];
        const fill = this.hexToRgb(color);
        if (Math.abs(target[0] - fill[0]) + Math.abs(target[1] - fill[1]) + Math.abs(target[2] - fill[2]) < 6) return 0;

        const TOL = 60;
        const done = new Uint8Array(W * H);
        const inside = (i) => {
            if (done[i] || (mask && mask[i])) return false;
            const p = i * 4;
            return Math.abs(data[p] - target[0]) + Math.abs(data[p + 1] - target[1]) + Math.abs(data[p + 2] - target[2]) <= TOL;
        };
        const set = (i) => {
            const p = i * 4;
            data[p] = fill[0]; data[p + 1] = fill[1]; data[p + 2] = fill[2]; data[p + 3] = 255;
            done[i] = 1;
        };

        let count = 0;
        const stack = [x, y];
        while (stack.length) {
            const sy = stack.pop(), sx0 = stack.pop();
            let sx = sx0;
            let i = sy * W + sx;
            if (!inside(i)) continue;
            while (sx > 0 && inside(i - 1)) { sx--; i--; }
            let up = false, down = false;
            for (; sx < W && inside(i); sx++, i++) {
                set(i);
                count++;
                if (sy > 0) {
                    const a = inside(i - W);
                    if (a && !up) { stack.push(sx, sy - 1); up = true; } else if (!a) up = false;
                }
                if (sy < H - 1) {
                    const b = inside(i + W);
                    if (b && !down) { stack.push(sx, sy + 1); down = true; } else if (!b) down = false;
                }
            }
        }

        // the colour also goes under the edge of the lines, so no white rim is left next to them
        if (mask && count) {
            for (let pass = 0; pass < 3; pass++) {
                const grow = [];
                for (let yy = 1; yy < H - 1; yy++) {
                    for (let xx = 1, i = yy * W + 1; xx < W - 1; xx++, i++) {
                        if (done[i] || !mask[i]) continue;
                        if (done[i - 1] === 1 || done[i + 1] === 1 || done[i - W] === 1 || done[i + W] === 1) grow.push(i);
                    }
                }
                grow.forEach((i) => set(i));
            }
        }
        this.paint.putImageData(image, 0, 0);
        return count;
    }

    hexToRgb(hex) {
        const value = parseInt(hex.slice(1), 16);
        return [(value >> 16) & 255, (value >> 8) & 255, value & 255];
    }

    /* ---------- undo, clear ---------- */

    saveUndo() {
        this.undoStack.push(this.paint.getImageData(0, 0, this.width, this.height));
        if (this.undoStack.length > this.MAX_UNDO) this.undoStack.shift();
        this.updateUndo();
    }

    undo() {
        const image = this.undoStack.pop();
        if (!image) return;
        this.paint.putImageData(image, 0, 0);
        this.counts.undos++;
        this.pushLogEntry({ state: 'UNDO' });
        this.updateUndo();
    }

    updateUndo() {
        if (this.undoButton) this.undoButton.disabled = this.undoStack.length === 0;
    }

    clearSheet() {
        this.saveUndo();
        this.paint.fillStyle = '#ffffff';
        this.paint.fillRect(0, 0, this.width, this.height);
        this.counts.clears++;
        this.pushLogEntry({ state: 'CLEAR' });
    }

    /* ---------- print ---------- */

    /** The paint with the drawing's lines on top, as one image. */
    composite() {
        const canvas = document.createElement('canvas');
        canvas.width = this.width;
        canvas.height = this.height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(this.paintCanvas, 0, 0);
        ctx.drawImage(this.lineCanvas, 0, 0);
        return canvas;
    }

    print() {
        this.counts.prints++;
        this.pushLogEntry({ state: 'PRINT' });
        this.printImage.onload = () => {
            this.printImage.onload = null;
            setTimeout(() => window.print(), 50);
        };
        this.printImage.src = this.composite().toDataURL('image/png');
    }

    /* ---------- end ---------- */

    finish() {
        if (this.sent) return;
        this.sent = true;
        this.pushLogEntry({
            state: 'FINISHED',
            strokes: this.counts.strokes,
            fills: this.counts.fills,
            undos: this.counts.undos,
            clears: this.counts.clears,
            prints: this.counts.prints,
            colors: [...this.colorsUsed],
            tools: [...this.toolsUsed]
        });
    }

    /* ---------- logging (as in the TMT) and sending at the end ---------- */

    /** Records an event. Results go to the host only once, when ✔ is pressed (the host then moves on). */
    pushLogEntry(logEntry) {
        logEntry.positionInTime = this.elapsedSeconds();
        this.log.push(logEntry);
        if (logEntry.state === 'FINISHED') this.sendResults();
    }

    sendResults() {
        const sendData = {
            type: 'NeuroExercises',
            activity: this.activity,
            dataNE: {
                strokes: this.counts.strokes,
                fills: this.counts.fills,
                colors: this.colorsUsed.size,
                duration: this.elapsedSeconds(),
                log: this.log
            }
        };
        if (window.vuplex) {
            window.vuplex.postMessage(JSON.stringify(sendData));
        } else {
            console.log('VUPLEX bridge not available', sendData);
        }
    }

    /* ---------- utilities ---------- */

    elapsedSeconds() {
        return this.startTime === null ? 0 : this.round((performance.now() - this.startTime) / 1000);
    }

    round(value) {
        return Number.isFinite(value) ? parseFloat(value.toFixed(2)) : 0;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.paintManager = new PaintManager();
});
