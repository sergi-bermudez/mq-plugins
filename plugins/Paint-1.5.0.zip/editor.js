'use strict';

/**
 * Paint — plugin editor (MQ Plugins contract v1).
 *
 * Receives the current configuration through window.vuplex ("{}" = new screen). The user picks an image and
 * adjusts how it becomes a drawing to colour (outlines or black and white, amount of lines, smoothing,
 * line thickness, cleaning of loose dots), or builds the drawing from geometric shapes (no shapes = a blank sheet).
 * Each shape keeps the line thickness chosen when it was put on the sheet. 🗑 clears the drawing.
 * Inside MQ Creator Junior (window.MQ_HOST.junior) only the shapes are offered.
 * Shapes: each shape is stored as { t, x, y, w, h, r, lw } (lw = line thickness 0–5, fixed when the shape is put) (x, y = centre as a fraction of the sheet; w, h = size as a
 * fraction of the sheet's short side; r = degrees; older drawings with one size «s» still open), so the drawing can be edited again; the game only uses lineArt. On save it returns
 *   window.vuplex.postMessage({ type: 'PluginConfig', config, files: {} })
 * The drawing and the original go inside the JSON as data: URLs (see paint.js for why).
 * Outside MQ Creator (no window.vuplex) it downloads the JSON.
 */
class PaintEditor {
    constructor() {
        this.MAX_SIDE = 1600;        // size of the drawing in the game
        this.SOURCE_SIDE = 1200;     // size of the original kept for editing again
        this.setupState();
        this.initializeUI();
        this.initializeConfigLoading();
    }

    setupState() {
        this.source = null;          // canvas with the original, at MAX_SIDE
        this.sourceName = '';
        this.settings = { mode: 'edges', threshold: 60, detail: 1, thickness: 1, clean: 2 };
        this.orient = 'landscape';
        this.pending = false;
        this.shapes = [];            // the drawing made of geometric shapes (null while an image is used); [] = blank sheet
        this.sel = -1;
        this.shapeThickness = 2;
        this.shapeOrient = 'landscape';
        this.drag = null;
        this.poly = null;            // connected lines being drawn: { pts: [[x, y] in canvas pixels], cur }
    }

    /* Shapes drawn in a box from -50 to 50 (SVG path data, also used for the buttons). */
    static get SHAPES() {
        if (PaintEditor._shapes) return PaintEditor._shapes;
        let star = '';
        for (let i = 0; i < 10; i++) {
            const a = -Math.PI / 2 + i * Math.PI / 5, r = i % 2 ? 21 : 52;
            star += (i ? 'L' : 'M') + (Math.cos(a) * r).toFixed(1) + ' ' + (Math.sin(a) * r + 5).toFixed(1);
        }
        PaintEditor._shapes = {
            circle: { name: MQT('Círculo'), d: 'M-50 0A50 50 0 1 0 50 0A50 50 0 1 0 -50 0Z' },
            square: { name: MQT('Quadrado'), d: 'M-50 -50H50V50H-50Z' },
            triangle: { name: MQT('Triângulo'), d: 'M0 -50L52 42H-52Z' },
            rect: { name: MQT('Retângulo'), d: 'M-50 -28H50V28H-50Z' },
            oval: { name: MQT('Oval'), d: 'M-50 0A50 32 0 1 0 50 0A50 32 0 1 0 -50 0Z' },
            half: { name: MQT('Meia-lua'), d: 'M-50 22A50 50 0 0 1 50 22Z' },
            star: { name: MQT('Estrela'), d: star + 'Z' },
            heart: { name: MQT('Coração'), d: 'M0 44C-70 2 -46 -56 0 -22C46 -56 70 2 0 44Z' },
            line: { name: MQT('Linha'), d: 'M-50 0H50' }
        };
        Object.values(PaintEditor._shapes).forEach((k) => { k.path = new Path2D(k.d); });
        return PaintEditor._shapes;
    }

    /* a shape is one of SHAPES, or «poly»: connected lines drawn point by point (its own path d in the -50..50 box) */
    validShape(o) { return !!o && (o.t === 'poly' ? !!o.d : !!PaintEditor.SHAPES[o.t]); }
    basePath(o) {
        if (o.t !== 'poly') return PaintEditor.SHAPES[o.t].path;
        if (!o._path || o._pathD !== o.d) { o._path = new Path2D(o.d); o._pathD = o.d; }
        return o._path;
    }

    /* ---------- interface ---------- */

    initializeUI() {
        this.imageInput = document.getElementById('imageInput');
        this.imageName = document.getElementById('imageName');
        this.convertBox = document.getElementById('convertBox');
        this.sourceCanvas = document.getElementById('sourceCanvas');
        this.resultCanvas = document.getElementById('resultCanvas');
        this.noImage = document.getElementById('noImage');
        this.message = document.getElementById('editorMessage');
        this.thresholdLabel = document.getElementById('thresholdLabel');

        this.imageInput.addEventListener('change', () => this.onImageChosen());
        {const b = document.getElementById('clearBtn'); b.addEventListener('click', () => {
            if (!b.dataset.sure) { b.dataset.sure = '1'; b.classList.add('sure'); b.textContent = MQT('🗑 Tocar outra vez'); setTimeout(() => { delete b.dataset.sure; b.classList.remove('sure'); b.textContent = '🗑'; }, 2500); return; }
            delete b.dataset.sure; b.classList.remove('sure'); b.textContent = '🗑'; this.clearDrawing(); }); }
        document.getElementById('shapesBtn').addEventListener('click', () => this.useShapes());
        this.initializeShapesUI();
        if (window.MQ_HOST && window.MQ_HOST.junior) document.body.classList.add('junior');   // MQ Creator Junior: only shapes
        document.getElementById('saveBtn').addEventListener('click', () => this.save());
        document.getElementById('downloadBtn').addEventListener('click', () => this.downloadJSON());

        document.querySelectorAll('input[name="mode"]').forEach((input) =>
            input.addEventListener('change', () => {
                this.settings.mode = input.value;
                this.showSettings();
                this.scheduleRender();
            }));
        ['threshold', 'detail', 'thickness', 'clean'].forEach((key) => {
            const input = document.getElementById(key);
            input.addEventListener('input', () => {
                this.settings[key] = Number(input.value);
                this.showSettings();
                this.scheduleRender();
            });
        });
        this.showSettings();
        this.render();
    }

    showSettings() {
        const s = this.settings;
        document.querySelectorAll('input[name="mode"]').forEach((input) => { input.checked = input.value === s.mode; });
        ['threshold', 'detail', 'thickness', 'clean'].forEach((key) => {
            document.getElementById(key).value = s[key];
            document.getElementById(key + 'Out').textContent = s[key];
        });
        this.thresholdLabel.textContent = s.mode === 'edges' ? MQT('Quantidade de linhas') : MQT('Limiar (mais alto = mais preto)');
        const shapes = !!this.shapes;
        this.convertBox.hidden = shapes || !this.source;
        document.getElementById('shapesBox').hidden = !shapes;
        document.getElementById('sourceFigure').hidden = shapes;
        document.getElementById('resultCaption').textContent = shapes
            ? MQT('Desenho com formas (o que aparece no jogo) — arraste as formas')
            : MQT('Para colorir (o que aparece no jogo)');
        this.resultCanvas.classList.toggle('shapes', shapes);
        this.noImage.style.display = this.source ? 'none' : '';
        this.imageName.textContent = shapes ? (this.shapes.length ? MQT('Formas geométricas ({n})', { n: this.shapes.length }) : MQT('Folha em branco (ponha formas, se quiser)')) : (this.sourceName || '');
        document.getElementById('shapeThickness').value = this.shapeThickness;
        {const pb = document.getElementById('polyBtn'); if (pb) { pb.classList.toggle('on', !!this.poly); pb.querySelector('span').textContent = this.poly ? MQT('✔ Terminar') : MQT('Linhas ligadas'); } }
        // the shape buttons are drawn with the thickness the next shape will have
        document.querySelectorAll('#shapeKinds button:not(.poly) svg').forEach((g) => g.setAttribute('stroke-width', String(5 + this.shapeThickness * 3)));
        const has = shapes && this.sel >= 0 && this.sel < this.shapes.length;
        document.querySelectorAll('#shapeActions button').forEach((b) => { b.disabled = !has; });
    }

    /* ---------- geometric shapes ---------- */

    initializeShapesUI() {
        const kinds = document.getElementById('shapeKinds');
        Object.entries(PaintEditor.SHAPES).forEach(([t, k]) => {
            const b = document.createElement('button');
            b.type = 'button';
            b.title = k.name;
            b.setAttribute('aria-label', k.name);
            b.innerHTML = '<svg viewBox="-62 -62 124 124" fill="none" stroke="#2d6b4a" stroke-width="' + (5 + this.shapeThickness * 3) + '" stroke-linejoin="round" aria-hidden="true"><path d="' + k.d + '"></path></svg>';
            b.addEventListener('click', () => this.addShape(t));
            kinds.appendChild(b);
        });
        {   /* 〰 connected lines: click point after point; click the first point to close it (a closed shape is an area
               for the bucket); double click, Enter or ✔ to finish; Esc to cancel */
            const pb = document.createElement('button');
            pb.type = 'button'; pb.id = 'polyBtn'; pb.className = 'poly';
            pb.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="#2d6b4a" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 18L9 7l6 9 6-11"/><circle cx="3" cy="18" r="1.6"/><circle cx="9" cy="7" r="1.6"/><circle cx="15" cy="16" r="1.6"/><circle cx="21" cy="5" r="1.6"/></svg><span>' + MQT('Linhas ligadas') + '</span>';
            pb.addEventListener('click', () => { if (this.poly) this.finishPoly(false); else this.startPoly(); });
            kinds.appendChild(pb);
        }
        this.resultCanvas.addEventListener('dblclick', () => { if (this.poly) this.finishPoly(false); });
        document.querySelectorAll('#shapeActions button').forEach((b) =>
            b.addEventListener('click', () => this.shapeAction(b.dataset.act)));
        const thick = document.getElementById('shapeThickness');
        thick.addEventListener('input', () => { this.shapeThickness = Number(thick.value); this.showSettings(); });   // only for the next shapes

        const c = this.resultCanvas;
        c.addEventListener('pointerdown', (e) => this.shapePointerDown(e));
        c.addEventListener('pointermove', (e) => this.shapePointerMove(e));
        const end = () => { if (this.drag) { this.drag = null; c.classList.remove('dragging'); this.scheduleRender(); } };
        c.addEventListener('pointerup', end);
        c.addEventListener('pointercancel', end);
        c.addEventListener('wheel', (e) => {
            if (!this.shapes || this.sel < 0) return;
            e.preventDefault();
            this.resize(e.deltaY < 0 ? 1.08 : 1 / 1.08);
        }, { passive: false });
        document.addEventListener('keydown', (e) => {
            if (this.poly && !/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) {
                if (e.key === 'Enter') { e.preventDefault(); this.finishPoly(false); }
                if (e.key === 'Escape') { e.preventDefault(); this.poly = null; this.showSettings(); this.render(); this.showMessage(''); }
                if (e.key === 'Backspace' || e.key === 'Delete') { e.preventDefault(); this.poly.pts.pop(); this.scheduleRender(); }
                return;
            }
            if (!this.shapes || this.sel < 0 || /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) return;
            const o = this.shapes[this.sel], step = e.shiftKey ? 0.05 : 0.01;
            const keys = {
                Delete: () => this.shapeAction('delete'), Backspace: () => this.shapeAction('delete'),
                ArrowLeft: () => { o.x = Math.max(0, o.x - step); }, ArrowRight: () => { o.x = Math.min(1, o.x + step); },
                ArrowUp: () => { o.y = Math.max(0, o.y - step); }, ArrowDown: () => { o.y = Math.min(1, o.y + step); },
                '+': () => this.resize(1.08), '-': () => this.resize(1 / 1.08), r: () => this.shapeAction('rotate')
            };
            if (!keys[e.key]) return;
            e.preventDefault();
            keys[e.key]();
            this.scheduleRender();
        });
    }

    useShapes() {
        this.source = null;
        this.sourceName = '';
        if (!this.shapes) this.shapes = [];
        this.sel = this.shapes.length - 1;
        this.showSettings();
        this.render();
        this.showMessage(this.shapes.length ? '' : MQT('Toque numa forma para começar o desenho.'));
    }

    shapeSize() { return this.shapeOrient === 'portrait' ? [1000, 1600] : [1600, 1000]; }

    addShape(t) {
        const n = this.shapes.length;
        this.shapes.push({ t, x: 0.5 + ((n % 5) - 2) * 0.13, y: 0.5 + ((n % 3) - 1) * 0.16, w: t === 'line' ? 0.4 : 0.3, h: t === 'line' ? 0.04 : 0.3, r: 0, lw: this.shapeThickness });
        this.sel = this.shapes.length - 1;
        this.showMessage('');
        this.showSettings();
        this.render();
    }

    resize(f) {
        const o = this.shapes[this.sel];
        if (!o) return;
        const g = Math.max(0.03 / Math.min(o.w, o.h), Math.min(f, 1.4 / Math.max(o.w, o.h)));
        o.w *= g; o.h *= g;
        this.scheduleRender();
    }

    shapeAction(act) {
        const l = this.shapes, i = this.sel, o = l && l[i];
        if (!o) return;
        if (act === 'bigger') this.resize(1.15);
        if (act === 'smaller') this.resize(1 / 1.15);
        if (act === 'rotate') o.r = ((o.r + 15) % 360 + 360) % 360;
        if (act === 'copy') { l.push(Object.assign({}, o, { x: Math.min(1, o.x + 0.05), y: Math.min(1, o.y + 0.05) })); this.sel = l.length - 1; }
        if (act === 'front') { l.push(l.splice(i, 1)[0]); this.sel = l.length - 1; }
        if (act === 'delete') { l.splice(i, 1); this.sel = -1; }
        this.showSettings();
        this.render();
    }

    /* Geometry of a shape in canvas pixels: centre, width, height (of its -50..50 box), angle in radians. */
    shapeBox(o) {
        const [W, H] = this.shapeSize(), m = Math.min(W, H);
        return { cx: o.x * W, cy: o.y * H, w: o.w * m, h: o.h * m, a: o.r * Math.PI / 180 };
    }

    /* The shape's outline already placed on the sheet (so the line keeps its thickness when stretched). */
    shapePath(o) {
        const b = this.shapeBox(o);
        const m = new DOMMatrix().translate(b.cx, b.cy).rotate(o.r).scale(b.w / 100, b.h / 100);
        const p = new Path2D();
        p.addPath(this.basePath(o), m);
        return p;
    }

    /* point → coordinates in the shape's own (rotated) frame, origin at its centre */
    toLocal(b, p) {
        const dx = p.x - b.cx, dy = p.y - b.cy, c = Math.cos(-b.a), s = Math.sin(-b.a);
        return { x: dx * c - dy * s, y: dx * s + dy * c };
    }

    toWorld(b, l) {
        const c = Math.cos(b.a), s = Math.sin(b.a);
        return { x: b.cx + l.x * c - l.y * s, y: b.cy + l.x * s + l.y * c };
    }

    /* canvas pixels per screen pixel (handles keep the same size on screen) */
    pixelScale() {
        const r = this.resultCanvas.getBoundingClientRect();
        return r.width ? this.resultCanvas.width / r.width : 1;
    }

    /* Handles of the selected shape, like PowerPoint: 4 corners, 4 sides and the round arrow above for rotating. */
    handles(o) {
        const b = this.shapeBox(o), f = this.pixelScale(), hw = b.w / 2, hh = b.h / 2;
        const list = [];
        [-1, 0, 1].forEach((hy) => [-1, 0, 1].forEach((hx) => {
            if (hx || hy) list.push({ hx, hy, ...this.toWorld(b, { x: hx * hw, y: hy * hh }) });
        }));
        list.push({ rot: true, ...this.toWorld(b, { x: 0, y: -hh - 34 * f }) });
        return list;
    }

    canvasPoint(e) {
        const r = this.resultCanvas.getBoundingClientRect();
        return { x: (e.clientX - r.left) / r.width * this.resultCanvas.width, y: (e.clientY - r.top) / r.height * this.resultCanvas.height };
    }

    hitHandle(p) {
        const o = this.shapes && this.shapes[this.sel];
        if (!o) return null;
        const f = this.pixelScale(), R = 13 * f;
        return this.handles(o).find((h) => Math.hypot(h.x - p.x, h.y - p.y) <= R) || null;
    }

    hitShape(p) {
        const ctx = this.resultCanvas.getContext('2d'), f = this.pixelScale();
        ctx.save();
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.lineWidth = 24 * f;              // generous margin around the line (fingers)
        let hit = -1;
        for (let i = this.shapes.length - 1; i >= 0 && hit < 0; i--) {
            const path = this.shapePath(this.shapes[i]);
            if (ctx.isPointInPath(path, p.x, p.y) || ctx.isPointInStroke(path, p.x, p.y)) hit = i;
        }
        ctx.restore();
        return hit;
    }

    cursorFor(h, o) {
        if (!h) return '';
        if (h.rot) return 'crosshair';
        const deg = ((Math.atan2(h.hy, h.hx) * 180 / Math.PI + o.r) % 180 + 180) % 180;
        return ['ew-resize', 'nwse-resize', 'ns-resize', 'nesw-resize'][Math.round(deg / 45) % 4];
    }

    startPoly() {
        if (!this.shapes) this.useShapes();
        this.poly = { pts: [], cur: null };
        this.sel = -1;
        this.showSettings();
        this.render();
        this.showMessage(MQT('Clique na folha para pôr os pontos. Clique no primeiro ponto para fechar; duplo clique, Enter ou ✔ para acabar.'));
    }

    /** ends the connected lines and turns them into one shape (closed = a closed figure, an area for the bucket) */
    finishPoly(closed) {
        const P = this.poly;
        this.poly = null;
        this.showMessage('');
        if (P) {
            const pts = [];
            P.pts.forEach((q) => { const l = pts[pts.length - 1]; if (!l || Math.hypot(l[0] - q[0], l[1] - q[1]) > 3) pts.push(q); });
            if (pts.length >= 2) {
                const [W, H] = this.shapeSize(), m = Math.min(W, H);
                const xs = pts.map((q) => q[0]), ys = pts.map((q) => q[1]);
                const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
                const bw = Math.max(1, x1 - x0), bh = Math.max(1, y1 - y0), cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
                const f = (v) => Math.round(v * 100) / 100;
                const d = pts.map((q, i) => (i ? 'L' : 'M') + f((q[0] - cx) / bw * 100) + ' ' + f((q[1] - cy) / bh * 100)).join('') + (closed ? 'Z' : '');
                this.shapes.push({ t: 'poly', d, closed: !!closed, x: cx / W, y: cy / H, w: bw / m, h: bh / m, r: 0, lw: this.shapeThickness });
                this.sel = this.shapes.length - 1;
            }
        }
        this.showSettings();
        this.render();
    }

    shapePointerDown(e) {
        if (!this.shapes) return;
        const p = this.canvasPoint(e), [W, H] = this.shapeSize();
        if (this.poly) {                                 // drawing connected lines: each click is a point
            const P = this.poly.pts, f0 = P[0];
            if (f0 && P.length >= 3 && Math.hypot(p.x - f0[0], p.y - f0[1]) <= 16 * this.pixelScale()) { this.finishPoly(true); return; }
            P.push([p.x, p.y]);
            this.scheduleRender();
            return;
        }
        const h = this.hitHandle(p);
        if (h) {
            const o = this.shapes[this.sel], b = this.shapeBox(o);
            this.drag = h.rot
                ? { kind: 'rotate' }
                : { kind: 'resize', hx: h.hx, hy: h.hy, w0: b.w, h0: b.h, anchor: this.toWorld(b, { x: -h.hx * b.w / 2, y: -h.hy * b.h / 2 }) };
        } else {
            const i = this.hitShape(p);
            this.sel = i;
            if (i >= 0) {
                const o = this.shapes[i];
                this.drag = { kind: 'move', dx: p.x - o.x * W, dy: p.y - o.y * H };
            }
        }
        if (this.drag) {
            try { this.resultCanvas.setPointerCapture(e.pointerId); } catch (_) { /* old browsers */ }
            this.resultCanvas.classList.add('dragging');
        }
        this.showSettings();
        this.render();
    }

    shapePointerMove(e) {
        const p = this.canvasPoint(e);
        if (this.poly) { this.poly.cur = [p.x, p.y]; this.resultCanvas.style.cursor = 'crosshair'; this.scheduleRender(); return; }
        if (!this.drag) {                        // hover: the right cursor over the handles
            const o = this.shapes && this.shapes[this.sel];
            this.resultCanvas.style.cursor = o ? this.cursorFor(this.hitHandle(p), o) : '';
            return;
        }
        const o = this.shapes[this.sel];
        if (!o) return;
        const [W, H] = this.shapeSize(), m = Math.min(W, H), d = this.drag;
        if (d.kind === 'move') {
            o.x = Math.max(0, Math.min(1, (p.x - d.dx) / W));
            o.y = Math.max(0, Math.min(1, (p.y - d.dy) / H));
        } else if (d.kind === 'rotate') {
            const b = this.shapeBox(o);
            let deg = Math.atan2(p.y - b.cy, p.x - b.cx) * 180 / Math.PI + 90;
            deg = e.shiftKey ? Math.round(deg / 15) * 15 : deg;
            for (const snap of [0, 90, 180, 270, 360]) if (Math.abs(deg - snap) < 4 || Math.abs(deg + 360 - snap) < 4) deg = snap;
            o.r = Math.round(((deg % 360) + 360) % 360);
        } else {
            // the opposite corner / side stays where it is (PowerPoint); corners with Shift keep the proportions
            const b = this.shapeBox(o), min = 0.03 * m;
            const v = this.toLocal({ cx: d.anchor.x, cy: d.anchor.y, a: b.a }, p);
            let nw = d.hx ? Math.max(min, d.hx * v.x) : d.w0;
            let nh = d.hy ? Math.max(min, d.hy * v.y) : d.h0;
            if (e.shiftKey && d.hx && d.hy) {
                const k = Math.max(nw / d.w0, nh / d.h0);
                nw = d.w0 * k; nh = d.h0 * k;
            }
            const c = this.toWorld({ cx: d.anchor.x, cy: d.anchor.y, a: b.a }, { x: d.hx * nw / 2, y: d.hy * nh / 2 });
            o.w = nw / m; o.h = nh / m;
            o.x = c.x / W; o.y = c.y / H;
        }
        this.scheduleRender();
    }

    /** Shapes → black lines on transparent (hard edges, like the converted images, so the bucket stops at them). */
    drawShapes() {
        const [W, H] = this.shapeSize();
        const out = document.createElement('canvas');
        out.width = W; out.height = H;
        const ctx = out.getContext('2d');
        ctx.lineJoin = 'round';
        ctx.strokeStyle = '#111111';
        this.shapes.forEach((o) => {
            if (!this.validShape(o)) return;
            ctx.lineWidth = 3 + (o.lw != null ? o.lw : this.shapeThickness) * 3;
            ctx.stroke(this.shapePath(o));
        });
        const img = ctx.getImageData(0, 0, W, H), d = img.data;
        for (let p = 0; p < d.length; p += 4) {
            const on = d[p + 3] >= 110;
            d[p] = d[p + 1] = d[p + 2] = 17;
            d[p + 3] = on ? 255 : 0;
        }
        ctx.putImageData(img, 0, 0);
        return out;
    }

    renderShapes() {
        const [W, H] = this.shapeSize();
        this.lineArt = this.drawShapes();
        const c = this.resultCanvas, ctx = c.getContext('2d');
        if (c.width !== W || c.height !== H) { c.width = W; c.height = H; }
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, W, H);
        ctx.drawImage(this.lineArt, 0, 0);
        if (this.poly) {                                 // connected lines being drawn
            const P = this.poly.pts, f = this.pixelScale();
            ctx.save();
            ctx.lineJoin = 'round'; ctx.lineCap = 'round';
            ctx.strokeStyle = '#111111'; ctx.lineWidth = 3 + this.shapeThickness * 3;
            if (P.length) { ctx.beginPath(); P.forEach((q, i) => (i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]))); ctx.stroke(); }
            if (P.length && this.poly.cur) {
                ctx.setLineDash([10 * f, 8 * f]); ctx.strokeStyle = '#8b5cf6'; ctx.lineWidth = 2 * f;
                ctx.beginPath(); ctx.moveTo(P[P.length - 1][0], P[P.length - 1][1]); ctx.lineTo(this.poly.cur[0], this.poly.cur[1]); ctx.stroke();
                ctx.setLineDash([]);
            }
            if (P.length >= 3) { ctx.fillStyle = '#ffffff'; ctx.strokeStyle = '#8b5cf6'; ctx.lineWidth = 3 * f; ctx.beginPath(); ctx.arc(P[0][0], P[0][1], 9 * f, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); }
            ctx.restore();
            this.fitPreviews();
            return;
        }
        const o = this.shapes[this.sel];
        if (this.validShape(o)) {           // selection frame and handles: only in the editor
            const b = this.shapeBox(o), f = this.pixelScale(), hs = this.handles(o);
            ctx.save();
            ctx.translate(b.cx, b.cy);
            ctx.rotate(b.a);
            ctx.strokeStyle = '#8b5cf6';
            ctx.lineWidth = 1.5 * f;
            ctx.setLineDash([6 * f, 4 * f]);
            ctx.strokeRect(-b.w / 2, -b.h / 2, b.w, b.h);
            ctx.setLineDash([]);
            ctx.beginPath();
            ctx.moveTo(0, -b.h / 2);
            ctx.lineTo(0, -b.h / 2 - 34 * f);
            ctx.stroke();
            ctx.restore();
            ctx.lineWidth = 2 * f;
            hs.forEach((h) => {
                ctx.beginPath();
                ctx.fillStyle = '#ffffff';
                ctx.strokeStyle = '#8b5cf6';
                if (h.rot) {
                    ctx.arc(h.x, h.y, 9 * f, 0, Math.PI * 2);
                    ctx.fill(); ctx.stroke();
                    ctx.beginPath();                           // round arrow inside
                    ctx.arc(h.x, h.y, 4.5 * f, -Math.PI * 0.9, Math.PI * 0.55);
                    ctx.stroke();
                } else {
                    ctx.arc(h.x, h.y, (h.hx && h.hy ? 6.5 : 5.5) * f, 0, Math.PI * 2);
                    ctx.fill(); ctx.stroke();
                }
            });
        }
        this.fitPreviews();
    }

    showMessage(text, isError = false) {
        this.message.textContent = text;
        this.message.classList.toggle('error', isError);
    }

    /* ---------- receiving the configuration (Vuplex) ---------- */

    initializeConfigLoading() {
        this.setupHostPicker();
        if (window.vuplex) {
            this.registerMessageReceiver();
        } else {
            window.addEventListener('vuplexready', () => this.registerMessageReceiver());
        }
    }

    registerMessageReceiver() {
        window.vuplex.addEventListener('message', (event) => {
            if (window.MQHost && MQHost.handle(event.data)) return;     /* answers of the host services */
            let config;
            try {
                config = typeof event.data === 'string' ? JSON.parse(event.data || '{}') : (event.data || {});
            } catch (error) {
                this.showMessage(MQT('O JSON recebido não é válido.'), true);
                return;
            }
            this.loadConfig(config || {});
        });
    }

    loadConfig(config) {
        this.setupState();
        ['mode', 'threshold', 'detail', 'thickness', 'clean'].forEach((key) => {
            if (config[key] !== undefined) this.settings[key] = key === 'mode' ? String(config[key]) : Number(config[key]);
        });
        if (Array.isArray(config.shapes)) {
            const K = PaintEditor.SHAPES;
            this.shapes = config.shapes.filter((o) => o && (K[o.t] || (o.t === 'poly' && o.d))).map((o) => ({
                t: o.t, d: o.t === 'poly' ? String(o.d) : undefined, closed: o.t === 'poly' ? !!o.closed : undefined, x: Number(o.x) || 0.5, y: Number(o.y) || 0.5,
                w: Number(o.w || o.s) || 0.3, h: Number(o.h || o.s) || 0.3, r: Number(o.r) || 0,
                lw: o.lw != null ? Number(o.lw) : (config.thickness !== undefined ? Number(config.thickness) : 2)
            }));
            this.shapeOrient = Number(config.height) > Number(config.width) ? 'portrait' : 'landscape';
            this.sel = -1;
            this.showSettings();
            this.render();
        } else if (config.source) {
            this.sourceName = config.sourceName || 'imagem';
            this.loadImage(config.source, this.sourceName);
        } else {
            // a blank sheet (older versions) or a new screen: the shapes mode with no shapes is a blank sheet
            this.shapes = [];
            this.sel = -1;
            this.shapeOrient = config.width && Number(config.height) > Number(config.width) ? 'portrait' : 'landscape';
            this.showSettings();
            this.render();
        }
    }

    /* ---------- image ---------- */

    /* one button: in MQ Creator it opens the creator's picker (file, clipart, internet, 3D model, camera — contract
       service PickImage); elsewhere it opens the file chooser */
    setupHostPicker() {
        const b = document.getElementById('pickBtn');
        if (!b) return;
        b.onclick = async () => {
            if (!(window.MQHost && MQHost.has('PickImage'))) { this.imageInput.click(); return; }
            const r = await MQHost.pickImage({ max: this.MAX_SIDE, png: true });
            if (r && r.img) this.loadImage(r.img, r.name || 'imagem');
        };
    }

    onImageChosen() {
        const file = this.imageInput.files[0];
        if (!file) return;
        const url = URL.createObjectURL(file);
        this.loadImage(url, file.name, () => URL.revokeObjectURL(url));
        this.imageInput.value = '';
    }

    loadImage(src, name, done) {
        const image = new Image();
        image.onload = () => {
            const scale = Math.min(1, this.MAX_SIDE / Math.max(image.naturalWidth, image.naturalHeight));
            const canvas = document.createElement('canvas');
            canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
            canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
            const ctx = canvas.getContext('2d');
            ctx.fillStyle = '#ffffff';                 // transparent images: white behind
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
            this.source = canvas;
            this.sourceName = name;
                this.shapes = null;
            this.showSettings();
            this.render();
            this.showMessage('');
            if (done) done();
        };
        image.onerror = () => {
            this.showMessage(MQT('Não foi possível abrir esta imagem.'), true);
            if (done) done();
        };
        image.src = src;
    }

    /** 🗑 clears the drawing: no image and no shapes (a blank sheet, to which shapes can be added). */
    clearDrawing() {
        this.poly = null;
        this.source = null;
        this.sourceName = '';
        this.shapes = [];
        this.sel = -1;
        this.showSettings();
        this.render();
        this.showMessage(MQT('Desenho apagado: a folha está em branco.'));
    }

    /* ---------- conversion ---------- */

    scheduleRender() {
        if (this.pending) return;
        this.pending = true;
        requestAnimationFrame(() => {
            this.pending = false;
            this.render();
        });
    }

    render() {
        if (this.shapes) { this.renderShapes(); return; }
        const sourceCtx = this.sourceCanvas.getContext('2d');
        const resultCtx = this.resultCanvas.getContext('2d');
        if (!this.source) {
            const [w, h] = this.orient === 'portrait' ? [1000, 1600] : [1600, 1000];
            this.sourceCanvas.width = 1; this.sourceCanvas.height = 1;
            this.resultCanvas.width = w; this.resultCanvas.height = h;
            resultCtx.fillStyle = '#ffffff';
            resultCtx.fillRect(0, 0, w, h);
            this.lineArt = null;
            this.fitPreviews();
            return;
        }
        const { width, height } = this.source;
        this.sourceCanvas.width = width; this.sourceCanvas.height = height;
        sourceCtx.drawImage(this.source, 0, 0);

        this.lineArt = this.convert(this.source);
        this.resultCanvas.width = width; this.resultCanvas.height = height;
        resultCtx.fillStyle = '#ffffff';
        resultCtx.fillRect(0, 0, width, height);
        resultCtx.drawImage(this.lineArt, 0, 0);
        this.fitPreviews();
    }

    fitPreviews() {
        [this.sourceCanvas, this.resultCanvas].forEach((canvas) => {
            canvas.style.width = '';
            canvas.style.height = '';
        });
    }

    /** Image → black lines on transparent, with the current settings. */
    convert(source) {
        const W = source.width, H = source.height, N = W * H;
        const pixels = source.getContext('2d').getImageData(0, 0, W, H).data;
        let gray = new Float32Array(N);
        for (let i = 0, p = 0; i < N; i++, p += 4) gray[i] = 0.299 * pixels[p] + 0.587 * pixels[p + 1] + 0.114 * pixels[p + 2];

        const s = this.settings;
        for (let pass = 0; pass < s.detail; pass++) gray = this.boxBlur(gray, W, H, 1 + pass);

        let line = new Uint8Array(N);
        if (s.mode === 'bw') {
            const cut = s.threshold * 2.55;
            for (let i = 0; i < N; i++) line[i] = gray[i] < cut ? 1 : 0;
        } else {
            // outlines: where a pixel is darker than its surroundings (difference of two blurs), which gives single
            // lines like a drawing; the slider sets how much of the picture becomes line, so it works for any photo
            const near = this.boxBlur(gray, W, H, 1);
            const far = this.boxBlur(this.boxBlur(gray, W, H, 4), W, H, 4);
            const diff = new Float32Array(N);
            const BINS = 1024, hist = new Uint32Array(BINS);
            for (let i = 0; i < N; i++) {
                const d = far[i] - near[i];
                diff[i] = d;
                if (d > 0) hist[Math.min(BINS - 1, Math.floor(d * 8))]++;
            }
            const share = 0.003 * Math.exp(s.threshold * 0.04);      // 0 → 0.3 %, 60 → 3.3 %, 100 → 16 % of the picture
            let want = share * N, bin = BINS - 1;
            for (; bin > 0 && want > 0; bin--) want -= hist[bin];
            const cut = Math.max(1.5, (bin + 1) / 8);                // never lines from noise on flat areas
            for (let i = 0; i < N; i++) line[i] = diff[i] > cut ? 1 : 0;
        }

        if (s.clean > 0) line = this.removeSpecks(line, W, H, s.clean * s.clean * 6);
        for (let pass = 0; pass < s.thickness; pass++) line = this.dilate(line, W, H);

        const out = document.createElement('canvas');
        out.width = W; out.height = H;
        const ctx = out.getContext('2d');
        const image = ctx.createImageData(W, H);
        for (let i = 0, p = 0; i < N; i++, p += 4) {
            if (!line[i]) continue;
            image.data[p] = 17; image.data[p + 1] = 17; image.data[p + 2] = 17; image.data[p + 3] = 255;
        }
        ctx.putImageData(image, 0, 0);
        return out;
    }

    boxBlur(src, W, H, r) {
        const tmp = new Float32Array(W * H), dst = new Float32Array(W * H);
        for (let y = 0; y < H; y++) {
            let acc = 0;
            const row = y * W;
            for (let x = -r; x <= r; x++) acc += src[row + Math.min(W - 1, Math.max(0, x))];
            for (let x = 0; x < W; x++) {
                tmp[row + x] = acc / (2 * r + 1);
                acc += src[row + Math.min(W - 1, x + r + 1)] - src[row + Math.max(0, x - r)];
            }
        }
        for (let x = 0; x < W; x++) {
            let acc = 0;
            for (let y = -r; y <= r; y++) acc += tmp[Math.min(H - 1, Math.max(0, y)) * W + x];
            for (let y = 0; y < H; y++) {
                dst[y * W + x] = acc / (2 * r + 1);
                acc += tmp[Math.min(H - 1, y + r + 1) * W + x] - tmp[Math.max(0, y - r) * W + x];
            }
        }
        return dst;
    }

    dilate(src, W, H) {
        const dst = new Uint8Array(W * H);
        for (let y = 0; y < H; y++) {
            for (let x = 0, i = y * W; x < W; x++, i++) {
                if (src[i] || (x > 0 && src[i - 1]) || (x < W - 1 && src[i + 1]) || (y > 0 && src[i - W]) || (y < H - 1 && src[i + W])) dst[i] = 1;
            }
        }
        return dst;
    }

    /** Removes groups of line pixels smaller than minSize (dust that would be hard to colour around). */
    removeSpecks(src, W, H, minSize) {
        const seen = new Uint8Array(W * H);
        const out = src.slice();
        const queue = new Int32Array(W * H);
        for (let start = 0; start < W * H; start++) {
            if (!src[start] || seen[start]) continue;
            let head = 0, tail = 0;
            queue[tail++] = start;
            seen[start] = 1;
            while (head < tail) {
                const i = queue[head++];
                const x = i % W;
                const next = [x > 0 ? i - 1 : -1, x < W - 1 ? i + 1 : -1, i - W, i + W];
                for (const j of next) {
                    if (j < 0 || j >= W * H || seen[j] || !src[j]) continue;
                    seen[j] = 1;
                    queue[tail++] = j;
                }
            }
            if (tail < minSize) for (let k = 0; k < tail; k++) out[queue[k]] = 0;
        }
        return out;
    }

    /* ---------- saving ---------- */

    buildConfig() {
        const s = this.settings;
        if (this.shapes) {
            const [width, height] = this.shapeSize();
            const r = (v) => Math.round(v * 10000) / 10000;
            return {
                lineArt: this.shapes.length ? this.drawShapes().toDataURL('image/png') : '',   // no shapes: a blank sheet
                width, height,
                thickness: this.shapeThickness,
                shapes: this.shapes.map((o) => Object.assign({ t: o.t, x: r(o.x), y: r(o.y), w: r(o.w), h: r(o.h), r: o.r, lw: o.lw }, o.t === 'poly' ? { d: o.d, closed: !!o.closed } : {})),
                sourceName: 'Formas'
            };
        }
        if (!this.source) {
            const [width, height] = this.orient === 'portrait' ? [1000, 1600] : [1600, 1000];
            return { lineArt: '', width, height };
        }
        const keep = document.createElement('canvas');
        const scale = Math.min(1, this.SOURCE_SIDE / Math.max(this.source.width, this.source.height));
        keep.width = Math.round(this.source.width * scale);
        keep.height = Math.round(this.source.height * scale);
        keep.getContext('2d').drawImage(this.source, 0, 0, keep.width, keep.height);
        return {
            lineArt: this.lineArt.toDataURL('image/png'),
            width: this.source.width,
            height: this.source.height,
            mode: s.mode,
            threshold: s.threshold,
            detail: s.detail,
            thickness: s.thickness,
            clean: s.clean,
            source: keep.toDataURL('image/jpeg', 0.85),
            sourceName: (this.sourceName || '').replace(/\.[^.]+$/, '')   // without extension: it is a label, not a file
        };
    }

    save() {
        if (!this.source && !this.shapes) {
            this.showMessage(MQT('Escolha uma imagem ou «Formas geométricas».'), true);
            return;
        }
        const config = this.buildConfig();
        if (window.vuplex) {
            window.vuplex.postMessage({ type: 'PluginConfig', config, files: {} });
            this.showMessage(MQT('Guardado.'));
        } else {
            this.downloadJSON();
        }
    }

    downloadJSON() {
        const config = this.buildConfig();
        const blob = new Blob([JSON.stringify(config)], { type: 'application/json' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = ((this.sourceName || 'desenho').replace(/\.[^.]+$/, '').replace(/[\\/:*?"<>|]+/g, '_') || 'desenho') + '.json';
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(link.href), 1000);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.paintEditor = new PaintEditor();
});
